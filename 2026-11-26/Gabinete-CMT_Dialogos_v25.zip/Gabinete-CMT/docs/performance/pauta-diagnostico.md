# Diagnóstico de lentidão da Pauta

## Resultado

A lentidão foi reproduzida no editor real, com dados sintéticos e APIs exclusivamente locais. O problema não depende de uma resposta lenta do banco: mesmo sem rede externa, selecionar um processo e atualizar o Prontuário produz tarefas longas de vários segundos.

O diagnóstico inicial foi somente de leitura. Depois da aprovação do usuário, as correções abaixo foram aplicadas ao código, sem alterar permissões nem dados compartilhados.

## Correções aplicadas após aprovação

- Prontuário inicia minimizado; quando fechado não monta nem mede seu conteúdo.
- Atualizações com o mesmo processo e dados não alteram o DOM do editor. As mutações do próprio Prontuário e da lista R3 não disparam o decorador da tabela antiga.
- Cabeçalho compacto único com identificação do processo, ações nativas e controle de recolher, sem mover ou clonar os controles.
- Lista R3 paginada em 25 cartões, com navegação ao processo em outras páginas. Filtros e seleção em lote continuam abrangendo o conjunto completo.
- Um único cartão aberto, inclusive ao restaurar estado antigo e ao usar a busca rápida.
- Notificações corrige a referência de inserção das abas e a variável de janela indefinida, integra o feed nativo ao painel único e mantém somente o lançador acima de Meu dia.
- Regras de posicionamento e empilhamento impedem que o painel fique atrás da barra esquerda ou que apareça o painel nativo antigo por baixo.

No cenário amplo de 300 processos, a maior tarefa de abertura do cartão passou de **8507 ms para 524 ms**, e os elementos conectados ao final passaram de **41.153 para 15.961**. As execuções têm sobrecarga de profiling e a inicialização agora é minimizada por solicitação do usuário; não se trata de comparação com todos os painéis abertos nas duas versões.

As verificações funcionais passaram em 1440 e 900 px: minimizar inicialmente, abrir primeiro/último, cartão único, paginação, campo digitado preservado ao trocar de página, seleção em lote preservada, atualizações sem mutações no Prontuário, botão único e alternância Notificações/Pendências.

**Limite remanescente:** ainda existem tarefas acima de 200 ms, chegando aproximadamente a 0,9–1,3 s em algumas interações do cenário amplo com 300 processos/notificações. A melhoria é relevante, mas não significa ausência de qualquer atraso.

## Método e limites

- Chromium headless, sem limitação artificial de CPU, em execuções sequenciais.
- Mesma preparação do documento usada na entrega: adaptador de diálogos, extração de dados e módulos de funcionalidades.
- Identidade sintética no bootstrap do editor; hidratação por `restoreSnapshot` e `renderShell`, como no hospedeiro real.
- Editor isolado em hostname de teste mapeado para loopback. A prévia especial de localhost permanece desativada.
- Todas as APIs respondidas pelo servidor de fixture; URLs HTTPS externas bloqueadas. As execuções preservadas fizeram somente GETs contra a fixture.
- CPU sampling, trace de timeline, Long Tasks e captura de tela. O diagnóstico que força layout entre callbacks ficou **desativado** nas medidas comparadas.
- Dados de 30 e 300 processos; viewports de 1440×1000 e 900×1000.
- Rolagem por eventos de roda do navegador sobre a posição medida da lista visível; abertura pelo botão da lista R3, não pela tabela antiga oculta.
- Os tempos incluem sobrecarga de profiling e variam com a máquina. Não representam promessa de latência no navegador do usuário.
- Não foi medida a sessão real autenticada do usuário, a camada React hospedeira, o banco ou a produção. A captura da prévia real mostrou somente o login, mantendo a autenticação intacta.

## Medições

Maior tarefa contínua no thread principal durante cada ação, em milissegundos. São tarefas acima de 50 ms observadas pelo navegador, **não** o tempo total da fase, que contém esperas deliberadas.

| Cenário | Rolar lista | Abrir primeiro cartão | Alternar Prontuário | Abrir Notificações | Recolher cartão | Ir ao último |
|---|---:|---:|---:|---:|---:|---:|
| 30 processos, 1440 px | 0 acima de 50 ms | 1089 | 407 | 219 + erro | 483 | 701 |
| 300 processos, 1440 px | 530 | 8507 | 2006 | 3403 + erro | não medido nessa execução | 1722 |
| 300 processos, 900 px | 198 | 2356 | 1891 | 214 + erro | 660 | 724 |

O cenário de 900 px confirmou rolagem efetiva, primeiro processo aberto, fechamento, último processo aberto e no máximo um cartão aberto nas fases verificadas. O caminho de Notificações falhou em todos os cenários.

## Causas atribuídas

### 1. Recálculos de estilo forçados pelo Prontuário

O perfil liga o getter nativo `getPropertyValue` à cadeia `AltPauta.run → QP.paint`, que consulta `getComputedStyle(g).getPropertyValue('--cmt-state')` depois de sincronizar classes, atributos e estrutura do painel. Também aparecem leituras de geometria em `fit`, `profileDock` e `sync`.

A inspeção do código confirma a mistura de escritas no DOM com leituras de estilo/geometria. O custo elevado não é apenas de gerar texto: leitores síncronos obrigam o navegador a processar estilos pendentes da árvore extensa.

Experimento de atribuição, **somente na fixture**: desativar `QP.paint` reduziu a maior tarefa da abertura do cartão de 8507 para 3193 ms. O ciclo do Prontuário participa materialmente do problema, mas não é a única causa. O salto ao último item piorou nessa variante, portanto **não se recomenda aplicar essa desativação ao app** nem extrapolar uma porcentagem de ganho global.

### 2. A lista visível não está virtualizada

`renderList` percorre a lista inteira e monta um `.proc` para cada item. Com 300 processos, as fases registraram **300 cartões R3**, além de cerca de 19–20 grupos da tabela antiga oculta. Ao final da execução ampla havia **41.153 elementos conectados ao documento**; com 30 processos, 21.579.

A virtualização da tabela antiga não limita a quantidade de cartões da lista R3. Isso aumenta a árvore envolvida em seletores, mutações e recálculos. A estrutura antiga ainda é usada como ponte pelo Prontuário e não deve ser simplesmente excluída.

### 3. Erro independente na montagem de Notificações

`ensureCenterPanelViews` procura o botão de fechar com uma consulta descendente e o usa como referência em `head.insertBefore(tabs, close)`. Na estrutura atual esse botão não é filho direto de `head`, e o navegador lança:

> NotFoundError: The node before which the new node is to be inserted is not a child of this node.

Isso impede a abertura normal das abas e precisa ser corrigido separadamente do desempenho.

## Direção definida no diagnóstico inicial

1. **Prontuário:** evitar escritas e reconstruções quando processo/estado não mudaram; separar leituras das escritas, coalescer atualizações e não medir painel fechado. Preservar editores reais, rascunhos, foco e o Gerador.
2. **Lista R3:** virtualizar ou paginar a lista efetivamente visível, mantendo seleção, campos em edição, item em foco, navegação ao primeiro/último e ponte com o formulário nativo.
3. **Notificações:** tornar a inserção das abas independente da posição aninhada do botão de fechar e verificar a montagem no painel esquerdo atual.

Depois, repetir os mesmos perfis com a mesma fixture. Contagens brutas de timers/observers não servem como critério de sucesso.

## Reprodução

A partir da raiz do workspace, usando as dependências já presentes:

```bash
pnpm --filter @workspace/api-server exec esbuild \
  ../../scripts/profile-pauta.ts --bundle --platform=node --format=esm \
  --outfile=/tmp/profile-pauta.mjs

node /tmp/profile-pauta.mjs --rows=300 --width=1440 \
  --out=generated-artifacts/pauta-performance/repro

node scripts/summarize-pauta-profile.mjs \
  generated-artifacts/pauta-performance/repro
```

Para executar também as verificações funcionais e um orçamento explícito de tarefa longa:

```bash
node /tmp/profile-pauta.mjs --rows=300 --width=900 \
  --out=generated-artifacts/pauta-performance/check \
  --check --max-task-ms=200
```

**Estado após correções:** `--check` passa nos cenários amplo e estreito. O orçamento adicional `--max-task-ms=200` continua reprovando, por causa das tarefas longas remanescentes. Não confundir a aprovação funcional com o atendimento desse orçamento de desempenho.

O orçamento é um parâmetro explícito da execução, não uma garantia universal entre máquinas.

## Evidências preservadas

`generated-artifacts/pauta-performance/` contém `summary.json`, `analysis.json`, `cpu.json`, `trace.json` e `screen.jpg` para:

- `visible-30`
- `visible-300`
- `narrow-300`
- `isolated-300` — experimento de atribuição, sem renderização do Prontuário.
- `after-wide` e `after-narrow` — verificações funcionais após as correções, com capturas visuais finais separadas.

Essa pasta está excluída de Git e da publicação. Os traces podem ser abertos no painel Performance do DevTools, e os perfis de CPU no JavaScript Profiler.

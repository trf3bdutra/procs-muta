# Acervo Muta — matrizes, parágrafos e o que alimenta o Gerador

Levantamento feito sobre o repositório `brndutra/trf3-muta-jurisprudencia` (público, ramo `main`), clonado e medido. Todos os números abaixo vêm de execução sobre os dados, não de estimativa.

## O que o acervo tem

| Conjunto | Arquivo | Volume |
| --- | --- | --- |
| Precedentes | `dados/indice.json.gz` | **33.207** registros — 26.050 acórdãos e 7.157 monocráticas |
| Textos | `dados/acordaos/<ano>.json.gz`, `dados/monocraticas/` | 19.851 integrais, 11.751 só acórdão, 1.605 só ementa |
| Modelos | `modelos/modelos.json.gz` | **752** modelos, cobrindo 12.216 ocorrências |
| **Matrizes de parágrafos** | `modelos/matrizes.json` | **20 matrizes, 314 slots, 441 versões de texto** |

Procedência em `MANIFESTO.json`: coleta de 30/10/2026 da base do TRF3, critério `relator_t: CARLOS MUTA`.

## As matrizes são o repositório de parágrafos

`matrizes.json` traz 20 matrizes da fase **TRMS** (a vigente), organizadas por **espécie × resultado**. Critérios de formação declarados no próprio arquivo: mínimo de 12 decisões do tipo, uso do slot em pelo menos 10% e no mínimo 3 matérias.

As maiores:

| Espécie | Resultado | Decisões | Matérias | Posições |
| --- | --- | --- | --- | --- |
| Apelação | desprovimento | 750 | 506 | 8 |
| Apelação | provimento | 304 | 198 | 7 |
| Embargos de declaração | rejeição | 266 | 208 | 7 |
| Apelação | parcial provimento | 240 | 194 | 7 |
| Agravo de instrumento | não conhecimento | 141 | 39 | 3 |

### Estrutura de uma matriz

Cada matriz tem três blocos: `posicoes` (o voto), `ementa` e `acordao`.

As posições do voto, numeradas, na ordem em que aparecem:

03 · Transição após preliminares · 04 · Delimitação da controvérsia · 05 · Fundamentação jurídica · 06 · Introdução fática · 07 · Exame fático-probatório · 08 · Aplicação ao caso · 09 · Conclusão · 11 · Custas e honorários · 12 · Questões complementares · 13 · Dispositivo

Cada posição tem `slots`, e cada slot tem `versoes` com o texto real, mais quatro medidas: `uso` (frequência relativa), `materias` (em quantas matérias ocorre), `ordem` (posição relativa no documento) e `opcional`.

Exemplo, da matriz `MATRIZ-TRMS-A-APELACAO-desprovimento`, posição "11 · Custas e honorários", slot com `uso: 0.7` e `materias: 305`:

> "Pela sucumbência recursal, a ré deve suportar condenação adicional (artigo 85, § 11, CPC), no equivalente a 1%, a ser acrescido ao fixado na origem, observada a Súmula 111/STJ…"

### O pareamento voto × ementa já está modelado

O bloco `ementa` de cada matriz traz as posições da ementa com o mesmo formato de slots: "II. Questão em discussão" (uso 0,956), "III. Razões de decidir" (uso 0,989), e as demais. O bloco `acordao` traz a fórmula do fecho: "Vistos e relatados estes autos… a Turma Regional de Mato Grosso do Sul, por unanimidade, negou provimento à apelação…".

Isto é, o Gerador não precisa inferir a correspondência entre o parágrafo do voto e o trecho da ementa: a matriz já a carrega.

## A armadilha da fase

Os 752 modelos se distribuem por fase assim:

| Fase | Modelos |
| --- | --- |
| 3ª Turma (2020–2023) | 537 |
| 1ª Turma (2023–2024) | 88 |
| **Turma Regional de MS (2026)** | **127** |

Os seis modelos de maior frequência do acervo são todos da 3ª Turma, com períodos entre 2020 e 2023. **Ordenar por frequência sem controlar fase traz o padrão abandonado ao topo.** A fase é porta, não peso; frequência só desempata dentro da mesma fase. Faltando modelo vigente, prefere-se precedente recente — há 2.721 de 2026 contra 127 modelos.

As matrizes, por serem todas da fase TRMS, não têm esse problema.

## Como ele decide, medido nos acórdãos de 2026

Sobre os 1.940 acórdãos de 2026, todos com texto integral.

### Honorários recursais — 1.052 ocorrências

- Recurso desprovido → "honorários recursais de 1% em acréscimo ao fixado na origem" (663 ocorrências).
- Provimento, ainda que parcial → não cabe fixação, Tema 1.059.
- Gratuidade → acrescenta "respeitados os termos do artigo 98, § 3º do CPC". Gratuidade citada em 835 acórdãos.
- Previdenciário → Súmula 111/STJ, em 689 acórdãos.

Três informações da ficha bastam: resultado do recurso, gratuidade, matéria previdenciária.

### Preliminares — 837 ocorrências, quatro desfechos

Rejeitada 247 · Acolhida 95 · Prejudicada 71 · Apenas arguida 59. Rejeição é duas vezes e meia mais comum que acolhimento.

Matérias mais frequentes: prescrição 327, cerceamento de defesa 251, interesse de agir 227, nulidade da sentença 189, ilegitimidade 188, decadência 65.

### Admissibilidade — pouco mais de 1% dos recursos

De 465 trechos sobre conhecimento, 440 não trazem motivo de inadmissão. Os motivos reais somam 25 casos em 1.940 acórdãos: falta de interesse 7, prejudicialidade 5, embargos sem vício 3, deserção 3, intempestividade 2, ilegitimidade 2, inovação recursal 2, preclusão 1.

**Consequência para o Prontuário:** admissibilidade não é checklist. O app calcula tempestividade pelas datas, preparo pela GRU e representação pelo ID da procuração, e só pergunta quando um sinal falha.

### Multa processual — gatilho estreito

Em amostra de 900 acórdãos: astreintes (matéria do processo) 65, afastada 28, litigância de má-fé 20, **embargos protelatórios pelo art. 1.026, § 2º: 12**.

A formulação é ligada à reiteração: "rejeito os **segundos** embargos de declaração e, em razão do caráter manifestamente protelatório, aplica-se multa". Uma pergunta resolve: é reiteração de embargos já rejeitados?

### Consectários

EC 113 em 421 acórdãos, SELIC 509, Manual de Cálculos 434, Tema 810 em 328, EC 136 em 304, Tema 1.419 em 104. A decisão depende do período, fatiado pelos marcos das emendas.

## Defeito encontrado no acervo

A mesma classe aparece grafada de dois modos no índice: "APELAÇÃO / REMESSA NECESSÁRIA" (2.643 registros) e "APELAÇÃO/REMESSA NECESSÁRIA" (1.257). São 43 siglas de classe ao todo, e cinco classes cobrem 97% do acervo. Qualquer filtro por classe precisa normalizar antes.

# Decisões do redesign do Gabinete CMT

Registro das decisões tomadas pelo usuário durante o redesign, para valer nas próximas sessões.

## Rotas e nomes

- Rotas: `/pauta`, `/mono`, `/session`, `/serv-user`, `/ementario`, `/repositorio`, `/protocolo`.
- `/controle-de-pauta` e `/controle-de-decisoes` continuam funcionando e redirecionam para `/pauta` e `/mono`.
- Renomes: "Controle de Pauta" → **Pauta de Julgamento**; "Controle de Decisões" → **Controle de Monocráticas**; "Página do servidor" e "Minha página" → **Campo do Servidor**.
- Renomes posteriores: "Referenciais" (seção) → **Apoio**; "Repertório" → **Repositório**; "Diretrizes e fluxos" → **Protocolo**.
- Endereços novos `/protocolo` e `/repositorio`; `/diretrizes-e-fluxos` e `/repertorio` continuam resolvendo para as mesmas páginas.
- "Apoio" foi escolhido porque o painel de apoio do Gerador bebe dessas três páginas: o nome do painel e o da fonte coincidem. "Recursos" foi descartado por colidir com recurso processual.

## Frame

- A estrutura do frame é refeita do zero: barra esquerda, trilho direito, rodapé e painel do rodapé. O miolo das páginas é preservado, assim como os cards de processo, o painel de pendências, o Prontuário, o Gerador e as integrações.
- Barra esquerda: crachá no topo, com encerrar sessão à esquerda e recolher à direita. No modo recolhido, o encerrar sessão não aparece.
- Navegação em duas seções: Produção (Pauta de Julgamento, Controle de Monocráticas, Campo do Servidor) e Apoio (Ementário, Protocolo, Repositório).
- Urgências, Pendências e Organograma saem da navegação lateral, em definitivo.
- Calendário na base da barra, com rodapé de três abas de altura fixa: Entregas (padrão), Marcos e Eventos. Sem mexer no calendário, o cartão com as entregas do dia de todo o gabinete já aparece. Mexer no calendário leva o rodapé para Marcos. Marcos de sessão não constam em Eventos.
- Trilho direito: botões de download no topo, conforme a página; na base, botões só para Administração; na ponta, a marca do TRF3 centrada, com etiqueta de quantas pessoas estão no app.
- Rodapé: altura igual à largura do trilho direito. À esquerda, um botão de ícone que abre o painel. À direita, a nota da rota.
- Painel do rodapé: Meu dia e Entregas de hoje em abas, mais Notificações e Pendências ao lado. Cada caixa abre por uma faixa com a sua etiqueta e a sua contagem.
- O painel de Pendências é um quadro de cartões, com **dois fluxos paralelos**: o fluxo padrão de pendências (urgências e vencidas, aguardando terceiros, conferências) e um fluxo dedicado exclusivamente às pendências de meta. Cada cartão pertence a um só fluxo.
- **Metas CNJ**: saem do menu. As Metas Nacionais ficam num escaninho próprio da página Triagem, onde a etiqueta de meta é atribuída, e aparecem no dia a dia pelo fluxo de meta do painel de Pendências. Não entram no fluxo padrão de pendências, que significa o que está parado e precisa de ação.
- A etiqueta de meta já é atributo de processo no app: as entregas trazem processos marcados META 2A e META 7.

## Painel de Pendências — o verso do painel do rodapé

O painel que sobe do rodapé tem duas faces. A **frente** traz Meu dia, Entregas de hoje e Notificações, em caixas com faixa rotulada. O **verso** é o painel de Pendências, e ele não é lista: é um **quadro de fluxo**, no feitio de um kanban.

### O que o cartão carrega

Processo, prioridade, servidor atribuído, prazo, situação e as contagens de anexos e de comentários. O quadro permite **atribuir servidor** e **definir prazo** no próprio cartão, sem sair dele.

### A pendência nasce de evento, não de digitação

Dois gestos do trabalho corrente emitem pendência automaticamente:

- **Registrar intercorrência** num processo da sessão, na Pauta de Julgamento.
- **Registrar urgência** numa monocrática, no Controle de Monocráticas.

Quem trabalha não precisa lembrar de abrir pendência. Ela nasce do gesto que já é feito, com o processo já vinculado.

### Dois fluxos paralelos

O quadro tem o fluxo padrão de pendências e, em paralelo, o fluxo dedicado às pendências de meta. Cada cartão pertence a um só fluxo. As metas aparecem no quadro sem contaminar o significado do fluxo padrão, que é o que está parado e precisa de ação.

### Notificações

O painel tem notificações próprias. Movimento no cartão — atribuição, prazo, mudança de situação, comentário — avisa quem interessa, e o aviso aparece na caixa Notificações da frente do painel.
- Barra de rolagem fina, sem setas e sem trilho, igual em todo o app.
- Miolo com bordas arredondadas sobre fundo cinza.

## Contadores da navegação

- Pauta de Julgamento: quantos processos faltam minutar para a próxima sessão. Ao zerar, passa para a sessão seguinte.
- Controle de Monocráticas: só as urgentes ainda não minutadas.

## Mesa de trabalho

- As abas "Pauta completa" e "Mesa de trabalho" saem do rodapé.
- A Mesa vira um botão à direita do último marco, na faixa de datas. Ao acionar, o painel do Prontuário surge da direita para a esquerda, empurrando a listagem.

## Ficha do Prontuário (Mesa de Trabalho v16)

- A v16 é documento de especificação, não módulo pronto: traz o mapa de 163 campos em 15 grupos, dos quais 85 existentes, 7 de estrutura, 9 de projeção e 62 previstos.
- **Decisão:** a ficha mostra só os campos que têm dado. No modo edição aparecem também os previstos, para serem preenchidos.
- A v16 é formada por 21 camadas de estilo empilhadas. A substância dela é dobrada no Prontuário existente, editando no lugar, sem trazer as sobreposições.

## Método

- Vale a regra do `replit.md`: editar a regra ou a função original no lugar. Nada de blocos versionados novos nem sobreposições por especificidade. Dois módulos não podem disputar o mesmo nó.
- Nunca inventar dado, contagem ou precedente. O que não vem do app não é escrito.

## Trilho direito · o miolo morto por trás das faixas

Sintoma: no trilho de 58px, a frase "Selecione um painel nos botões abaixo" aparecia
quebrada palavra a palavra, escura sobre o verde, por baixo do botão de descarga.

Causa, medida no navegador (`CSSRule` por folha, não por leitura do arquivo): cinco regras
disputam `.rr-slot`, de três módulos.

| Módulo | Regra | Vale? |
| --- | --- | --- |
| `cmt-center-panels-style` | `display:none!important` · 2 ids | sim, mas perde |
| `prontuario.css` | `visibility:hidden!important` no trilho recolhido | **não** — presa em `@media (max-width:1099px)` |
| `cmt-frame-stability-css` | `display:block!important` · **3 ids** | sim, e vence |

O bloco de estabilidade governa o trilho **aberto**: as regras irmãs dele, todas, trazem
`:not(.cmtx-rr-min)`. A regra do miolo era a única sem. Sem essa cláusula ela vencia por ter
três ids e acendia o miolo também no trilho recolhido.

Correção: a cláusula que faltava, na própria regra. Nada de bloco novo.
Guarda: `tests/trilho-direito-faixas.test.mjs` — verificado que falha sem a correção.

Decidido: a faixa vira real, e as regras soltas saem de cena.

Razão: um `top:` fixo prende **um** nó. `RR_DL` já tem um segundo download escrito — o Excel do
acervo de monocráticas — que cairia nos mesmos dez pixels do primeiro. Faixa é recipiente:
empilha, espaça sozinha, carrega o rótulo. Prego não compõe; cada item novo pediria um `top:`
escolhido à mão e uma regra nova.

Três consertos, todos na regra ou função original:

1. `exportAction` levava o botão para a raiz do trilho (`rail.prepend`) e, antes disso, apagava
   o que estivesse no trilho inteiro — inclusive o que `railDownloads` tinha posto na faixa.
   Agora os dois módulos apontam para o mesmo destino: a faixa.
2. Quem enchia a faixa e quem decidia se ela aparece eram módulos diferentes, e a decisão vinha
   antes do conteúdo. A faixa passou a se esconder por conteúdo, em CSS
   (`:not(:has(>button:not([hidden])))`); `railDownloads` não decide mais visibilidade.
3. O rótulo de texto do botão era escondido pela regra do botão solto, que deixou de casar
   dentro da faixa. A regra da faixa passou a escondê-lo: no trilho o botão é só ícone.

A faixa `ADM` não tinha defeito: `railAdm` a esconde quando `canOpenSettings()` é falso, e o
login de teste é de servidor. Ela aparece para a Administração.

## Protocolo · o fluxo vindo da Central de Comando

Origem: aba Rotina de `command_11_Dr_Jean_Gabinetes_A_C.html`. O conteúdo não foi copiado à mão
nem reconstruído: o arquivo foi aberto em navegador sem tela e o HTML já montado foi colhido,
com as seções abertas uma a uma para forçar o preenchimento preguiçoso. As estruturas de dados
(`SEQ`, `PHASES`, `R`, `ACTS`) saíram por recorte de literal, sem executar o arquivo inteiro.

O que a página passou a ter, em duas abas novas antes das Diretrizes de Conformidade:

- **Sequência do gabinete** — quatro etapas agrupando nove passos, mais a tabela de prazos.
  Ao pé de cada passo, as seções transversais que ele cita, vindas da estrutura (`blocks[].sc`),
  não de busca no texto.
- **Ato e via cabível** — oito atos impugnáveis; escolhido um, aparecem as vias cabíveis com
  prazo, o que impugnam, órgão julgador, sustentação oral, os pontos essenciais e a base legal.
  Dez vias em três famílias, sete prazos distintos.

Medidas: 4 etapas · 10 passos · 12 seções · 10 vias · 8 atos · 7 prazos.

O bloco de dados segue o padrão dos demais referenciais: `cmt-ref-protocolo-src`, base64 de gzip,
servido por `/api/app/referenciais/protocolo.json` com etag e cache imutável, buscado só quando a
aba abre. São 136 KB de JSON que viajam em 32 KB; o documento não cresce.

O CSS da Central foi colhido junto (199 regras) e reescopado para `.cmt-proto`, para não vazar
no resto do app. O cabeçalho de cada fase é redesenhado aqui, e o original sai do HTML colhido.

Guarda: `tests/protocolo-fluxo.test.mjs` confere as contagens, a integridade das referências
cruzadas (etapa→passo, ato→via, passo→seção), o escopo do CSS e que nenhum passo, via ou seção
está vazio.

## Prontuário · a ficha mostra o que tem dado

Decisão do usuário: a ficha mostra apenas os campos preenchidos; os previstos aparecem só no
modo de edição. Implementada como dois modos, com seletor no alto do Prontuário:

- **Ficha** (padrão) — só os campos com dado. Painel sem nada lançado traz uma linha dizendo
  quantos campos esperam, em vez de ficar mudo. O roteiro guiado vira registro: aparecem só as
  perguntas já respondidas, e a Conferência de conformidade, que é lista de trabalho, sai.
- **Preencher** — todos os campos previstos, vazios à espera, e o roteiro inteiro.

As duas contas do seletor saem de `filled()`, a função que o próprio app já usa para contar
preenchimento. Nenhum número escrito à mão.

Medida num processo da pauta: **9 linhas em leitura contra 20 em preenchimento**, e o HTML da
ficha cai de 44,7 KB para 13,8 KB. As 31 perguntas do roteiro não aparecem enquanto não
respondidas.

Campos de conteúdo próprio — voto, acessórios, peças, listas de recursos — ficam sempre à vista:
não entram na conta de preenchimento e têm a sua própria forma de dizer que estão vazios.

A escolha do modo fica no navegador do servidor (`cmt.prontuario.modo.v1`), não no registro do
processo: é preferência de quem lê, não dado do caso.

Conferido pela API do próprio módulo (`CMTCardR3.prontuarioHTML`), não por leitura do código.
Guarda: `tests/prontuario-modo-ficha.test.mjs`. Zero erro de console nas oito rotas.

Observação para o desenho do roteiro: a análise guiada **já existia** e é mais densa do que o
desenho de ~10 perguntas em 5 blocos — são 31 perguntas em 3 blocos, tiradas do Padrão Muta
(`cmt-padrao-muta`, MESTRE mais o roteiro da espécie). Não foi substituída.

## Pendências · o que já existia e o que faltava

Correção ao registro anterior, que dizia que o kanban estava desenhado e não construído. **Estava
construído.** O quadro `pnb-board` tem quatro etapas — Novas, Em andamento, Aguardando terceiros,
Concluídas —, arrastar entre colunas, inclusão rápida, prazo, responsáveis, idade do cartão, visão
de lista, gaveta de detalhe, desfazer e nota de produtividade. As concluídas saem do quadro
quatorze dias depois; a contagem de produtividade continua.

O modelo de dados do cartão já trazia o que o desenho pedia: `assignees` (servidor), `dueDate`
(prazo) e `stage` (coluna). E a intercorrência já abria pendência sozinha, pela `incPend`.

O que faltava era a outra metade: **a urgência não abria pendência.** Só havia
`origin:'intercorrencia'` no app inteiro.

Feito agora, espelhando a intercorrência:

- `urgPend(h,x)` abre a pendência quando uma urgência é gravada no Controle de Monocráticas.
  Título é a medida; prazo e responsável vêm do próprio pedido; a origem fica registrada.
- Gravada de novo, a mesma pendência é atualizada, não duplicada.
- Decidida a urgência, a pendência vai para Concluídas e registra o resultado na linha do tempo.
- Pedido que já chega decidido não abre acompanhamento nenhum.
- `cleanLim` passou a guardar `pendenciaId`: sem isso o vínculo se perdia a cada gravação, porque
  essa função reconstrói o registro campo a campo.

Conferido pela API do módulo: uma urgência em aberto abre uma pendência; a mesma urgência gravada
de novo não abre a segunda; decidida, o cartão vai para Concluídas com duas atividades; uma
urgência que nasce decidida não abre nada.

Guarda: `tests/urgencia-vira-pendencia.test.mjs`.

### A virada do painel

O quadro de Pendências já abria na mesma casca sobre o rodapé que o painel — é o verso, como o
desenho pedia. O que faltava era a passagem: o painel não tinha nenhum caminho para o quadro.

O cabeçalho da coluna Pendências virou o botão que abre o verso; no quadro, "← Painel" volta à
frente. A virada usa o mecanismo `data-center-tab` que o painel já tinha, sem caminho novo.

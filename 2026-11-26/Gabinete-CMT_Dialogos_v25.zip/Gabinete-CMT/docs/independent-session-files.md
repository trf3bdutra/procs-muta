# Listagens no HTML independente de Sessões

## Uso

1. Baixe `sessoes-independente.html` e abra no Chrome ou Edge. Não é necessário iniciar o GabCMT.
2. Entre na aba **Montar listagem**, crie ou selecione uma sessão e salve as cinco datas.
3. Inclua os processos com CNJ de 20 dígitos e item positivo. Complete partes, classe, assunto, servidor e corretor; use Editar, Subir, Descer ou Retirar.
4. **Exportar sessão para o app** baixa somente a sessão escolhida, em um JSON aceito pelo Hub.
5. No app autenticado, abra **Controle de Sessões → Importar sessão JSON**, disponível a quem pode abrir Configurações Globais. Escolha o arquivo, confira a prévia e confirme a mesclagem.

**Exportar backup local**, na barra superior do HTML, é outra operação: guarda todo o estado local do arquivo. Não use esse backup como se fosse o JSON específico de importação de uma sessão.

Os arquivos independentes começam sem dados reais. A edição é salva no armazenamento do navegador, isolada da Triagem. Use backups para transferir entre computadores ou proteger os dados antes de limpar o navegador; o HTML não grava alterações de volta no próprio arquivo.

## Contrato reutilizado

O JSON específico usa `formato: "controle-pauta-hub-sessoes"`, `versao: 1`, `sessions`, `sessionDetails`, `rows`, `_pautaEntries` e `pautaPreferences.jsonSessionLists`. Não é um novo esquema paralelo.

- As datas `pecoDia`, `prepStart`, `minutasDeadline`, `releaseDeadline` e `date` usam `AAAA-MM-DD`.
- O nome/chave da sessão é idêntico nos marcos, nos vínculos e na listagem.
- O CNJ normalizado identifica o processo. O item identifica sua posição dentro de uma sessão, não o processo global.
- A exportação não leva equipe nem calendário para sobrescrever o app. Os indicadores são recalculados, não importados como totais fixos.

## Segurança da importação

- Ler a prévia não altera a pauta. A confirmação só é comunicada após o salvamento ser reconhecido.
- **Mesclar** preserva processos e vínculos ausentes do arquivo, outras sessões e campos vazios/ausentes.
- A prévia indica processos novos/existentes, campos diferentes, marcos e colisões. Um item ocupado por outro processo preservado ou uma participação ativa em outra sessão bloqueia a mesclagem até resolver o conflito.
- Participações concluídas não são reabertas por um rascunho offline. Equipe e calendário ficam desmarcados por padrão.
- **Retirar** no HTML apenas remove o vínculo local. Não envia exclusões ao app nem apaga a ficha global.
- O modo antigo **Substituir** continua exigindo confirmação destrutiva própria; não é necessário para esse fluxo e não é o padrão.

Não há credenciais, consultas ao banco, chamadas à API real ou autenticação remota no arquivo independente. Importações no app continuam sujeitas à autenticação e às permissões existentes.

## Verificação

- `node --test artifacts/api-server/tests/session-transfer.test.mjs`
- Gerar os HTMLs com o script de exportação, empacotado com esbuild.
- `node scripts/test-standalone-pages.mjs`

O teste de navegador usa `file://`, dados fictícios e perfil temporário. Exercita criação, cinco datas, validação, inclusão, edição, ordenação, retirada local, download real do JSON, prévia/confirmar/reimportar pelo código do importador do app, abas originais e persistência após recarga. Não utiliza sessão real nem altera a base compartilhada.

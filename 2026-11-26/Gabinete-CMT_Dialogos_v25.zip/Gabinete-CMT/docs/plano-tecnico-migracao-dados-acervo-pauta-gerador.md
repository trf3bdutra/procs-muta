# Plano técnico de migração — Acervo, Pauta, Prontuário e Gerador

**Status:** proposta técnica; nenhuma migração de dados ou alteração de banco foi executada por este documento.

## Objetivo

Separar os fatos globais do processo dos dados que pertencem a uma sessão, a um card, a uma análise jurídica ou a uma versão de minuta. Fazer isso sem interromper a operação, perder edições, sobrescrever correções manuais ou alterar a precedência entre PJe, BI e DataJud.

## Situação atual verificada

- `pauta_snapshots` guarda o estado compartilhado da Pauta em JSON, com uma revisão crescente. A rota `PUT /api/pauta` faz mesclagem por revisão, bloqueia a linha durante a gravação e, na mesma transação, sincroniza correções do Acervo e atualiza a Pauta.
- `acervo` usa o CNJ normalizado como chave e mantém dados importados separados de `operacional`. `acervo_fontes` registra as importações. A interface, a Pauta e a Triagem usam o PostgreSQL próprio do app.
- Correções da Pauta no Acervo ficam em `operacional.pautasPorFicha`, hoje indexadas pelo conjunto ordenado de rótulos de sessão. O campo legado `operacional.pauta` só pode ser reaplicado quando há uma única ficha para aquele CNJ.
- A identidade usada pela mesclagem de linhas da Pauta é atualmente o processo mais o conjunto de sessões; não há ainda um `cardId` e um `sessaoId` estáveis em todos os registros.
- A biblioteca interna do Gerador, incluindo o Padrão Muta, fica sob uma chave própria dentro do JSON de `pauta_snapshots`. Ela tem revisão e controle de edição próprios, mas ainda compartilha a linha de estado `main`.
- Os catálogos editoriais públicos vêm do GitHub por rotas distintas: `catalogos-gerador` consulta `data/modelos.json` e `data/paragrafos.json`; `paradigmas` consulta os dados de jurisprudência e modelos do repositório. A biblioteca interna não deve ser confundida com esses catálogos públicos.
- **Atualização da matriz anexada:** a extração dos módulos de Configurações e Gerador já está ligada à rota do GabCMT. Os módulos são servidos separadamente, autenticados e identificados por hash. Isso separa recursos HTML/CSS/JavaScript, mas não muda o modelo de dados nem cria, por si só, uma página de Gerador independente do shell do Gabinete.

## Modelo de dados de destino

| Entidade lógica | Chave | Conteúdo e limites |
|---|---|---|
| Processo no Acervo | CNJ normalizado (`processoId`) | Fatos globais e importados, situação, origem, data da importação e divergências. PJe, BI e DataJud mantêm precedência por campo. |
| Sessão | `sessaoId` estável | Data, marcos e demais dados da sessão. O nome e a data continuam sendo atributos legíveis, não a chave permanente. |
| Caso pautado / card | `cardId` estável, ligado a `processoId` e `sessaoId` | Designações, etapa, prazo e situação operacional daquela ficha na sessão. Recursos, respostas, peças, ocorrências e especificidades permanecem nesse escopo. |
| Prontuário / análise | `cardId` | Conclusões jurídicas, estados, fundamentos e referências probatórias. “Pendente”, “não informado” e “confirmado como ausente” são estados distintos. |
| Julgamento da sessão | `cardId` | Espécie julgada, resultado, efeitos, honorários, votação e proclamação da decisão que está sendo preparada. Histórico importado permanece separado. |
| Minuta | `cardId` + versão | Conteúdo editável, ementa, estado de revisão e referências aos IDs/versões do modelo e dos trechos usados. A redação não altera fatos, análise ou julgamento. |
| Biblioteca interna do Gerador | ID próprio + revisão | Padrão Muta e conteúdo interno, com edição restrita à Assessoria. Não publicar no GitHub. |
| Catálogos públicos do Gerador | ID do registro + origem/versão | Referências aos modelos, trechos e julgados do repositório público. Não copiar o cadastro inteiro para cada minuta. |

Um registro antigo da Pauta pode ter entradas em mais de uma sessão. Nesses casos, a migração deve mapear cada vínculo a uma ficha identificável, mas não duplicar automaticamente campos cujo significado não seja claramente global ou próprio daquela sessão. Esses casos vão para relatório de conferência.

## Precedência que deve permanecer

1. **PJe** prevalece em tarefa atual, entrada na tarefa, etiquetas, partes e advogados.
2. **BI** prevalece em códigos de classe e assunto, conclusão, sobrestamento, seção julgadora e distribuição; nos campos sem fonte prioritária, completa lacunas sem substituir dado confiável do PJe.
3. **DataJud** complementa lacunas, registra divergências e só atualiza a movimentação se for mais recente. Não cria nem remove processos do Acervo.
4. **Correção manual** não altera silenciosamente o bloco importado. É gravada em separado e, quando ligada a um card, não pode alcançar outro card do mesmo CNJ.
5. Valores vazios de importação não substituem valores existentes. Divergências preservam valor mantido, valor recebido, fonte e referência temporal.
6. A espécie ou o resultado do julgamento em preparação não é inferido da classe processual nem substituído por julgamentos históricos do BI.

Antes de codificar a migração, fechar um dicionário campo a campo: nome canônico, tipo, entidade proprietária, fontes autorizadas, precedência, semântica de vazio/ausente e regras de conflito. Não usar mesclagem genérica por espalhamento de objetos.

## Etapas de execução

### 0. Preparação e linha de base

- Registrar revisão atual de `pauta_snapshots`, contagens de processos, sessões, cards, recursos, análises e minutas.
- Fazer backup verificável do banco e exportação legível do estado `main` e do Acervo antes de qualquer DDL ou backfill.
- Gerar relatório somente de leitura de CNJs inválidos/duplicados, rótulos de sessão ambíguos, cards com várias sessões e correções legadas sem correspondência única.
- Fixar casos de referência para testes: mesmo CNJ em sessões diferentes, correção manual, recurso com resposta, análise incompleta, julgamento histórico e minuta revisada.

**Gate:** não avançar com colisões de identidade sem classificação e plano de resolução; confirmar a restauração do backup em ambiente isolado.

### 1. Contrato de dados e identidade

- Definir o formato canônico do CNJ e o `processoId`.
- Criar identificador persistente para cada sessão e uma tabela de correspondência entre os rótulos antigos e `sessaoId`.
- Definir a unidade de card: uma ficha de um processo em uma sessão. Atribuir `cardId` persistente; não depender de índice da linha, nome ou data.
- Mapear a identidade legada `[CNJ, conjunto de sessões]` para a nova identidade. Se um registro reunir mais de uma sessão, revisar os campos antes de separar os casos.
- Classificar cada campo legado como global do processo, próprio do card/sessão, análise, julgamento, minuta ou catálogo.

**Gate:** revisão do dicionário de dados e do relatório de mapeamento; nenhum identificador estável será derivado apenas de rótulo de sessão ou posição em array.

### 2. Expansão compatível do banco

- Acrescentar o esquema novo sem remover `pauta_snapshots`, `acervo`, `importado`, `operacional` ou campos legados.
- Criar as estruturas normalizadas para sessões e fichas de processo por sessão; acrescentar tabelas filhas para recursos/peças, análise, julgamento e versões de minuta conforme o dicionário aprovado.
- Manter `acervo` como cadastro global por CNJ e preservar o bloco `operacional.pautasPorFicha` durante a transição.
- Usar chaves estrangeiras, índices por CNJ/sessão/card e restrições de unicidade somente depois de medir colisões reais.
- Adotar migração aditiva, versionada e repetível. O pacote atual tem `drizzle-kit push`; não usar `push-force` nem comandos destrutivos diretamente no banco publicado como substituto de um plano de migração revisado.

**Gate:** aplicar primeiro em ambiente não produtivo; verificar que a aplicação antiga continua lendo e gravando sem alteração de comportamento.

### 3. Backfill idempotente e conferível

- Copiar sessões e fichas com IDs estáveis usando uma tabela de correspondência do legado.
- Vincular os fatos globais ao Acervo por CNJ; manter correções operacionais por ficha/card.
- Separar histórico de julgamentos importados do julgamento atual em preparação.
- Migrar recursos, respostas, peças, análises e minutas para o escopo correto. Não escolher silenciosamente entre valores conflitantes.
- Preservar revisões e referências do Gerador. Manter a biblioteca interna em sua chave atual até que sua separação seja tratada em etapa própria.
- Registrar por lote a revisão de origem, contagens de entrada/saída, hash, exceções e resultado. A mesma migração deve poder ser executada novamente sem duplicar registros.

**Gate:** relatório de diferenças aprovado por domínio; toda ficha sem mapeamento inequívoco fica preservada no legado e sinalizada para revisão, não descartada.

### 4. Escrita dupla transacional

- Atualizar o salvamento da Pauta para escrever o snapshot legado e as entidades normalizadas na mesma transação PostgreSQL.
- Preservar `baseRevision`, a mesclagem de três estados, o bloqueio por transação e a sincronização do Acervo já feita no `PUT /api/pauta`.
- Atualizar o `cardId`/`sessaoId` antes de substituir a identidade usada na mesclagem. Um salvamento antigo não pode apagar campos que não conhece.
- Publicar SSE, sincronização de planilha e confirmações de salvamento somente depois do commit.
- Se qualquer escrita falhar, a transação inteira deve falhar; não aceitar sucesso parcial entre Pauta, Acervo e fichas normalizadas.

**Gate:** testes de concorrência em dois navegadores e confirmação de que uma resposta de salvamento só limpa a revisão efetivamente enviada.

### 5. Leitura paralela e comparação

- Ler a visão antiga e a nova sem mudar ainda o que aparece para os usuários.
- Comparar por `processoId`, `sessaoId` e `cardId`: contagens, designações, marcos, status, recursos/respostas, análise, julgamento, minutas e correções do Acervo.
- Registrar diferenças com contexto suficiente para corrigir; não aplicar “última gravação vence” como regra geral.
- Ativar leitura nova por módulo e por flag reversível, começando por dados globais do Acervo e depois cards, Prontuário, julgamento e Gerador.

**Gate:** zero diferenças não explicadas nos campos migrados e nenhum aumento de conflitos ou falhas de salvamento durante o período de observação.

### 6. Troca gradual e encerramento do legado

- Mudar cada leitor para a fonte nova mantendo escrita dupla e resposta compatível com o formato atual do GabCMT.
- Observar pelo menos dois ciclos de publicação e um período operacional acordado; confirmar que não há leitores/escritores usando os campos antigos.
- Só então preparar uma alteração separada para parar a escrita legada. Manter exportação e cópia de recuperação antes de qualquer remoção posterior.
- Não excluir `pauta_snapshots`: ele ainda contém estado e configurações não migrados, incluindo dados internos do Gerador.

## Validação obrigatória

- CNJ normalizado continua apontando para um único processo no Acervo; o mesmo CNJ pode ter fichas independentes em sessões distintas.
- Sessões antigas preservam data, marcos, quantidade de processos e designações.
- Recursos e respectivas contrarrazões/contraminutas permanecem vinculados corretamente ao card; nenhum recurso de outro card aparece após a migração.
- Correções de um card não aparecem em outra sessão com o mesmo CNJ; `operacional.pauta` legado só é aplicado à ficha única.
- Reimportar PJe, BI e DataJud respeita precedência e não sobrescreve correções operacionais.
- Estado de análise distingue pendente, não informado e confirmado como ausente; DPU/MPF entram como fatos de apoio, não como conclusão automática.
- Histórico de julgamento não substitui o julgamento atual em preparação.
- Minuta, ementa, conformidade e referências de catálogo preservam suas versões e não regravam o Acervo.
- Salvar em navegadores simultâneos preserva alterações independentes e informa conflitos reais.
- Triagem, Controle de Pauta, Controle de Decisões, `/cm`, Google Sheets e Gerador leem dados coerentes após cada fase.
- Testar importação, exclusão autorizada, mudança de sessão, sessão encerrada, dados ausentes e restauração do backup.

## Reversão segura

1. **Antes da escrita dupla:** interromper o backfill; o estado legado permanece intocado.
2. **Durante escrita dupla:** desativar a leitura nova e voltar ao snapshot legado. Como as escritas são atômicas, uma falha não deve deixar metade dos dados gravados. Manter as tabelas novas para diagnóstico; não apagá-las.
3. **Depois da troca de leitura, antes do encerramento do legado:** voltar a flag para a leitura antiga; manter escrita dupla até reconciliar diferenças.
4. **Depois de parar a escrita legada:** primeiro executar a migração reversa de compatibilidade para reconstruir o formato antigo a partir do novo e comparar revisões. Não restaurar um backup antigo sobre dados recentes sem autorização explícita, pois isso pode apagar trabalho feito após o corte.
5. Em qualquer fase, preferir reversão por flag e migração aditiva. `DROP`, `TRUNCATE` ou restauração destrutiva exigem backup validado e aprovação específica.

## Bloqueios antes de implementar

- Confirmar como tratar registros duplicados do mesmo CNJ na mesma sessão e registros antigos que agrupam várias sessões.
- Aprovar a identidade e a política de conversão de cada sessão e card.
- Validar no repositório GitHub os caminhos e formatos dos catálogos antes de gravar referências de modelo/trecho.
- Decidir se, e quando, a biblioteca interna do Gerador deve sair de `pauta_snapshots`; ela não deve migrar junto com os catálogos públicos sem regra própria.
- Aprovar ambiente, janela, backup e responsável pela execução produtiva. Este plano não autoriza aplicar DDL ou backfill na versão publicada.

import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const repositoryRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const artifactPath =
  "artifacts/pauta-compartilhada/.replit-artifact/artifact.toml";
const builds = [
  {
    name: "API Server",
    args: ["--filter", "@workspace/api-server", "run", "build"],
    env: { PORT: "20816" },
    artifact: {
      path: artifactPath,
      serviceName: "api",
      buildSection: "services.production",
      commandKey: "build",
      envSection: "services.env",
    },
  },
  {
    name: "Gabinete CMT web",
    args: ["--filter", "@workspace/pauta-compartilhada", "run", "build"],
    env: { PORT: "20815", BASE_PATH: "/" },
    artifact: {
      path: artifactPath,
      serviceName: "web",
      buildSection: "services.production",
      commandKey: "build",
      envSection: "services.env",
      publicDirKey: "publicDir",
      viteConfigPath: "artifacts/pauta-compartilhada/vite.config.ts",
    },
  },
];

function stripTomlComment(line) {
  let inString = false;
  let escaped = false;

  for (let index = 0; index < line.length; index += 1) {
    const character = line[index];
    if (escaped) {
      escaped = false;
    } else if (character === "\\" && inString) {
      escaped = true;
    } else if (character === '"') {
      inString = !inString;
    } else if (character === "#" && !inString) {
      return line.slice(0, index).trimEnd();
    }
  }

  return line.trimEnd();
}

function parseTomlValue(value, artifactName, setting) {
  const normalized = value.replace(/,\s*\]$/, "]");
  try {
    if (normalized.startsWith("[") || normalized.startsWith('"')) {
      return JSON.parse(normalized);
    }
  } catch (error) {
    throw new Error(
      `${artifactName}: could not read ${setting} from artifact.toml (${error.message})`,
    );
  }
  if (/^-?\d+(?:\.\d+)?$/.test(normalized)) return Number(normalized);
  if (normalized === "true") return true;
  if (normalized === "false") return false;
  throw new Error(
    `${artifactName}: unsupported value for ${setting} in artifact.toml`,
  );
}

function parseTomlServices(contents, artifactName) {
  const services = [];
  let currentService;
  let section = "";
  const lines = contents.split(/\r?\n/);

  for (let index = 0; index < lines.length; index += 1) {
    const line = stripTomlComment(lines[index]).trim();
    if (!line) continue;

    const arrayTableMatch = line.match(/^\[\[([^\]]+)\]\]$/);
    if (arrayTableMatch) {
      if (arrayTableMatch[1] === "services") {
        currentService = new Map();
        currentService.set("services", new Map());
        services.push(currentService);
        section = "services";
      } else {
        section = "";
      }
      continue;
    }

    const tableMatch = line.match(/^\[([^\]]+)\]$/);
    if (tableMatch) {
      section = tableMatch[1];
      if (
        currentService &&
        section.startsWith("services.") &&
        !currentService.has(section)
      ) {
        currentService.set(section, new Map());
      }
      continue;
    }

    const assignment = line.match(/^([A-Za-z0-9_-]+)\s*=\s*(.*)$/);
    if (!assignment) continue;

    const [, key] = assignment;
    let value = assignment[2].trim();
    if (value.startsWith("[") && !value.includes("]")) {
      while (++index < lines.length) {
        value += ` ${stripTomlComment(lines[index]).trim()}`;
        if (value.includes("]")) break;
      }
    }
    if (
      !currentService ||
      (section !== "services" && !section.startsWith("services."))
    ) {
      continue;
    }
    if (!currentService.has(section)) currentService.set(section, new Map());
    currentService
      .get(section)
      .set(key, parseTomlValue(value, artifactName, `${section}.${key}`));
  }

  return services;
}

export function readArtifactBuildSettings(contents, build) {
  const service = parseTomlServices(contents, build.name).find(
    (candidate) =>
      candidate.get("services")?.get("name") === build.artifact.serviceName,
  );
  if (!service) {
    throw new Error(
      `${build.name}: service "${build.artifact.serviceName}" is missing from artifact.toml`,
    );
  }

  const sections = service;
  const buildSettings = sections.get(build.artifact.buildSection);
  const command = buildSettings?.get(build.artifact.commandKey);
  const env = sections.get(build.artifact.envSection);

  if (!Array.isArray(command)) {
    throw new Error(
      `${build.name}: missing ${build.artifact.serviceName}.${build.artifact.buildSection}.${build.artifact.commandKey} in artifact.toml`,
    );
  }

  return {
    command,
    env: Object.fromEntries(env ?? []),
    publicDir: sections
      .get(build.artifact.buildSection)
      ?.get(build.artifact.publicDirKey),
  };
}

export function readViteBuildOutputDir(contents, build) {
  const outDir = contents.match(
    /\boutDir\s*:\s*path\.resolve\(\s*import\.meta\.dirname\s*,\s*(['"])(.*?)\1\s*\)/,
  )?.[2];

  if (typeof outDir !== "string") {
    throw new Error(
      `${build.name}: could not read Vite build.outDir from ${build.artifact.viteConfigPath}`,
    );
  }

  return outDir;
}

export function compareBuildOutputSettings(
  build,
  artifactSettings,
  viteBuildOutDir,
) {
  if (!build.artifact.publicDirKey) return [];

  if (typeof artifactSettings.publicDir !== "string") {
    return [
      `${build.artifact.buildSection}.${build.artifact.publicDirKey} is missing from artifact.toml`,
    ];
  }

  const artifactPublicDir = resolve(artifactSettings.publicDir);
  const vitePublicDir = resolve(
    dirname(dirname(build.artifact.path)),
    viteBuildOutDir,
  );

  if (artifactPublicDir === vitePublicDir) return [];

  return [
    `production publicDir mismatch (artifact: ${artifactSettings.publicDir}; Vite build.outDir: ${viteBuildOutDir})`,
  ];
}

export function compareBuildSettings(build, artifactSettings) {
  const mismatches = [];
  const localCommand = ["pnpm", ...build.args];

  if (
    JSON.stringify(localCommand) !== JSON.stringify(artifactSettings.command)
  ) {
    mismatches.push(
      `production build command mismatch (validation: ${JSON.stringify(
        localCommand,
      )}; artifact: ${JSON.stringify(artifactSettings.command)})`,
    );
  }

  const envKeys = new Set([
    ...Object.keys(build.env),
    ...Object.keys(artifactSettings.env),
  ]);
  for (const key of [...envKeys].sort()) {
    if (build.env[key] !== artifactSettings.env[key]) {
      mismatches.push(
        `production build environment ${key} mismatch (validation: ${
          build.env[key] ?? "<unset>"
        }; artifact: ${artifactSettings.env[key] ?? "<unset>"})`,
      );
    }
  }

  return mismatches;
}

function validateArtifactSettings(build) {
  try {
    const contents = readFileSync(
      resolve(repositoryRoot, build.artifact.path),
      "utf8",
    );
    const artifactSettings = readArtifactBuildSettings(contents, build);
    const mismatches = compareBuildSettings(build, artifactSettings);

    if (build.artifact.viteConfigPath) {
      const viteConfig = readFileSync(
        resolve(repositoryRoot, build.artifact.viteConfigPath),
        "utf8",
      );
      const viteBuildOutDir = readViteBuildOutputDir(viteConfig, build);
      mismatches.push(
        ...compareBuildOutputSettings(
          build,
          artifactSettings,
          viteBuildOutDir,
        ),
      );
    }

    return mismatches;
  } catch (error) {
    return [error.message];
  }
}

function run() {
  const settingFailures = [];
  for (const build of builds) {
    const mismatches = validateArtifactSettings(build);
    for (const mismatch of mismatches) {
      settingFailures.push({ name: build.name, detail: mismatch });
    }
  }

  if (settingFailures.length > 0) {
    console.error(
      "Production build validation settings do not match artifact configuration:",
    );
    for (const failure of settingFailures) {
      console.error(`FAIL: ${failure.name} — ${failure.detail}`);
    }
    process.exitCode = 1;
    return;
  }

  const results = [];

  for (const build of builds) {
    console.log(`\n=== Production build: ${build.name} ===`);
    const result = spawnSync("pnpm", build.args, {
      cwd: repositoryRoot,
      env: { ...process.env, ...build.env },
      stdio: "inherit",
    });

    if (result.error) {
      results.push({
        name: build.name,
        success: false,
        detail: result.error.message,
      });
    } else if (result.status !== 0) {
      const detail = result.signal
        ? `terminated by signal ${result.signal}`
        : `exited with code ${result.status}`;
      results.push({ name: build.name, success: false, detail });
    } else {
      results.push({ name: build.name, success: true });
    }
  }

  console.log("\n=== Production build summary ===");
  for (const result of results) {
    console.log(
      `${result.success ? "PASS" : "FAIL"}: ${result.name}${
        result.detail ? ` (${result.detail})` : ""
      }`,
    );
  }

  if (results.some((result) => !result.success)) {
    process.exitCode = 1;
  }
}

if (
  process.argv[1] &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  run();
}

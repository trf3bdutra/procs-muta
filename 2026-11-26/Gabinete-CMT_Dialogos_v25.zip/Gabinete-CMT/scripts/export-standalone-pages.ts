/**
 * Export the existing legacy pages, not approximations of their markup.
 * No database, environment variables, live sessions or production APIs are read.
 */
import fs from "node:fs";
import path from "node:path";
import { prepareGabcmtDocument } from "../artifacts/api-server/src/lib/gabcmt-settings-document";

const root = process.cwd();
const protectedDir = path.join(root, "artifacts/api-server/src/protected");
const publicDir = path.join(root, "artifacts/pauta-compartilhada/public");
const out = path.join(root, "generated-artifacts/paginas-independentes");
fs.mkdirSync(out, { recursive: true });
const raw = fs.readFileSync(path.join(protectedDir, "gabcmt.html"), "utf8");
const initial = JSON.parse(raw.match(/<script id="pauta-initial" type="application\/json">([\s\S]*?)<\/script>/)![1]);
Object.assign(initial, {
  rows: [], names: [], sessions: [], sessionDetails: {}, importLog: [],
  pautaPreferences: {}, pautaDaily: {},
  team: { ...initial.team, members: [], unavailability: [], absences: [] },
});
let source = prepareGabcmtDocument(raw.replace(
  /(<script id="pauta-initial" type="application\/json">)[\s\S]*?(<\/script>)/,
  (_, a, b) => a + JSON.stringify(initial).replace(/</g, "\\u003c") + b,
));
// These controllers own the host frame, not either exported page.
for (const id of ["cmt-dev-preview", "cmt-frame-stability-js", "cmt-v169-triagem-fit", "cmtx-v37-rrail-script"]) {
  source = source.replace(new RegExp(`<script\\b[^>]*id="${id}"[^>]*>[\\s\\S]*?<\\/script>`, "i"), "");
}
const fontResponse = await fetch("https://fonts.googleapis.com/css2?family=Figtree:wght@400;600;700;800&display=swap", {
  headers: { "User-Agent": "Mozilla/5.0 Chrome/120.0.0.0 Safari/537.36" },
  signal: AbortSignal.timeout(15000),
});
if (!fontResponse.ok) throw new Error("Não foi possível incorporar a fonte Figtree.");
const allFonts = await fontResponse.text();
let fontCss = Array.from(allFonts.matchAll(/\/\* latin \*\/([\s\S]*?)(?=\/\*|$)/g), match => match[1]).join("\n");
if (!fontCss) fontCss = allFonts;
const fontData = new Map<string, string>();
for (const match of fontCss.matchAll(/url\((https:[^)]+)\)/g)) {
  if (fontData.has(match[1])) continue;
  const response = await fetch(match[1], { signal: AbortSignal.timeout(15000) });
  if (!response.ok) throw new Error("Falha ao incorporar os bytes da fonte Figtree.");
  fontData.set(match[1], "data:font/woff2;base64," + Buffer.from(await response.arrayBuffer()).toString("base64"));
}
fontCss = fontCss.replace(/url\((https:[^)]+)\)/g, (_, url) => `url(${fontData.get(url)})`);
const overrides: Record<string, string> = {
  "/api/app/dialogs/runtime.js": "cmt-app-dialogs.js",
  "/api/app/dialogs/frame.css": "cmt-app-dialogs.css",
  "/api/app/painel-lateral/workspace.js": "cmt-triagem-workspace.js",
  "/api/app/painel-lateral/prontuario.css": "cmt-right-panel.css",
};
function asset(url: string): string | null {
  const clean = url.split("?")[0];
  const candidates = [
    overrides[clean] && path.join(protectedDir, overrides[clean]),
    clean.startsWith("/api/app/") && path.join(protectedDir, "cmt-" + path.basename(clean)),
    path.join(publicDir, clean.replace(/^\//, "")),
  ].filter(Boolean) as string[];
  return candidates.find(p => fs.existsSync(p) && fs.statSync(p).isFile()) || null;
}
function inlineResources(html: string): string {
  html = html.replace(/<script\b([^>]*?)\bsrc=["']([^"']+)["']([^>]*)>\s*<\/script>/gi, (all, before, url, after) => {
    if (url.includes("${")) return all;
    const file = asset(url);
    if (file) return `<script ${before} ${after}>${fs.readFileSync(file, "utf8").replace(/<\/script/gi, "<\\/script")}</script>`;
    // Optional remote libraries must not turn an offline file into a network client.
    if (/^(?:https?:|\/)/.test(url)) return "<!-- optional online script omitted in the independent export -->";
    return all;
  });
  html = html.replace(/<link\b[^>]*href=["']([^"']+)["'][^>]*>/gi, (all, url) => {
    if (url.includes("${")) return all;
    const file = asset(url);
    if (file && file.endsWith(".css")) return `<style>${fs.readFileSync(file, "utf8")}</style>`;
    if (/^(?:https?:|\/)/.test(url)) return "<!-- optional online stylesheet omitted -->";
    return all;
  });
  return html;
}
const shared = inlineResources(source);
for (const [kind, title, file] of [
  ["triagem", "Triagem", "triagem-independente.html"],
  ["sessoes", "Controle de Sessões", "sessoes-independente.html"],
]) {
  const bootstrap = `<script id="independent-bootstrap">
(()=>{
'use strict';
const prefix='gabcmt.independente.${kind}.';
window.CMT_INDEPENDENT_SESSION=${kind === 'sessoes'};
const get=Storage.prototype.getItem,set=Storage.prototype.setItem,remove=Storage.prototype.removeItem;
Storage.prototype.getItem=function(k){return get.call(this,prefix+k)};
Storage.prototype.setItem=function(k,v){return set.call(this,prefix+k,v)};
Storage.prototype.removeItem=function(k){return remove.call(this,prefix+k)};
const open=indexedDB.open.bind(indexedDB);
indexedDB.open=function(name,...rest){return open(prefix+name,...rest)};
window.CMT_AUTH_SESSION={authenticated:true,userId:'arquivo-local',role:'administracao',name:'Arquivo local',server:'LOCAL'};
sessionStorage.setItem('cmt:sessao',JSON.stringify({nome:'Arquivo local',servidor:'LOCAL',papel:'admin'}));
const nativeFetch=window.fetch.bind(window);
window.fetch=(input,options)=>{const url=String(input?.url||input);
if(/^(data:|blob:)/.test(url))return nativeFetch(input,options);
return Promise.reject(new Error('Arquivo independente: conexão com serviços externos desativada. Use Importar JSON ou Exportar JSON.'));};
window.XMLHttpRequest.prototype.send=function(){throw new Error('Serviço externo indisponível no arquivo independente')};
window.EventSource=class{readyState=2;addEventListener(){}removeEventListener(){}close(){}};
location.hash='#/${kind}';
})();
</script>`;
  const footer = `<style id="independent-layout">
${fontCss}
html#independent-page body::before,html#independent-page body::after{display:none!important;content:none!important}
html#independent-page body #alt-side,html#independent-page body #cx-rrail,
html#independent-page body #pauta-global-dock,html#independent-page body #pq-side-panel,
html#independent-page body #alt-qp,html#independent-page body #cmtx-gate{display:none!important}
html#independent-page#independent-page#independent-page body main.app-main{position:fixed!important;inset:44px 0 0!important;margin:0!important;width:100%!important;height:calc(100dvh - 44px)!important;max-width:none!important;padding:0!important;background:#edf1f3!important;transform:none!important}
html#independent-page#independent-page#independent-page body :is(#cmtx-view,#cmt-ref-host){position:absolute!important;inset:0!important;margin:0!important;width:100%!important;height:100%!important;max-width:none!important;box-sizing:border-box;overflow:auto}
html#independent-page{--alt-side-width:0px;--alt-side-w:0px;--cx-rrail-w:0px}
#independent-tools{position:fixed;inset:0 0 auto;height:44px;z-index:2147483500;display:flex;align-items:center;gap:8px;padding:0 14px;box-sizing:border-box;background:#193b43;color:#f5f8f7;font:12px system-ui,sans-serif;border-bottom:2px solid #d2b462}
#independent-tools strong{margin-right:auto}#independent-tools small{color:#d4e0df}#independent-tools button{background:#f5f8f7;color:#193b43;border:0;border-radius:6px;padding:6px 9px;font:inherit;cursor:pointer}
@media(max-width:650px){#independent-tools small{display:none}#independent-tools{padding:0 6px;font-size:10px;gap:4px}}
@media print{#independent-tools{display:none}html#independent-page body main.app-main{position:static!important;height:auto!important}}
</style>
<aside id="independent-tools" aria-label="Arquivo independente">
<strong>${title} · GabCMT</strong><small>Dados locais · sem conexão com o Gabinete</small>
<button id="independent-import" type="button">${kind === 'sessoes' ? 'Importar backup/JSON' : 'Importar JSON'}</button>
<button id="independent-export" type="button">${kind === 'sessoes' ? 'Exportar backup local' : 'Exportar JSON'}</button>
<input id="independent-input" type="file" accept=".json,application/json" hidden>
</aside>
${kind === 'sessoes' ? '<style>' + fs.readFileSync(path.join(protectedDir, 'cmt-independent-session-editor.css'), 'utf8') + '</style>' + ['cmt-independent-sessions.js', 'cmt-independent-session-editor.js'].map(name => '<script>' + fs.readFileSync(path.join(protectedDir, name), 'utf8').replace(/<\/script/gi, '<\\/script') + '</script>').join('') : ''}
<script id="independent-controller">
(()=>{
'use strict';
const kind=${JSON.stringify(kind)};
const open=()=>{
 if(kind==='triagem')window.CMTViews?.open('triagem');
 else {window.CMTSessoes?.abrir('sessoes');window.CMTIndependentSessionEditor?.mount();}
 document.documentElement.classList.remove('pauta-booting');
};
async function start(){
 for(let i=0;i<100;i++){
  if(window.PautaApp&&!PautaApp._exclusive&&window.CMTViews&&window.CMTSessoes){
   open();document.documentElement.dataset.independentReady='true';return;
  }
  await new Promise(r=>setTimeout(r,100));
 }
 const status=document.querySelector('#independent-tools small');
 if(status)status.textContent='Não foi possível iniciar. Abra este arquivo em Chrome ou Edge atualizado.';
}
document.getElementById('independent-import').onclick=()=>document.getElementById('independent-input').click();
document.getElementById('independent-input').onchange=async event=>{
 const file=event.target.files?.[0];if(!file)return;
 try{
  const value=JSON.parse(await file.text()),state=value.state||value;
  if(!Array.isArray(state.rows)||!Array.isArray(state.sessions))throw new Error('O JSON precisa conter rows e sessions, como na exportação de dados do Gabinete.');
  if(value.triagem){if(!Array.isArray(value.triagem.rows))throw new Error('A Triagem importada precisa conter uma lista de processos.');state.team={...(state.team||{}),triagem:value.triagem};}
  PautaApp.restoreSnapshot(state);PautaApp.renderShell();const saved=await PautaApp.saveDB();
  if(saved===false)throw new Error('Não foi possível gravar no armazenamento local deste navegador.');
  if(kind==='sessoes'){CMTSessoes.fechar();document.getElementById('cmt-ref-host')?.remove();}
  open();
 }catch(error){alert('Não foi possível importar: '+error.message)}
 event.target.value='';
};
document.getElementById('independent-export').onclick=()=>{
 try{
  const state=PautaApp.snapshot(),triagem=window.CMTViews?.triagem?.st;
  const blob=new Blob([JSON.stringify({formato:'gabcmt-independente',pagina:kind,state,triagem},null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=kind+'-dados.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
 }catch(error){alert('Não foi possível exportar: '+error.message)}
};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
</script>`;
  let html = shared.replace(/<html\b/, '<html id="independent-page"')
    .replace(/<head\b[^>]*>/i, head => head + '<meta http-equiv="Content-Security-Policy" content="connect-src data: blob:; img-src data: blob:; font-src data:; style-src &#39;unsafe-inline&#39; data:; frame-src data: blob:;">' + bootstrap)
    .replace(/<title>[\s\S]*?<\/title>/i, `<title>${title} — arquivo independente</title>`);
  const end = html.toLowerCase().lastIndexOf("</body>");
  if (end < 0) throw new Error("Missing body terminator");
  html = html.slice(0, end) + footer + html.slice(end);
  fs.writeFileSync(path.join(out, file), html);
  console.log(file, Buffer.byteLength(html), "bytes");
}

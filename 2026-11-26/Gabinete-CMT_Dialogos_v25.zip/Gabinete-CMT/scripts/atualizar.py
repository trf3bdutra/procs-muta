"""Atualiza as Diretrizes do Gerador a partir do Manual CMT (HTML).

Uso (na raiz do workspace):
  python3 scripts/manual-diretrizes/atualizar.py Manual_CMT.html            # grava no gabcmt.html
  python3 scripts/manual-diretrizes/atualizar.py Manual_CMT.html saida.json # só gera o JSON completo

O Gerador lê o bloco <script type="application/json" id="cmt-manual-diretrizes"> do
artifacts/api-server/src/protected/gabcmt.html. A versão embutida não leva o campo "texto"
(o Gerador o calcula ao buscar) nem a introdução "Como usar o aplicativo".

Saída: árvore Parte > seção > tópico, cada tópico com seus blocos (origem, abas, html).
As abas de cada bloco saem do rótulo de origem do próprio manual ("Relatório — …",
"Voto", "Ementa", "Despachos e decisões"). Rótulos sem aba explícita recebem a aba
por regra fixa e ficam marcados com "abasInferidas": true, para conferência.
O texto não é alterado: o html de cada bloco é o do manual.
"""
import hashlib, html, json, re, sys
from datetime import date

ABAS = ('relatorio', 'voto', 'ementa', 'despachos')
EXPLICITAS = {'Relatório': 'relatorio', 'Voto': 'voto', 'Ementa': 'ementa',
              'Despachos e decisões': 'despachos'}
# rótulos sem aba no texto do manual: regra fixa, a conferir
INFERIDAS = {
    'CNJ': ['ementa'],
    'Modo matriz': ['voto'],
    'Banco de parágrafos': ['voto', 'despachos'],
    'Ordem do raciocínio': ['voto', 'despachos'],
}


def texto(h):
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', h))).strip()


def blocos_blk(h):
    """(início, fim, html interno) de cada <div class="blk"> de nível superior, com divs balanceadas."""
    i = 0
    while True:
        ini = h.find('<div class="blk">', i)
        if ini < 0:
            return
        prof, j = 0, ini
        for t in re.finditer(r'<div\b|</div>', h[ini:]):
            prof += 1 if t.group() == '<div' else -1
            if prof == 0:
                j = ini + t.end()
                break
        yield ini, j, h[ini + len('<div class="blk">'):j - len('</div>')]
        i = j


def abas_do_rotulo(rot):
    cab = rot.split(' — ')[0]
    cab = re.sub(r'\s*\((versão do módulo|todos os módulos)\)', '', cab).strip()
    achadas = [EXPLICITAS[p.strip()] for p in cab.split('·') if p.strip() in EXPLICITAS]
    if achadas:
        return achadas, False
    if cab in INFERIDAS:
        return INFERIDAS[cab], True
    return list(ABAS), cab not in ('Formas uniformizadas', 'Sugestão',
                                    'Diretriz complementar do gabinete', 'Vocabulário')


def main(src, dst):
    s = open(src, encoding='utf-8').read()
    main_html = s[s.find('<main'):s.rfind('</main>')]
    # cortes por cabeçalho: parte (section.part), h3 l1, h4 l2, h5 l3
    marc = re.compile(r'<section class="part" id="([^"]+)">.*?<span class="pn">(.*?)</span><h2>(.*?)</h2>'
                      r'|<h([345]) class="hx (l\d)" id="([^"]+)"><span class="sn">(.*?)</span>(.*?)</h\4>', re.S)
    ms = list(marc.finditer(main_html))
    partes, cur_p, pilha = [], None, []
    for i, m in enumerate(ms):
        fim = ms[i + 1].start() if i + 1 < len(ms) else len(main_html)
        corpo = main_html[m.end():fim]
        corpo = re.sub(r'</section>\s*$', '', corpo.strip())
        if m.group(1):
            cur_p = {'id': m.group(1), 'rotulo': texto(m.group(2)), 'titulo': texto(m.group(3)),
                     'subtitulo': texto(re.search(r'<p class="psub">(.*?)</p>', corpo, re.S).group(1))
                     if 'class="psub"' in corpo else '', 'filhos': []}
            partes.append(cur_p); pilha = []
            continue
        nivel = int(m.group(5)[1])
        no = {'id': m.group(6), 'numero': texto(m.group(7)), 'titulo': texto(m.group(8)),
              'nivel': nivel, 'blocos': [], 'filhos': []}
        # blocos com origem
        pos = 0
        for ini, fim_b, interno in blocos_blk(corpo):
            antes = corpo[pos:ini].strip()
            if texto(antes):
                no['blocos'].append({'origem': '', 'abas': list(ABAS), 'abasInferidas': True, 'html': antes})
            bt = re.match(r'\s*<div class="bt">(.*?)</div>', interno, re.S)
            if bt:
                interno = interno[bt.end():]
            org = re.match(r'\s*<div class="org">(.*?)</div>', interno, re.S)
            rot = texto(org.group(1)) if org else ''
            if org:
                interno = interno[org.end():]
            abas, inf = abas_do_rotulo(rot) if rot else (list(ABAS), True)
            no['blocos'].append({'titulo': texto(bt.group(1)) if bt else '', 'origem': rot, 'abas': abas,
                                 'abasInferidas': inf, 'html': interno.strip()})
            pos = fim_b
        resto = corpo[pos:].strip()
        if texto(resto):
            no['blocos'].append({'origem': '', 'abas': list(ABAS), 'abasInferidas': True, 'html': resto})
        while pilha and pilha[-1]['nivel'] >= nivel:
            pilha.pop()
        (pilha[-1]['filhos'] if pilha else cur_p['filhos']).append(no)
        pilha.append(no)

    def fechar(no):
        for f in no['filhos']:
            fechar(f)
        ab = set(a for b in no['blocos'] for a in b['abas'])
        for f in no['filhos']:
            ab |= set(f['abas'])
        no['abas'] = [a for a in ABAS if a in ab] or list(ABAS)
        no['texto'] = ' '.join(texto(b['html']) for b in no['blocos'])
    for p in partes:
        for f in p['filhos']:
            fechar(f)

    intro = [p for p in partes if p['id'] == 'intro']
    diretrizes = [p for p in partes if p['id'] != 'intro']
    edicao = re.search(r'Edição de ([^·<]+)', s)
    saida = {
        'schema': 'gabcmt.referencias.manual-diretrizes', 'versao': '1.0.0',
        'atualizadoEm': date.today().isoformat(),
        'fonte': {'arquivo': src.rsplit('/', 1)[-1], 'edicao': edicao.group(1).strip() if edicao else '',
                  'sha256': hashlib.sha256(s.encode('utf-8')).hexdigest()},
        'abas': {'relatorio': 'Relatório', 'voto': 'Minuta — voto', 'ementa': 'Ementa',
                 'despachos': 'Minuta — despachos e decisões'},
        'partes': diretrizes,
        'ajuda': intro,
    }
    json.dump(saida, open(dst, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    def andar(nos, d=0):
        for n in nos:
            inf = sum(b['abasInferidas'] and bool(b['origem']) for b in n['blocos'])
            print('  ' * d + f"{n['numero']} {n['titulo'][:60]} · {','.join(n['abas'])} · {len(n['blocos'])} bl" + (f' · {inf} inferido(s)' if inf else ''))
            andar(n['filhos'], d + 1)
    for p in diretrizes:
        print(p['rotulo'], '—', p['titulo']); andar(p['filhos'], 1)


GABCMT = 'artifacts/api-server/src/protected/gabcmt.html'


def embutir(json_path, gab=GABCMT):
    d = json.load(open(json_path, encoding='utf-8'))

    def limpa(n):
        n.pop('texto', None); n.pop('abas', None)
        for f in n['filhos']:
            limpa(f)
    for p in d['partes']:
        for f in p['filhos']:
            limpa(f)
    d.pop('ajuda', None)
    d['gerador'] = 'Painel Diretrizes do Gerador: blocos recortados pela aba do documento (relatorio, voto, ementa, despachos).'
    txt = json.dumps(d, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    s = open(gab, encoding='utf-8').read()
    abre = '<script type="application/json" id="cmt-manual-diretrizes">'
    i = s.index(abre); j = s.index('</script>', i)
    s = s[:i + len(abre)] + txt + s[j:]
    open(gab, 'w', encoding='utf-8').write(s)
    print(f'gabcmt.html atualizado ({len(txt.encode()):,} bytes de diretrizes)')


if __name__ == '__main__':
    if len(sys.argv) > 2:
        main(sys.argv[1], sys.argv[2])
    else:
        import os, tempfile
        tmp = os.path.join(tempfile.mkdtemp(), 'manual-diretrizes.json')
        main(sys.argv[1], tmp)
        embutir(tmp)

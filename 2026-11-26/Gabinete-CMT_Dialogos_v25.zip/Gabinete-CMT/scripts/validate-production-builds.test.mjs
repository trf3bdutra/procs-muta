import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import { resolve } from "node:path";
import {
  compareBuildOutputSettings,
  compareBuildSettings,
  readArtifactBuildSettings,
  readViteBuildOutputDir,
} from "./validate-production-builds.mjs";

const root = resolve(import.meta.dirname, "..");
const artifactPath =
  "artifacts/pauta-compartilhada/.replit-artifact/artifact.toml";
const apiBuild = {
  name: "API Server",
  args: ["--filter", "@workspace/api-server", "run", "build"],
  env: { PORT: "20816" },
  artifact: {
    path: artifactPath,
    serviceName: "api",
    buildSection: "services.production",
    commandKey: "build",
    envSection: "services.env",
  },
};
const webBuild = {
  name: "Gabinete CMT web",
  args: ["--filter", "@workspace/pauta-compartilhada", "run", "build"],
  env: { PORT: "20815", BASE_PATH: "/" },
  artifact: {
    path: artifactPath,
    serviceName: "web",
    buildSection: "services.production",
    commandKey: "build",
    envSection: "services.env",
    publicDirKey: "publicDir",
    viteConfigPath: "artifacts/pauta-compartilhada/vite.config.ts",
  },
};

test("local production checks match both artifact build commands and environments", () => {
  const contents = readFileSync(resolve(root, artifactPath), "utf8");
  for (const build of [apiBuild, webBuild]) {
    assert.deepEqual(
      compareBuildSettings(build, readArtifactBuildSettings(contents, build)),
      [],
      `${build.name} should match its artifact configuration`,
    );
  }

  const artifactContents = readFileSync(
    resolve(root, artifactPath),
    "utf8",
  );
  const viteConfig = readFileSync(
    resolve(root, webBuild.artifact.viteConfigPath),
    "utf8",
  );
  const artifactSettings = readArtifactBuildSettings(
    artifactContents,
    webBuild,
  );
  assert.deepEqual(
    compareBuildOutputSettings(
      webBuild,
      artifactSettings,
      readViteBuildOutputDir(viteConfig, webBuild),
    ),
    [],
    `${webBuild.name} should publish the Vite build output`,
  );
});

test("reports a changed Vite output directory with the artifact name", () => {
  const artifactContents = readFileSync(
    resolve(root, artifactPath),
    "utf8",
  );
  const viteConfig = readFileSync(
    resolve(root, webBuild.artifact.viteConfigPath),
    "utf8",
  ).replace("'dist/public'", "'dist/changed'");
  const artifactSettings = readArtifactBuildSettings(
    artifactContents,
    webBuild,
  );

  assert.deepEqual(
    compareBuildOutputSettings(
      webBuild,
      artifactSettings,
      readViteBuildOutputDir(viteConfig, webBuild),
    ),
    [
      "production publicDir mismatch (artifact: artifacts/pauta-compartilhada/dist/public; Vite build.outDir: dist/changed)",
    ],
  );
});

test("reports a changed build command and environment with the artifact name", () => {
  const build = {
    ...webBuild,
    args: ["--filter", "@workspace/changed", "run", "build"],
    env: { PORT: "3000" },
  };
  const settings = {
    command: [
      "pnpm",
      "--filter",
      "@workspace/pauta-compartilhada",
      "run",
      "build",
    ],
    env: { PORT: "20815", BASE_PATH: "/" },
  };

  assert.deepEqual(compareBuildSettings(build, settings), [
    'production build command mismatch (validation: ["pnpm","--filter","@workspace/changed","run","build"]; artifact: ["pnpm","--filter","@workspace/pauta-compartilhada","run","build"])',
    "production build environment BASE_PATH mismatch (validation: <unset>; artifact: /)",
    "production build environment PORT mismatch (validation: 3000; artifact: 20815)",
  ]);
});

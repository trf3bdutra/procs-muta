import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {setTimeout as delay} from 'node:timers/promises';
import assert from 'node:assert/strict';
const dir=path.resolve('generated-artifacts/paginas-independentes');
for(const kind of ['triagem','sessoes']){
 const profile=await fs.mkdtemp(path.join(os.tmpdir(),'gabcmt-html-'));
 const child=spawn('/repl/tools/bin/chromium',['--headless','--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--no-first-run','--disable-background-networking','--remote-debugging-port=0',`--user-data-dir=${profile}`,'about:blank'],{stdio:'ignore',detached:true});
 let socket;
 try{
  let port;
  for(let i=0;i<100;i++){try{port=(await fs.readFile(path.join(profile,'DevToolsActivePort'),'utf8')).split('\n')[0];break}catch{}await delay(50)}
  const targets=await(await fetch(`http://localhost:${port}/json/list`)).json();
  socket=new WebSocket(targets.find(t=>t.type==='page').webSocketDebuggerUrl);
  await new Promise((r,j)=>{socket.addEventListener('open',r,{once:true});socket.addEventListener('error',j,{once:true})});
  const pending=new Map();let seq=0;const errors=[],requests=[],responses=[];
  socket.addEventListener('message',e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);if(m.error)p?.reject(m.error);else p?.resolve(m.result)}
   if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.text+': '+m.params.exceptionDetails.exception?.description);
   if(m.method==='Network.requestWillBeSent')requests.push(m.params.request.url);
   if(m.method==='Network.responseReceived')responses.push(m.params.response.url);
  });
  const send=(method,params={})=>new Promise((resolve,reject)=>{const id=++seq;pending.set(id,{resolve,reject});socket.send(JSON.stringify({id,method,params}))});
  const evaluate=async expression=>{const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result?.value};
  await send('Runtime.enable');await send('Page.enable');await send('Network.enable');
  await send('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});
  await send('Page.navigate',{url:'file://'+path.join(dir,kind+'-independente.html')});
  let state;
  for(let i=0;i<100;i++){
   await delay(150);
   state=await evaluate(`({ready:document.documentElement.dataset.independentReady,view:window.CMTViews?.active?.(),sessions:window.CMTSessoes?.aberto?.(),text:document.body?.innerText?.slice(-800),url:location.href})`);
   if(state.ready==='true')break;
  }
  console.log(kind,'START',state,'ERRORS',errors);
  console.log('LAYOUT',await evaluate(`({id:document.documentElement.id,bodyClass:document.body.className,main:document.querySelector('main.app-main')?.getBoundingClientRect().toJSON(),side:document.getElementById('alt-side')&&getComputedStyle(document.getElementById('alt-side')).display,rail:document.getElementById('cx-rrail')&&getComputedStyle(document.getElementById('cx-rrail')).display,rules:document.getElementById('independent-layout')?.sheet?.cssRules?.length,cover:document.elementsFromPoint(50,200).slice(0,5).map(e=>({tag:e.tagName,id:e.id,cls:e.className})),before:getComputedStyle(document.body,'::before').display})`));
  assert.equal(state.ready,'true');
  assert.equal(kind==='triagem'?state.view:state.sessions,kind==='triagem'?'triagem':true);
  const layout=await evaluate(`(()=>{const id=${JSON.stringify(kind)}==='triagem'?'cmtx-view':'cmt-ref-host',r=document.getElementById(id).getBoundingClientRect();return {left:r.left,right:r.right,top:r.top,width:innerWidth,rail:document.getElementById('cx-rrail')?.getBoundingClientRect().width||0,before:getComputedStyle(document.body,'::before').display}})()`);
  assert.equal(layout.left,0);assert.equal(layout.right,layout.width);assert.equal(layout.top,44);
  assert.equal(layout.rail,0);assert.equal(layout.before,'none');
  if(kind==='sessoes'){
   const editor=await evaluate(`(async()=>{
    const wait=()=>new Promise(r=>setTimeout(r,100));
    const submit=async(selector,values,allowError=false)=>{
     const f=document.querySelector(selector);if(!f)throw Error('Formulário não encontrado: '+selector);
     for(const [k,v]of Object.entries(values))f.elements[k].value=v;
     f.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));
     for(let i=0;i<50;i++){await wait();if(!document.querySelector('[data-ise-status]')?.textContent.includes('Salvando'))break;}
     if(!allowError&&document.querySelector('[data-ise-status]')?.classList.contains('err'))throw Error(document.querySelector('[data-ise-status]').textContent);
    };
    await submit('[data-ise-sform]',{date:'2027-02-04',pecoDia:'2027-01-10',prepStart:'2027-01-20',minutasDeadline:'2027-01-28',releaseDeadline:'2027-02-02'});
    const session=CMTIndependentSessions.list()[0].session;
    await submit('[data-ise-pform]',{Processo:'123','Item (Pauta de Julgamento)':'1'},true);
    if(CMTIndependentSessions.rows(session).length)throw Error('CNJ inválido aceito');
    const one='9000001-00.2027.4.03.0000',two='9000002-00.2027.4.03.0000';
    await submit('[data-ise-pform]',{Processo:one,'Item (Pauta de Julgamento)':'1',Partes:'A × B',Assunto:'Assunto 1',SERVIDOR:'Exemplo',CORRETOR:'Revisor'});
    await submit('[data-ise-pform]',{Processo:two,'Item (Pauta de Julgamento)':'2',Partes:'C × D'});
    document.querySelector('[data-ise-down]').click();await wait();await wait();
    if(CMTIndependentSessions.rows(session)[0].Processo!==two)throw Error('Reordenação falhou');
    document.querySelector('[data-ise-edit="'+one+'"]').click();
    await submit('[data-ise-pform]',{Assunto:'Assunto atualizado'});
    window.confirm=()=>true;
    document.querySelector('[data-ise-remove="'+two+'"]').click();await wait();await wait();
    if(CMTIndependentSessions.rows(session).length!==1||PautaApp.rows.length!==2)throw Error('Retirada local excluiu ficha ou não removeu vínculo');
    const data=CMTIndependentSessions.exportSession(session);CMTSessionTransfer.validate(data);
    let exported;const create=URL.createObjectURL;URL.createObjectURL=blob=>{exported=blob;return create(blob)};
    document.querySelector('[data-ise-export]').click();URL.createObjectURL=create;
    if(!exported||(JSON.parse(await exported.text())).formato!=='controle-pauta-hub-sessoes')throw Error('Download da sessão inválido');
    document.querySelector('.cmt-ref-tabs [data-ref-aba="controle"]').click();
    if(!document.querySelector('#cmt-ref-host .ses-t tbody tr'))throw Error('Aba original não foi preservada: '+JSON.stringify({sessions:PautaApp.sessions,tab:document.querySelector('#cmt-ref-host')?.dataset.refAba,panes:document.querySelector('#cmt-ref-host .cmt-ref-panes')?.innerHTML.slice(0,1200)}));
    if(PautaControl.sessionRows(PautaApp,session).length!==1)throw Error('O total da pauta não acompanha a listagem');
    document.querySelector('.cmt-ref-tabs [data-ref-aba="montar"]').click();
    window.__exportedSession=data;
    return {session,processes:data.rows.length,dates:data.sessionDetails[session],assunto:data.rows[0].Assunto,formato:data.formato};
   })()`);
   console.log('EDITOR',editor);assert.equal(editor.processes,1);assert.equal(editor.assunto,'Assunto atualizado');assert.equal(editor.dates.pecoDia,'2027-01-10');
   await fs.writeFile(path.join(dir,'sessoes-editor-verificacao.png'),Buffer.from((await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false})).data,'base64'));
   const appImport=await evaluate(`(async()=>{
    const wait=()=>new Promise(r=>setTimeout(r,100));
    window.CMT_INDEPENDENT_SESSION=false;CMTSessoes.fechar();document.getElementById('cmt-ref-host').remove();CMTSessoes.abrir('sessoes');
    const button=document.querySelector('[data-ses-import]');if(!button)throw Error('Ação autenticada de importar não disponível');
    button.click();
    let input=document.querySelector('#cmt-settings-dialog [data-hub-file="sessions"]');if(!input)throw Error('Entrada do importador do app não disponível: '+document.body.innerText.slice(-500));
    const file=new File([JSON.stringify(window.__exportedSession)],'sessao.json',{type:'application/json'});
    const receive=async()=>{
     input=document.querySelector('#cmt-settings-dialog [data-hub-file="sessions"]');
     const dt=new DataTransfer();dt.items.add(file);input.files=dt.files;input.dispatchEvent(new Event('change',{bubbles:true}));
     for(let i=0;i<30;i++){await wait();if(document.querySelector('[data-hub-form="import"]'))break;}
     const form=document.querySelector('[data-hub-form="import"]');if(!form)throw Error('Prévia de importação não abriu');
     if(form.querySelector('[name="team"]').checked||form.querySelector('[name="calendar"]').checked)throw Error('Equipe/calendário marcados por padrão');
     if(!form.innerText.includes('Peço-dia'))throw Error('Prévia não informa os marcos');
     return form;
    };
    const before=JSON.stringify(PautaApp.rows);let form=await receive();
    if(JSON.stringify(PautaApp.rows)!==before)throw Error('Leitura da prévia alterou a pauta');
    const submit=async f=>{f.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));for(let i=0;i<50;i++){await wait();if(!document.querySelector('[data-hub-form="import"]'))return;}throw Error('Importação não foi confirmada: '+document.body.innerText.slice(-700))};
    await submit(form);const count=PautaApp.rows.length;await submit(await receive());
    if(PautaApp.rows.length!==count)throw Error('Reimportação duplicou processos');
    CMTAppDialogs.closeSettings();window.CMT_INDEPENDENT_SESSION=true;
    CMTSessoes.fechar();document.getElementById('cmt-ref-host')?.remove();CMTSessoes.abrir('sessoes');CMTIndependentSessionEditor.mount();
    return {count,preview:true,reimport:true};
   })()`);
   console.log('APP IMPORT',appImport);assert.equal(appImport.preview,true);assert.equal(appImport.reimport,true);
  }
  const importResult=await evaluate(`(async()=>{
   const state=PautaApp.snapshot();
   state.sessions=['2027-02-04'];state.sessionDetails={'2027-02-04':{date:'2027-02-04',prepStart:'2027-01-21',minutasDeadline:'2027-01-28',releaseDeadline:'2027-02-02'}};
   state.rows=[{Processo:'9000001-00.2027.4.03.0000',SERVIDOR:'EXEMPLO',Partes:'Parte A × Parte B','Sessão Destino':'2027-02-04','Item (Pauta de Julgamento)':'1'}];
   state.names=['EXEMPLO'];state.team.members=[{id:'exemplo',name:'EXEMPLO',active:true}];
   const triagem=structuredClone(CMTViews.triagem.st);
   const file=new File([JSON.stringify({state,triagem})],'teste.json',{type:'application/json'});
   const input=document.getElementById('independent-input');
   await input.onchange({target:{files:[file],value:''}});
   return {rows:PautaApp.rows.length,sessions:PautaApp.sessions.length};
  })()`);
  await delay(700);
  console.log(kind,'IMPORT',importResult);
  assert.equal(importResult.rows,1);assert.equal(importResult.sessions,1);
  if(kind==='sessoes'){
   assert.equal(await evaluate(`!!document.querySelector('#cmt-ref-host .ses-t tbody tr')`),true);
   await evaluate(`CMTSessoes.aba('designacoes')`);
   assert.equal(await evaluate(`document.querySelector('#cmt-ref-host').dataset.refAba`),'designacoes');
   await evaluate(`CMTSessoes.aba('controle')`);
  }
  await fs.writeFile(path.join(dir,kind+'-verificacao.png'),Buffer.from((await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false})).data,'base64'));
  await send('Page.reload');
  await delay(2500);
  const persisted=await evaluate(`({rows:window.PautaApp?.rows?.length,sessions:window.PautaApp?.sessions?.length,ready:document.documentElement.dataset.independentReady})`);
  assert.equal(persisted.rows,1);assert.equal(persisted.sessions,1);
  const unexpected=requests.filter(u=>/^https?:/.test(u));
  console.log(kind,'RELOAD',persisted,'NETWORK count',unexpected.length,'EXCEPTIONS',errors);
  assert.equal(errors.length,0);
  assert.equal(responses.filter(u=>/^https?:/.test(u)).length,0);
 }finally{socket?.close();try{process.kill(-child.pid,'SIGTERM')}catch{}await fs.rm(profile,{recursive:true,force:true}).catch(()=>{})}
}

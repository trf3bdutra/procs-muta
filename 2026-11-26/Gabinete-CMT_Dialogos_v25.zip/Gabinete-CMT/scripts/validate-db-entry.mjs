import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const repositoryRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const packagePath = resolve(repositoryRoot, "lib/db/package.json");

const fail = (message) => {
  console.error(`Database entry validation failed: ${message}`);
  process.exitCode = 1;
};

let dbPackage;
try {
  dbPackage = JSON.parse(await readFile(packagePath, "utf8"));
} catch (error) {
  fail(`could not read lib/db/package.json (${error.message})`);
  process.exit();
}

const entryPath = dbPackage.exports?.["."];
if (typeof entryPath !== "string" || !entryPath.endsWith(".ts")) {
  fail('the "." export in lib/db/package.json must point to a TypeScript file');
  process.exit();
}

const sourcePath = resolve(repositoryRoot, "lib/db", entryPath);
if (!sourcePath.endsWith(".ts")) {
  fail("the database entry point must use the .ts extension");
  process.exit();
}

let source;
try {
  source = await readFile(sourcePath, "utf8");
} catch (error) {
  fail(`could not read ${entryPath} (${error.message})`);
  process.exit();
}

const missingExports = [
  ['export const pool', /\bexport\s+const\s+pool\b/],
  ['export const db', /\bexport\s+const\s+db\b/],
  ['schema re-export', /\bexport\s+\*\s+from\s+["']\.\/schema["']/],
].filter(([, pattern]) => !pattern.test(source));

if (missingExports.length > 0) {
  fail(`missing expected ${missingExports.map(([name]) => name).join(", ")}`);
}

const misplacedStyles = source.match(/^\s*@(?:import|theme)\b.*$/gm) ?? [];
if (misplacedStyles.length > 0) {
  fail(
    `CSS directives are not allowed in the database entry point: ${misplacedStyles
      .map((directive) => directive.trim())
      .join("; ")}`,
  );
}

if (process.exitCode !== 1) {
  console.log("Database entry validation passed.");
}

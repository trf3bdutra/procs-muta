import fs from "node:fs";
import path from "node:path";

const dir = process.argv[2];
if (!dir) throw Error("Usage: node scripts/summarize-pauta-profile.mjs <profile-directory>");
const summary = JSON.parse(fs.readFileSync(path.join(dir, "summary.json"), "utf8"));
const cpu = JSON.parse(fs.readFileSync(path.join(dir, "cpu.json"), "utf8"));
const sampled = new Map();
for (let i = 0; i < cpu.samples.length; i++) {
  const id = cpu.samples[i];
  sampled.set(id, (sampled.get(id) || 0) + cpu.timeDeltas[i]);
}
const functions = new Map();
for (const node of cpu.nodes) {
  const frame = node.callFrame;
  const key = JSON.stringify([frame.functionName, frame.url.replace(/:\d+(?=\/)/, ":PORT"), frame.lineNumber + 1]);
  const total = functions.get(key) || { name: frame.functionName, url: frame.url, line: frame.lineNumber + 1, selfMs: 0 };
  total.selfMs += (sampled.get(node.id) || 0) / 1000;
  functions.set(key, total);
}
const result = {
  rows: summary.rowsCount, width: summary.width, timerDiagnostics: summary.timerDiagnostics,
  attributionWithoutProntuario: summary.attributionWithoutProntuario,
  connectedNodes: summary.state.nodes,
  phases: summary.phases.map(phase => {
    const tasks = summary.state.long.filter(task => task.start >= phase.start && task.start < phase.end);
    return {
      name: phase.name, elapsedMs: Math.round(phase.end - phase.start),
      longTasks: tasks.length,
      maxTaskMs: Math.round(Math.max(0, ...tasks.map(task => task.duration))),
      blockingMs: Math.round(tasks.reduce((sum, task) => sum + Math.max(0, task.duration - 50), 0)),
      renderedCards: phase.state.rows.length, expandedCards: phase.state.expanded,
      scroll: phase.state.scroll, error: phase.actionError,
    };
  }),
  errors: summary.errors,
  fixtureRequests: summary.requests.reduce((counts, request) => {
    counts[request.method] = (counts[request.method] || 0) + 1;
    return counts;
  }, {}),
  topSelfCpu: [...functions.values()].sort((a, b) => b.selfMs - a.selfMs).slice(0, 12)
    .map(value => ({ ...value, selfMs: Math.round(value.selfMs) })),
};
console.log(JSON.stringify(result, null, 2));

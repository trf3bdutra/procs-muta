#!/usr/bin/env bash
set -euo pipefail

cd "$(git rev-parse --show-toplevel)"

dependency_stamp="node_modules/.cache/post-merge-dependencies.sha256"

dependency_fingerprint() {
  {
    sha256sum pnpm-lock.yaml pnpm-workspace.yaml
    git ls-files -z -- 'package.json' '**/package.json' |
      sort -z |
      xargs -0 -r sha256sum
  } | sha256sum | awk '{print $1}'
}

current_fingerprint="$(dependency_fingerprint)"
installed_lock="node_modules/.pnpm/lock.yaml"

if [[ ! -s "$dependency_stamp" ]] ||
  [[ "$(cat "$dependency_stamp")" != "$current_fingerprint" ]] ||
  [[ ! -f "$installed_lock" ]] ||
  ! cmp -s pnpm-lock.yaml "$installed_lock"; then
  echo "Workspace dependencies changed; installing from the frozen lockfile."
  pnpm install --frozen-lockfile
  mkdir -p "$(dirname "$dependency_stamp")"
  printf '%s\n' "$current_fingerprint" > "$dependency_stamp"
else
  echo "Workspace dependencies unchanged; skipping installation."
fi

echo "Applying the development database schema."
pnpm --filter @workspace/db run push

/**
 * Read-only performance harness for the complete delivered legacy editor.
 * All APIs are served by a loopback fixture. No real session, database or writes.
 * Bundle with esbuild, then run with --rows=30 or --rows=300.
 */
import fs from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import http from "node:http";
import { spawn } from "node:child_process";
import { setTimeout as delay } from "node:timers/promises";
import { prepareGabcmtDocument } from "../artifacts/api-server/src/lib/gabcmt-settings-document";
import { prepareGabcmtDataDocument } from "../artifacts/api-server/src/lib/gabcmt-data-modules";
import { prepareGabcmtFeatureDocument } from "../artifacts/api-server/src/lib/gabcmt-feature-modules";

const cwd = process.cwd();
const protectedDir = path.join(cwd, "artifacts/api-server/src/protected");
const publicDir = path.join(cwd, "artifacts/pauta-compartilhada/public");
const rowsCount = Number(process.argv.find(a => a.startsWith("--rows="))?.split("=")[1] || 300);
const width = Number(process.argv.find(a => a.startsWith("--width="))?.split("=")[1] || 1440);
const timerDiagnostics = process.argv.includes("--timer-diagnostics");
const visualOnly = process.argv.includes("--visual-only");
const out = process.argv.find(a => a.startsWith("--out="))?.slice(6) || `/tmp/pauta-profile-${rowsCount}`;
await fs.mkdir(out, { recursive: true });
const raw = await fs.readFile(path.join(protectedDir, "gabcmt.html"), "utf8");
const seed = JSON.parse(raw.match(/<script id="pauta-initial" type="application\/json">([\s\S]*?)<\/script>/)![1]);
const session = "13/11/2026";
seed.rows = Array.from({ length: rowsCount }, (_, i) => ({
  Processo: `${String(9000001 + i)}-00.2026.4.03.0000`,
  Assunto: `Assunto de teste ${i % 8}`, Partes: "PARTE A × PARTE B",
  SERVIDOR: "TESTE", CORRETOR: "TESTE", MINUTADO: i % 3 ? "Sim" : "",
  "Sessão Destino": session, "Item (Pauta de Julgamento)": String(i + 1),
  "Status de Julgamento": "PAUTADO", COMPLEXIDADE: "1",
  _pautaEntries: [{ session, item: String(i + 1), status: "PAUTADO", closed: false }],
}));
seed.names = ["TESTE"];
seed.sessions = [session];
seed.team.members = [{ id: "perf", name: "TESTE", hierarchy: "Membro do Time", active: true }];
seed.pautaPreferences.session = session;
seed.pautaPreferences.jsonSessionLists = { [session]: seed.rows.map(r => r.Processo.replace(/\D/g, "")) };
seed.pautaDaily = {};
const identity = { authenticated: true, userId: "performance-fixture", role: "administracao", name: "Teste", server: "TESTE" };
let prepared = prepareGabcmtDocument(raw.replace(
  /(<script id="pauta-initial" type="application\/json">)[\s\S]*?(<\/script>)/,
  (_, a, b) => a + JSON.stringify(seed) + b,
));
const data = prepareGabcmtDataDocument(prepared);
const features = prepareGabcmtFeatureDocument(data.html);
prepared = features.html
  .replace(/<style\b(?=[^>]*\bid=["']cmt-v265-cal-css["'])[^>]*>[\s\S]*?<\/style>/i, "")
  .replace(/<script\b(?=[^>]*\bid=["']cmt-v265-cal["'])[^>]*>[\s\S]*?<\/script>/i, "");
prepared = prepared.replace(/<head[^>]*>/i, head => head + `<base href="/"><link rel="stylesheet" href="/api/app/pauta-side-panel.css"><script src="/api/app/pauta-side-panel.js"></script><script>window.CMT_AUTH_SESSION=${JSON.stringify(identity)};sessionStorage.setItem('cmt:sessao',JSON.stringify({nome:'Teste',servidor:'TESTE',papel:'admin'}));</script>`);
if (process.argv.includes("--without-header-timer")) {
  prepared = prepared.replace(/<script\b[^>]*id="cmt-v259-pauta-hdr"[^>]*>[\s\S]*?<\/script>/, "");
}
// Attribution experiment only: never changes the application's source files.
if (process.argv.includes("--without-prontuario-paint")) {
  const target = "function paint(force) {\n        const inPauta = vis();";
  if (!prepared.includes(target)) throw Error("Prontuário attribution target changed");
  prepared = prepared.replace(target, "function paint(force) {\n        return; /* isolated only in this fixture */\n        const inPauta = vis();");
}
await fs.writeFile(path.join(out, "fixture.html"), prepared);
const requests: any[] = [];
const apiFiles: Record<string, string> = {
  "/api/app/session-transfer.js": "cmt-session-transfer.js",
  "/api/app/dialogs/runtime.js": "cmt-app-dialogs.js",
  "/api/app/dialogs/frame.css": "cmt-app-dialogs.css",
  "/api/app/painel-lateral/prontuario.css": "cmt-right-panel.css",
  "/api/app/painel-lateral/workspace.js": "cmt-triagem-workspace.js",
  "/api/app/urgency-whatsapp.js": "cmt-urgency-whatsapp.js",
};
for (const name of ["daily-workspace", "pauta-side-panel", "geradores-ementario"]) {
  for (const ext of ["js", "css"]) apiFiles[`/api/app/${name}.${ext}`] = `cmt-${name}.${ext}`;
}
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url!, "http://fixture");
  const p = url.pathname;
  requests.push({ method: req.method, path: p });
  try {
    if (p === "/gabinete") {
      res.setHeader("Content-Type", "text/html; charset=utf-8"); res.end(prepared); return;
    }
    const asset = p.startsWith("/api/app/gabcmt-dados/") ? data.assets[path.basename(p)]
      : p.startsWith("/api/app/gabcmt-feature-modules/") ? features.assets[path.basename(p)] : null;
    if (asset) { res.setHeader("Content-Type", asset.contentType); res.end(asset.content); return; }
    if (p === "/api/app/painel-lateral/rail.js") {
      const tag = raw.match(/<script\b[^>]*id="cmtx-v37-rrail-script"[^>]*>([\s\S]*?)<\/script>/);
      res.setHeader("Content-Type", "application/javascript"); res.end(tag?.[1] || ""); return;
    }
    if (apiFiles[p]) {
      const content = await fs.readFile(path.join(protectedDir, apiFiles[p]));
      res.setHeader("Content-Type", p.endsWith(".css") ? "text/css" : "application/javascript"); res.end(content); return;
    }
    if (p.startsWith("/api/")) {
      res.setHeader("Content-Type", "application/json");
      res.end(JSON.stringify(p === "/api/auth/session" ? identity
        : p === "/api/pauta" ? { revision: 1, state: seed }
        : p.includes("catalog") ? { revision: 0, catalogs: {} }
        : p.includes("central/estado") ? { state: {} }
        : p.includes("presence") ? { users: [] } : {})); return;
    }
    if (!p.includes("..")) {
      const content = await fs.readFile(path.join(publicDir, p.slice(1)));
      res.setHeader("Content-Type", p.endsWith(".js") ? "application/javascript" : p.endsWith(".css") ? "text/css" : p.endsWith(".svg") ? "image/svg+xml" : "image/png");
      res.end(content); return;
    }
  } catch {}
  res.statusCode = 404; res.end();
});
await new Promise<void>(r => server.listen(0, "127.0.0.1", r));
const origin = `http://pauta-perf.test:${(server.address() as any).port}`;
const profile = await fs.mkdtemp(path.join(os.tmpdir(), "pauta-cdp-"));
const browser = spawn("/repl/tools/bin/chromium", ["--headless", "--no-sandbox", "--disable-dev-shm-usage",
  "--disable-gpu", "--no-first-run", "--no-default-browser-check", "--disable-background-networking",
  "--host-resolver-rules=MAP pauta-perf.test 127.0.0.1", "--no-proxy-server",
  "--remote-debugging-port=0", `--user-data-dir=${profile}`, "about:blank"], { stdio: "ignore", detached: true });
let socket: WebSocket;
const pending = new Map<number, any>(); let id = 0;
const events = new Map<string, (params: any) => void>();
const send = (method: string, params = {}) => new Promise<any>((resolve, reject) => {
  const n = ++id; pending.set(n, { resolve, reject });
  socket.send(JSON.stringify({ id: n, method, params }));
});
const evaluate = async (expression: string) => {
  const r = await send("Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result?.value;
};
const errors: any[] = [];
try { testRun: {
  let port = 0;
  for (let i = 0; i < 100 && !port; i++) {
    try { port = Number((await fs.readFile(path.join(profile, "DevToolsActivePort"), "utf8")).split("\n")[0]); } catch { await delay(100); }
  }
  const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
  socket = new WebSocket(targets.find(t => t.type === "page").webSocketDebuggerUrl);
  await new Promise<void>(r => socket.addEventListener("open", () => r(), { once: true }));
  socket.addEventListener("message", e => {
    const m = JSON.parse(String(e.data));
    if (m.id && pending.has(m.id)) {
      const p = pending.get(m.id); pending.delete(m.id); m.error ? p.reject(Error(m.error.message)) : p.resolve(m.result);
    } else if (m.method) events.get(m.method)?.(m.params);
  });
  await send("Page.enable"); await send("Runtime.enable"); await send("Network.enable");
  await send("Network.setBlockedURLs", { urls: ["https://*", "http://api.*"] });
  events.set("Runtime.exceptionThrown", p => errors.push({ error: p.exceptionDetails.exception?.description, url: p.exceptionDetails.url, line: p.exceptionDetails.lineNumber }));
  await send("Page.addScriptToEvaluateOnNewDocument", { source: `
    window.__perfLong=[];new PerformanceObserver(l=>l.getEntries().forEach(x=>__perfLong.push({start:x.startTime,duration:x.duration}))).observe({type:'longtask',buffered:true});
    ${timerDiagnostics ? "window.__cmtAgendadorDiag={};window.__cmtAgendadorOrigem=true;" : ""}
  ` });
  await send("Emulation.setDeviceMetricsOverride", { width, height: 1000, deviceScaleFactor: 1, mobile: false });
  await send("Page.navigate", { url: `${origin}/gabinete?shared=1` });
  for (let i = 0; i < 120; i++) {
    if (await evaluate("!!window.PautaApp").catch(() => false)) break;
    await delay(250);
  }
  await evaluate(`window.__fixture=${JSON.stringify(seed)};PautaApp.restoreSnapshot(__fixture);PautaApp._loading=false;PautaApp.state.storageBusy=false;PautaApp.saveDeb=()=>{};PautaApp.renderShell();document.documentElement.classList.remove('pauta-booting');`);
  await delay(2500);
  const startup = await evaluate(`({minimized:document.querySelector('.pq-side-workspace')?.dataset.collapsed==='true',bodyHidden:document.getElementById('pq-side-body')?.hidden})`);
  console.log("READY", await evaluate(`JSON.stringify({rows:PautaApp.rows.length,page:document.documentElement.dataset.v2Page,groups:document.querySelectorAll('tbody.pq-group').length,title:document.title,ready:!!window.PautaControl?.page})`));
  if (process.argv.includes("--server-layout-only")) {
    await evaluate(`window.CMTServidor.open('teste');`);
    await delay(1800);
    const state = await evaluate(`(()=>{const footer=document.querySelector('#pauta-global-dock>.gd-foot[data-page-footer="servidor"]'),profile=document.querySelector('#cmt-srv'),r=footer?.getBoundingClientRect();return {open:CMTServidor.isOpen(),footerVisible:!!footer&&!footer.hidden&&r.height>0,footerPage:CMTPageFooters.current(),footerBounds:r&&{left:r.left,right:r.right,top:r.top,bottom:r.bottom},profile:!!profile,profileWidth:profile?.getBoundingClientRect().width,viewport:innerWidth,frame:CMTFrameStability.dimensions(),tabs:[...document.querySelectorAll('#cmt-srv [data-srv-sec]')].map(n=>({text:n.textContent,key:n.dataset.srvSec})),controls:[...document.querySelectorAll('#cmt-srv button')].slice(0,15).map(n=>({text:n.textContent,action:n.getAttribute('data-srv')}))};})()`);
    Object.assign(state, await evaluate(`({rootClasses:document.documentElement.className,bodyClasses:document.body.className,footerFunction:CMTPageFooters.current.toString(),footerCount:document.querySelectorAll('#pauta-global-dock>.gd-foot').length})`));
    await fs.writeFile(path.join(out,"server-layout.json"), JSON.stringify(state,null,2));
    await fs.writeFile(path.join(out,"server-layout.jpg"),Buffer.from((await send("Page.captureScreenshot",{format:"jpeg",quality:85})).data,"base64"));
    await evaluate(`window.CMTRail?.syncPendingFooter?.();document.querySelector('#pauta-global-dock>.gd-foot[data-page-footer="servidor"] [data-footer-pending-toggle]')?.click();`);
    await delay(600);
    const pending = await evaluate(`(()=>{const p=document.getElementById('cmt-footer-pending'),r=p?.getBoundingClientRect();return {visible:!!p&&!p.hidden,board:!!p?.querySelector('[data-pnd-root]'),bounds:r&&{left:r.left,right:r.right,top:r.top,bottom:r.bottom}};})()`);
    await evaluate(`window.CMTRail?.closePanel?.();document.querySelector('#cmt-footer-pending [data-footer-pending-close]')?.click();`);
    const design = await evaluate(`(()=>{const p=document.querySelector('#pauta-public-profile.cmt-srv-embed'),title=p?.querySelector('.cxp-h2'),facts=p?.querySelector('.cxp-facts'),fact=facts?.querySelector('.cxp-fact'),card=p?.querySelector('.cxp-card'),srv=document.getElementById('cmt-srv'),wrap=p?.querySelector('.cxp-wrap'),r=srv?.getBoundingClientRect();return {font:title&&getComputedStyle(title).fontFamily,factsColumns:facts&&getComputedStyle(facts).gridTemplateColumns,factWidth:fact?.getBoundingClientRect().width,cardWidth:card?.getBoundingClientRect().width,wrapColumns:wrap&&getComputedStyle(wrap).gridTemplateColumns,pageBounds:r&&{left:r.left,right:r.right,top:r.top,bottom:r.bottom},scrollWidth:srv?.scrollWidth,ownWidth:srv?.clientWidth,title:title?.textContent};})()`);
    await fs.writeFile(path.join(out,"server-design.json"), JSON.stringify(design,null,2));
    await fs.writeFile(path.join(out,"server-pending.json"), JSON.stringify(pending,null,2));
    const edit=await evaluate(`(()=>{const edit=document.querySelector('#cmt-srv [data-pp2-edit]');edit?.click();const fields=document.querySelectorAll('#cmt-srv [data-pp2-personal]').length;document.querySelector('#cmt-srv [data-pp2-cancel]')?.click();return {available:!!edit,fields,cancelled:!document.querySelector('#cmt-srv [data-pp2-cancel]')};})()`);
    await evaluate(`window.CMTServidor.close();window.CMTRotas?.ir?.('pauta');`);
    await delay(350);
    const returned=await evaluate(`({page:CMTPageFooters.current(),active:[...document.querySelectorAll('#pauta-global-dock>.gd-foot')].filter(f=>!f.hidden&&!f.inert&&f.getClientRects().length).map(f=>f.dataset.pageFooter)})`);
    await fs.writeFile(path.join(out,"server-behavior.json"), JSON.stringify({edit,returned},null,2));
    console.log("SERVER", JSON.stringify({state,pending,design,edit,returned,errors}));
    if (!state.open || !state.footerVisible || state.footerPage!=='servidor' || !pending.visible || !pending.board || !edit.fields || !edit.cancelled || returned.page!=='pauta' || returned.active.length!==1 || !design.font?.startsWith('Figtree') || design.scrollWidth>design.ownWidth+1 || errors.length) throw Error("Server workspace layout or behavior failed");
    break testRun;
  }
  await send("Performance.enable");
  const initialMetrics = (await send("Performance.getMetrics")).metrics;
  await send("Profiler.enable"); await send("Profiler.start");
  await send("Tracing.start", { categories: "devtools.timeline,blink.user_timing", transferMode: "ReturnAsStream" });
  const phases: any[] = [];
  async function phase(name: string, action: string | (() => Promise<void>), wait = 1200) {
    if(visualOnly&&!["expand","prontuario-toggle","notifications","jump-last"].includes(name))return;
    const start = await evaluate("performance.now()");
    await evaluate(`performance.mark(${JSON.stringify(name + "-start")})`);
    let actionError: string | undefined;
    try {
      if (typeof action === "string") await evaluate(action); else await action();
    } catch (error) {
      actionError = String(error);
      errors.push({ phase: name, error: actionError });
    }
    await delay(visualOnly&&name!=="jump-last"?Math.min(wait,400):wait);
    const metrics = await send("Performance.getMetrics");
    phases.push({ name, start, end: await evaluate("performance.now()"), actionError, metrics: Object.fromEntries(metrics.metrics.map(x => [x.name, x.value])),
      state: await evaluate(`({expanded:document.querySelectorAll('#pa-r3 .proc.open').length,openIds:[...document.querySelectorAll('#pa-r3 .proc.open')].map(x=>x.dataset.id),rows:[...document.querySelectorAll('#pa-r3 .proc')].map(x=>x.dataset.id),scroll:[...document.querySelectorAll('#pa-r3')].map(x=>({top:x.scrollTop,height:x.scrollHeight,client:x.clientHeight})),panel:document.querySelector('#cmt-center-panels')?.dataset.active,panelVisible:!!document.querySelector('#cmt-center-panels:not([hidden])')?.getClientRects().length,collapsed:document.querySelector('.pq-side-workspace')?.dataset.collapsed,focused:window.CMTProntuario?.currentProcess?.(),identity:document.querySelector('#alt-qp [data-testid="prontuario-focused-process"]')?.textContent})`) });
  }
  await phase("idle", "void 0", 3000);
  await phase("scroll", async () => {
    const point = await evaluate(`(()=>{const r=document.getElementById('pa-r3').getBoundingClientRect();return {x:Math.min(innerWidth-10,r.right-30),y:Math.min(innerHeight-10,r.top+Math.min(r.height/2,200))};})()`);
    for (let i=0;i<24;i++) {
      await send("Input.dispatchMouseEvent", { type:"mouseWheel", ...point, deltaX:0, deltaY:150 });
      await delay(35);
    }
  }, 1000);
  await phase("expand", `(()=>{const list=document.getElementById('pa-r3');if(list)list.scrollTop=0;document.querySelector('#pa-r3 .proc .chev')?.click();})()`, 1500);
  await phase("prontuario-toggle", `document.querySelector('[data-pq-side-toggle]')?.click()`, 1200);
  const qpScreenshot = await send("Page.captureScreenshot", { format:"jpeg", quality:75 });
  await fs.writeFile(path.join(out,"prontuario.jpg"),Buffer.from(qpScreenshot.data,"base64"));
  const compactHeader=await evaluate(`(()=>{const b=document.querySelector('[data-pq-side-toggle]'),r=b.getBoundingClientRect(),h=document.querySelector('#alt-qp .qp-h')?.getBoundingClientRect(),hit=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return {clickable:b===hit||b.contains(hit),sameRow:!!h&&Math.abs(h.top-r.top)<32,captionHidden:getComputedStyle(document.querySelector('#pq-side-panel>header>span')).display==='none'};})()`);
  await phase("prontuario-noop", `new Promise(resolve=>{const p=document.getElementById('alt-qp'),first=p?.firstChild;let count=0;const o=new MutationObserver(m=>count+=m.length);if(p)o.observe(p,{childList:true,subtree:true,attributes:true});for(let n=0;n<3;n++)window.CMTProntuario?.refresh?.();queueMicrotask(()=>{count+=o.takeRecords().length;o.disconnect();window.__qpStable={sameNode:first===p?.firstChild,mutations:count};resolve();});})`,200);
  await phase("notifications", `document.getElementById('cmt-sidebar-notifications-launch')?.click()`, 1200);
  const noticeScreenshot = await send("Page.captureScreenshot", { format:"jpeg", quality:75 });
  await fs.writeFile(path.join(out,"notifications.jpg"),Buffer.from(noticeScreenshot.data,"base64"));
  const notificationLayout=await evaluate(`(()=>{const p=document.getElementById('cmt-center-panels'),r=p.getBoundingClientRect();return {insideViewport:r.left>=0&&r.top>=0&&r.right<=innerWidth+1&&r.bottom<=innerHeight+1,rect:{left:r.left,top:r.top,right:r.right,bottom:r.bottom},duplicateFeeds:[...document.querySelectorAll('.gd-p-notif')].filter(n=>!p.contains(n)&&n.getClientRects().length>0).length,visibleLaunchers:[...document.querySelectorAll('#cmt-sidebar-notifications-launch,#alt-side .as-bell,#alt-side .gd-bell,#pauta-global-dock .gd-bell,#pauta-global-dock [data-center-launch]')].filter(n=>n.getClientRects().length>0).map(n=>({id:n.id,cls:n.className}))};})()`);
  await phase("notifications-close", `document.getElementById('cmt-sidebar-notifications-launch')?.click()`,300);
  await phase("notifications-reopen", `document.getElementById('cmt-sidebar-notifications-launch')?.click()`,400);
   const pendingOpenTiming=await evaluate(`(()=>{const t0=performance.now();CMTRail.syncPendingFooter();const prepared=performance.now(),button=[...document.querySelectorAll('[data-footer-pending-toggle]')].find(n=>n.getClientRects().length);button?.click();const panel=document.querySelector('#cmt-footer-pending');return {syncMs:prepared-t0,clickHandlerMs:performance.now()-prepared,opened:!!panel&&!panel.hidden,panelMounted:!!panel?.querySelector('[data-pnd-root]'),error:!!panel?.querySelector('[data-pending-error]')};})()`);
  await delay(500);
  const pendingLayout=await evaluate(`(()=>{const panel=document.querySelector('#cmt-footer-pending'),footer=[...document.querySelectorAll('#pauta-global-dock>.gd-foot')].find(n=>n.getClientRects().length&&!n.hidden),p=panel?.getBoundingClientRect(),f=footer?.getBoundingClientRect();const mine=[...panel.querySelectorAll('.pnb-pill')].find(n=>n.textContent.startsWith('Minhas'));mine?.click();return {visible:!!panel&&!panel.hidden,attached:!!p&&!!f&&Math.abs(p.bottom-f.top)<2,insideViewport:!!p&&p.top>=0&&p.left>=0&&p.right<=innerWidth+1,filterWorks:mine?.getAttribute('aria-pressed')==='true'||[...panel.querySelectorAll('.pnb-pill')].find(n=>n.textContent.startsWith('Minhas'))?.getAttribute('aria-pressed')==='true',centerHasPending:!!document.querySelector('#cmt-center-panels [data-pending-panel],#cmt-center-panels [data-center-tab="pend"]')};})()`);
   const pendingNew=await evaluate(`(()=>{const panel=document.querySelector('#cmt-footer-pending'),button=panel?.querySelector('[data-pnd="new"]');button?.click();const input=panel?.querySelector('[data-pnd-quick] input');return {button:!!button,quickInput:!!input,focused:document.activeElement===input,allFilter:panel?.querySelector('[data-pnd="filter"][data-value="all"]')?.getAttribute('aria-pressed')==='true',error:!!panel?.querySelector('[data-pending-error]')};})()`);
   await evaluate(`(()=>{const input=document.querySelector('#cmt-footer-pending [data-pnd-quick] input');if(!input)return;input.value='Fixture: pendência com sessão';input.form?.requestSubmit();})()`);
   await delay(250);
   await evaluate(`(()=>{const panel=document.querySelector('#cmt-footer-pending'),form=panel?.querySelector('[data-pnd-form]'),process=form?.elements?.namedItem('process');if(!form||!process)return;process.value=${JSON.stringify(seed.rows[0].Processo)};process.dispatchEvent(new Event('input',{bubbles:true}));form.requestSubmit();})()`);
   await delay(500);
   const pendingSession=await evaluate(`(()=>{const panel=document.querySelector('#cmt-footer-pending'),issue=window.PautaApp?.team?.pendingIssues?.find(x=>x.title==='Fixture: pendência com sessão'),restored=issue&&window.PautaTeam?.restore?.({pendingIssues:[issue]})?.pendingIssues?.find(x=>x.id===issue.id),root=panel?.querySelector('[data-pnd-root]'),drawer=root?.querySelector('.pnb-drawer'),dr=drawer?.getBoundingClientRect(),rr=root?.getBoundingClientRect(),db=root?.querySelector('.pnb-db'),styles=drawer&&getComputedStyle(drawer);const drawerFits=!!dr&&!!rr&&dr.left>=rr.left-1&&dr.right<=rr.right+1&&dr.top>=rr.top-1&&dr.bottom<=rr.bottom+1,drawerPosition=styles?.position||'',drawerZIndex=styles?.zIndex||'',bodyScroll=getComputedStyle(db||root).overflowY,drawerRect=dr&&{left:dr.left,top:dr.top,right:dr.right,bottom:dr.bottom},rootRect=rr&&{left:rr.left,top:rr.top,right:rr.right,bottom:rr.bottom};const session=issue?.session||'',selected=panel?.querySelector('[data-pnd-form] select[name="session"]')?.value||'';const filter=panel?.querySelector('[data-pnd="filter"][data-value="session"]');filter?.click();return {created:!!issue,session,restoredSession:restored?.session||'',selected,drawerFits,drawerPosition,drawerZIndex,bodyScroll,drawerRect,rootRect,sessionFilter:panel?.querySelector('[data-pnd="filter"][data-value="session"]')?.getAttribute('aria-pressed')==='true',cardSession:!!panel?.querySelector('.pnb-session')};})()`);
   await fs.writeFile(path.join(out,"pending.jpg"),Buffer.from((await send("Page.captureScreenshot",{format:"jpeg",quality:80})).data,"base64"));
  const pendingControls=await evaluate(`(()=>{const panel=document.getElementById('cmt-footer-pending');panel.querySelector('[data-footer-pending-close]')?.click();const closed=panel.hidden;const button=[...document.querySelectorAll('[data-footer-pending-toggle]')].find(n=>n.getClientRects().length);button?.click();return {closed,reopened:!panel.hidden,sameNode:panel===document.getElementById('cmt-footer-pending')};})()`);
  const noFooter=await evaluate(`(()=>{const footers=[...document.querySelectorAll('#pauta-global-dock>.gd-foot')],hidden=footers.map(n=>n.hidden);footers.forEach(n=>n.hidden=true);CMTRail.syncPendingFooter();const result={hidden:!!document.querySelector('#cmt-footer-pending[hidden]'),opens:CMTRail.openPanel('pend')};footers.forEach((n,i)=>n.hidden=hidden[i]);CMTRail.syncPendingFooter();return result;})()`);
  await phase("notifications-return", `document.getElementById('cmt-sidebar-notifications-launch')?.click()`,400);
  const noticeTopics=await evaluate(`(()=>{const panel=document.querySelector('#cmt-center-panels'),details=panel.querySelector('details[data-notice-topic]');if(details)details.open=true;return {topics:panel.querySelectorAll('details[data-notice-topic]').length,hasSelector:!!panel.querySelector('.cp-seg,[data-cppane="tudo"]'),calendar:!!panel.querySelector('[data-daily-calendar]')};})()`);
  await phase("notifications-final-close", `window.CMTRail?.closePanel?.()`,300);
  await phase("pagination-draft", `new Promise(resolve=>{const input=document.querySelector('#pa-r3 .proc.open input[data-f]:not([type=checkbox]):not([type=date])');window.__draftCheck={available:!!input};if(!input){resolve();return;}const key=input.dataset.f;input.value='TESTE DE PRESERVAÇÃO';input.dispatchEvent(new Event('input',{bubbles:true}));PautaControl.page.selected.add(0);PautaControl.page.selected.add(${rowsCount-1});document.querySelector('[data-r3-page="1"]')?.click();setTimeout(()=>{document.querySelector('[data-r3-page="-1"]')?.click();window.__draftCheck={available:true,key,preserved:document.querySelector('#pa-r3 .proc.open input[data-f="'+CSS.escape(key)+'"]')?.value==='TESTE DE PRESERVAÇÃO',selection:PautaControl.page.selected.has(0)&&PautaControl.page.selected.has(${rowsCount-1})};resolve();},500);})`,300);
  await phase("collapse", `document.querySelector('#pa-r3 .proc.open .chev')?.click()`, 1200);
   await phase("jump-last", `(()=>{const i=document.getElementById('pauta-quick-item');if(i){i.value=${JSON.stringify(String(rowsCount))};i.dispatchEvent(new Event('input',{bubbles:true}));}})()`, 2100);
   const quickSearch=await evaluate(`(async()=>{
     const highlighted=i=>!!document.querySelector('#pa-r3 .proc[data-id="'+i+'"].r3-flash, #controle-pauta-root tbody.pq-group[data-pre-row="'+i+'"].cmt-flash, #controle-pauta-root tbody.pq-group[data-pre-row="'+i+'"].pauta-jump-highlight');
     let input=document.getElementById('pauta-quick-item'),jump=input?.closest('.pauta-quick-jump');
     const rect=jump?.getBoundingClientRect(),head=jump?.closest('.pc-heading')?.getBoundingClientRect();
     const result={inSearch:!!input?.closest('.pc-filter-card>.pc-heading'),hasIr:!!jump?.querySelector('[data-pauta-jump]'),inFooter:!!jump?.closest('.gd-foot'),itemHighlighted:highlighted(${rowsCount-1}),processHighlighted:false,visible:!!rect&&rect.width>0&&rect.top>=head.top&&rect.bottom<=head.bottom+1};
     jump?.querySelector('[data-pauta-jump-mode]')?.click();
     input=document.getElementById('pauta-quick-item');
     if(input){input.value=${JSON.stringify(seed.rows[2].Processo)};input.dispatchEvent(new Event('input',{bubbles:true}));await new Promise(r=>setTimeout(r,1700));}
     result.processHighlighted=highlighted(2);
     const page=window.PautaControl.page;page.filters.Assunto=['Assunto de teste 2'];page.render();
     await new Promise(r=>setTimeout(r,500));
     const chip=document.querySelector('#controle-pauta-root .cmt-fb2 .fb-chip'),header=document.querySelector('#controle-pauta-root .pc-filter-card>.pc-heading');
     result.filtersBelowSearch=!!chip&&chip.getBoundingClientRect().top>=header.getBoundingClientRect().bottom-1;
     return result;
   })()`);
   await fs.writeFile(path.join(out,"quick-search.jpg"),Buffer.from((await send("Page.captureScreenshot",{format:"jpeg",quality:85})).data,"base64"));
   await evaluate(`history.replaceState({},'', '/tria');document.documentElement.dataset.cmtWorkspace='filter';window.CMTViews.triagem.st.rows=[{id:'triage-fixture',processo:PautaApp.rows[0].Processo,apt:'',det:'Teste de integração',espec:[],chk:{}}];window.CMTViews.open('triagem');document.dispatchEvent(new CustomEvent('cmt:route'));`);
   await delay(700);
   const triageShell=await evaluate(`(()=>{const w=document.querySelector('main.app-main.cmt-route-prontuario-open[data-cmt-prontuario-page="triagem"]'),p=w?.querySelector('#pq-side-panel'),page=w?.querySelector(':scope>#cmtx-view'),slot=w?.querySelector(':scope>#cmt-route-prontuario-slot'),body=p?.querySelector('#pq-side-body'),r=n=>{const x=n?.getBoundingClientRect();return x&&{left:x.left,top:x.top,right:x.right,bottom:x.bottom,width:x.width,height:x.height}};return {workspace:!!w,content:!!page,panel:!!p,picker:!!body?.querySelector('[data-cmt-process-picker]'),collapsed:w?.dataset.collapsed,bodyHidden:body?.hidden,bodyContext:body?.dataset.cmtContextPage,bodyDisplay:body&&getComputedStyle(body).display,qpHidden:document.getElementById('alt-qp')?.hidden,qpParent:document.getElementById('alt-qp')?.parentElement?.id,duplicatePanels:document.querySelectorAll('#pq-side-panel').length,display:p&&getComputedStyle(p).display,workspaceRect:r(w),pageRect:r(page),panelRect:r(p),slotRect:r(slot),active:window.CMTPagina?.tipo?.(),isOn:window.CMTProntuario?.isOn?.()};})()`);
   await evaluate(`document.querySelector('main.app-main.cmt-route-prontuario-open [data-pq-side-toggle]')?.click()`);
   await delay(350);
    const triagePicker=await evaluate(`(()=>{const search=document.querySelector('[data-cmt-process-search]');if(search){search.value=PautaApp.rows[0].Processo;search.dispatchEvent(new Event('input',{bubbles:true}));}const select=document.querySelector('[data-cmt-process-select]');if(select){select.value=PautaApp.rows[0].Processo;select.dispatchEvent(new Event('change',{bubbles:true}));}const qp=document.getElementById('alt-qp'),r=qp?.getBoundingClientRect(),body=qp?.parentElement?.getBoundingClientRect(),first=qp?.firstElementChild,fr=first?.getBoundingClientRect(),fields=qp?.querySelector('.qp-ass-row'),fieldRect=fields?.getBoundingClientRect(),proc=qp?.querySelector('.qp-process-control strong'),pr=proc?.getBoundingClientRect(),head=qp?.querySelector('.qp-h'),hr=head?.getBoundingClientRect(),point=qp&&document.elementFromPoint(1020,80);return {options:select?.options.length||0,process:window.CMTProntuario?.currentProcess?.(),panel:!!qp?.querySelector('[data-testid="prontuario-focused-process"]'),visibleFields:!!fields&&fieldRect.width>0&&fieldRect.height>0&&getComputedStyle(fields).visibility==='visible',qpHidden:qp?.hidden,qpScrollTop:qp?.scrollTop,qpParent:qp?.parentElement?.id,qpText:qp?.innerText?.slice(0,180),qpHTML:qp?.innerHTML?.length,qpRect:r&&{x:r.x,y:r.y,w:r.width,h:r.height},bodyRect:body&&{x:body.x,y:body.y,w:body.width,h:body.height},qpStyle:qp&&{display:getComputedStyle(qp).display,visibility:getComputedStyle(qp).visibility,opacity:getComputedStyle(qp).opacity,position:getComputedStyle(qp).position,overflow:getComputedStyle(qp).overflow,color:getComputedStyle(qp).color,background:getComputedStyle(qp).backgroundColor},firstChild:first&&{tag:first.tagName,text:first.innerText?.slice(0,100),rect:fr&&{x:fr.x,y:fr.y,w:fr.width,h:fr.height},display:getComputedStyle(first).display,color:getComputedStyle(first).color,visibility:getComputedStyle(first).visibility},processText:proc?.innerText,processStyle:proc&&{color:getComputedStyle(proc).color,opacity:getComputedStyle(proc).opacity,font:getComputedStyle(proc).fontSize,rect:pr&&{x:pr.x,y:pr.y,w:pr.width,h:pr.height}},header:head&&{rect:hr&&{x:hr.x,y:hr.y,w:hr.width,h:hr.height},display:getComputedStyle(head).display,opacity:getComputedStyle(head).opacity},elementAtProcess:point&&{tag:point.tagName,id:point.id,cls:point.className,text:point.innerText?.slice(0,80)},bodyContext:document.querySelector('#pq-side-panel #pq-side-body')?.dataset.cmtContextPage,isOn:window.CMTProntuario?.isOn?.()};})()`);
    await delay(500);
   await fs.writeFile(path.join(out,"triagem-prontuario.jpg"),Buffer.from((await send("Page.captureScreenshot",{format:"jpeg",quality:80})).data,"base64"));
    await fs.writeFile(path.join(out,"triagem-prontuario-panel.jpg"),Buffer.from((await send("Page.captureScreenshot",{format:"jpeg",quality:92,clip:{x:990,y:0,width:420,height:880,scale:1}})).data,"base64"));
   await evaluate(`window.CMTViews.close?.();history.replaceState({},'','/gabinete');document.documentElement.removeAttribute('data-cmt-workspace');window.CMTRotas?.ir?.('pauta');`);
    const routePanels={triageShell,triagePicker};
  const cpu = (await send("Profiler.stop")).profile;
  const completed = new Promise<any>(resolve => events.set("Tracing.tracingComplete", resolve));
  await send("Tracing.end");
  const complete = await completed; let trace = "";
  while (true) { const r = await send("IO.read", { handle: complete.stream }); trace += r.data; if (r.eof) break; }
  await send("IO.close", { handle: complete.stream });
  const screenshot = await send("Page.captureScreenshot", { format: "jpeg", quality: 70 });
  await fs.writeFile(path.join(out, "screen.jpg"), Buffer.from(screenshot.data, "base64"));
  await evaluate(`window.CMTAppDialogs?.openSettings?.()`);
  await delay(500);
  const globalSettings = await evaluate(`(()=>{const api=window.CMTAppDialogs,d=api?.settingsDocument,root=d?.getElementById?.('cmt-settings-dialog'),tabs=[...(d?.querySelectorAll?.('#cfg-tabs [data-cfg-tab]')||[])],rect=root?.getBoundingClientRect();return {api:!!api,open:!!root&&!root.hidden&&getComputedStyle(root).display!=='none',tabs:tabs.map(b=>({id:b.dataset.cfgTab,label:b.textContent.trim(),current:b.getAttribute('aria-current')})),dialogFits:!!rect&&rect.width>700&&rect.height>400&&rect.right<=innerWidth+1&&rect.bottom<=innerHeight+1,content:!!d?.getElementById?.('cfg-app-content')?.firstElementChild};})()`);
  const settingsTabs=await evaluate(`(async()=>{const root=document.querySelector('#cmt-settings-dialog'),rr=root?.getBoundingClientRect(),visible=()=>[...(root?.querySelectorAll('button')||[])].filter(b=>b.getClientRects().length&&b.getBoundingClientRect().top<(rr?.top||0)+115),before=window.CMTCfgNav?.atual?.()||'',buttons=visible(),target=buttons.find(b=>b.textContent.trim().startsWith('Backup'));target?.click();await new Promise(r=>setTimeout(r,180));const after=window.CMTCfgNav?.atual?.()||'';const restored=visible().find(b=>b.textContent.trim().startsWith('Sessões'));restored?.click();await new Promise(r=>setTimeout(r,180));return {buttons:buttons.map(b=>b.textContent.trim()),before,after,restored:window.CMTCfgNav?.atual?.()||'',switched:!!target&&before!==after};})()`);
   const sessionBackup=await evaluate(`(async()=>{const root=document;await new Promise(r=>setTimeout(r,180));const panel=root.querySelector('.psh-session-backup'),exportButton=panel?.querySelector('[data-hub="backup-export"]'),importButton=panel?.querySelector('[data-hub="backup-import"]'),file=panel?.querySelector('[data-backup-session]'),rect=panel?.getBoundingClientRect(),style=panel&&getComputedStyle(panel),visible=!!panel&&panel.getClientRects().length>0&&style.display!=='none'&&rect.width>0&&rect.height>0,session=exportButton?.dataset.hubSession||'';if(!panel||!exportButton||!importButton||!file)return {visible,exportButton:!!exportButton,importInput:!!file,exported:false,imported:false};const oldCreate=URL.createObjectURL,oldClick=HTMLAnchorElement.prototype.click;let blob=null;URL.createObjectURL=function(value){blob=value;return oldCreate.call(URL,value)};HTMLAnchorElement.prototype.click=function(){};try{exportButton.click();await new Promise(r=>setTimeout(r,80));const backup=blob?JSON.parse(await blob.text()):null,exported=backup?.formato==='controle-pauta-hub-sessoes'&&backup?.escopo==='sessão'&&backup?.sessions?.length===1&&backup.sessions[0]===session&&!!backup.sessionDetails?.[session]&&backup.rows?.some(row=>row.Processo&&row._pautaEntries?.some(entry=>entry.session===session))&&!!backup.pautaDaily&&!!backup.workCalendar&&!!backup.team&&!!backup.estatisticas?.[session];let imported=false;if(exported){const dt=new DataTransfer();dt.items.add(new File([JSON.stringify(backup)],'fixture-session.json',{type:'application/json'}));file.files=dt.files;file.dispatchEvent(new Event('change',{bubbles:true}));await new Promise(r=>setTimeout(r,220));const form=root.querySelector('.psh-hub-dialog[data-hub-form="import"]');if(form){form.requestSubmit();await new Promise(r=>setTimeout(r,900));const host=window.PautaApp;imported=host?.sessions?.includes(session)&&window.PautaControl?.sessionRows?.(host,session)?.length>=backup.rows.length&&!root.querySelector('.psh-hub-dialog[data-hub-form="import"]');}}return {visible,rect:rect&&{top:rect.top,bottom:rect.bottom,width:rect.width,height:rect.height},display:style?.display,exportButton:true,importInput:true,exported,imported};}finally{URL.createObjectURL=oldCreate;HTMLAnchorElement.prototype.click=oldClick;}})()`);
  const sessionsPageRemoval=await evaluate(`(()=>{const script=document.getElementById('cmt-retired-sessions-route'),original=location.pathname,redirected=[];for(const path of ['/session','/sessions']){history.replaceState(history.state,'',path);try{if(script)eval(script.textContent)}catch(_){}redirected.push(location.pathname)}history.replaceState(history.state,'',original);const links=[...document.querySelectorAll('#alt-side button,#cx-rrail button')].filter(b=>/Controle de Sessões/i.test((b.textContent||'')+' '+(b.title||'')+' '+(b.getAttribute('aria-label')||'')));return {redirectScript:!!script,redirected,navLinks:links.length,railButtons:document.querySelectorAll('[data-rr-sessoes]').length,pageAssets:performance.getEntriesByType('resource').filter(r=>r.name.includes('/sessions-page.')).length};})()`);
  const collapsedAvatar=await evaluate(`(()=>{const html=document.documentElement;html.classList.add('alt-collapsed');const ring=document.querySelector('#alt-side .as-avatar svg.ring'),face=document.querySelector('#alt-side .as-avatar .face'),ringHidden=!!ring&&getComputedStyle(ring).display==='none',faceSize=face&&getComputedStyle(face).width;html.classList.remove('alt-collapsed');return {ringHidden,faceSize};})()`);
  await fs.writeFile(path.join(out,"global-settings.jpg"),Buffer.from((await send("Page.captureScreenshot",{format:"jpeg",quality:80})).data,"base64"));
  await evaluate(`(()=>{const d=window.CMTAppDialogs?.settingsDocument;const tabs=[...(d?.querySelectorAll?.('#cfg-tabs [data-cfg-tab]')||[])];for(const id of ['team','materias','calendario'])tabs.find(b=>b.dataset.cfgTab===id)?.click();window.CMTAppDialogs?.closeSettings?.();})()`);
  const state = await evaluate(`({nodes:document.querySelectorAll('*').length,groups:document.querySelectorAll('tbody.pq-group').length,expanded:document.querySelectorAll('.pauta-list-expanded').length,long:__perfLong,intervals:window.__cmtAgendadorDiag||{},root:document.documentElement.className,qpStable:window.__qpStable,draft:window.__draftCheck,panels:{prontuario:!!document.querySelector('#alt-qp'),notification:!!document.querySelector('#cmt-center-panels')}})`);
  await fs.writeFile(path.join(out, "cpu.json"), JSON.stringify(cpu));
  await fs.writeFile(path.join(out, "trace.json"), trace);
  await fs.writeFile(path.join(out, "summary.json"), JSON.stringify({ rowsCount, width, timerDiagnostics,
    attributionWithoutProntuario:process.argv.includes("--without-prontuario-paint"),
     startup,compactHeader,notificationLayout,pendingOpenTiming,pendingLayout,pendingNew,pendingSession,pendingControls,noFooter,noticeTopics,routePanels,globalSettings,settingsTabs,sessionBackup,sessionsPageRemoval,collapsedAvatar,quickSearch,initialMetrics, phases, state, errors, requests }, null, 2));
  console.log(JSON.stringify({ out, nodes: state.nodes, groups: state.groups, errors: errors.length, phases: phases.map(p => ({ name: p.name, duration: p.end-p.start })), intervals: Object.entries(state.intervals).sort((a:any,b:any)=>(b[1].js+b[1].layout)-(a[1].js+a[1].layout)).slice(0,10) }, null, 2));
  const budget = Number(process.argv.find(a => a.startsWith("--max-task-ms="))?.split("=")[1]);
  const violations: string[] = [];
  if (process.argv.includes("--check")) {
    if (errors.length) violations.push(`${errors.length} browser/action errors`);
    if(!startup.minimized||!startup.bodyHidden)violations.push("Prontuário did not initialize minimized");
    if(!compactHeader.clickable||!compactHeader.sameRow||!compactHeader.captionHidden)violations.push("compact Prontuário header is not integrated or clickable");
    if(!notificationLayout.insideViewport||notificationLayout.duplicateFeeds||notificationLayout.visibleLaunchers.length!==1)violations.push("notifications layout is clipped or duplicated");
    if(!state.qpStable?.sameNode||state.qpStable?.mutations)violations.push("unchanged Prontuário refresh mutated its editor");
    if(!state.draft?.preserved||!state.draft?.selection)violations.push("pagination lost draft or global selection");
    if(phases.some(p=>p.state.rows.length>25))violations.push("list exceeded 25 mounted cards");
    for(const name of ["notifications","notifications-reopen","notifications-return"]) {
      const s=phases.find(p=>p.name===name)?.state;
      if(!s?.panelVisible||s.panel!=="painel")violations.push(`${name} did not open notifications`);
    }
    if(phases.find(p=>p.name==="notifications-close")?.state.panelVisible)violations.push("notification launcher did not close the panel");
    if(!pendingLayout.visible||!pendingLayout.attached||!pendingLayout.insideViewport||!pendingLayout.filterWorks||pendingLayout.centerHasPending)violations.push("footer Pendências is misplaced, duplicated or filters do not work");
    if(!pendingOpenTiming.opened||!pendingOpenTiming.panelMounted||pendingOpenTiming.error)violations.push("Pendências footer did not mount its working board");
    if(!pendingNew.button||!pendingNew.quickInput||!pendingNew.focused||!pendingNew.allFilter||pendingNew.error)violations.push("Nova pendência did not reset the recorte and focus the title field");
    if(!pendingSession.created||!pendingSession.session||pendingSession.session!==session||pendingSession.restoredSession!==session||pendingSession.selected!==session||!pendingSession.drawerFits||pendingSession.drawerPosition!=="absolute"||pendingSession.drawerZIndex!=="100"||pendingSession.bodyScroll!=="auto"||!pendingSession.sessionFilter||!pendingSession.cardSession)violations.push("Pendência process/session association or editor layout failed");
    if(!globalSettings.open||!globalSettings.dialogFits||globalSettings.tabs.length<3||!globalSettings.content)violations.push("Global Settings dialog or tabs are missing or clipped");
    if(!settingsTabs.switched||settingsTabs.before===settingsTabs.after||!settingsTabs.restored||settingsTabs.restored==='backup')violations.push("Global Settings tabs did not switch and restore correctly");
    if(!sessionBackup.visible||!sessionBackup.exported||!sessionBackup.imported)violations.push("Session JSON backup export/import failed");
    if(!sessionsPageRemoval.redirectScript||sessionsPageRemoval.redirected.some(path=>path!=='/pauta')||sessionsPageRemoval.navLinks||sessionsPageRemoval.railButtons||sessionsPageRemoval.pageAssets)violations.push("Standalone Sessions route or navigation remains available");
    if(!collapsedAvatar.ringHidden||collapsedAvatar.faceSize!=='44px')violations.push("Collapsed left profile avatar still has its frame");
    if(!pendingControls.closed||!pendingControls.reopened||!pendingControls.sameNode)violations.push("Pendências close/reopen lost its mounted board");
    if(!noFooter.hidden||noFooter.opens)violations.push("Pendências opens without a visible central footer");
    if(!quickSearch.inSearch||quickSearch.hasIr||quickSearch.inFooter||!quickSearch.visible||!quickSearch.itemHighlighted||!quickSearch.processHighlighted||!quickSearch.filtersBelowSearch)violations.push("Pauta quick search did not auto-locate items and processes from the search toolbar");
    if(!noticeTopics.topics||noticeTopics.hasSelector||!noticeTopics.calendar)violations.push("notifications topics/calendar or removed selector regressed");
    if(!triageShell.workspace||!triageShell.content||!triageShell.panel||!triageShell.picker||!triagePicker.process||!triagePicker.panel||!triagePicker.visibleFields||!triagePicker.options)violations.push("Triagem lacks its shared Prontuário fields or process picker");
    if (!phases.find(p => p.name === "expand")?.state.openIds.includes("0")) violations.push("first process did not open");
    if (!phases.find(p => p.name === "jump-last")?.state.openIds.includes(String(rowsCount-1))) violations.push("last process did not open");
    if (phases.some(p => p.state.expanded > 1)) violations.push("more than one expanded process");
    if (!phases.find(p => p.name === "scroll")?.state.scroll.some(s => s.top > 0)) violations.push("scroll did not move the visible list");
  }
  if (budget > 0 && state.long.some(t => t.start >= phases[0].start && t.duration > budget)) {
    violations.push(`long task exceeded ${budget}ms budget`);
  }
  if (violations.length) throw Error(violations.join("; "));
} } finally {
  socket?.close();
  try { process.kill(-browser.pid!, "SIGKILL"); } catch {}
  server.closeAllConnections(); server.close();
  await fs.rm(profile, { recursive: true, force: true }).catch(() => {});
}

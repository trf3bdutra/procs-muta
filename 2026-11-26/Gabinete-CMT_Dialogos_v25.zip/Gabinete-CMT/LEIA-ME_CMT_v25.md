# Gabinete CMT (25) — Correção incremental do shell e painéis

## Alterações
- **Notificações na lateral direita:** abertura via `AltShell.notifications(true)` com seletor exclusivo do feed em `#alt-side .as-notif`. O botão `data-k="notif"` já existe no controlador do rail e não é removido.
- **Caixa postal no Centro Operacional:** workspace DOM independente (`.cbp-mailbox`), sem deslocar nem ocultar as Notificações. Reaproveita `CMTCommunicationTabs`, `CMTSolicitacoes`, `CMTAgentMailCommunication` e `CMTMail`, respeitando as permissões existentes.
- **Frame:** novo coordenador `CMTFrameStability` com `ResizeObserver` e atualização coalescida em um frame; variáveis CSS publicadas apenas quando os valores mudam. Removidas animações repetitivas da gaveta e reduzida a frequência de um polling do adaptador de comunicação (400ms → 4000ms).
- **Configurações Globais e Ementário:** preservados como diálogos nativos de `cmt-app-dialogs.js`. A rotina antiga de captura de foco da página não interfere no `#cmt-settings-dialog[open]`.
- **Distribuição:** arquivos atualizados tanto em `src/protected` como em `dist/protected`; frame-stability é incorporado no final de `gabcmt.html` e também disponibilizado separadamente para evolução futura.

## Limitações e testes
- Trata-se de consolidação **incremental de compatibilidade**, não de migração integral da página para CSS Grid. Converter o HTML legado (aprox. 12 MB e muitas regras globais) sem um teste de navegador em execução seria arriscado.
- A montagem real dos canais E-mail, Telefone, Avisos e Solicitações depende das rotas, permissões e serviços externos em execução. Não foram utilizadas credenciais nem registros reais.
- `node --check` passou para os JS modificados. Os três testes de regressão criados para este ajuste passaram. Dois testes legados existentes de notificações foram executados mas apresentaram falhas associadas ao mock do documento e/ou expectativas não atendidas; não se declarou suíte integral aprovada.

## Instalação
Copie os caminhos relativos presentes no ZIP sobre o mesmo projeto. Se usar o pacote completo, utilize-o diretamente como projeto. Preserve backups e teste as três abas do Centro Operacional, Notificações da lateral direita, Configurações Globais e Ementário antes de publicar.

import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { buildDatajudQuery, buildDatajudTriageResult } from "./triage.mjs";

const root = dirname(fileURLToPath(import.meta.url));
const publicDir = join(root, "public");
const host = process.env.HOST || "127.0.0.1";
const port = Number(process.env.PORT || 3000);
const alias = process.env.DATAJUD_ALIAS || "api_publica_trf3";
const base = process.env.DATAJUD_BASE || "https://api-publica.datajud.cnj.jus.br/";
const apiKey = String(process.env.DATAJUD_API_KEY || "").replace(/^APIKey\s+/i, "").trim();
const maxRequestBytes = 16 * 1024;
const maxResponseBytes = 30 * 1024 * 1024;
const minimumIntervalMs = 1500;
let lastRequestAt = 0;
let paceQueue = Promise.resolve();

class DataJudError extends Error {
  constructor(message, status = 502) {
    super(message);
    this.status = status;
  }
}

function send(res, status, body, contentType = "application/json; charset=utf-8") {
  res.writeHead(status, {
    "Content-Type": contentType,
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
  });
  res.end(body);
}

function sendJson(res, status, payload) {
  send(res, status, JSON.stringify(payload));
}

async function readJson(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maxRequestBytes) {
      throw new DataJudError("A solicitação excede o limite permitido.", 413);
    }
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw new DataJudError("O corpo da solicitação não contém JSON válido.", 400);
  }
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function paceRequest() {
  const next = paceQueue.then(async () => {
    const delay = Math.max(0, lastRequestAt + minimumIntervalMs - Date.now());
    if (delay) await wait(delay);
    lastRequestAt = Date.now();
  });
  paceQueue = next.catch(() => {});
  return next;
}

function datajudEndpoint() {
  if (!/^api_publica_[a-z0-9_-]{2,30}$/.test(alias)) {
    throw new DataJudError("DATAJUD_ALIAS inválido.", 500);
  }
  let apiBase;
  try {
    apiBase = new URL(base.endsWith("/") ? base : `${base}/`);
  } catch {
    throw new DataJudError("DATAJUD_BASE inválido.", 500);
  }
  if (apiBase.protocol !== "https:") {
    throw new DataJudError("DATAJUD_BASE deve usar HTTPS.", 500);
  }
  return new URL(`${alias}/_search`, apiBase);
}

async function queryDataJud(numero) {
  if (!apiKey) {
    throw new DataJudError(
      "Configure DATAJUD_API_KEY no arquivo .env antes de consultar.",
      503,
    );
  }
  const endpoint = datajudEndpoint();
  const body = JSON.stringify(buildDatajudQuery(numero));

  for (let attempt = 0; attempt < 3; attempt += 1) {
    await paceRequest();
    let response;
    try {
      response = await fetch(endpoint, {
        method: "POST",
        signal: AbortSignal.timeout(30_000),
        headers: {
          "Content-Type": "application/json",
          Authorization: `APIKey ${apiKey}`,
        },
        body,
      });
    } catch {
      if (attempt < 2) {
        await wait(1500 * (2 ** attempt));
        continue;
      }
      throw new DataJudError("Não foi possível conectar à API do DataJud.", 502);
    }

    if ((response.status === 429 || response.status >= 500) && attempt < 2) {
      await wait(2000 * (2 ** attempt));
      continue;
    }
    if (response.status === 401 || response.status === 403) {
      throw new DataJudError(
        "A API do DataJud recusou a chave. Confira DATAJUD_API_KEY.",
        502,
      );
    }
    if (!response.ok) {
      throw new DataJudError(`DataJud respondeu HTTP ${response.status}.`, 502);
    }

    const text = await response.text();
    if (text.length > maxResponseBytes) {
      throw new DataJudError("A resposta do DataJud excede o limite seguro.", 502);
    }
    let payload;
    try {
      payload = JSON.parse(text);
    } catch {
      throw new DataJudError("DataJud retornou uma resposta inválida.", 502);
    }
    const hits = Array.isArray(payload?.hits?.hits) ? payload.hits.hits : [];
    return hits.map((hit) => hit?._source).filter(Boolean);
  }
  throw new DataJudError("Não foi possível consultar o DataJud.", 502);
}

async function handleRequest(req, res) {
  const url = new URL(req.url || "/", `http://${req.headers.host || "127.0.0.1"}`);
  if (req.method === "GET" && url.pathname === "/healthz") {
    sendJson(res, 200, { ok: true });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/datajud/triagem/consultar") {
    if (!req.headers["content-type"]?.toLowerCase().startsWith("application/json")) {
      sendJson(res, 415, { ok: false, error: "Envie a solicitação como JSON." });
      return;
    }
    let body;
    try {
      body = await readJson(req);
    } catch (error) {
      sendJson(res, error instanceof DataJudError ? error.status : 400, {
        ok: false,
        error: error instanceof Error ? error.message : "Solicitação inválida.",
      });
      return;
    }
    const numero = String(body?.numero ?? "").replace(/\D/g, "");
    if (!/^\d{20}$/.test(numero)) {
      sendJson(res, 400, { ok: false, error: "Informe o número CNJ com 20 dígitos." });
      return;
    }
    try {
      const records = await queryDataJud(numero);
      sendJson(res, 200, buildDatajudTriageResult(numero, records));
    } catch (error) {
      const status = error instanceof DataJudError ? error.status : 502;
      const message = error instanceof DataJudError
        ? error.message
        : "Não foi possível consultar o DataJud.";
      if (status >= 500) console.error(`[DataJud] ${message}`);
      sendJson(res, status, { ok: false, error: message });
    }
    return;
  }

  if (req.method === "GET" && ["/", "/index.html", "/triage.js", "/standalone.js"].includes(url.pathname)) {
    const assets = {
      "/": ["index.html", "text/html; charset=utf-8"],
      "/index.html": ["index.html", "text/html; charset=utf-8"],
      "/triage.js": ["triage.js", "text/javascript; charset=utf-8"],
      "/standalone.js": ["standalone.js", "text/javascript; charset=utf-8"],
    };
    const [file, type] = assets[url.pathname];
    try {
      const content = await readFile(join(publicDir, file));
      send(res, 200, content, type);
    } catch {
      sendJson(res, 500, { ok: false, error: "Não foi possível carregar a interface." });
    }
    return;
  }

  sendJson(res, 404, { ok: false, error: "Rota não encontrada." });
}

if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error("PORT deve ser um número entre 1 e 65535.");
  process.exit(1);
}

createServer((req, res) => {
  handleRequest(req, res).catch(() => {
    if (!res.headersSent) sendJson(res, 500, { ok: false, error: "Erro interno do servidor." });
    else res.destroy();
  });
}).listen(port, host, () => {
  console.log(`Triagem DataJud local em http://${host}:${port}`);
  if (!apiKey) console.warn("DATAJUD_API_KEY não configurada; a interface abrirá, mas consultas serão recusadas.");
});

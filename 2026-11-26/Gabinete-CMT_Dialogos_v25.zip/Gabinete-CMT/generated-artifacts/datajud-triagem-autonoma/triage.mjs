const rules = [
  { id: "R01", titulo: "Interposição", pattern: /\b(recurso|apelacao|agravo|embargos)\b/ },
  { id: "R02", titulo: "Decisão", pattern: /(decisao|sentenca|julgament|acordao)/ },
  { id: "R03", titulo: "Intimação", pattern: /(intima|ciencia|publicacao|expedicao)/ },
  { id: "R04", titulo: "Prazos", pattern: /(decurso|prazo|suspensao)/ },
  { id: "R05", titulo: "Preparo", pattern: /(preparo|custas|desercao|gratuidade|justica gratuita)/ },
  { id: "R06", titulo: "Representação", pattern: /(procuracao|substabelec|representacao|mandato)/ },
  { id: "R07", titulo: "Saneamento", pattern: /(regularizacao|emenda|sanear|saneamento)/ },
  { id: "R08", titulo: "Admissibilidade anterior", pattern: /(nao conhec|conheciment|admissib)/ },
  { id: "R09", titulo: "Fato superveniente", pattern: /(desistencia|perda de objeto|prejudicad|extincao)/ },
];

const object = (value) =>
  value && typeof value === "object" && !Array.isArray(value) ? value : {};
const digits = (value) => String(value ?? "").replace(/\D/g, "");
const normalizeText = (value) =>
  value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

function movementCode(movement) {
  const national = object(movement.movimentoNacional);
  const raw = movement.codigo ?? national.codigo;
  if (raw == null || raw === "") return null;
  const code = Number(raw);
  return Number.isInteger(code) && code >= 0 ? code : null;
}

function movementName(movement) {
  const national = object(movement.movimentoNacional);
  return String(movement.nome ?? national.nome ?? "").trim();
}

function movementComplements(movement) {
  if (!Array.isArray(movement.complementosTabelados)) return [];
  return movement.complementosTabelados
    .map((value) => {
      if (typeof value === "string") return value.trim();
      const item = object(value);
      const details = [item.nome, item.descricao, item.valor]
        .filter((part) => part != null && String(part).trim() !== "")
        .map((part) => String(part).trim());
      if (details.length) return [...new Set(details)].join(" · ");
      if (item.codigo != null) return `Código ${String(item.codigo)}`;
      try {
        return JSON.stringify(item);
      } catch {
        return "";
      }
    })
    .filter(Boolean);
}

function matchedRules(text) {
  return rules
    .filter((rule) => rule.pattern.test(text))
    .map(({ id, titulo }) => ({ id, titulo }));
}

export function buildDatajudTriageResult(numero, sourceRecords) {
  const registros = sourceRecords.filter((record) => {
    const source = object(record);
    return digits(source.numeroProcesso) === numero;
  });

  const movimentos = registros.flatMap((record) => {
    const source = object(record);
    if (!Array.isArray(source.movimentos)) return [];
    return source.movimentos.flatMap((rawMovement) => {
      const movement = object(rawMovement);
      const nome = movementName(movement);
      const complementos = movementComplements(movement);
      const codigo = movementCode(movement);
      const regras = matchedRules(normalizeText(`${nome} ${complementos.join(" ")}`));
      if (!regras.length) return [];
      const rawDate = movement.dataHora ?? movement.data;
      return [{
        data: rawDate == null || rawDate === "" ? null : String(rawDate),
        codigo,
        nome,
        complementos,
        regras,
      }];
    });
  });

  return {
    ok: true,
    numero,
    status: registros.length ? "encontrado" : "nao_localizado",
    registros,
    movimentos,
  };
}

export function buildDatajudQuery(numero) {
  return {
    size: 4,
    _source: [
      "numeroProcesso",
      "movimentos",
      "grau",
      "classe",
      "orgaoJulgador",
      "dataAjuizamento",
      "dataHoraUltimaAtualizacao",
      "@timestamp",
      "nivelSigilo",
      "assuntos",
    ],
    query: {
      bool: {
        should: [{ match: { numeroProcesso: numero } }],
        minimum_should_match: 1,
      },
    },
  };
}

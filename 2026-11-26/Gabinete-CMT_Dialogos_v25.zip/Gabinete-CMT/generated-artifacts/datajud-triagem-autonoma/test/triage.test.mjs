import test from "node:test";
import assert from "node:assert/strict";
import { buildDatajudQuery, buildDatajudTriageResult } from "../triage.mjs";

const numero = "50059724320244036000";

test("query DataJud pede movimentos e filtra pelo CNJ selecionado", () => {
  const query = buildDatajudQuery(numero);
  assert.equal(query.size, 4);
  assert.deepEqual(query.query.bool.should, [{ match: { numeroProcesso: numero } }]);
  assert.ok(query._source.includes("movimentos"));
});

test("classifica movimentos pelos nove sinais e mantém os dados brutos", () => {
  const nomes = [
    "Interposição de recurso",
    "Sentença proferida",
    "Intimação expedida",
    "Decurso de prazo",
    "Recolhimento de custas",
    "Juntada de procuração",
    "Emenda à inicial",
    "Não conhecimento do recurso",
    "Desistência do processo",
  ];
  const record = {
    numeroProcesso: numero,
    grau: "G2",
    movimentos: nomes.map((nome, index) => ({
      codigo: index + 1,
      nome,
      dataHora: "2026-01-02T12:00:00",
      complementosTabelados: [],
    })),
  };
  const result = buildDatajudTriageResult(numero, [record]);
  assert.equal(result.status, "encontrado");
  assert.equal(result.registros[0], record);
  const ruleIds = result.movimentos.map((movement) =>
    movement.regras.map((rule) => rule.id),
  );
  assert.deepEqual(ruleIds.slice(0, 7), [
    ["R01"], ["R02"], ["R03"], ["R04"], ["R05"], ["R06"], ["R07"],
  ]);
  assert.deepEqual(ruleIds[7], ["R01", "R08"]);
  assert.deepEqual(ruleIds[8], ["R09"]);
});

test("ignora outro processo e diferencia consulta sem registro", () => {
  const result = buildDatajudTriageResult(numero, [{
    numeroProcesso: "00000000000000000000",
    movimentos: [{ nome: "Interposição de recurso" }],
  }]);
  assert.equal(result.status, "nao_localizado");
  assert.deepEqual(result.registros, []);
  assert.deepEqual(result.movimentos, []);
});

test("usa nome nacional, complementos e código alternativos", () => {
  const result = buildDatajudTriageResult(numero, [{
    numeroProcesso: numero,
    movimentos: [{
      movimentoNacional: { codigo: 500, nome: "Juntada" },
      complementosTabelados: [{ descricao: "Recurso interposto", codigo: 9 }],
    }],
  }]);
  assert.equal(result.movimentos[0].codigo, 500);
  assert.equal(result.movimentos[0].regras[0].id, "R01");
});

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    var root = document.getElementById('triage-root');
    if (!root || !window.CMTDataJudTriage) {
      if (root) root.textContent = 'Não foi possível iniciar a tela de triagem.';
      return;
    }
    window.CMTDataJudTriage.render(root);
    root.addEventListener('click', function (event) {
      window.CMTDataJudTriage.click(event, root);
    });
  });
})();

# Triagem DataJud autônoma

Aplicação local independente do GabCMT. Consulta os 15 processos incluídos no pacote, em sequência, classifica movimentos como sinais para conferência e permite exportar JSON e CSV. As consultas não são gravadas em banco de dados nem alteram processos.

## Requisitos

- Node.js 20.6 ou superior.
- Acesso à internet.
- Uma chave válida da API Pública do DataJud, configurada somente no servidor.

## Iniciar

1. Extraia o ZIP para uma pasta local.
2. Copie `.env.example` para `.env`.
3. Preencha `DATAJUD_API_KEY` no `.env` usando uma chave válida. Não a coloque em arquivos dentro de `public/` nem a envie por chat.
4. No terminal, dentro da pasta extraída, execute `npm start`.
5. Abra `http://127.0.0.1:3000` no navegador.

O servidor fica vinculado a `127.0.0.1` por padrão, para não expor a chave na rede. Não altere `HOST` para `0.0.0.0` em uma máquina ou rede pública.

## Conteúdo

- `server.mjs`: servidor HTTP local e proxy seguro para a API do CNJ; a chave fica apenas no processo do servidor.
- `triage.mjs`: validação do número CNJ e regras de classificação dos movimentos.
- `public/`: página, interface, estilos e lista de 15 processos.
- `.env.example`: modelo de configuração sem credenciais.

## O que a tela faz

- Consulta um processo selecionado ou executa a fila em sequência, com intervalo entre consultas.
- Diferencia processo localizado, não localizado e falha técnica.
- Mostra movimentos, códigos, datas, complementos e regras identificadas; permite abrir o JSON bruto.
- Exporta os resultados consultados em JSON e CSV.
- Não persiste respostas; atualizar a página reinicia os estados da consulta.

Os rótulos R01–R09 são apenas sinais baseados no texto dos movimentos. Não determinam prazo, preparo, admissibilidade, regularidade ou resultado jurídico. Ausência de registro também não comprova ausência de evento.

## Testes locais

`npm test`

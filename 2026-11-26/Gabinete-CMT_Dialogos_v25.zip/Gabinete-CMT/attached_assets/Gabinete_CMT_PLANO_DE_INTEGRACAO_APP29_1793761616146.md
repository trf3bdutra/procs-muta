# Gabinete CMT · Consolidação técnica (base: Gabinete-CMT 29)

## Estado das entregas

- **HTML de redesign independente** (`Gabinete_CMT_FINAL_Redesign_Card_Prontuario_Gerador_Git.html`): interface experimental de Card, Prontuário, Correspondências, Análise guiada, Gerador, Conformidade, Diretrizes, Modelos/Trechos e Voto em seis faixas. Usa um acervo processual de demonstração; **não** sincroniza automaticamente com PostgreSQL ou com a sessão produtiva.
- **Patch do aplicativo real** (arquivos-fonte em `Gabinete_CMT_APP29_Patch_Git_e_Conformidade.zip`): modifica a edição 29 do projeto, mantendo os demais arquivos e rotas. Implementado: endpoints canônicos exclusivos para modelos/trechos, bancos sem fallback, ID preservado, seleção de modelo por ID, trechos exclusivamente do catálogo Git e painel de conformidade textual no Gerador legado; rota de avaliação `/api/app/redesign-avaliacao`.
- **HTML grande da aplicação** (`Gabinete_CMT_APP29_HTML_Atualizado.html`): cópia do HTML privado do projeto contendo as modificações da edição 29. Isoladamente não reproduz backend, autenticação, banco PostgreSQL e scripts/CSS servidos por `/api`; para funcionar integralmente deve ser aplicado no projeto e executado pelo servidor.

## Fontes únicas — regras efetivamente introduzidas

1. `/api/catalogos-gerador/modelos` consulta **exclusivamente** `https://raw.githubusercontent.com/brndutra/trf3-muta-jurisprudencia/main/data/modelos.json`.
2. `/api/catalogos-gerador/trechos` consulta **exclusivamente** `https://raw.githubusercontent.com/brndutra/trf3-muta-jurisprudencia/main/data/paragrafos.json`.
3. Ambas as consultas retornam `503`, `registros: []` e a mensagem “Catálogo Git indisponível. Nenhuma fonte alternativa será utilizada.” em caso de falha. Não consultam bancos pessoais, seeds, paradigmas, PM, acervo de processos nem localStorage.
4. O `id` da linha do Git permanece identificador. Card e Prontuário só entram no cálculo de aderência e ordenação; não geram modelos ou trechos.
5. **ATENÇÃO — BLOQUEADOR REAL:** os dois caminhos `data/...` retornaram HTTP 404 na branch `main` do repositório informado na consulta realizada em 03/11/2026. Não foram substituídos por outros caminhos. Os bancos permanecem vazios até publicação desses arquivos no local canônico.

## Mapa dos módulos encontrados no ZIP

| Área | Código em Gabinete-CMT 29 | Responsabilidade correta |
|---|---|---|
| Lista e Card | `cmt-v261-card-r3` no `artifacts/api-server/src/protected/gabcmt.html` | localização, situação, atribuições e eventos; mesmo registro processual da ficha e do Prontuário |
| Ficha do processo | `cmt-v198-ficha` no mesmo HTML | visualização abrangente do registro, íntegro e consistente; sem cadastro paralelo |
| Painel/Prontuário | `cmt-v268-prontuario` | fatos, questões processuais, preliminares, mérito, autos, recursos, julgamento e conclusão jurídica |
| Gerador | `cmt-v269-gerador` | elaboração documental, templates, redação e projeções a partir do caso, sem alterar automaticamente o julgamento |
| Biblioteca | `cmt-geradores-biblioteca.js` | Modelos e Trechos canônicos Git; precedentes pertencem à área de Correspondências, não aos bancos editoriais |
| Backend | `src/routes/generator-catalogs.ts` e `src/routes/index.ts` | leitura autenticada, exclusivamente Git, fail-closed; nenhum fallback |
| Banco operacional | `PautaApp.rows`, `PautaControl.page.processPayload`, `pautaSnapshotsTable` | sessão/listagem e dados processuais, sem ligação contínua com o espelho original da pauta |

## Contrato de dados recomendado — próxima etapa de migração

- **processoId:** número CNJ; **sessaoId:** sessão em pauta; **cardOperational:** status, designação, correção, liberação, prazos.
- **processRecord:** contexto, classe, espécie efetivamente julgada, partes, origem, decisão recorrida, recursos, contrarrazões, peças, IDs, ocorrências, preliminares e especificidades.
- **legalAnalysis:** admissibilidade e questões da espécie; cada requisito tem estado jurídico (presente, ausente, pendente de confirmação), fundamento, ID ou referência probatória. Responder se um recurso é tempestivo, e não se “a tempestividade foi conferida”.
- **judgment:** resultado, extensão, efeitos, honorários, sucumbência, consectários, votação, relator, divergência; única fonte da proclamação.
- **editorial:** modeloGitId e referenciasTrechosGit (IDs somente), lacunas manuais e revisões da ementa; edição editorial não regrava o registro jurídico.
- **compliance:** avaliação automática ou manual da **minuta produzida**, com justificativa e referência à diretriz; não altera fatos nem conclusões jurídicas.

## Fluxo definitivo de responsabilidade

1. **Configurações Globais** importa/consolida dados do espelho para criar a listagem. Depois, Card e Prontuário leem a listagem; o espelho deixa de ser fonte operacional independente.
2. **Card e Ficha** usam a mesma chave do processo e a mesma camada de gravação. Ficha é uma visão completa, não um segundo cadastro.
3. **Prontuário** possui blocos de Autos/peças, Origem, Regularidade, Recursos, Caso e controvérsias, Julgamento. A Análise guiada altera apenas a apresentação e a coleta das respostas jurídicas, jamais a disponibilidade de Correspondências.
4. **Correspondências** consulta precedentes e julgados similares, com filtros por ramo, assunto, subassunto, classe, espécie julgada, resultado e tipo de pronunciamento. Usa dados apenas para busca e ranking.
5. **Gerador › Apoio** expõe Conformidade, Diretrizes, Modelos e Trechos. Diretrizes é referência e fórmula copiável; Conformidade verifica texto, apresenta alertas/revisão humana e não reabre questões jurídicas como checklist duplicado.
6. **Voto** inicia sempre no template-base de seis faixas (01 Abertura; 02 Fundamentação; 03 Caso vertente; 04 Encerramento; 04.1 Honorários; 04.2 Dispositivo). Modelo Git pode substituir integralmente a estrutura. Trechos Git são acrescentados por ID; somente `{{CAMPO}}` é editável. Copiar exporta exclusivamente texto jurídico.
7. **Ementa** recebe sugestões de Caso em exame e Questões em discussão sintetizadas a partir do Prontuário; Razões de decidir e Dispositivo vêm do Julgamento, porém a edição final da Ementa é independente e não sobrescreve o registro jurídico. Não há Tese de julgamento como campo próprio.
8. **Proclamação** é texto derivado da espécie, resultado e votação do Julgamento. Se os dados faltarem, mostra pendência; não cria formulário paralelo.

## Distinção semântica: análise jurídica versus conformidade

| Questão | Deve ficar em | Motivo |
|---|---|---|
| Há impugnação específica, tempestividade ou cabimento? | Prontuário › Análise guiada | Característica jurídica do processo |
| O acórdão é compatível com o precedente vinculante? | Prontuário › Juízo de retratação | Qualificação jurídica necessária ao julgamento |
| A minuta expõe a comparação com o precedente? | Gerador › Conformidade | Exame do texto efetivamente produzido |
| Honorários e consectários aplicáveis, qual montante e regime? | Prontuário › Julgamento | Definição jurídica substantiva |
| A minuta tratou honorários e consectários pertinentes? | Gerador › Conformidade | Verificação da redação |
| O dispositivo da minuta corresponde à conclusão registrada? | Gerador › Conformidade | Confronto textual |
| Preliminar está presente e qual sua solução? | Prontuário › Regularidade | Análise jurídica |
| Cada preliminar registrada foi enfrentada no voto? | Gerador › Conformidade | Conferência individualizada da minuta |

## Etapas seguras para promover o redesign à aplicação produtiva

1. **Migração do contrato**: criar esquema de processo partilhado (com versionamento e normalização), preservar dados antigos e testar equivalência com `processPayload`.
2. **Card/Ficha**: alterar as duas vistas para consumir as mesmas chaves sem duplicar formulários. Adicionar testes de persistência e de edição cruzada.
3. **Prontuário**: substituir overlays legados por blocos da nova análise jurídica; mover perguntas meramente redacionais à Conformidade. Não perder regras por espécie e dados já registrados.
4. **Gerador**: substituir o esqueleto legado por componente de seis faixas ligado ao contrato; preservar edição de rascunhos, importação, ações de copiar e fontes de documento.
5. **Correspondências e Ementa**: integrar filtros e sugestões, com revisão editorial independente; proclamação automática a partir do Julgamento.
6. **Testes de regressão**: abrir e alterar um mesmo processo no Card, Ficha, Prontuário e Gerador, alternar Guiada/Livre, testar respostas de conformidade, abrir Catálogo Git indisponível e garantir banco vazio, selecionar modelo por ID, inserir trecho por ID, comparar texto copiado com texto jurídico, validar responsividade e impressão.

## Limites desta entrega

O HTML independente consolida a experiência visual e os fluxos do redesign. O patch **não transplanta automaticamente todas as telas do protótipo para a aplicação real de 12 MB**, pois isso exigiria migrar o esquema e a persistência. O patch modifica apenas as áreas explicitamente descritas acima; mantive os demais módulos originais para evitar regressões. Não houve publicação em GitHub nem implantação no servidor do usuário.

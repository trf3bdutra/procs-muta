# COMANDO PARA A IA — Central de Comando em /command, integrada ao GabCMT

> Cole este comando na IA que edita o projeto **Gabinete-CMT** (Replit), anexando o arquivo `central_de_comando_trgms.html`. O comando é autossuficiente: traz o objetivo, os contratos entre a página e o servidor, as edições no `gabcmt.html` e os testes de aceitação.

---

## 0. Papel e restrições

Você é o desenvolvedor do **Gabinete-CMT**: pnpm workspaces, Express 5, PostgreSQL com Drizzle, `artifacts/api-server` e o app `gabcmt.html`, servido protegido e carregado pelo shell React.

**Objetivo.** Publicar a página anexa como **página própria, em `/command`**, com o título **CENTRAL DE COMANDO · GABCMT**, integrada ao GabCMT. A integração tem quatro partes:

- **Referências:** a aba lê ao vivo os **Assuntos e Procedimentos** cadastrados no app (hoje em Configurações › Assuntos e procedimentos).
- **Competência:** as listas de impedimento e suspeição, o julgador de cada advogado, os períodos de atuação e as convocações passam a ser **da equipe**, gravados no servidor, e não de cada navegador.
- **Acervo:** a aba usa o **banco de acervo do app** (`/api/acervo`). Importar o relatório na Central grava nesse banco.
- **Dados calculados:** o que só a Central calcula vira consulta para o **preenchimento e a ficha dos processos** do app: situação, onde está, tipo de julgamento, Seção vinculada e alertas de impedimento.

**Restrições**

1. **A página é independente do `gabcmt.html`.** Ela fica num arquivo próprio e não é embutida, injetada nem copiada para dentro do app. O `gabcmt.html` só ganha atalhos para ela e passa a ler os dados que ela grava no servidor (seção 5).
2. **Siga a regra do `replit.md` para o `gabcmt.html`:** edite a regra ou a função original no lugar. Não crie blocos versionados (`cmt-vNNN-…`) nem sobreposições por especificidade.
3. **Não reescreva a página anexa.** Ela já traz a ponte com o app (bloco `V40 · PONTE COM O GABCMT`, objeto `window.CMTCentral`). Se uma rota existente tiver contrato diferente do descrito aqui, ajuste **só** a função correspondente da ponte, indicada em cada item, ou adapte a rota. Não mexa no restante da página.
4. **Não altere a mesclagem da pauta, as rotas da pauta nem os dados existentes.** Tudo o que é novo fica em tabelas novas, criadas em tempo de execução como em `garantirTabelas`.
5. **Mantenha o modo autônomo.** Aberta como arquivo solto (`file://`) e sem as variáveis injetadas, a página continua funcionando como hoje, com dados no navegador. A ponte só liga quando o servidor injeta `window.__CMT_BRIDGE__`.
6. Rode os **testes de aceitação** (seção 7) e corrija até passarem.

---

## 1. O que a página anexa já faz (não reimplemente)

A página procura três variáveis globais, que o servidor deve definir **antes** dos scripts dela:

| Variável | Para quê | Sem ela |
|---|---|---|
| `window.__CMT_BRIDGE__` | Liga a ponte. Pode trazer `api` para trocar endereços: `{api:{importar, acervo, central, estado}}`. | Página autônoma |
| `window.__CMT_ASSUNTOS__` | Objeto `assuntos` do app (`subjects`, `ramos`, `procedures`, `models`), igual ao exportado por `materiasPayload()`, **sem `rows`**, mais `atualizadoEm` (ISO). | Usa a tabela embutida |
| `window.__CMT_CENTRAL__` | Estado compartilhado da Competência: `{_v, conv, impPer, impAdvJ}`. | Usa o que está no navegador |

Com a ponte ligada, a página faz o seguinte:

- **Referências.** Monta a aba com os assuntos ao vivo. Os assuntos ainda sem Seção recebem a Seção vinculada pela Central (mapa `AP_SECFIX`, com a justificativa do art. 10 do RITRF3). O botão **"Gravar Seções vinculadas no GabCMT…"** gera um JSON no formato `controle-pauta-assuntos`, para importar em Configurações › Assuntos e procedimentos com a prévia já existente (`importTab('materias')`). A página nunca grava assuntos diretamente.
- **Competência.** Ao alterar listas, julgador do advogado, períodos ou convocações, envia `PUT` para `api.estado` (padrão `/api/central/estado`) com `{_v, conv, impPer, impAdvJ}`, com espera de 0,9 s entre alterações. Em `409`, carrega a versão do servidor que veio em `estado` e avisa a pessoa. Função: `pushShared`.
- **Acervo.**
  - Ao abrir, faz `GET` em `api.acervo` (padrão `/api/acervo?completo=1`), com `If-None-Match`, e monta o acervo a partir de `registros[].linha` (ou `registros[].linhas`). Função: `pullAcervo` e `rowsFromServer`.
  - Ao importar o relatório principal ou uma planilha complementar, lê o arquivo na hora e também o envia em `multipart/form-data` para `api.importar` (padrão `/api/acervo/importar`). Os campos são `arquivo` (o .xlsx ou .csv original), `origem=central` e `tipo=principal|complementar`. Função: `upload`.
- **Dados calculados.** Depois de cada importação ou leitura do banco, envia `POST` para `api.central` (padrão `/api/acervo/central`), comprimido em gzip quando passa de 64 KB:

  ```json
  {"origem":"Central de Comando","geradoEm":"ISO","registros":[{
    "processo":"5006130-11.2018.4.03.6000","situacao":"Em tramitação","secao":"1ª Seção",
    "assunto":"…","classe":"…","local":"Gabinete","ondeEsta":"Sessão de julgamento",
    "tarefa":"[Sessão] Aguardando a sessão","diasNaTarefa":43,"tipoJulgamento":"1º julgamento",
    "prioridade":true,"sigilo":false,"etiquetas":["…"],
    "alertas":[{"tipo":"impedimento|suspeicao","julgador":"jean|ney|?","advogado":"…","oab":"…"},
               {"tipo":"origem","julgador":"Dr. …","texto":"Conferir origem: …"}]}]}
  ```

  Função: `pushDerived`. O mesmo objeto de um processo sai de `window.CMTCentral.derived(rec)`.
- **Links diretos.**
  - `/command?p=<número com ou sem máscara>` abre o Acervo em modo planilha, filtrado no processo.
  - `/command?assunto=<nome>` abre o Acervo filtrado pelo assunto.
  - `/command?aba=referencias|acervo|competencia|regimento|recursos|tarefas` abre a aba indicada.
- **Voltar.** O botão Voltar lê `<meta name="escudo-home" content="/">`, que já está no arquivo, e volta para `/`.

O título da página já é `CENTRAL DE COMANDO · GABCMT`, na janela e no topo.

---

## 2. Arquivo e rota `/command`

1. Copie o anexo para `artifacts/api-server/src/protected/command.html`. Garanta que o build o copie para `dist/protected/command.html`, como acontece com o `gabcmt.html`.
2. **Rota `GET /command` (e `/command/`)** no api-server:
   - Use **a mesma proteção de acesso** da página do `gabcmt.html`: sessão e contas de acesso. Sem login, segue o mesmo fluxo de entrada do app (`auth-login.html`).
   - Use a mesma compressão (`artifacts/api-server/src/lib/compress.ts`, br ou gzip) e `Cache-Control: no-cache`.
   - Antes de enviar, injete logo depois de `<head>`:

     ```html
     <script>window.__CMT_BRIDGE__={};window.__CMT_ASSUNTOS__=…;window.__CMT_CENTRAL__=…;</script>
     ```

   - Serialize com `JSON.stringify` e troque `</` por `<\/` (e ` `/` `), para não fechar o `<script>`.
   - `__CMT_ASSUNTOS__`: o objeto `assuntos` do **estado salvo da pauta**, o mesmo que `PUT /api/pauta` grava (`lib/db/src/schema/pauta.ts`), **sem `rows`**, mais `atualizadoEm`. Se não houver estado, injete `null`.
   - `__CMT_CENTRAL__`: o registro da seção 3.1, ou `null`.
   - O corpo varia a cada requisição. Comprima o HTML base uma vez e acrescente a injeção já comprimida em separado, ou guarde em cache a versão comprimida pela chave `versão do estado + hash dos assuntos`. Não recomprima 1 MB a cada acesso.
3. **Reserve a rota.** Pelo `replit.md`, a rota do shell `/:serverSlug` e a validação de e-mail ("usuário antes do @ que não coincida com rotas do sistema") precisam reconhecer `command`:
   - inclua `command` na lista de rotas reservadas do servidor, de `server-profile-data.ts` e da validação do e-mail;
   - registre `GET /command` **antes** de qualquer fallback do SPA, para o shell não tratá-lo como página de servidor.
4. A página é **de nível superior**: não fica no iframe do shell. O app abre `/command` na aba inteira (`window.top.location`) ou em nova aba.

---

## 3. Servidor — rotas novas e ajustes

Todas as rotas exigem a mesma autenticação das rotas `/api/acervo`. Aceite corpo com `Content-Encoding: gzip`, como `/api/acervo/consultar` já aceita.

### 3.1 Estado compartilhado da Competência — `GET` e `PUT /api/central/estado`

- **Tabela** `central_estado`, criada em tempo de execução:

  ```text
  id text primary key  -- 'gabinete'
  dados jsonb
  versao integer
  atualizado_em timestamptz
  atualizado_por text
  ```

- **`GET`** devolve `{...dados, _v: versao}`, ou `{_v: 0}` quando não há registro.
- **`PUT`** recebe `{_v, conv, impPer, impAdvJ}`:
  - se `_v` for diferente da `versao` atual, responde **409** com `{error:'versão desatualizada', estado:{...dados,_v}}`;
  - se for igual, grava os três campos, soma 1 à `versao` e responde `{_v}`;
  - na primeira gravação, aceite `_v` nulo ou 0.
- **Validação mínima:**
  - `conv`: lista de `{d:'AAAA-MM-DD', s:'1ª Seção'|'2ª Seção'|'3ª Seção'|'Todas', …}`;
  - `impPer`: objeto;
  - `impAdvJ`: objeto `{oab: 'jean'|'ney'|'?'}`;
  - corpo de no máximo 256 KB.
- Os dados incluem nomes, OAB e CPF de advogados. A rota não é pública e não entra no backup HTML público.

### 3.2 Importação pela Central — `POST /api/acervo/importar`

- Leia a rota atual. A página envia `multipart/form-data` com `arquivo`, `origem=central` e `tipo=principal|complementar`.
- **Se a rota já aceita o arquivo** (o reconhecimento é pela célula A1 e pelo cabeçalho, conforme `acervo-fontes.ts`), basta aceitar esse formato. Responda incluindo `aplicados` (quantidade de processos gravados), que a página mostra no aviso.
- **Se a rota espera outro formato** (JSON de linhas, base64 etc.), ajuste **só** a função `upload(file, tipo)` do bloco V40 da página para o contrato real. Não duplique a rota.
- O relatório **PJe ID 278** (Relação Acervo Detalhado 2G por Órgão Julgador) tem uma linha por processo e tarefa. Se o banco guarda uma linha por processo, mantenha todas as tarefas atuais do processo (por exemplo, em `linhas` ou no histórico), para a Central não perder caixas paralelas.
- As planilhas complementares (painel de indicadores, `tramitacao`/`julgamentos`/`metas`) seguem as regras já existentes: vazio nunca sobrescreve; processo inexistente não é criado.

### 3.3 Leitura completa — `GET /api/acervo?completo=1`

Hoje o app usa `?campos=indice`. Acrescente o modo `completo=1`:

```json
{"atualizadoEm":"ISO","cursor":"…","registros":[
  {"processo":"5006130-11.2018.4.03.6000","ativo":true,
   "linha":{"processo":"…","classe_judicial":"…","assunto_judicial":"…","data_distribuicao":"dd/mm/aaaa",
            "tarefa_atual":"…","data_entrada_tarefa":"dd/mm/aaaa hh:mm","prioridade":"Sim","etiquetas":"a, b",
            "polo_ativo":"…","polo_passivo":"…","advogado_pa":"…","advogado_pp":"…","ultimo_movimento":"…","valor_causa":0},
   "linhas":[ /* opcional: uma por tarefa atual, mesmas chaves */ ]}]}
```

- As chaves são **os nomes originais das colunas do relatório do PJe**. Datas podem ir em `dd/mm/aaaa [hh:mm]` ou como serial do Excel; a página converte as colunas `data_*` e `dt_*`.
- Inclua também os processos **inativos** (baixados, arquivados, remetidos), com `ativo:false`. A Central calcula as situações e mostra os encerrados quando a pessoa pede.
- Use ETag, gzip e resposta `304`, como o modo índice.

### 3.4 Dados calculados pela Central — `POST /api/acervo/central`

- **Tabela** `acervo_central`:

  ```text
  processo text primary key  -- só dígitos, 20 posições
  dados jsonb
  atualizado_em timestamptz
  ```

- Recebe o corpo da seção 1. Numa transação: apague o lote anterior, insira o novo e responda `{ok:true, gravados:n}`. Limite o corpo a 20 MB descomprimido.
- **Exponha o resultado:** inclua `central: {…dados}` em cada item de `POST /api/acervo/consultar` e em `GET /api/acervo/:processo`, quando existir. Não altere nenhum outro campo dessas respostas.

---

## 4. Referências ao vivo — o que conferir

- A página usa `__CMT_ASSUNTOS__.subjects`, `ramos` e `procedures` exatamente como o app exporta. Não converta campos.
- Assuntos com `active:false` não aparecem.
- Contagens por assunto, cliques que abrem o acervo filtrado e links para os procedimentos continuam funcionando com os dados ao vivo.
- Gravar as Seções vinculadas no cadastro é sempre **decisão de quem administra**: botão → JSON → Configurações › Assuntos e procedimentos › Importar, com a prévia e a escolha já existentes. Não crie gravação automática.

---

## 5. Edições no `gabcmt.html` (no lugar, sem blocos novos)

1. **Atalho na navegação principal.** Na barra esquerda (onde estão Pauta, Decisões e Triagem), acrescente o item **Central de Comando** na função que monta esses itens. Ele abre `/command` em nível superior (`window.top.location.href = '/command'`), porque o app roda dentro do iframe do shell.
2. **Configurações › Assuntos e procedimentos.** Ao lado do título da área, um link discreto **"Ver na Central de Comando"** → `/command?aba=referencias`.
3. **Ficha do processo** (`window.CMTFicha`, `cmt-v198-ficha`), aba **Processo**. Quando a consulta ao acervo trouxer `central`, mostre um quadro **"Central de Comando"**, só leitura:
   - situação;
   - onde está;
   - tarefa atual e dias na tarefa;
   - tipo de julgamento;
   - Seção indicada pela Central;
   - etiquetas;
   - **alertas de impedimento ou suspeição em destaque**, com julgador e advogado ou origem.

   Inclua o link **"Abrir na Central"** → `/command?p=<número>`, em nova aba. Na aba **Resumo**, só um selo "⚠ impedimento/suspeição a verificar" quando houver alerta.
4. **Preenchimento pelo acervo** (`preencherPauta` e o caminho que usa `consultar`):
   - quando `central.secao` existir e os campos **`Seção competente`** e **`Seção`** da linha estiverem vazios, preencha os dois;
   - `assunto` e `classe` continuam vindo de `linha`, como hoje;
   - nunca sobrescreva valor digitado nem campo operacional, e respeite `sobrescrever` e `chavesOp`, como já faz;
   - os demais dados de `central` (situação, onde está, tipo de julgamento, dias na tarefa) **não viram colunas da pauta**: aparecem na ficha, em "Outros dados do processo" ou no quadro do item 3.
5. **Triagem** (`CMTViews.open('triagem')`). Na linha do processo, se `central.alertas` não estiver vazio, mostre o selo ⚠ com dica (julgador e motivo), usando o dado da consulta já feita. Não faça uma consulta extra por linha.
6. **Atualize o `replit.md`**, na seção "Where things live" e num item de Gotchas, com:
   - a rota `/command`;
   - as variáveis injetadas;
   - as tabelas `central_estado` e `acervo_central`;
   - a regra: "a Central é página própria; o app só lê `central` pela consulta do acervo".

---

## 6. Segurança e privacidade

- `/command` e as rotas `/api/central/*` e `/api/acervo/central` exigem login, como o app. O link público de edição da pauta **não** dá acesso à Central.
- Ao exportar com segredo de justiça, a Central já pede confirmação. Não exponha `acervo_central` em backup HTML nem em exportações públicas.
- Nada vai para serviços externos. A página carrega fontes do Google Fonts; mantenha isso ou sirva as fontes localmente, se a política do app exigir.

---

## 7. Testes de aceitação

1. **Rota e título.** Com login, `/command` abre a página com título **CENTRAL DE COMANDO · GABCMT**. Sem login, cai na tela de acesso. `/command` não é tratado como página de servidor, e não é possível cadastrar servidor com e-mail `command@…`.
2. **Independência.** O `gabcmt.html` não contém o conteúdo da Central. Abrir o anexo direto do disco continua funcionando, com dados no navegador.
3. **Referências ao vivo.** Renomeie um assunto em Configurações › Assuntos e procedimentos e salve. Ao recarregar `/command?aba=referencias`, o nome novo aparece, e o cabeçalho de origem diz "Assuntos e Procedimentos do GabCMT · ao vivo". O botão "Gravar Seções vinculadas no GabCMT…" baixa o JSON. A importação dele em Configurações mostra a prévia, e só grava após a confirmação.
4. **Estado compartilhado.**
   - No navegador A, cadastre uma convocação na aba Competência. No navegador B, ela aparece ao recarregar `/command`.
   - Altere a mesma lista nos dois sem recarregar: o segundo recebe 409, a página carrega a versão do servidor e avisa.
5. **Acervo.**
   - Importe o relatório ID 278 em `/command`: o aviso informa a gravação no banco, com `aplicados`.
   - Em outro navegador, `/command` abre o acervo completo vindo do banco, com as situações, inclusive baixados e arquivados ao escolher "Todas".
   - Recarregar sem mudanças gera `304` em `/api/acervo?completo=1`.
6. **Dados calculados no app.**
   - Depois da importação, a ficha de um processo da pauta mostra o quadro "Central de Comando", com situação, onde está, tarefa e dias, e tipo de julgamento.
   - O link "Abrir na Central" leva a `/command?p=<número>` com o processo filtrado.
   - Um processo com advogado das listas mostra o alerta na ficha e o selo na Triagem.
7. **Preenchimento.** Num processo da pauta com `Seção competente` vazia, o preenchimento pelo acervo grava a Seção da Central. Num processo com Seção digitada, nada muda.
8. **Atalhos.** O item "Central de Comando" da barra esquerda abre `/command` na janela inteira, e o Voltar da Central volta para `/`.
9. **Erros.** Nenhum erro no console de `/command` nem do app. Typecheck e build de produção passam: `pnpm run typecheck` e `pnpm run validate:production-builds`.

---

## 8. Entrega

Devolva:

- a lista de arquivos alterados e criados;
- uma linha por mudança;
- o contrato final de cada rota (se algum diferir deste comando, diga qual função da ponte foi ajustada);
- o resultado de cada teste da seção 7.

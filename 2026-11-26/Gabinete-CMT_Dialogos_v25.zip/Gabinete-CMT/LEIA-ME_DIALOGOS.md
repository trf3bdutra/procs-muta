# Gabinete CMT — diálogos e pendências

Alterações desta versão:
- Notificações: diálogo nativo, centralizado, com cabeçalho cinza, superfície clara, bordas e controles em azul-marinho; preserva conteúdo, calendário e ações.
- Pendências: mesma linguagem visual. O editor agora tem fundo opaco, largura adaptável e rolagem própria abrangendo o formulário e suas ações. Os estilos apontam para o painel real do rodapé.
- Servidor: o crachá abre o perfil completo em diálogo nativo. Não troca a página, sessão ou filtros. Edição, foto, ausência e produção continuam usando o controlador existente. Fechamento pelo botão ou Esc; restauração do foco.
- Rotas antigas /serv-user e /servidor abrem o perfil sobre o Gabinete; cliques nos perfis não abrem páginas nem novas abas.
- Controle Global preservado.

## Usar no projeto

Este é um pacote de fontes. Substitua os arquivos do projeto mantendo o banco e as variáveis de ambiente existentes. No ambiente do aplicativo, execute `pnpm install --frozen-lockfile` e `pnpm build`, depois reinicie os serviços habituais. Os builds anteriores e os caches locais não integram este pacote para evitar servir a versão antiga.

O HTML principal é `artifacts/api-server/src/protected/gabcmt.html`. Ele depende dos demais arquivos do aplicativo; abrir isoladamente não reproduz o sistema completo.

## Validação

12 testes direcionados passaram: controlador de perfil, abertura sem navegação, fechamento/foco, ciclo modal de notificações, sintaxe dos scripts, painel de pendências, permissões e montagem do Prontuário. A montagem do documento de produção, incluindo 24 recursos de funcionalidades e 10 de dados, foi executada com sucesso.

Foi corrigida uma incompatibilidade preexistente do transformador do Prontuário com o texto atual da chamada de seleção, que impedia a montagem do HTML a partir das fontes.

Limites: não houve compilação integral do React nem validação com o banco de produção. A tentativa de homologação visual foi bloqueada pelo ambiente local: o Chromium falhou ao criar seu socket de execução (Operation not permitted). É necessário conferir o visual no ambiente do aplicativo, inclusive telas pequenas e salvar alterações em perfil/pendência.

Um teste antigo da Mesa de Trabalho, fora desta alteração, continua esperando uma implementação que já não existia na versão recebida.

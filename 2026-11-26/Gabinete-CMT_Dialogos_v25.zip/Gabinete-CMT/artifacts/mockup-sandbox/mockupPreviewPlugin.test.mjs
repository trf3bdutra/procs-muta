import assert from "node:assert/strict";
import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { mockupPreviewPlugin } from "./mockupPreviewPlugin.ts";

async function fixture(t) {
  const root = await mkdtemp(path.join(os.tmpdir(), "mockup-discovery-"));
  t.after(() => rm(root, { recursive: true, force: true }));
  const plugin = mockupPreviewPlugin();
  plugin.configResolved({ root });
  return {
    root,
    plugin,
    async add(name) {
      const file = path.join(root, "src/components/mockups", name);
      await mkdir(path.dirname(file), { recursive: true });
      await writeFile(file, "export default function Preview() { return null; }");
    },
    async generate() {
      await plugin.buildStart();
      return readFile(
        path.join(root, "src/.generated/mockup-components.ts"),
        "utf8",
      );
    },
  };
}

test("discovers nested TSX previews and excludes private and hidden files", async (t) => {
  const f = await fixture(t);
  for (const name of [
    "Zebra.tsx",
    "cards/Alpha.tsx",
    "_Private.tsx",
    "_internal/Hidden.tsx",
    "cards/_internal/Hidden.tsx",
    ".hidden/Hidden.tsx",
    ".Hidden.tsx",
    "helper.ts",
  ]) {
    await f.add(name);
  }
  await mkdir(path.join(f.root, "src/components/mockups/Directory.tsx"));
  const source = await f.generate();
  assert.match(
    source,
    /"\.\/components\/mockups\/cards\/Alpha\.tsx": \(\) => import\("\.\.\/components\/mockups\/cards\/Alpha\.tsx"\)/,
  );
  assert.match(source, /Zebra\.tsx/);
  assert.doesNotMatch(source, /Private|Hidden|helper|Directory/);
  assert.ok(source.indexOf("Zebra.tsx") < source.indexOf("cards/Alpha.tsx"));
  assert.equal(await f.generate(), source);
});

test("handles missing and empty mockup directories", async (t) => {
  const f = await fixture(t);
  const empty = await f.generate();
  assert.match(empty, /export const modules: ModuleMap = \{\n\n\};/);
  await mkdir(path.join(f.root, "src/components/mockups"), { recursive: true });
  assert.equal(await f.generate(), empty);
});

test("refreshes generated imports after a preview is added or removed", async (t) => {
  const f = await fixture(t);
  await f.generate();
  await f.add("New.tsx");
  assert.match(await f.generate(), /New\.tsx/);
  await rm(path.join(f.root, "src/components/mockups/New.tsx"));
  assert.doesNotMatch(await f.generate(), /New\.tsx/);
});

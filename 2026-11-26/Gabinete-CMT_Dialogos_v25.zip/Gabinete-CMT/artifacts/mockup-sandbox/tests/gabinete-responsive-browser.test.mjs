import { existsSync } from "node:fs";
import { createRequire } from "node:module";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createServer } from "node:http";
import { access, mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import test from "node:test";
import { setTimeout as delay } from "node:timers/promises";

const appDirectory = path.resolve("dist");
// Resolve o Chromium no Replit, no PATH ou no Playwright instalado (CI e máquinas locais).
const chromiumPath = (() => {
  const candidates = [
    process.env.CHROMIUM_PATH,
    "/repl/tools/bin/chromium",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/usr/bin/google-chrome",
  ].filter(Boolean);
  for (const candidate of candidates) {
    if (existsSync(candidate)) return candidate;
  }
  try {
    return createRequire(import.meta.url)("playwright").chromium.executablePath();
  } catch {
    return candidates[0];
  }
})();
const mimeTypes = {
  ".css": "text/css",
  ".html": "text/html",
  ".ico": "image/x-icon",
  ".js": "text/javascript",
  ".json": "application/json",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".woff2": "font/woff2",
};

const server = createServer(async (request, response) => {
  const url = new URL(request.url || "/", "http://localhost");
  const requestedPath = decodeURIComponent(url.pathname).replace(/^\/+/, "");
  let filename = path.resolve(appDirectory, requestedPath || "index.html");
  if (!filename.startsWith(`${appDirectory}${path.sep}`) && filename !== appDirectory) {
    response.writeHead(400).end("Invalid path");
    return;
  }
  try {
    await access(filename);
  } catch {
    filename = path.join(appDirectory, "index.html");
  }
  try {
    const contents = await readFile(filename);
    response.writeHead(200, {
      "Cache-Control": "no-store",
      "Content-Type": mimeTypes[path.extname(filename)] || "application/octet-stream",
    });
    response.end(contents);
  } catch {
    response.writeHead(404).end("Not found");
  }
});

class DevTools {
  #socket;
  #nextId = 0;
  #pending = new Map();

  constructor(socket) {
    this.#socket = socket;
    socket.addEventListener("message", (event) => {
      const message = JSON.parse(event.data);
      if (!message.id) return;
      const pending = this.#pending.get(message.id);
      if (!pending) return;
      this.#pending.delete(message.id);
      if (message.error) pending.reject(new Error(message.error.message));
      else pending.resolve(message.result);
    });
  }

  async send(method, params = {}) {
    const id = ++this.#nextId;
    const result = new Promise((resolve, reject) => this.#pending.set(id, { resolve, reject }));
    this.#socket.send(JSON.stringify({ id, method, params }));
    return result;
  }

  async evaluate(expression) {
    const response = await this.send("Runtime.evaluate", {
      expression,
      awaitPromise: true,
      returnByValue: true,
      userGesture: true,
    });
    if (response.exceptionDetails) {
      throw new Error(response.exceptionDetails.text || "Browser evaluation failed");
    }
    return response.result?.value;
  }

  close() {
    this.#socket.close();
  }
}

async function waitFor(predicate, message, timeout = 12_000) {
  const deadline = Date.now() + timeout;
  let lastError;
  while (Date.now() < deadline) {
    try {
      if (await predicate()) return;
    } catch (error) {
      lastError = error;
    }
    await delay(100);
  }
  throw new Error(message, { cause: lastError });
}

async function stopBrowser(child, userDataDir) {
  const exited = new Promise((resolve) => child.once("exit", resolve));
  try {
    process.kill(-child.pid, "SIGTERM");
  } catch {
    child.kill("SIGTERM");
  }
  await Promise.race([exited, delay(2_000)]);
  try {
    process.kill(-child.pid, "SIGKILL");
  } catch {
    child.kill("SIGKILL");
  }
  await Promise.race([exited, delay(1_000)]);
  await rm(userDataDir, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
}

async function startBrowser() {
  const userDataDir = await mkdtemp(path.join(tmpdir(), "gabinete-responsive-browser-"));
  const child = spawn(chromiumPath, [
    "--headless=new",
    "--no-sandbox",
    "--disable-gpu",
    "--no-first-run",
    "--no-default-browser-check",
    "--remote-debugging-address=127.0.0.1",
    "--remote-debugging-port=0",
    `--user-data-dir=${userDataDir}`,
    "about:blank",
  ], { stdio: "ignore", detached: true });

  try {
    const portFile = path.join(userDataDir, "DevToolsActivePort");
    let port;
    await waitFor(async () => {
      try {
        port = Number((await readFile(portFile, "utf8")).split("\n")[0]);
        return port > 0;
      } catch {
        return false;
      }
    }, "Chromium did not start its remote debugging endpoint.");
    const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    const target = targets.find((item) => item.type === "page");
    assert.ok(target?.webSocketDebuggerUrl, "Chromium did not expose a page target.");
    const socket = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => {
      socket.addEventListener("open", resolve, { once: true });
      socket.addEventListener("error", reject, { once: true });
    });
    return { child, userDataDir, devtools: new DevTools(socket) };
  } catch (error) {
    await stopBrowser(child, userDataDir);
    throw error;
  }
}

test("refined cabinet header and side panels fit phone, tablet, and desktop widths", async (t) => {
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });

  let browser;
  t.after(async () => {
    browser?.devtools.close();
    if (browser) await stopBrowser(browser.child, browser.userDataDir);
    server.closeAllConnections();
    server.close();
  });
  browser = await startBrowser();
  await browser.devtools.send("Page.enable");
  await browser.devtools.send("Runtime.enable");
  const appUrl = `http://127.0.0.1:${server.address().port}/preview/gabinete-main/Refined`;

  for (const width of [390, 768, 1024, 1280]) {
    await browser.devtools.send("Emulation.setDeviceMetricsOverride", {
      width,
      height: 900,
      deviceScaleFactor: 1,
      mobile: true,
    });
    await browser.devtools.send("Page.navigate", { url: appUrl });
    await waitFor(
      () => browser.devtools.evaluate(`Boolean(document.querySelector('.gm-root'))`),
      `Refined preview did not render at ${width}px.`,
    );

    const layout = await browser.devtools.evaluate(`(() => {
      const rect = (selector) => {
        const element = document.querySelector(selector);
        if (!element) return null;
        const box = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        return {
          x: box.x, y: box.y, right: box.right, bottom: box.bottom,
          width: box.width, height: box.height,
          display: style.display, position: style.position,
        };
      };
      return {
        viewportWidth: innerWidth,
        documentWidth: document.documentElement.scrollWidth,
        bodyWidth: document.body.scrollWidth,
        title: rect('.cmt-ab-title'),
        navigation: rect('.cmt-apptabs'),
        actions: rect('.cmt-ab-gear'),
        header: rect('#cmt-appbar'),
        overview: rect('.pc-session-overview'),
        left: rect('#alt-side'),
        main: rect('#app-content'),
        calendar: rect('#alt-rside'),
        calendarToggle: rect('#alt-rp-tab'),
      };
    })()`);

    assert.equal(layout.viewportWidth, width, `Chromium viewport should be ${width}px.`);
    assert.ok(
      layout.documentWidth <= width && layout.bodyWidth <= width,
      `${width}px layout causes horizontal page scrolling: ${JSON.stringify(layout)}`,
    );
    for (const name of ["title", "navigation", "actions"]) {
      assert.ok(layout[name]?.display !== "none" && layout[name].width > 0, `${name} is unavailable at ${width}px.`);
    }
    for (const [firstName, secondName] of [
      ["title", "navigation"],
      ["title", "actions"],
      ["navigation", "actions"],
    ]) {
      const first = layout[firstName];
      const second = layout[secondName];
      const overlap = first.x < second.right && first.right > second.x &&
        first.y < second.bottom && first.bottom > second.y;
      assert.equal(overlap, false, `${firstName} overlaps ${secondName} at ${width}px: ${JSON.stringify(layout)}`);
    }
    assert.ok(
      layout.overview.y >= layout.header.bottom - 1,
      `Central content overlaps the header at ${width}px: ${JSON.stringify(layout)}`,
    );
    assert.ok(layout.left.width > 0 && layout.main.width > 0, `Left navigation or central content is missing at ${width}px.`);
    assert.ok(
      layout.left.right <= layout.main.x + 1 || layout.left.bottom <= layout.main.y + 1,
      `Left panel overlaps the central content at ${width}px: ${JSON.stringify(layout)}`,
    );
    assert.equal(
      layout.calendar.display !== "none",
      width > 1120,
      `Calendar rail should be inline only on desktop at ${width}px.`,
    );
    assert.equal(
      layout.calendarToggle.display !== "none",
      width <= 1120,
      `Calendar toggle visibility is incorrect at ${width}px.`,
    );

    if (width > 1120) {
      assert.ok(
        layout.main.x + layout.main.width <= layout.calendar.x + 1,
        `Desktop calendar rail overlaps central content at ${width}px.`,
      );
    } else {
      await browser.devtools.evaluate(`document.querySelector('#alt-rp-tab').click()`);
      await waitFor(
        () => browser.devtools.evaluate(`document.querySelector('.gm-root').classList.contains('gm-calendar-open')`),
        `Calendar rail did not open at ${width}px.`,
      );
      const opened = await browser.devtools.evaluate(`(() => {
        const panel = document.querySelector('#alt-rside').getBoundingClientRect();
        return {
          visible: getComputedStyle(document.querySelector('#alt-rside')).display !== 'none',
          toggleHidden: getComputedStyle(document.querySelector('#alt-rp-tab')).display === 'none',
          panelLeft: panel.left,
          panelRight: panel.right,
          documentWidth: document.documentElement.scrollWidth,
        };
      })()`);
      assert.equal(opened.visible, true, `Calendar rail did not become visible at ${width}px.`);
      assert.equal(opened.toggleHidden, true, `Calendar open toggle remained visible at ${width}px.`);
      assert.ok(
        opened.panelLeft >= 0 && opened.panelRight <= width + 1 && opened.documentWidth <= width,
        `Opened calendar rail breaks the ${width}px viewport: ${JSON.stringify(opened)}`,
      );
      await browser.devtools.evaluate(`document.querySelector('[aria-label="Fechar Calendário público"]').click()`);
      await waitFor(
        () => browser.devtools.evaluate(`!document.querySelector('.gm-root').classList.contains('gm-calendar-open')`),
        `Calendar rail did not close at ${width}px.`,
      );
      const restored = await browser.devtools.evaluate(`({
        mainVisible: document.querySelector('#app-content').getBoundingClientRect().width > 0,
        toggleVisible: getComputedStyle(document.querySelector('#alt-rp-tab')).display !== 'none',
        documentWidth: document.documentElement.scrollWidth,
      })`);
      assert.equal(restored.mainVisible, true, `Central content was unavailable after closing the calendar at ${width}px.`);
      assert.equal(restored.toggleVisible, true, `Calendar toggle did not return at ${width}px.`);
      assert.ok(restored.documentWidth <= width, `Closing the calendar caused horizontal scrolling at ${width}px.`);
    }
  }
});

import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Uma folha de estilo que falhe ao carregar (rede bloqueada, fonte externa)
// não deve impedir a prévia de abrir: o componente continua utilizável.
window.addEventListener("vite:preloadError", (event) => {
  event.preventDefault();
});

createRoot(document.getElementById("root")!).render(<App />);

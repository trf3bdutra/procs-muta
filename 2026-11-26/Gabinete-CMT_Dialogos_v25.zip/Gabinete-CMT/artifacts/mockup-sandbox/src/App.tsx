import { useEffect, useState, type ComponentType } from "react";
import { modules } from "./.generated/mockup-components";

type ModuleMap = Record<string, () => Promise<Record<string, unknown>>>;

function resolveComponent(
  mod: Record<string, unknown>,
  name: string,
): ComponentType | undefined {
  const functions = Object.values(mod).filter(
    (value): value is ComponentType => typeof value === "function",
  );
  return (
    (mod.default as ComponentType | undefined) ||
    (mod.Preview as ComponentType | undefined) ||
    (mod[name] as ComponentType | undefined) ||
    functions[functions.length - 1]
  );
}

function getPreviewPath(): string | null {
  const base = import.meta.env.BASE_URL.replace(/\/+$/, "");
  let pathname = window.location.pathname;
  if (base && pathname.startsWith(base)) pathname = pathname.slice(base.length);
  pathname = pathname.replace(/^\/+|\/+$/g, "");
  const match = pathname.match(/^preview\/(.+)$/);
  if (!match) return null;
  try {
    return decodeURIComponent(match[1]).replace(/\.tsx$/, "");
  } catch {
    return match[1].replace(/\.tsx$/, "");
  }
}

function PreviewRenderer({
  componentPath,
  registry,
}: {
  componentPath: string;
  registry: ModuleMap;
}) {
  const [Component, setComponent] = useState<ComponentType | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setComponent(null);
    setError(null);

    async function load(): Promise<void> {
      const key = `./components/mockups/${componentPath}.tsx`;
      const loader = registry[key];
      if (!loader) {
        setError(`Componente não encontrado: ${componentPath}.tsx`);
        return;
      }
      try {
        const mod = await loader();
        if (cancelled) return;
        const name = componentPath.split("/").pop() || "";
        const resolved = resolveComponent(mod, name);
        if (!resolved) {
          setError(`Nenhum componente React exportado em ${componentPath}.tsx.`);
          return;
        }
        setComponent(() => resolved);
      } catch (reason) {
        if (!cancelled) {
          setError(reason instanceof Error ? reason.message : String(reason));
        }
      }
    }

    void load();
    return () => {
      cancelled = true;
    };
  }, [componentPath, registry]);

  if (error) {
    return (
      <main role="alert" style={{ padding: 24, color: "#8a2e2e", fontFamily: "system-ui, sans-serif" }}>
        Não foi possível abrir esta prévia: {error}
      </main>
    );
  }
  return Component ? <Component /> : null;
}

function Gallery({ registry }: { registry: ModuleMap }) {
  const entries = Object.keys(registry)
    .map((key) => key.replace(/^\.\/components\/mockups\//, "").replace(/\.tsx$/, ""))
    .sort();

  return (
    <main style={{ maxWidth: 760, margin: "10vh auto", padding: 24, color: "#334155", fontFamily: "system-ui, sans-serif" }}>
      <p style={{ fontSize: 11, letterSpacing: ".12em", textTransform: "uppercase", color: "#7b8792" }}>
        Gabinete CMT · sandbox de componentes
      </p>
      <h1 style={{ fontSize: 24, marginBottom: 8 }}>Pré-visualizações</h1>
      <p style={{ color: "#64748b" }}>Abra um componente pelo endereço de prévia para visualizá-lo isoladamente.</p>
      <ul style={{ paddingLeft: 20, lineHeight: 1.9 }}>
        {entries.map((entry) => (
          <li key={entry}>
            <a href={`${import.meta.env.BASE_URL}preview/${entry}`} style={{ color: "#36576d" }}>
              {entry}
            </a>
          </li>
        ))}
      </ul>
    </main>
  );
}

function App() {
  const componentPath = getPreviewPath();
  return componentPath ? (
    <PreviewRenderer componentPath={componentPath} registry={modules} />
  ) : (
    <Gallery registry={modules} />
  );
}

export default App;

import { useMemo, useState, type ReactNode } from "react";
import "./shared-pauta-refined.css";

type PautaRow = {
  id: number;
  process: string;
  subject: string;
  rapporteur: string;
  clerk: string;
  status: "Minutado" | "Em revisão" | "Pendente";
  item: string;
};

const initialRows: PautaRow[] = [
  { id: 1, process: "5001842-61.2023.4.03.6000", subject: "Benefício previdenciário · aposentadoria rural", rapporteur: "Des. Fed. André Nabarrete", clerk: "Marina Lopes", status: "Minutado", item: "01" },
  { id: 2, process: "5000927-14.2022.4.03.6000", subject: "Responsabilidade civil · dano moral", rapporteur: "Des. Fed. André Nabarrete", clerk: "Rafael Mendonça", status: "Em revisão", item: "02" },
  { id: 3, process: "5007310-08.2021.4.03.6000", subject: "Execução fiscal · prescrição intercorrente", rapporteur: "Des. Fed. Inês Virgínia", clerk: "Marina Lopes", status: "Pendente", item: "03" },
  { id: 4, process: "5002165-39.2023.4.03.6000", subject: "Direito administrativo · servidor público", rapporteur: "Des. Fed. Inês Virgínia", clerk: "Caio Martins", status: "Em revisão", item: "04" },
  { id: 5, process: "5004881-72.2022.4.03.6000", subject: "Benefício assistencial · pessoa com deficiência", rapporteur: "Des. Fed. André Nabarrete", clerk: "Rafael Mendonça", status: "Minutado", item: "05" },
];

function Icon({ name, size = 18 }: { name: string; size?: number }) {
  const paths: Record<string, ReactNode> = {
    grid: <><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18" /></>,
    archive: <><path d="M4 4h16v5H4zM6 9v11h12V9M10 13h4" /></>,
    chart: <><path d="M4 19V5M4 19h17M8 15l4-4 3 2 5-7" /></>,
    search: <><circle cx="10.8" cy="10.8" r="6.8" /><path d="m16 16 4.5 4.5" /></>,
    chevron: <path d="m7 10 5 5 5-5" />,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    download: <><path d="M12 3v12m-5-5 5 5 5-5M4 20h16" /></>,
    more: <><circle cx="5" cy="12" r="1" fill="currentColor" stroke="none" /><circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" /><circle cx="19" cy="12" r="1" fill="currentColor" stroke="none" /></>,
    filter: <><path d="M4 6h16M7 12h10m-7 6h4" /></>,
    bell: <><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" /></>,
    check: <path d="m5 12 4 4L19 6" />,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

export default function SharedPautaRefined() {
  const [rows, setRows] = useState(initialRows);
  const [activeView, setActiveView] = useState("Pauta atual");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<number[]>([]);
  const [saved, setSaved] = useState(true);
  const [filter, setFilter] = useState("Todos os status");
  const visibleRows = useMemo(() => rows.filter(row => {
    const matchesSearch = `${row.process} ${row.subject} ${row.rapporteur} ${row.clerk}`.toLowerCase().includes(search.toLowerCase());
    return matchesSearch && (filter === "Todos os status" || row.status === filter);
  }), [rows, search, filter]);
  const toggleSelected = (id: number) => setSelected(current => current.includes(id) ? current.filter(item => item !== id) : [...current, id]);
  const updateStatus = (id: number) => {
    setRows(current => current.map(row => row.id === id ? { ...row, status: row.status === "Pendente" ? "Em revisão" : row.status === "Em revisão" ? "Minutado" : "Pendente" } : row));
    setSaved(false);
  };
  const views = ["Pauta atual", "Todas as sessões", "Acompanhar"];

  return (
    <main className="pr-shell">
      <aside className="pr-sidebar">
        <div className="pr-brand">
          <div className="pr-mark"><span>G</span><i /></div>
          <div><strong>Gabinete CMT</strong><small>TRF · 3ª REGIÃO</small></div>
        </div>
        <div className="pr-side-label">ESPAÇO DE TRABALHO</div>
        <nav className="pr-nav" aria-label="Navegação principal">
          <button className="pr-nav-item active"><Icon name="grid" /> <span>Mesa do CM</span><span className="pr-nav-indicator" /></button>
          <button className="pr-nav-item" onClick={() => setActiveView("Pauta atual")}><Icon name="calendar" /><span>Calendário</span></button>
          <button className="pr-nav-item" onClick={() => setActiveView("Todas as sessões")}><Icon name="archive" /><span>Acervo</span></button>
          <button className="pr-nav-item" onClick={() => setActiveView("Acompanhar")}><Icon name="chart" /><span>Indicadores</span></button>
        </nav>
        <div className="pr-sidebar-bottom">
          <div className="pr-sync"><span className="pr-sync-dot" /><div><b>Sincronizado</b><small>Atualizado há 2 min</small></div><Icon name="check" size={15} /></div>
          <div className="pr-user"><div className="pr-avatar">ML</div><div><b>Marina Lopes</b><small>Assessora</small></div><button aria-label="Mais opções"><Icon name="more" /></button></div>
        </div>
      </aside>

      <section className="pr-main">
        <header className="pr-topbar">
          <div className="pr-breadcrumb"><span>Gabinete</span><b>/</b><strong>Mesa do CM</strong></div>
          <div className="pr-top-actions">
            <div className={`pr-save-state ${saved ? "" : "pending"}`}><span />{saved ? "Tudo salvo" : "Alterações pendentes"}</div>
            <button className="pr-icon-button" aria-label="Notificações"><Icon name="bell" /><i /></button>
            <div className="pr-top-avatar">ML</div>
          </div>
        </header>

        <div className="pr-content">
          <div className="pr-heading">
            <div>
              <div className="pr-eyebrow"><span className="pr-eyebrow-line" /> GABINETE CMT <span className="pr-eyebrow-dot">·</span> MESA DE TRABALHO</div>
              <h1>Controle de pauta</h1>
              <p>Uma visão clara do que está pronto, em revisão e por decidir.</p>
            </div>
            <div className="pr-heading-actions">
              <button className="pr-secondary-button" onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 1800); }}><Icon name="download" size={16} /> Exportar</button>
              <button className="pr-primary-button" onClick={() => { const newId = Math.max(...rows.map(row => row.id)) + 1; setRows(current => [...current, { id: newId, process: `500${String(newId * 1387).padStart(4, "0")}-42.2024.4.03.6000`, subject: "Novo processo · classificação pendente", rapporteur: "A definir", clerk: "Marina Lopes", status: "Pendente", item: String(rows.length + 1).padStart(2, "0") }]); setSaved(false); }}><Icon name="plus" size={17} /> Adicionar processo</button>
            </div>
          </div>

          <div className="pr-session-bar">
            <div className="pr-session-title"><span className="pr-session-icon"><Icon name="calendar" size={16} /></span><div><span>SESSÃO DE JULGAMENTO</span><b>18ª Sessão Ordinária · 2025</b></div></div>
            <div className="pr-session-meta"><span className="pr-session-date">12 jun 2025 <Icon name="chevron" size={14} /></span><span className="pr-session-divider" /><span className="pr-session-count"><b>{rows.length}</b> processos na pauta</span><span className="pr-live-dot" /> <span className="pr-live-label">COMPARTILHADA</span></div>
          </div>

          <section className="pr-summary" aria-label="Resumo da sessão">
            <div className="pr-summary-intro"><span>VISÃO GERAL</span><small>Esta sessão</small></div>
            <div className="pr-metric"><div className="pr-metric-label">Total de processos <span className="pr-metric-icon">▦</span></div><div className="pr-metric-value">128 <small>itens</small></div><div className="pr-metric-foot">+12 desde a última sessão</div></div>
            <div className="pr-metric"><div className="pr-metric-label"><i className="status-dot gold" /> Minutados</div><div className="pr-metric-value">84 <small><span className="pr-metric-percent">65,6%</span></small></div><div className="pr-mini-track"><i style={{ width: "66%" }} /></div></div>
            <div className="pr-metric"><div className="pr-metric-label"><i className="status-dot blue" /> Em revisão</div><div className="pr-metric-value">31 <small><span className="pr-metric-percent">24,2%</span></small></div><div className="pr-mini-track blue-track"><i style={{ width: "24%" }} /></div></div>
            <div className="pr-metric"><div className="pr-metric-label"><i className="status-dot muted" /> Pendentes</div><div className="pr-metric-value">13 <small><span className="pr-metric-percent">10,2%</span></small></div><div className="pr-mini-track muted-track"><i style={{ width: "10%" }} /></div></div>
          </section>

          <section className="pr-worklist">
            <div className="pr-list-heading">
              <div><h2>Processos da sessão</h2><p>Organize o trabalho e acompanhe cada etapa.</p></div>
              <button className="pr-text-action" onClick={() => setSelected(visibleRows.map(row => row.id))}>Selecionar vários <span>↗</span></button>
            </div>
            <div className="pr-tabs" role="tablist" aria-label="Visualização da pauta">
              {views.map(view => <button key={view} role="tab" aria-selected={activeView === view} onClick={() => setActiveView(view)} className={activeView === view ? "selected" : ""}>{view}{view === "Pauta atual" && <span className="pr-tab-count">{rows.length}</span>}</button>)}
            </div>
            <div className="pr-toolbar">
              <label className="pr-search"><Icon name="search" size={17} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Buscar processo, assunto ou responsável…" /></label>
              <div className="pr-toolbar-right">
                <select value={filter} onChange={event => setFilter(event.target.value)} aria-label="Filtrar por status"><option>Todos os status</option><option>Minutado</option><option>Em revisão</option><option>Pendente</option></select>
                <button className="pr-filter-button" onClick={() => setFilter(filter === "Todos os status" ? "Pendente" : "Todos os status")}><Icon name="filter" size={16} /> Filtros</button>
                <button className="pr-more-button" aria-label="Mais opções"><Icon name="more" /></button>
              </div>
            </div>
            {selected.length > 0 && <div className="pr-selection-bar"><strong>{selected.length} selecionados</strong><span>Atualizar status:</span><button onClick={() => { setRows(current => current.map(row => selected.includes(row.id) ? { ...row, status: "Em revisão" } : row)); setSelected([]); setSaved(false); }}>Em revisão</button><button onClick={() => { setRows(current => current.map(row => selected.includes(row.id) ? { ...row, status: "Minutado" } : row)); setSelected([]); setSaved(false); }}>Minutado</button><button className="pr-clear-select" onClick={() => setSelected([])}>Limpar</button></div>}
            <div className="pr-table-wrap">
              <table className="pr-table">
                <thead><tr><th className="pr-check-cell"><input aria-label="Selecionar todos" type="checkbox" checked={selected.length === visibleRows.length && visibleRows.length > 0} onChange={() => setSelected(selected.length === visibleRows.length ? [] : visibleRows.map(row => row.id))} /></th><th>ITEM / PROCESSO</th><th>ASSUNTO</th><th>RELATOR</th><th>RESPONSÁVEL</th><th>STATUS</th><th aria-label="Ações" /></tr></thead>
                <tbody>{visibleRows.map(row => <tr key={row.id}>
                  <td className="pr-check-cell"><input aria-label={`Selecionar processo ${row.process}`} type="checkbox" checked={selected.includes(row.id)} onChange={() => toggleSelected(row.id)} /></td>
                  <td><div className="pr-process"><span className="pr-item-number">{row.item}</span><div><b>{row.process}</b><small>Apelação Cível</small></div></div></td>
                  <td><span className="pr-subject">{row.subject}</span></td>
                  <td><span className="pr-person">{row.rapporteur.replace("Des. Fed. ", "")}</span></td>
                  <td><div className="pr-clerk"><span>{row.clerk.split(" ").map(part => part[0]).slice(0, 2).join("")}</span>{row.clerk}</div></td>
                  <td><button className={`pr-status ${row.status === "Minutado" ? "complete" : row.status === "Em revisão" ? "review" : "pending"}`} onClick={() => updateStatus(row.id)}><i />{row.status}<Icon name="chevron" size={13} /></button></td>
                  <td><button className="pr-row-more" aria-label={`Opções para ${row.process}`}><Icon name="more" size={17} /></button></td>
                </tr>)}</tbody>
              </table>
              {visibleRows.length === 0 && <div className="pr-empty"><span><Icon name="search" size={20} /></span><b>Nenhum processo encontrado</b><small>Tente outro termo ou ajuste o filtro de status.</small><button onClick={() => { setSearch(""); setFilter("Todos os status"); }}>Limpar busca</button></div>}
            </div>
            <div className="pr-table-footer"><span>Exibindo <b>{visibleRows.length ? 1 : 0}–{visibleRows.length}</b> de <b>{rows.length}</b> processos</span><div><button disabled aria-label="Página anterior">‹</button><button className="page-active">1</button><button onClick={() => setActiveView("Todas as sessões")}>2</button><button onClick={() => setActiveView("Todas as sessões")}>3</button><span>…</span><button onClick={() => setActiveView("Todas as sessões")}>9</button><button aria-label="Próxima página" onClick={() => setActiveView("Todas as sessões")}>›</button></div></div>
          </section>
          <footer className="pr-footer"><span>Gabinete CMT <i>·</i> Controle de pauta</span><span><span className="pr-footer-dot" /> Dados compartilhados com segurança</span></footer>
        </div>
      </section>
    </main>
  );
}

import "./_group.css";

const sampleText =
  "A apelação foi conhecida e teve o pedido analisado. A sentença permanece válida diante do conjunto dos autos.";

function currentConformityMarkup() {
  const ST: {
    F: {
      conf: Record<string, string>;
      acRes: string;
      esp: string;
      ctx: string;
    };
    tab: string;
  } = {
    F: {
      conf: {},
      acRes: "nega provimento à apelação",
      esp: "ap",
      ctx: "",
    },
    tab: "rel",
  };
  const texto = (_tab: string) => sampleText;
  const N = (value: unknown) =>
    String(value ?? "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();
  const E = (value: unknown) =>
    String(value ?? "").replace(/[&<>"']/g, (char) =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;",
      })[char]!,
    );

  // Extracted from rotHTML() in gabcmt.html; state and text are local fixtures.
  function rotHTML() {
    var F = ST.F,
      tab = ST.tab,
      body = texto(tab),
      low = N(body),
      has = body.replace(/\{\{[^}]*\}\}/g, "").trim().length > 30;
    var checks: Array<{
      group: string;
      id: string;
      label: string;
      explain: string;
      status: string;
      manual: boolean;
    }> = [];
    function add(
      group: string,
      id: string,
      label: string,
      explain: string,
      auto: string,
    ) {
      var saved = F.conf && F.conf[id],
        value =
          saved === "ok" ||
          saved === "bad" ||
          saved === "na"
            ? saved
            : null;
      var status = value || auto || "review";
      checks.push({
        group: group,
        id: id,
        label: label,
        explain: explain,
        status: status,
        manual: !!value,
      });
    }
    add(
      "Estrutura",
      "cab",
      "O documento contém abertura adequada à espécie e ao pronunciamento?",
      "A presença de uma abertura não demonstra sua suficiência jurídica. Confronte-a com o tipo de voto.",
      has ? "review" : "bad",
    );
    if (tab === "em") {
      throw new Error("The extracted fixture uses the Relatório tab.");
    } else {
      add(
        "Fundamentação",
        "fund",
        "A minuta enfrenta as questões jurídicas efetivamente registradas no Prontuário?",
        "Verificação humana: a existência de texto não comprova enfrentamento suficiente das questões.",
        "review",
      );
      add(
        "Fundamentação",
        "regras",
        "Os fundamentos legais e precedentes foram expostos depois do raciocínio do caso?",
        "Verifique a progressão lógica antes da jurisprudência, sem conferir apenas palavras-chave.",
        "review",
      );
      add(
        "Encerramento",
        "resultado",
        "A solução jurídica da controvérsia conduz a resultado definido na minuta?",
        "Confronte as conclusões escritas com o resultado processual registrado. Não redefina o resultado aqui.",
        F.acRes && low.includes(N(F.acRes)) ? "ok" : "review",
      );
      add(
        "Encerramento",
        "hon",
        "Honorários, sucumbência e consectários estão tratados para este resultado?",
        "O Prontuário registra o tratamento jurídico; aqui se verifica sua redação na minuta.",
        "review",
      );
      add(
        "Encerramento",
        "disp",
        "O dispositivo redigido corresponde às conclusões do Prontuário?",
        "Verificar conhecimento, provimento, extensão, efeitos e eventual julgamento parcial.",
        "review",
      );
      if (/retrata/i.test([F.esp, F.ctx].join(" ")))
        add(
          "Espécie",
          "retr",
          "O voto de retratação enfrenta a aderência ou distinção ao precedente vinculante?",
          "Compatibilidade com o precedente é análise do caso; sua exposição na minuta é Conformidade.",
          "review",
        );
    }
    var counts = { ok: 0, bad: 0, review: 0, na: 0 };
    checks.forEach(function (check) {
      counts[check.status as keyof typeof counts] =
        (counts[check.status as keyof typeof counts] || 0) + 1;
    });
    return (
      '<div class="gr-conf"><h5>Conformidade da ' +
      (tab === "em" ? "ementa" : tab === "esq" ? "minuta de voto" : "redação") +
      "</h5>" +
      '<p class="gr-vz">Verificação do texto gerado. Questões de admissibilidade, prova e solução jurídica permanecem no Prontuário.</p>' +
      '<div class="gr-conf-summary"><b>' +
      counts.bad +
      " alertas</b> · " +
      counts.review +
      " a conferir · " +
      counts.ok +
      " conformes · " +
      counts.na +
      " N/A</div>" +
      checks
        .map(function (check) {
          return (
            '<section class="gr-rg gr-conf-item"><small>' +
            E(check.group) +
            " · " +
            (check.manual ? "conferido manualmente" : "inspeção automática") +
            "</small><b>" +
            E(check.label) +
            "</b><p>" +
            E(check.explain) +
            '</p><div class="gr-conf-controls">' +
            [
              ["ok", "Conforme"],
              ["bad", "Inconforme"],
              ["review", "Conferir"],
              ["na", "N/A"],
            ]
              .map(function (option) {
                return (
                  '<button type="button" data-gr="conf-set" data-id="' +
                  E(check.id) +
                  '" data-val="' +
                  option[0] +
                  '" class="' +
                  (check.status === option[0] ? "on" : "") +
                  '">' +
                  option[1] +
                  "</button>"
                );
              })
              .join("") +
            "</div></section>"
          );
        })
        .join("") +
      '<p class="gr-vz">As marcações manuais são específicas deste rascunho. Diretrizes oferece a orientação e as fórmulas de redação.</p></div>'
    );
  }

  return rotHTML();
}

const sourceTabs = [
  ["rot", "Conformidade"],
  ["dir", "Diretrizes"],
  ["mod", "Modelos"],
  ["par", "Trechos"],
  ["sim", "Correspondências"],
];

export function Current() {
  return (
    <main id="cmt-ger" aria-label="Gerador de Acórdão">
      <aside className="gr-c3" aria-label="Apoio">
        <nav className="gr-ap" aria-label="Recursos de apoio">
          {sourceTabs.map(([id, label]) => (
            <button
              className={id === "rot" ? "on" : ""}
              key={id}
              type="button"
              data-ap={id}
              aria-pressed={id === "rot"}
            >
              {label}
              {id === "sim" ? <em>5</em> : null}
            </button>
          ))}
        </nav>
        <div
          className="gr-apb"
          dangerouslySetInnerHTML={{ __html: currentConformityMarkup() }}
        />
      </aside>
    </main>
  );
}

import "./_group.css";

const navItems = ["Pauta", "Decisões", "Triagem"];

function Badge() {
  return (
    <div className="badge-updated">
      <div className="badge-updated-top">
        <button className="mini-action" aria-label="Encerrar sessão">↪</button>
        <div className="badge-updated-ident">
          <b>JUSTIÇA FEDERAL</b>
          <span>TRF DA 3ª REGIÃO</span>
          <span className="online-pill"><i /> <b>4</b> pessoas online</span>
        </div>
        <button className="mini-action" aria-label="Recolher barra">‹</button>
      </div>
      <div className="badge-updated-person">
        <div className="avatar-updated">BR</div>
        <div className="person-copy">
          <b>Servidor</b>
          <span>Assessoria</span>
        </div>
      </div>
      <div className="stats-updated">
        <div><b>4</b><span>Disponíveis</span><small>na equipe</small></div>
        <div><b>18</b><span>Minutadas</span><small>hoje</small></div>
        <div><b>1</b><span>Meta</span><small>do dia</small></div>
      </div>
      <div className="session-updated"><i /> DISPONÍVEL <b>GABINETE CMT · TRMS</b></div>
    </div>
  );
}

function Rail({ compact = false }: { compact?: boolean }) {
  return (
    <aside className={`rail-updated ${compact ? "rail-updated-compact" : ""}`}>
      <div className="rail-updated-top">
        {!compact && <Badge />}
        {compact && <div className="avatar-updated compact-avatar">BR</div>}
      </div>
      <nav className="nav-updated" aria-label="Navegação">
        {navItems.map((item, index) => (
          <div className={index === 0 ? "nav-updated-item active" : "nav-updated-item"} key={item}>
            <i>{index === 0 ? "▤" : index === 1 ? "◫" : "⌕"}</i>
            {!compact && <span>{item}</span>}
          </div>
        ))}
      </nav>
      <div className="rail-updated-tools">
        <button aria-label="Notificações">♧</button>
        {!compact && <span>Notificações</span>}
      </div>
      {compact && <div className="justice-base" title="Gabinete CMT"><span>JF</span></div>}
    </aside>
  );
}

export function Updated() {
  return (
    <main className="sidebar-stage updated-stage">
      <header className="sidebar-stage-header">
        <div><b>GabCMT</b><span>Crachá integrado · presença visível · trilho compacto</span></div>
        <span className="state-label improved">proposta</span>
      </header>
      <section className="sidebar-stage-views">
        <div className="sidebar-view">
          <span className="view-label">Expandida</span>
          <Rail />
        </div>
        <div className="sidebar-view">
          <span className="view-label">Minimizada</span>
          <Rail compact />
        </div>
      </section>
    </main>
  );
}

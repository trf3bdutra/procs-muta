import "./_group.css";

export function Current() {
  return (
    <div className="resource-demo resource-demo-stage">
      <section className="resource-demo-shell">
        <h2 className="resource-demo-title">Cartão do processo</h2>
        <p className="resource-demo-subtitle">Estrutura atual do recurso e da peça de resposta, reproduzida do formulário existente.</p>
        <div className="resource-demo-card">
          <div className="r3-resource">
            <div className="r3-resource-head"><span>Recurso principal</span></div>
            <div className="r3-resource-fields">
              <label><span>Espécie</span><select defaultValue="ap"><option value="ap">Apelação</option><option>Agravo interno</option></select></label>
              <label><span>Parte recorrente</span><select defaultValue="inss"><option value="inss">INSS</option><option>Parte autora</option></select></label>
              <label><span>Data do recurso</span><input type="date" defaultValue="2026-10-22" /></label>
              <label><span>ID(s) do recurso</span><input placeholder="Um ou mais IDs" defaultValue="287103190" /></label>
            </div>
            <div className="r3-resource-response">
              <div className="r3-resource-response-title">RESPOSTA VINCULADA · CONTRARRAZÕES</div>
              <div className="r3-resource-fields">
                <label><span>Situação</span><select defaultValue="apresentadas"><option value="apresentadas">Apresentadas</option><option value="nao">Não apresentadas</option></select></label>
                <label><span>ID(s) da peça resposta</span><input placeholder="Um ou mais IDs" defaultValue="291880442" /></label>
                <label><span>Data da peça resposta</span><input type="date" defaultValue="2026-10-29" /></label>
              </div>
            </div>
          </div>
          <button className="resource-demo-add" type="button">＋ Adicionar recurso</button>
        </div>
      </section>
    </div>
  );
}

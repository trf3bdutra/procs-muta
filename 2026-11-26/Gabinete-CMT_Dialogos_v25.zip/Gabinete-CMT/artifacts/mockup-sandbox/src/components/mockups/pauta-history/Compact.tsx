import { HistorySample } from "./HistorySample";

export function Compact() {
  return <HistorySample compact />;
}

import { useEffect, useId, useState, type ReactNode } from 'react';
import { LOADING_MESSAGES, MESSAGE_INTERVAL_MS, shuffleMessages } from './loading-messages';
import './gabinete-loader.css';

/** Único sistema de carregamento do Gabinete CMT.
 *  fullscreen = abertura do app · overlay = operação que bloqueia · inline = região de conteúdo. */
export type LoaderVariant = 'fullscreen' | 'overlay' | 'inline';

export interface GabineteLoaderProps {
  variant?: LoaderVariant;
  /** Etapa real da operação em curso (a única informação confiável da tela). */
  stage?: string;
  /** Detalhe opcional abaixo da etapa. */
  detail?: string;
  /** Nome da sessão autenticada; a saudação usa só o primeiro nome. Nunca fixo no componente. */
  userName?: string | null;
  /** Frases de ambientação, uma por vez. Padrão: só na tela cheia e fora do estado de erro. */
  rotateMessages?: boolean;
  /** Mensagem de boas-vindas da tela cheia. */
  welcome?: boolean;
  /** 0–100 quando houver progresso real; sem ele, a barra é indeterminada. */
  progress?: number;
  /** Estado de erro: sem barra nem frases; a etapa vira a mensagem do problema. */
  error?: boolean;
  /** Ocupa só o contêiner posicionado em que está (em vez da janela inteira). */
  cover?: boolean;
  logoSrc?: string;
  className?: string;
  /** Ações (por exemplo, tentar de novo ou sair), mostradas abaixo da barra. */
  children?: ReactNode;
}

const DEFAULT_LOGO = 'https://i.ibb.co/7t3P0c1m/LOGO-COM-FUNDO-QUADRADO1.png';

function greeting() {
  const hour = new Date().getHours();
  return hour < 12 ? 'Bom dia' : hour < 18 ? 'Boa tarde' : 'Boa noite';
}

function nextCycle(previous: string) {
  const queue = shuffleMessages(LOADING_MESSAGES);
  /* Não repete, na virada do ciclo, a última frase do ciclo anterior. */
  if (queue.length > 1 && queue[0] === previous) [queue[0], queue[1]] = [queue[1], queue[0]];
  return queue;
}

export function GabineteLoader({
  variant = 'fullscreen',
  stage = 'Preparando os processos e os dados da equipe…',
  detail,
  userName,
  rotateMessages,
  welcome = true,
  progress,
  error = false,
  cover = false,
  logoSrc = DEFAULT_LOGO,
  className = '',
  children,
}: GabineteLoaderProps) {
  const filterId = useId().replace(/:/g, '');
  const full = variant === 'fullscreen';
  const rotating = (rotateMessages ?? full) && !error;
  const [messages, setMessages] = useState(() => ({ queue: shuffleMessages(LOADING_MESSAGES), index: 0 }));

  useEffect(() => {
    if (!rotating || LOADING_MESSAGES.length < 2) return;
    const timer = window.setInterval(() => {
      setMessages((current) => {
        if (current.index + 1 < current.queue.length) return { ...current, index: current.index + 1 };
        return { queue: nextCycle(current.queue[current.queue.length - 1]), index: 0 };
      });
    }, MESSAGE_INTERVAL_MS);
    return () => window.clearInterval(timer);
  }, [rotating]);

  const known = typeof progress === 'number' && Number.isFinite(progress);
  const value = known ? Math.min(100, Math.max(0, progress as number)) : undefined;
  const name = typeof userName === 'string' ? userName.trim().split(/\s+/)[0] ?? '' : '';
  const classes = [
    'cmt-loader',
    `cmt-loader--${variant}`,
    cover ? 'cmt-loader--cover' : '',
    error ? 'is-error' : '',
    className,
  ].filter(Boolean).join(' ');

  return (
    <div className={classes} role="status" aria-live="polite" aria-busy={!error}>
      {variant !== 'inline' && (
        <svg className="cmt-loader__defs" aria-hidden="true" focusable="false" width="0" height="0">
          <filter id={filterId} colorInterpolationFilters="sRGB">
            <feColorMatrix type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  -0.3333 -0.3333 -0.3333 1 0" />
            <feComponentTransfer result="key">
              <feFuncA type="linear" slope="22" intercept="-1.05" />
            </feComponentTransfer>
            <feFlood floodColor="#e6d3a8" result="tint" />
            <feComposite in="tint" in2="key" operator="in" />
          </filter>
        </svg>
      )}
      <section className="cmt-loader__content">
        {variant !== 'inline' && (
          <img
            className="cmt-loader__logo"
            src={logoSrc}
            alt="Logotipo do Gabinete CMT"
            style={{ filter: `url(#${filterId}) drop-shadow(0 5px 18px rgba(0,0,0,.2))` }}
          />
        )}
        {full && (
          <>
            <p className="cmt-loader__identity">
              <strong>Gabinete do Des. Fed. Carlos Muta</strong>
              <span aria-hidden="true"> · </span>
              {greeting()}{name ? `, ${name}` : ''}
            </p>
            {welcome && !error && (
              <p className="cmt-loader__welcome">Que bom ter você aqui. A Turma estava esperando por você.</p>
            )}
          </>
        )}
        <p className="cmt-loader__stage">{stage}</p>
        {detail && <p className="cmt-loader__detail">{detail}</p>}
        {rotating && (
          <p className="cmt-loader__message" aria-live="off">{messages.queue[messages.index] ?? ''}</p>
        )}
        {!error && (
          <div
            className={`cmt-loader__track${known ? ' cmt-loader__track--determinate' : ''}`}
            role={known ? 'progressbar' : undefined}
            aria-valuemin={known ? 0 : undefined}
            aria-valuemax={known ? 100 : undefined}
            aria-valuenow={value}
            aria-label={known ? 'Progresso da operação' : undefined}
            aria-hidden={known ? undefined : true}
          >
            <div className="cmt-loader__progress" style={known ? { width: `${value}%` } : undefined} />
          </div>
        )}
        {children && <div className="cmt-loader__actions">{children}</div>}
      </section>
    </div>
  );
}

export default GabineteLoader;

import "./_group.css";

const processes = [
  {
    number: "5001234-12.2026.4.03.0000",
    className: "Agravo de Instrumento · Previdenciário",
    urgency: "Tutela de urgência",
    request: "Restabelecimento de benefício após cessação administrativa; risco social e prova documental.",
    parties: "M. S. A. × INSS",
    server: "ANA PAULA",
    received: "14/10/2026",
    deadline: "16/10/2026 · 2 dias úteis",
    status: "Aguardando análise",
    result: "—",
  },
  {
    number: "5005678-90.2026.4.03.0000",
    className: "Apelação Cível · Saúde",
    urgency: "Liminar",
    request: "Fornecimento de tratamento de uso contínuo enquanto se aguarda avaliação médica especializada.",
    parties: "J. R. C. × UNIÃO",
    server: "MARCELO",
    received: "13/10/2026",
    deadline: "19/10/2026 · 3 dias úteis",
    status: "Em elaboração",
    result: "—",
  },
];

export function Current() {
  return (
    <div className="urgency-demo-stage">
      <style>{`
        .urgent-current-scroll{overflow-x:auto;border:1px solid #e0e8ef;border-radius:9px;scrollbar-width:thin}
        .urgent-current-table{width:100%;min-width:1280px;table-layout:fixed;border-collapse:separate;border-spacing:0;font-size:11px}
        .urgent-current-table tbody{display:grid;gap:7px;padding:7px}
        .urgent-current-table tr{display:grid;grid-template-columns:minmax(160px,1.1fr) minmax(230px,1.7fr) minmax(125px,.95fr) minmax(92px,.65fr) minmax(160px,1.05fr) minmax(155px,1.05fr) minmax(175px,1.15fr) minmax(82px,.55fr);align-items:center;min-height:48px;border:1px solid #e3e9ee;border-radius:8px;background:#fff}
        .urgent-current-table td{display:flex;flex-direction:row;align-items:flex-start;gap:4px 7px;min-width:0;min-height:44px;padding:6px 8px;border-right:1px solid #edf1f4;color:#344b60;white-space:normal;overflow-wrap:anywhere}
        .urgent-current-table td:before{flex:0 0 auto;color:#82909e;font-size:7px;font-weight:800;letter-spacing:.06em}
        .urgent-current-table td:nth-child(1):before{content:"PROCESSO"}
        .urgent-current-table td:nth-child(2):before{content:"MEDIDA · PEDIDO"}
        .urgent-current-table td:nth-child(3):before{content:"RESPONSÁVEL"}
        .urgent-current-table td:nth-child(4):before{content:"RECEBIDO"}
        .urgent-current-table td:nth-child(5):before{content:"PRAZO"}
        .urgent-current-table td:nth-child(6):before{content:"ANDAMENTO"}
        .urgent-current-table td:nth-child(7):before{content:"RESULTADO"}
        .urgent-current-table td:nth-child(8){justify-content:center;border:0}
        .urgent-current-table td:nth-child(8):before{content:""}
        .urgent-current-table .urgent-demo-number,.urgent-current-table .urgent-demo-class,.urgent-current-table .urgent-demo-tag{flex:0 1 auto;min-width:0;overflow-wrap:anywhere}
        .urgent-current-table .urgent-demo-select{width:140px;flex:0 0 auto}
        @media(max-width:700px){.urgent-current-scroll{max-width:100%}}
      `}</style>
      <section className="urgency-demo-panel">
        <header className="urgency-demo-head">
          <div>
            <small>CONTROLE</small>
            <h2>Pedidos <span className="urgency-demo-muted">2</span></h2>
            <p>Andamento e dados essenciais dos pedidos de urgência.</p>
          </div>
          <button className="urgency-demo-add" type="button">＋ Processo</button>
        </header>
        <div className="urgent-current-scroll">
          <table className="urgent-current-table">
            <tbody>
              {processes.map((item) => (
                <tr key={item.number}>
                  <td><strong className="urgency-demo-number">{item.number}</strong><span className="urgency-demo-class">{item.className}</span><span className="urgency-demo-tag">{item.urgency}</span></td>
                  <td><span>{item.request}</span><small className="urgency-demo-muted">{item.parties}</small></td>
                  <td>{item.server}</td>
                  <td>{item.received}</td>
                  <td>{item.deadline}</td>
                  <td><select className="urgency-demo-select" defaultValue={item.status}><option>{item.status}</option></select></td>
                  <td>{item.result}</td>
                  <td><div className="urgency-demo-actions"><button type="button" aria-label="Editar">✎</button><button type="button" aria-label="Excluir">×</button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

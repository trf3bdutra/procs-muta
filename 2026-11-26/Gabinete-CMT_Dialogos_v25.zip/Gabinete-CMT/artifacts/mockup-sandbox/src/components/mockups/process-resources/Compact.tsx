import "./_group.css";

export function Compact() {
  return (
    <div className="resource-demo resource-demo-stage">
      <section className="resource-demo-shell">
        <h2 className="resource-demo-title">Cartão do processo</h2>
        <p className="resource-demo-subtitle">Cada resposta aparece logo abaixo do recurso correspondente.</p>
        <div className="resource-demo-card">
          <div className="resource-demo-row">
            <span className="resource-demo-label">Recurso</span>
            <select aria-label="Parte recorrente" defaultValue="INSS"><option>INSS</option><option>Parte autora</option><option>União</option></select>
            <select aria-label="Espécie do recurso" defaultValue="Apelação"><option>Apelação</option><option>Agravo interno</option></select>
            <button className="id-action" type="button">＋ ID</button>
            <button className="copy-action" type="button" aria-label="Copiar dados do recurso" title="Copiar dados do recurso">▢</button>
          </div>
          <div className="resource-demo-date"><input aria-label="Data do recurso" type="date" defaultValue="2026-10-22" /></div>
          <div className="resource-demo-row response">
            <span className="resource-demo-label">Contrarrazões</span>
            <select aria-label="Situação das contrarrazões" defaultValue="Apresentadas"><option>Apresentadas</option><option>Não apresentadas</option><option>Prazo em curso</option><option>—</option></select>
            <button className="id-action" type="button">＋ ID</button>
            <button className="copy-action" type="button" aria-label="Copiar dados da resposta" title="Copiar dados da resposta">▢</button>
          </div>
          <div className="resource-demo-date"><input aria-label="Data das contrarrazões" type="date" defaultValue="2026-10-29" /></div>
          <button className="resource-demo-add" type="button">＋ Adicionar recurso</button>
          <p className="resource-demo-note">Os IDs e as datas permanecem editáveis; cada resposta fica vinculada ao recurso da mesma linha.</p>
        </div>
      </section>
    </div>
  );
}

import { useMemo, useState } from "react";

type CaseItem = {
  number: string;
  title: string;
  party: string;
  rapporteur: string;
  status: "Pronto" | "Em revisão" | "Pendente";
  topic: string;
};

const sessions = [
  { day: "18", month: "JUN", label: "Sessão ordinária", year: "2025", count: 24, complete: 17, state: "Atual" },
  { day: "25", month: "JUN", label: "Sessão ordinária", year: "2025", count: 19, complete: 8, state: "Próxima" },
  { day: "02", month: "JUL", label: "Sessão extraordinária", year: "2025", count: 11, complete: 4, state: "Agendada" },
  { day: "09", month: "JUL", label: "Sessão ordinária", year: "2025", count: 16, complete: 0, state: "Agendada" },
];

const allCases: CaseItem[] = [
  { number: "5001842-61.2024.4.03.6000", title: "Benefício por incapacidade permanente", party: "Maria Aparecida dos Santos", rapporteur: "Des. Fed. João Silva", status: "Pronto", topic: "Previdenciário" },
  { number: "5009327-08.2023.4.03.6000", title: "Revisão de benefício — tempo especial", party: "Antônio Carlos Ferreira", rapporteur: "Des. Fed. João Silva", status: "Em revisão", topic: "Previdenciário" },
  { number: "5002714-33.2024.4.03.6000", title: "Responsabilidade civil do Estado", party: "Comercial Pantanal Ltda.", rapporteur: "Des. Fed. Ana Ribeiro", status: "Pronto", topic: "Administrativo" },
  { number: "5006190-45.2022.4.03.6000", title: "Fornecimento de medicamento", party: "Lucas Henrique Nunes", rapporteur: "Des. Fed. Ana Ribeiro", status: "Pendente", topic: "Saúde" },
  { number: "5004038-92.2024.4.03.6000", title: "Pensão por morte — dependência", party: "Rosa Maria de Oliveira", rapporteur: "Des. Fed. João Silva", status: "Em revisão", topic: "Previdenciário" },
  { number: "5001586-70.2023.4.03.6000", title: "Execução fiscal — nulidade de CDA", party: "Município de Campo Grande", rapporteur: "Des. Fed. Ana Ribeiro", status: "Pronto", topic: "Tributário" },
];

function Glyph({ name, size = 17 }: { name: string; size?: number }) {
  const common = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.7, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, "aria-hidden": true as const };
  if (name === "search") return <svg {...common}><circle cx="10.8" cy="10.8" r="6.6" /><path d="m16 16 4.2 4.2" /></svg>;
  if (name === "plus") return <svg {...common}><path d="M12 5v14M5 12h14" /></svg>;
  if (name === "download") return <svg {...common}><path d="M12 3v12m-5-5 5 5 5-5M4 20h16" /></svg>;
  if (name === "refresh") return <svg {...common}><path d="M20 7v5h-5M4 17v-5h5" /><path d="M5.6 9a7 7 0 0 1 11.7-2L20 12M4 12l2.7 5a7 7 0 0 0 11.7-2" /></svg>;
  if (name === "chevron") return <svg {...common}><path d="m9 18 6-6-6-6" /></svg>;
  if (name === "calendar") return <svg {...common}><rect x="3.5" y="5" width="17" height="16" rx="2" /><path d="M7.5 3v4M16.5 3v4M4 9h16" /></svg>;
  if (name === "dots") return <svg {...common}><circle cx="5" cy="12" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /></svg>;
  return <svg {...common}><path d="M5 7h14M5 12h14M5 17h14" /></svg>;
}

export default function PautaLayout() {
  const [activeSession, setActiveSession] = useState(0);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("Todos");
  const [view, setView] = useState<"Lista" | "Por relator">("Lista");
  const [notice, setNotice] = useState("");
  const filteredCases = useMemo(() => allCases.filter((item) => {
    const matchesQuery = `${item.number} ${item.title} ${item.party} ${item.rapporteur} ${item.topic}`.toLowerCase().includes(query.toLowerCase());
    const matchesFilter = filter === "Todos" || (filter === "Prontos" ? item.status === "Pronto" : item.status !== "Pronto");
    return matchesQuery && matchesFilter;
  }), [query, filter]);
  const active = sessions[activeSession];

  const announce = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2600);
  };

  return (
    <main className="pl-app">
      <style>{`
        .pl-app{--ink:#202f3c;--muted:#75818a;--line:#dce1df;--paper:#f5f4ef;--white:#fffefa;--navy:#193449;--navy2:#294b60;--gold:#c6a263;--mint:#dcebe4;min-height:100dvh;background:var(--paper);color:var(--ink);font-family:'DM Sans',sans-serif;font-size:13px;overflow:hidden}
        .pl-app *{box-sizing:border-box}.pl-app button,.pl-app input{font:inherit}.pl-app button{cursor:pointer}
        .pl-top{height:64px;padding:0 30px;background:var(--navy);display:flex;align-items:center;justify-content:space-between;color:#f6f2e9;gap:20px}
        .pl-brand{display:flex;align-items:center;gap:12px;min-width:240px}.pl-mark{width:31px;height:31px;border:1px solid #bba36f;display:grid;place-items:center;color:#d6bd87;font:600 13px 'Manrope',sans-serif;letter-spacing:-.05em}.pl-brand-copy{display:flex;flex-direction:column;gap:2px}.pl-brand-copy b{font:700 13px 'Manrope',sans-serif;letter-spacing:.03em}.pl-brand-copy span{font-size:9px;letter-spacing:.14em;text-transform:uppercase;color:#b5c3c9}
        .pl-topnav{height:100%;display:flex;align-items:stretch;gap:5px}.pl-topnav button{border:0;border-bottom:2px solid transparent;background:none;padding:0 17px;color:#b9c6ca;font-size:12px;font-weight:600}.pl-topnav button.active{color:#fff4d9;border-bottom-color:var(--gold)}.pl-topnav button:hover{color:#fff}
        .pl-user{display:flex;align-items:center;gap:10px;min-width:240px;justify-content:flex-end}.pl-live{display:inline-flex;align-items:center;gap:7px;color:#c6d7cd;font-size:10px}.pl-live i{width:6px;height:6px;border-radius:50%;background:#8fc5a3;box-shadow:0 0 0 3px #8fc5a31e}.pl-avatar{width:30px;height:30px;border-radius:50%;display:grid;place-items:center;color:#f0e5cc;background:#476274;font-size:10px;font-weight:700}.pl-user span{font-size:11px;color:#e1e5e3}
        .pl-workspace{max-width:1600px;margin:0 auto;padding:28px 32px 32px}.pl-heading{display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:23px;gap:18px}.pl-kicker{display:flex;align-items:center;gap:8px;color:#687983;font-size:10px;letter-spacing:.14em;text-transform:uppercase;font-weight:700}.pl-kicker:before{content:'';width:19px;height:1px;background:var(--gold)}.pl-heading h1{font:700 clamp(24px,2.2vw,32px)/1.1 'Manrope',sans-serif;letter-spacing:-.04em;margin:8px 0 5px;color:#213747}.pl-heading p{margin:0;color:#74818a;font-size:12px}.pl-heading-actions{display:flex;gap:8px;align-items:center}.pl-btn{height:36px;padding:0 13px;display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid #cbd2d0;background:var(--white);color:#365164;font-size:11px;font-weight:700;transition:transform .18s,background .18s}.pl-btn:hover{background:#edf1ee;transform:translateY(-1px)}.pl-btn.primary{background:#b99557;border-color:#b99557;color:#fffdf7}.pl-btn.primary:hover{background:#a9874c}
        .pl-metrics{display:grid;grid-template-columns:minmax(210px,1.45fr) repeat(3,minmax(130px,.72fr));border-top:1px solid #cbd2cf;border-bottom:1px solid #cbd2cf;margin-bottom:19px;background:#f1f0e9}.pl-metric{padding:14px 19px 13px;border-right:1px solid #d7dcd8}.pl-metric:last-child{border-right:0}.pl-metric:first-child{padding-left:2px}.pl-metric label{display:block;color:#728087;font-size:9px;letter-spacing:.13em;text-transform:uppercase;font-weight:700}.pl-metric strong{display:block;margin-top:4px;font:700 22px 'Manrope',sans-serif;letter-spacing:-.045em;color:#294457}.pl-metric small{font-size:10px;color:#78858b;margin-left:6px;font-weight:500;letter-spacing:0}.pl-progress{height:3px;margin-top:8px;background:#d9dfdb}.pl-progress i{display:block;width:71%;height:100%;background:#8eaa9b}
        .pl-body{display:grid;grid-template-columns:220px minmax(0,1fr) 255px;gap:0;align-items:stretch;border:1px solid #d8ddda;background:var(--white);min-height:590px;box-shadow:0 8px 26px #233b4909}
        .pl-sessions{background:#f0f1eb;border-right:1px solid #d8ddda;padding:18px 0}.pl-section-label{display:flex;align-items:center;justify-content:space-between;padding:0 16px 13px;color:#77848a;font-size:9px;text-transform:uppercase;letter-spacing:.13em;font-weight:700}.pl-section-label button{border:0;background:none;color:#597386;padding:2px;display:grid;place-items:center}.pl-session{border:0;border-left:3px solid transparent;background:transparent;width:100%;display:flex;align-items:center;gap:11px;text-align:left;padding:12px 13px;color:inherit}.pl-session:hover{background:#e7eae4}.pl-session.selected{background:#fffefa;border-left-color:#b99557}.pl-date{width:40px;min-width:40px;height:46px;background:#fafaf5;border:1px solid #d9ded9;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#536e7f}.pl-session.selected .pl-date{background:#f5eee0;border-color:#ddc99f;color:#785f36}.pl-date b{font:700 17px/1 'Manrope',sans-serif;letter-spacing:-.05em}.pl-date small{margin-top:3px;font:600 8px 'IBM Plex Mono',monospace;letter-spacing:.08em}.pl-session-copy{min-width:0;flex:1}.pl-session-copy b{display:block;font-size:11px;font-weight:700;white-space:nowrap}.pl-session-copy span{display:block;margin-top:3px;color:#859097;font-size:10px}.pl-session-count{font:500 9px 'IBM Plex Mono',monospace;color:#71828b;align-self:flex-start;padding-top:3px}.pl-sess-progress{height:2px;background:#dce1db;margin-top:8px}.pl-sess-progress i{display:block;height:100%;background:#90aa9b}
        .pl-list{min-width:0;padding:19px 22px 17px}.pl-list-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:17px}.pl-list-head h2{font:700 17px 'Manrope',sans-serif;letter-spacing:-.035em;margin:0;color:#233b4b}.pl-list-head p{font-size:10px;color:#77858a;margin:5px 0 0}.pl-view-toggle{display:flex;border:1px solid #d8ddda;background:#f6f6f1;padding:2px}.pl-view-toggle button{border:0;background:transparent;padding:6px 9px;font-size:9px;color:#738087}.pl-view-toggle button.on{background:#fffefa;color:#38566a;box-shadow:0 1px 3px #233b4918;font-weight:700}
        .pl-toolbar{display:flex;align-items:center;justify-content:space-between;gap:10px;padding-bottom:12px;border-bottom:1px solid #e0e4e0}.pl-search{height:34px;display:flex;align-items:center;gap:8px;border:1px solid #d8ddda;background:#fffefa;padding:0 10px;min-width:210px;flex:1;max-width:320px;color:#7a888d}.pl-search input{width:100%;border:0;outline:0;background:transparent;color:#2b4250;font-size:10px}.pl-search input::placeholder{color:#97a1a4}.pl-filters{display:flex;gap:4px}.pl-filters button{border:0;padding:7px 9px;background:none;color:#829097;font-size:9px}.pl-filters button.on{background:#e8eee9;color:#38596a;font-weight:700}
        .pl-table{width:100%;border-collapse:collapse;text-align:left}.pl-table th{padding:11px 8px 9px;color:#899398;text-transform:uppercase;font-size:8px;letter-spacing:.11em;font-weight:700;border-bottom:1px solid #e2e5e1;white-space:nowrap}.pl-table td{padding:12px 8px;border-bottom:1px solid #edf0ed;vertical-align:middle}.pl-table tbody tr{transition:background .15s}.pl-table tbody tr:hover{background:#f7f8f3}.pl-table td:first-child{padding-left:9px}.pl-case-num{font:500 10px 'IBM Plex Mono',monospace;color:#426178;white-space:nowrap}.pl-case-title{margin-top:4px;color:#334a57;font-size:10px;max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.pl-party{font-size:10px;color:#52656f;max-width:135px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.pl-topic{color:#7b878a;font-size:9px}.pl-status{display:inline-flex;align-items:center;gap:5px;white-space:nowrap;color:#77847f;font-size:9px}.pl-status:before{content:'';width:5px;height:5px;border-radius:50%;background:#8eb39b}.pl-status.review:before{background:#d3ae66}.pl-status.pending:before{background:#bc8077}.pl-row-menu{border:0;background:none;color:#829096;padding:4px}.pl-empty{padding:55px 20px;text-align:center;color:#76858b;font-size:11px}
        .pl-aside{border-left:1px solid #dce1df;background:#f8f8f3;padding:19px 17px}.pl-aside-top{display:flex;align-items:center;justify-content:space-between}.pl-aside-top span{color:#839096;font-size:9px;text-transform:uppercase;letter-spacing:.12em;font-weight:700}.pl-aside h3{font:700 15px 'Manrope',sans-serif;letter-spacing:-.03em;color:#294252;margin:15px 0 3px}.pl-aside-date{color:#718088;font-size:10px}.pl-aside-date b{font-weight:700;color:#476378}.pl-agenda{margin:18px 0 22px;padding:0;list-style:none}.pl-agenda li{display:grid;grid-template-columns:26px 1fr;gap:8px;padding:8px 0;border-bottom:1px solid #e3e6e1;align-items:center}.pl-agenda li span{font:500 9px 'IBM Plex Mono',monospace;color:#99a19f}.pl-agenda li b{font-size:10px;color:#526670;font-weight:600}.pl-agenda li.active b{color:#314f63}.pl-agenda li.active span{color:#b38b4e}.pl-people{border-top:1px solid #dce1dd;padding-top:14px}.pl-people h4{font-size:9px;margin:0 0 12px;text-transform:uppercase;letter-spacing:.12em;color:#87918e}.pl-person{display:flex;align-items:center;gap:8px;margin:9px 0}.pl-person-mark{width:23px;height:23px;border:1px solid #d3dbd6;border-radius:50%;background:#edf2ed;display:grid;place-items:center;color:#537368;font-size:8px;font-weight:700}.pl-person b{display:block;font-size:9px;color:#485d67}.pl-person small{display:block;margin-top:2px;color:#919b9c;font-size:8px}.pl-legend{padding:12px 0 0;margin-top:14px;border-top:1px solid #dce1dd;color:#84908e;font-size:9px;line-height:1.7}.pl-legend strong{color:#536d70;font-weight:700}
        .pl-toast{position:fixed;right:24px;bottom:22px;padding:11px 15px;background:#213e50;color:#fff5de;font-size:11px;box-shadow:0 6px 20px #1d33452c;animation:pl-in .18s ease-out;z-index:4}.pl-toast:before{content:'';display:inline-block;width:6px;height:6px;border-radius:50%;background:#a6c6aa;margin-right:8px}
        @keyframes pl-in{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}@media(prefers-reduced-motion:reduce){.pl-app *{scroll-behavior:auto!important;transition:none!important;animation:none!important}}
        @media(max-width:1150px){.pl-body{grid-template-columns:195px minmax(0,1fr)}.pl-aside{display:none}.pl-metrics{grid-template-columns:minmax(180px,1.3fr) repeat(3,minmax(110px,.7fr))}.pl-list{padding:17px 17px}.pl-table th:nth-child(3),.pl-table td:nth-child(3){display:none}}
        @media(max-width:760px){.pl-top{height:auto;min-height:58px;padding:10px 15px;flex-wrap:wrap;gap:8px}.pl-brand{min-width:0;flex:1}.pl-brand-copy span{font-size:8px}.pl-topnav{order:3;width:100%;height:38px;margin:0 -3px}.pl-topnav button{padding:0 11px;font-size:10px}.pl-user{min-width:0}.pl-live{display:none}.pl-user span{display:none}.pl-workspace{padding:22px 14px}.pl-heading{align-items:flex-start;flex-direction:column;margin-bottom:16px}.pl-heading-actions{width:100%}.pl-heading-actions .pl-btn{flex:1}.pl-metrics{grid-template-columns:repeat(2,minmax(0,1fr));margin-bottom:14px}.pl-metric{padding:11px 12px!important;border-bottom:1px solid #d7dcd8}.pl-metric:first-child{grid-column:1/-1}.pl-metric:nth-child(2){border-left:0}.pl-metric strong{font-size:19px}.pl-body{display:flex;flex-direction:column;min-height:unset}.pl-sessions{border-right:0;border-bottom:1px solid #d8ddda;padding:12px 0 7px}.pl-section-label{padding:0 13px 8px}.pl-session-stack{display:flex;overflow:auto;gap:5px;padding:0 9px 6px}.pl-session{width:auto;min-width:170px;border:1px solid #dce1dc;padding:8px;background:#f8f8f3}.pl-session.selected{border-color:#d5c091;border-left:1px solid #d5c091}.pl-session-copy b{font-size:10px}.pl-session-copy span{font-size:9px}.pl-sess-progress{margin-top:5px}.pl-list{padding:16px 12px}.pl-list-head{align-items:center}.pl-toolbar{align-items:stretch;flex-direction:column}.pl-search{max-width:none}.pl-filters{justify-content:flex-start}.pl-table th:nth-child(2),.pl-table td:nth-child(2),.pl-table th:nth-child(3),.pl-table td:nth-child(3){display:none}.pl-table th{font-size:7px;padding:9px 5px}.pl-table td{padding:10px 5px}.pl-case-num{font-size:9px}.pl-case-title{font-size:9px;max-width:180px}.pl-topic{font-size:8px}.pl-row-menu{display:none}.pl-view-toggle button{padding:6px 7px}.pl-heading p{max-width:280px;line-height:1.5}}
      `}</style>
      <header className="pl-top">
        <div className="pl-brand">
          <div className="pl-mark">CMT</div>
          <div className="pl-brand-copy"><b>Gabinete CMT</b><span>Turma Regional · MS</span></div>
        </div>
        <nav className="pl-topnav" aria-label="Áreas do Gabinete">
          <button className="active" onClick={() => announce("Controle de Pauta aberto")}>Controle de Pauta</button>
          <button onClick={() => announce("Controle de Decisões selecionado")}>Controle de Decisões</button>
        </nav>
        <div className="pl-user"><div className="pl-live"><i />Pauta sincronizada</div><div className="pl-avatar">CM</div><span>Equipe CMT</span></div>
      </header>

      <div className="pl-workspace">
        <div className="pl-heading">
          <div>
            <div className="pl-kicker">Coordenação de julgamentos</div>
            <h1>Controle de pauta</h1>
            <p>Organize os processos, acompanhe revisões e prepare cada sessão.</p>
          </div>
          <div className="pl-heading-actions">
            <button className="pl-btn" onClick={() => announce("Arquivo Excel preparado para exportação")}><Glyph name="download" />Exportar Excel</button>
            <button className="pl-btn primary" onClick={() => announce("Novo processo: selecione a sessão e informe o número") }><Glyph name="plus" />Adicionar processo</button>
          </div>
        </div>

        <section className="pl-metrics" aria-label="Resumo da pauta">
          <div className="pl-metric"><label>Sessão selecionada</label><strong>{active.day} {active.month} <small>· {active.year}</small></strong><div className="pl-progress"><i /></div></div>
          <div className="pl-metric"><label>Processos na pauta</label><strong>{active.count}<small>itens</small></strong></div>
          <div className="pl-metric"><label>Prontos para sessão</label><strong>{active.complete}<small>de {active.count}</small></strong></div>
          <div className="pl-metric"><label>Em acompanhamento</label><strong>{active.count - active.complete}<small>itens</small></strong></div>
        </section>

        <section className="pl-body">
          <aside className="pl-sessions">
            <div className="pl-section-label"><span>Calendário de sessões</span><button aria-label="Abrir calendário" onClick={() => announce("Calendário de sessões")}><Glyph name="calendar" size={15} /></button></div>
            <div className="pl-session-stack">
              {sessions.map((session, index) => (
                <button key={`${session.day}-${session.month}`} className={`pl-session${index === activeSession ? " selected" : ""}`} onClick={() => setActiveSession(index)} aria-pressed={index === activeSession}>
                  <span className="pl-date"><b>{session.day}</b><small>{session.month}</small></span>
                  <span className="pl-session-copy"><b>{session.label}</b><span>{session.state} · {session.year}</span><span className="pl-sess-progress"><i style={{ width: `${session.complete / session.count * 100}%` }} /></span></span>
                  <span className="pl-session-count">{session.count}</span>
                </button>
              ))}
            </div>
          </aside>

          <section className="pl-list">
            <div className="pl-list-head">
              <div><h2>Itens da sessão</h2><p>{active.day} de {active.month.toLowerCase()} de {active.year} <span>·</span> {filteredCases.length} processos exibidos</p></div>
              <div className="pl-view-toggle" aria-label="Modo de visualização">
                <button className={view === "Lista" ? "on" : ""} onClick={() => setView("Lista")}>Lista</button>
                <button className={view === "Por relator" ? "on" : ""} onClick={() => setView("Por relator")}>Por relator</button>
              </div>
            </div>
            <div className="pl-toolbar">
              <label className="pl-search"><Glyph name="search" size={15} /><input aria-label="Buscar processos" placeholder="Buscar processo, parte ou assunto" value={query} onChange={(event) => setQuery(event.target.value)} /></label>
              <div className="pl-filters" aria-label="Filtrar situação">
                {["Todos", "Prontos", "Em andamento"].map((item) => <button key={item} className={filter === item ? "on" : ""} onClick={() => setFilter(item)}>{item}</button>)}
              </div>
            </div>
            <div style={{ overflowX: "auto" }}>
              <table className="pl-table">
                <thead><tr><th>Processo / item de pauta</th><th>Parte principal</th><th>Relatoria</th><th>Área</th><th>Situação</th><th aria-label="Ações" /></tr></thead>
                <tbody>
                  {filteredCases.map((item) => <tr key={item.number}>
                    <td><div className="pl-case-num">{item.number}</div><div className="pl-case-title">{item.title}</div></td>
                    <td><div className="pl-party">{item.party}</div></td><td><div className="pl-party">{item.rapporteur}</div></td>
                    <td><span className="pl-topic">{item.topic}</span></td>
                    <td><span className={`pl-status${item.status === "Em revisão" ? " review" : item.status === "Pendente" ? " pending" : ""}`}>{item.status}</span></td>
                    <td><button className="pl-row-menu" aria-label={`Mais ações para ${item.number}`} onClick={() => announce(`Ações do processo ${item.number}`)}><Glyph name="dots" /></button></td>
                  </tr>)}
                  {filteredCases.length === 0 && <tr><td colSpan={6}><div className="pl-empty">Nenhum processo corresponde à busca.</div></td></tr>}
                </tbody>
              </table>
            </div>
          </section>

          <aside className="pl-aside">
            <div className="pl-aside-top"><span>Visão da sessão</span><button className="pl-row-menu" aria-label="Atualizar sessão" onClick={() => announce("Pauta atualizada")}><Glyph name="refresh" size={15} /></button></div>
            <h3>Sessão {active.day} {active.month}</h3>
            <div className="pl-aside-date"><b>{active.label}</b> · {active.year}</div>
            <ol className="pl-agenda">
              <li className="active"><span>01</span><b>Previdenciário <small>12 itens</small></b></li>
              <li><span>02</span><b>Administrativo <small>5 itens</small></b></li>
              <li><span>03</span><b>Saúde <small>4 itens</small></b></li>
              <li><span>04</span><b>Tributário <small>3 itens</small></b></li>
            </ol>
            <div className="pl-people">
              <h4>Equipe nesta pauta</h4>
              <div className="pl-person"><div className="pl-person-mark">JS</div><div><b>João Silva</b><small>Relatoria · 13 processos</small></div></div>
              <div className="pl-person"><div className="pl-person-mark">AR</div><div><b>Ana Ribeiro</b><small>Relatoria · 11 processos</small></div></div>
            </div>
            <div className="pl-legend"><strong>Última sincronização</strong><br />há poucos segundos · equipe conectada</div>
          </aside>
        </section>
      </div>
      {notice && <div className="pl-toast" role="status">{notice}</div>}
    </main>
  );
}

import "./_group.css";

const days = [
  {
    date: "13/10/2026",
    target: "3 / 4 minutas",
    count: "3 minutas",
    rows: [
      ["5001322-16.2025.4.03.6000", "Aposentadoria por incapacidade permanente", "pc-complexity-2", "Α Intermediário"],
      ["5004631-29.2024.4.03.6000", "Benefício assistencial à pessoa com deficiência", "pc-complexity-1", "Ω Padrão"],
      ["5005087-72.2023.4.03.6000", "Revisão de benefício previdenciário", "pc-complexity-3", "Σ Complexo"],
    ],
  },
  {
    date: "12/10/2026",
    target: "4 / 4 minutas",
    count: "4 minutas",
    rows: [
      ["5008914-35.2024.4.03.6000", "Pensão por morte — dependência econômica", "pc-complexity-1", "Ω Padrão"],
      ["5001770-08.2022.4.03.6000", "Aposentadoria por tempo de contribuição", "pc-complexity-2", "Α Intermediário"],
      ["5007462-41.2023.4.03.6000", "Benefício assistencial ao idoso", "pc-complexity-1", "Ω Padrão"],
    ],
  },
];

export function HistorySample({ compact = false }: { compact?: boolean }) {
  return (
    <main className="history-stage">
      <section className={`gd-detail ${compact ? "gd-history-compact" : ""}`} aria-label="Histórico de produtividade">
        <div className="pc-prod-detail">
          <header className="pc-prod-detail-head">
            <h4>Histórico · ANA</h4>
            <span className="pc-muted">Até 13/10/2026 · últimos 2 dias com registro</span>
          </header>
          {days.map((day) => (
            <section className="pc-hist-day" key={day.date}>
              <div className="pc-hist-top">
                <strong>{day.date}</strong>
                <span className="pc-tone-chip">{day.target}</span>
                <span className="pc-muted">{day.count}</span>
              </div>
              {day.rows.map(([process, subject, level, label]) => (
                <div className="pc-prod-proc" key={process}>
                  <div className="pc-prod-proc-id">
                    <strong>{process}</strong>
                    <span>{subject}</span>
                  </div>
                  <span className={`pc-complexity ${level}`}>{label}</span>
                </div>
              ))}
            </section>
          ))}
        </div>
      </section>
    </main>
  );
}

import React, { useMemo, useState } from "react";
import "./_group.css";

type CaseRow = { id: string; number: string; title: string; party: string; relator: string; area: string; status: "Pronto" | "Em revisão" | "Pendente" };
const cases: CaseRow[] = [
  { id: "01", number: "5001842-61.2024.4.03.6000", title: "Benefício por incapacidade permanente", party: "Maria Aparecida dos Santos", relator: "Des. Fed. João Silva", area: "Previdenciário", status: "Pronto" },
  { id: "02", number: "5009327-08.2023.4.03.6000", title: "Revisão de benefício — tempo especial", party: "Antônio Carlos Ferreira", relator: "Des. Fed. João Silva", area: "Previdenciário", status: "Em revisão" },
  { id: "03", number: "5002714-33.2024.4.03.6000", title: "Responsabilidade civil do Estado", party: "Comercial Pantanal Ltda.", relator: "Des. Fed. Ana Ribeiro", area: "Administrativo", status: "Pronto" },
  { id: "04", number: "5006190-45.2022.4.03.6000", title: "Fornecimento de medicamento", party: "Lucas Henrique Nunes", relator: "Des. Fed. Ana Ribeiro", area: "Saúde", status: "Pendente" },
  { id: "05", number: "5004038-92.2024.4.03.6000", title: "Pensão por morte — dependência", party: "Rosa Maria de Oliveira", relator: "Des. Fed. João Silva", area: "Previdenciário", status: "Em revisão" },
  { id: "06", number: "5001586-70.2023.4.03.6000", title: "Execução fiscal — nulidade de CDA", party: "Município de Campo Grande", relator: "Des. Fed. Ana Ribeiro", area: "Tributário", status: "Pronto" },
];
const tabs = ["Controle de Pauta", "Controle de Decisões", "Controle de Metas"];

function Glyph({ name }: { name: string }) {
  const shapes: Record<string, React.ReactNode> = {
    docket: <><rect x="4" y="3" width="16" height="18" rx="2" /><path d="M8 8h9M8 12h9M8 16h5" /></>,
    decisions: <><path d="M6 3h9l4 4v14H6z" /><path d="M15 3v5h4M9 12h7M9 16h7" /></>,
    goals: <><path d="M4 19V5M4 19h17" /><path d="m7 15 4-4 3 2 5-7" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M7 3v4M17 3v4M3 10h18" /></>,
    settings: <><circle cx="12" cy="12" r="3" /><path d="m19.4 15 .1.1 1.1.8-1.3 2.2-1.3-.5a7.8 7.8 0 0 1-1.4.8l-.2 1.4h-2.6l-.2-1.4a7.8 7.8 0 0 1-1.4-.8l-1.3.5-1.3-2.2 1.1-.8a7 7 0 0 1 0-1.6l-1.1-.8 1.3-2.2 1.3.5a7.8 7.8 0 0 1 1.4-.8l.2-1.4h2.6l.2 1.4a7.8 7.8 0 0 1 1.4.8l1.3-.5 1.3 2.2-1.1.8a7 7 0 0 1 0 1.5z" /></>,
    close: <path d="m6 6 12 12M18 6 6 18" />,
    search: <><circle cx="10.8" cy="10.8" r="6.5" /><path d="m16 16 4 4" /></>,
    bell: <><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" /></>,
    sheet: <><path d="M5 3h10l4 4v14H5z" /><path d="M15 3v5h4M8 12h8M8 16h8" /></>,
  };
  return <svg viewBox="0 0 24 24" aria-hidden="true">{shapes[name]}</svg>;
}

function CabinetShell({ refined }: { refined: boolean }) {
  const [activeTab, setActiveTab] = useState(tabs[0]);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("Todos");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const [calendarDay, setCalendarDay] = useState(18);
  const [month, setMonth] = useState(0);
  const [day, setDay] = useState("2025-06-18");
  const [dockPanel, setDockPanel] = useState("");
  const [calendarOpen, setCalendarOpen] = useState(false);
  const visible = useMemo(() => cases.filter((item) => {
    const searchMatch = `${item.number} ${item.title} ${item.party} ${item.relator} ${item.area}`.toLocaleLowerCase("pt-BR").includes(query.toLocaleLowerCase("pt-BR"));
    const filterMatch = statusFilter === "Todos" || (statusFilter === "Prontos" ? item.status === "Pronto" : item.status !== "Pronto");
    return searchMatch && filterMatch;
  }), [query, statusFilter]);
  const allSelected = visible.length > 0 && visible.every((item) => selected.includes(item.id));
  const toggleSelected = (id: string) => setSelected((value) => value.includes(id) ? value.filter((entry) => entry !== id) : [...value, id]);
  const shownMonth = new Date(2025, 5 + month, 1);
  const monthLabel = shownMonth.toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
  const calendarStart = new Date(shownMonth.getFullYear(), shownMonth.getMonth(), 1).getDay();
  const monthDays = new Date(shownMonth.getFullYear(), shownMonth.getMonth() + 1, 0).getDate();
  const cells = [...Array(calendarStart).fill(0), ...Array.from({ length: monthDays }, (_, index) => index + 1)];
  const iconNames = ["docket", "decisions", "goals"];
  const className = `gm-root${refined ? " gm-refined" : " gm-current"}${calendarOpen ? " gm-calendar-open" : ""}`;

  return <div className={className}>
    <div className="gm-shell">
      <aside id="alt-side">
        <div className="as-top">
          <div className="as-brand"><span className="as-brand-mark">CMT</span><b>Gabinete CMT</b></div>
          <div className="as-who"><span className="as-avatar">CM</span><span className="as-whotx"><b className="as-name">Equipe CMT</b><small className="as-role">Turma Regional · MS</small></span></div>
        </div>
        <div className="as-body">
          <div className="as-sec">Áreas do Gabinete</div>
          <nav aria-label="Áreas do Gabinete"><ul className="as-nav">{tabs.map((label, index) => <li key={label} className={`as-item${activeTab === label ? " is-active" : ""}`}><button className="as-link" onClick={() => setActiveTab(label)} aria-current={activeTab === label ? "page" : undefined}><Glyph name={iconNames[index]} /><span className="lbl">{label}</span></button></li>)}</ul></nav>
        </div>
      </aside>

      <header id="cmt-appbar" role="banner">
        <div className="cmt-ab-title"><span className="cmt-ab-over">GABINETE · GESTÃO DO TRABALHO</span><strong className="cmt-ab-name">Gabinete CMT</strong></div>
        <nav className="cmt-apptabs" aria-label="Áreas do Gabinete CMT">{tabs.map((label) => <button key={label} type="button" aria-current={activeTab === label ? "page" : undefined} onClick={() => setActiveTab(label)}>{label}</button>)}</nav>
        <div className="cmt-ab-right"><button className="cmt-ab-gear" aria-label="Configurações Globais"><Glyph name="settings" /></button></div>
      </header>

      <main id="app-content">
        <section id="controle-pauta-root" className="pc-pauta">
          <section className="pc-session-overview">
            <header className="pc-ref-integrated-heading"><div><h1>{activeTab}</h1><p>Itens da sessão · 18 de junho de 2025</p></div></header>
            <div className="pc-ref-dates">
              <div className="pc-date-chip"><label>Sessão selecionada</label><strong>18 <small>JUN 2025</small></strong></div>
              <div className="pc-date-chip"><label>Processos na pauta</label><strong>24</strong></div>
              <div className="pc-date-chip"><label>Prontos para sessão</label><strong>17</strong></div>
              <div className="pc-date-chip"><label>Em acompanhamento</label><strong>7</strong></div>
            </div>
            <div className="pc-capsule-band"><span aria-hidden="true" /><b>Pauta sincronizada</b> · Turma Regional de MS</div>
          </section>

          <section className="pc-filter-card">
            <div className="pc-heading"><div><h2>Painel de Controle</h2><p>PREPARAÇÃO P/ JULGAMENTO</p></div><div className="pc-filter-heading-tools"><button type="button" aria-pressed={allSelected} onClick={() => setSelected(allSelected ? [] : visible.map((item) => item.id))}>Selecionar todos os filtrados</button><span className="pc-result-count">{visible.length}<small> de 24 processos</small></span><button type="button" onClick={() => { setQuery(""); setStatusFilter("Todos"); }}>Limpar filtros</button><select aria-label="Escopo da exportação"><option>Resultados filtrados</option><option>Sessão completa</option></select><button type="button" aria-disabled="true" title="Ação desativada na prévia">Exportar</button></div></div>
            <div className="pq-filter-workspace">
              <div className="pq-search-main"><div className="pq-search-main-input"><input value={query} onChange={(event) => setQuery(event.target.value)} aria-label="Buscar processos" placeholder="Buscar processo, parte ou assunto" /></div><select className="pq-search-field" aria-label="Campo da busca"><option>Todos os campos</option><option>Processo</option><option>Parte</option><option>Assunto</option></select><button type="button" className="pq-ft" aria-label="Buscar"><Glyph name="search" /></button></div>
            </div>
            <div className="pq-filter-status" aria-label="Filtrar situação">{["Todos", "Prontos", "Em andamento"].map((item) => <button type="button" key={item} className={statusFilter === item ? "is-on" : ""} onClick={() => setStatusFilter(item)}>{item}</button>)}</div>
          </section>

          <section className="pc-sheet-card">
            <div className="pc-sheet-toolbar"><h2>Processos da sessão</h2><div className="pc-sheet-actions"><button type="button" aria-pressed={allSelected} onClick={() => setSelected(allSelected ? [] : visible.map((item) => item.id))}>Selecionar todos os filtrados</button><button type="button" onClick={() => { setQuery(""); setStatusFilter("Todos"); }}>Limpar filtros</button><button type="button" aria-disabled="true">Exportar</button></div></div>
            <div className="pc-table-scroll"><table className="pq-table"><thead><tr><th><input type="checkbox" aria-label="Selecionar todos os processos" checked={allSelected} onChange={() => setSelected(allSelected ? [] : visible.map((item) => item.id))} /></th><th>Processo / item de pauta</th><th>Parte principal</th><th>Relatoria</th><th>Área</th><th>Situação</th></tr></thead><tbody>
              {visible.map((item) => <React.Fragment key={item.id}><tr className={`pq-main-row${expanded === item.id ? " is-expanded" : ""}`} onClick={() => setExpanded(expanded === item.id ? null : item.id)}><td onClick={(event) => event.stopPropagation()}><input type="checkbox" aria-label={`Selecionar ${item.number}`} checked={selected.includes(item.id)} onChange={() => toggleSelected(item.id)} /></td><td><span className="pq-number">{item.number}</span><span className="pq-case-title">{item.title}</span></td><td><span className="pq-party">{item.party}</span></td><td><span className="pq-party">{item.relator}</span></td><td><span className="pq-area">{item.area}</span></td><td><span className={`pq-status${item.status === "Em revisão" ? " review" : item.status === "Pendente" ? " pending" : ""}`}>{item.status}</span></td></tr>{expanded === item.id && <tr className="pq-expansion"><td colSpan={6}><div className="pq-expansion-content"><span>Processo: <b>{item.number}</b></span><span>Relatoria: <b>{item.relator}</b></span><span>Área: <b>{item.area}</b></span></div></td></tr>}</React.Fragment>)}
              {visible.length === 0 && <tr><td className="pq-empty" colSpan={6}>Nenhum processo selecionado corresponde à sessão e aos filtros.</td></tr>}
            </tbody></table></div>
          </section>
        </section>
      </main>

      <button id="alt-rp-tab" aria-label="Abrir Calendário público" onClick={() => setCalendarOpen(true)}><Glyph name="calendar" /></button>
      <aside id="alt-rside" aria-label="Calendário público">
        <div className="rp-top"><div className="rp-brand"><b>Calendário público</b><button className="rp-x" aria-label="Fechar Calendário público" onClick={() => setCalendarOpen(false)}><Glyph name="close" /></button></div><div className="rp-month"><strong>{monthLabel}</strong><div className="rp-ctl"><button aria-label="Mês anterior" onClick={() => setMonth((value) => value - 1)}>‹</button><button className="tdy" onClick={() => setMonth(0)}>Hoje</button><button aria-label="Próximo mês" onClick={() => setMonth((value) => value + 1)}>›</button></div></div></div>
        <div className="rp-calendar"><div className="rp-week">{["D", "S", "T", "Q", "Q", "S", "S"].map((letter, index) => <span key={`${letter}-${index}`}>{letter}</span>)}</div><div className="rp-days">{cells.map((date, index) => date === 0 ? <span key={`blank-${index}`} /> : <button key={date} className={`${date === 18 && month === 0 ? "is-today" : ""}${date === calendarDay ? " is-selected" : ""}`} aria-label={`${date} de ${monthLabel}`} onClick={() => setCalendarDay(date)}>{date}</button>)}</div></div>
      </aside>

      <footer id="pauta-global-dock" className={dockPanel ? "is-open" : ""} aria-label="Rodapé do Controle de Pauta"><div className="gd-foot">
        <div className="gd-left"><button className={dockPanel === "notif" ? "is-on" : ""} title="Notificações" aria-label="Notificações" aria-pressed={dockPanel === "notif"} onClick={() => setDockPanel(dockPanel === "notif" ? "" : "notif")}><Glyph name="bell" /></button></div>
        <div className="gd-main" role="list" aria-label="Servidor usuário"><button className={dockPanel === "prod" ? "is-on" : ""} title="Ordem do Dia" aria-label="Ordem do Dia" aria-pressed={dockPanel === "prod"} onClick={() => setDockPanel(dockPanel === "prod" ? "" : "prod")}><Glyph name="sheet" /></button><span>Ordem do Dia</span></div>
        <div className="gd-right"><div className="gd-daypill"><button className="is-on" onClick={() => setDay("2025-06-18")}>Hoje</button><input type="date" aria-label="Dia de produção" value={day} onChange={(event) => setDay(event.target.value)} /></div><span className="gd-status">Pauta sincronizada</span></div>
      </div></footer>
    </div>
  </div>;
}

export function Current() { return <CabinetShell refined={false} />; }
export default Current;

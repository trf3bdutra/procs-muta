import "./_group.css";

const processes = [
  {
    number: "5001234-12.2026.4.03.0000",
    className: "Agravo de Instrumento · Previdenciário",
    urgency: "Tutela de urgência",
    request: "Restabelecimento de benefício após cessação administrativa; risco social e prova documental.",
    parties: "M. S. A. × INSS",
    server: "ANA PAULA",
    received: "14/10/2026",
    deadline: "16/10/2026 · 2 dias úteis",
    status: "Aguardando análise",
    result: "—",
  },
  {
    number: "5005678-90.2026.4.03.0000",
    className: "Apelação Cível · Saúde",
    urgency: "Liminar",
    request: "Fornecimento de tratamento de uso contínuo enquanto se aguarda avaliação médica especializada.",
    parties: "J. R. C. × UNIÃO",
    server: "MARCELO",
    received: "13/10/2026",
    deadline: "19/10/2026 · 3 dias úteis",
    status: "Em elaboração",
    result: "—",
  },
];

export function Readable() {
  return (
    <div className="urgency-demo-stage">
      <style>{`
        .urgent-readable-scroll{overflow:visible}
        .urgent-readable-table{display:block;width:100%;min-width:0;table-layout:fixed;border-collapse:separate;border-spacing:0;font-size:11px}
        .urgent-readable-table tbody{display:grid;gap:8px}
        .urgent-readable-table tr{display:grid;grid-template-columns:minmax(160px,1.15fr) minmax(140px,1fr) minmax(150px,1fr) minmax(140px,.95fr) minmax(130px,.9fr) 56px;grid-template-rows:minmax(52px,auto) minmax(44px,auto);align-items:stretch;min-width:0;overflow:hidden;border:1px solid #dce5ec;border-radius:10px;background:#fff;box-shadow:0 2px 7px rgba(21,43,64,.04)}
        .urgent-readable-table td{display:flex;flex-direction:column;align-items:flex-start;justify-content:center;gap:5px;min-width:0;min-height:0;padding:8px 10px;border-right:1px solid #edf1f4;border-bottom:1px solid #edf1f4;color:#344b60;white-space:normal;overflow-wrap:anywhere}
        .urgent-readable-table td:before{display:block;flex:0 0 auto;color:#82909e;font-size:8px;font-weight:800;letter-spacing:.08em;line-height:1.2}
        .urgent-readable-table td:nth-child(1){grid-column:1;grid-row:1}.urgent-readable-table td:nth-child(1):before{content:"PROCESSO"}
        .urgent-readable-table td:nth-child(2){grid-column:2/4;grid-row:1}.urgent-readable-table td:nth-child(2):before{content:"MEDIDA · PEDIDO"}
        .urgent-readable-table td:nth-child(3){grid-column:4;grid-row:1}.urgent-readable-table td:nth-child(3):before{content:"RESPONSÁVEL"}
        .urgent-readable-table td:nth-child(4){grid-column:1;grid-row:2}.urgent-readable-table td:nth-child(4):before{content:"RECEBIDO"}
        .urgent-readable-table td:nth-child(5){grid-column:2;grid-row:2}.urgent-readable-table td:nth-child(5):before{content:"PRAZO"}
        .urgent-readable-table td:nth-child(6){grid-column:3/5;grid-row:2}.urgent-readable-table td:nth-child(6):before{content:"ANDAMENTO"}
        .urgent-readable-table td:nth-child(7){grid-column:5;grid-row:1/3}.urgent-readable-table td:nth-child(7):before{content:"RESULTADO"}
        .urgent-readable-table td:nth-child(8){grid-column:6;grid-row:1/3;align-items:center;justify-content:center;gap:7px;padding:6px;border-right:0;border-bottom:0}
        .urgent-readable-table td:nth-child(8):before{content:""}
        .urgent-readable-table .urgent-demo-number,.urgent-readable-table .urgent-demo-class,.urgent-readable-table .urgent-demo-tag{display:block;min-width:0;max-width:100%;overflow-wrap:anywhere;line-height:1.35}
        .urgent-readable-table .urgent-demo-select{width:100%;min-width:0}
        .urgent-readable-table .urgency-demo-actions{flex-direction:column}
        @media(max-width:820px){
          .urgent-readable-table tr{grid-template-columns:repeat(2,minmax(0,1fr));grid-template-rows:repeat(4,auto)}
          .urgent-readable-table td:nth-child(1){grid-column:1;grid-row:1}.urgent-readable-table td:nth-child(2){grid-column:2;grid-row:1}
          .urgent-readable-table td:nth-child(3){grid-column:1;grid-row:2}.urgent-readable-table td:nth-child(4){grid-column:2;grid-row:2}
          .urgent-readable-table td:nth-child(5){grid-column:1;grid-row:3}.urgent-readable-table td:nth-child(6){grid-column:2;grid-row:3}
          .urgent-readable-table td:nth-child(7){grid-column:1;grid-row:4}.urgent-readable-table td:nth-child(8){grid-column:2;grid-row:4;flex-direction:row;justify-content:flex-end}
        }
        @media(max-width:560px){
          .urgent-readable-table tr{grid-template-columns:minmax(0,1fr);grid-template-rows:auto}
          .urgent-readable-table td:nth-child(n){grid-column:1;grid-row:auto;min-height:42px;border-right:0}
          .urgent-readable-table td:nth-child(8){justify-content:flex-end;border-bottom:0}
        }
      `}</style>
      <section className="urgency-demo-panel">
        <header className="urgency-demo-head">
          <div>
            <small>CONTROLE</small>
            <h2>Pedidos <span className="urgency-demo-muted">2</span></h2>
            <p>Andamento e dados essenciais dos pedidos de urgência.</p>
          </div>
          <button className="urgency-demo-add" type="button">＋ Processo</button>
        </header>
        <div className="urgent-readable-scroll">
          <table className="urgent-readable-table">
            <tbody>
              {processes.map((item) => (
                <tr key={item.number}>
                  <td><strong className="urgency-demo-number">{item.number}</strong><span className="urgency-demo-class">{item.className}</span><span className="urgency-demo-tag">{item.urgency}</span></td>
                  <td><span>{item.request}</span><small className="urgency-demo-muted">{item.parties}</small></td>
                  <td>{item.server}</td>
                  <td>{item.received}</td>
                  <td>{item.deadline}</td>
                  <td><select className="urgency-demo-select" defaultValue={item.status}><option>{item.status}</option></select></td>
                  <td>{item.result}</td>
                  <td><div className="urgency-demo-actions"><button type="button" aria-label="Editar">✎</button><button type="button" aria-label="Excluir">×</button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

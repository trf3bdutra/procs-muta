import { useMemo, useState, type ReactNode } from "react";
import "./pauta-atlas.css";

type Status = "Minutado" | "Em revisão" | "Pendente";
type DocketCase = { id: number; process: string; subject: string; rapporteur: string; clerk: string; status: Status; item: string; type: string };

const seedCases: DocketCase[] = [
  { id: 1, process: "5001842-61.2023.4.03.6000", subject: "Benefício previdenciário · aposentadoria rural", rapporteur: "Des. Fed. André Nabarrete", clerk: "Marina Lopes", status: "Minutado", item: "01", type: "Apelação Cível" },
  { id: 2, process: "5000927-14.2022.4.03.6000", subject: "Responsabilidade civil · dano moral", rapporteur: "Des. Fed. André Nabarrete", clerk: "Rafael Mendonça", status: "Em revisão", item: "02", type: "Apelação Cível" },
  { id: 3, process: "5007310-08.2021.4.03.6000", subject: "Execução fiscal · prescrição intercorrente", rapporteur: "Des. Fed. Inês Virgínia", clerk: "Marina Lopes", status: "Pendente", item: "03", type: "Agravo de Instrumento" },
  { id: 4, process: "5002165-39.2023.4.03.6000", subject: "Direito administrativo · servidor público", rapporteur: "Des. Fed. Inês Virgínia", clerk: "Caio Martins", status: "Em revisão", item: "04", type: "Apelação Cível" },
  { id: 5, process: "5004881-72.2022.4.03.6000", subject: "Benefício assistencial · pessoa com deficiência", rapporteur: "Des. Fed. André Nabarrete", clerk: "Rafael Mendonça", status: "Minutado", item: "05", type: "Apelação Cível" },
];

function Glyph({ name, size = 16 }: { name: string; size?: number }) {
  const paths: Record<string, ReactNode> = {
    desk: <><rect x="3" y="4" width="18" height="16" rx="2" /><path d="M7 8h10M7 12h6M7 16h4" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18" /></>,
    archive: <><path d="M4 4h16v5H4zM6 9v11h12V9M10 13h4" /></>,
    chart: <><path d="M4 19V5M4 19h17M8 15l4-4 3 2 5-7" /></>,
    search: <><circle cx="10.8" cy="10.8" r="6.8" /><path d="m16 16 4.5 4.5" /></>,
    bell: <><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" /></>,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    download: <><path d="M12 3v12m-5-5 5 5 5-5M4 20h16" /></>,
    dots: <><circle cx="5" cy="12" r="1" fill="currentColor" /><circle cx="12" cy="12" r="1" fill="currentColor" /><circle cx="19" cy="12" r="1" fill="currentColor" /></>,
    chevron: <path d="m8 10 4 4 4-4" />,
    arrow: <><path d="M5 12h14M13 6l6 6-6 6" /></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

const statusOrder: Status[] = ["Pendente", "Em revisão", "Minutado"];
const statusLabels: Record<Status, string> = { "Minutado": "Minutado", "Em revisão": "Em revisão", "Pendente": "Pendente" };

export default function PautaAtlas() {
  const [cases, setCases] = useState(seedCases);
  const [selectedId, setSelectedId] = useState(1);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("Todos");
  const [section, setSection] = useState("Pauta atual");
  const [toast, setToast] = useState("");
  const selectedCase = cases.find(item => item.id === selectedId) ?? cases[0];
  const visibleCases = useMemo(() => cases.filter(item => {
    const matchSearch = `${item.process} ${item.subject} ${item.rapporteur} ${item.clerk}`.toLowerCase().includes(search.toLowerCase());
    return matchSearch && (filter === "Todos" || item.status === filter);
  }), [cases, search, filter]);
  const showToast = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 2400);
  };
  const setStatus = (id: number, status: Status) => setCases(current => current.map(item => item.id === id ? { ...item, status } : item));
  const addCase = () => {
    const id = Math.max(0, ...cases.map(item => item.id)) + 1;
    const row: DocketCase = { id, process: `500${String(id * 1387).padStart(4, "0")}-42.2024.4.03.6000`, subject: "Novo processo · classificação pendente", rapporteur: "A definir", clerk: "Marina Lopes", status: "Pendente", item: String(cases.length + 1).padStart(2, "0"), type: "Apelação Cível" };
    setCases(current => [...current, row]);
    setSelectedId(id);
    showToast("Processo incluído na pauta.");
  };
  const exportDocket = () => {
    const text = ["ITEM\tPROCESSO\tASSUNTO\tRELATOR\tRESPONSÁVEL\tSTATUS", ...cases.map(item => [item.item, item.process, item.subject, item.rapporteur, item.clerk, item.status].join("\t"))].join("\n");
    const url = URL.createObjectURL(new Blob([text], { type: "text/tab-separated-values;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "pauta-sessao.tsv";
    anchor.click();
    URL.revokeObjectURL(url);
    showToast("Arquivo da pauta exportado.");
  };
  const initials = (name: string) => name.split(" ").map(part => part[0]).slice(0, 2).join("");

  return (
    <main className="pa-root">
      <div className="pa-layout">
        <aside className="pa-rail">
          <div className="pa-brand"><div className="pa-brand-mark">G</div><div><strong>Gabinete CMT</strong><small>TRF · 3ª REGIÃO</small></div></div>
          <div className="pa-rail-label">ESPAÇO DE TRABALHO</div>
          <nav className="pa-nav" aria-label="Navegação principal">
            <button className={section === "Pauta atual" ? "active" : ""} onClick={() => setSection("Pauta atual")}><Glyph name="desk" /><span>Mesa do CM</span><span className="pa-nav-count">05</span></button>
            <button className={section === "Calendário" ? "active" : ""} onClick={() => { setSection("Calendário"); showToast("Calendário da sessão selecionado."); }}><Glyph name="calendar" /><span>Calendário</span></button>
            <button className={section === "Acervo" ? "active" : ""} onClick={() => { setSection("Acervo"); showToast("Acervo de sessões selecionado."); }}><Glyph name="archive" /><span>Acervo</span></button>
            <button className={section === "Indicadores" ? "active" : ""} onClick={() => { setSection("Indicadores"); showToast("Indicadores selecionados."); }}><Glyph name="chart" /><span>Indicadores</span></button>
          </nav>
          <div className="pa-rail-spacer" />
          <div className="pa-rail-note"><span><i className="pa-sync-dot" /> Pauta sincronizada</span><small>Atualizada há 2 minutos</small></div>
          <div className="pa-profile"><div className="pa-avatar">ML</div><div><strong>Marina Lopes</strong><small>Assessora</small></div><button aria-label="Opções da conta" onClick={() => showToast("Conta de Marina Lopes")}><Glyph name="dots" /></button></div>
        </aside>
        <section className="pa-workspace">
          <header className="pa-topbar">
            <div className="pa-crumb"><span>Gabinete</span><b>/</b><strong>Mesa do CM</strong></div>
            <div className="pa-top-actions"><span className="pa-sync-label"><i className="pa-sync-dot" /> Tudo salvo</span><button className="pa-icon-btn" aria-label="Notificações" onClick={() => showToast("Você está em dia com as notificações.")}><Glyph name="bell" /><i className="pa-alert-dot" /></button><div className="pa-avatar">ML</div></div>
          </header>
          <div className="pa-content">
            <div className="pa-heading">
              <div><div className="pa-kicker">GABINETE CMT <span>·</span> MESA DE TRABALHO</div><h1>Controle de pauta</h1><p>O andamento da sessão, visto processo por processo.</p></div>
              <div className="pa-heading-actions"><button className="pa-button" onClick={exportDocket}><Glyph name="download" size={15} /> Exportar</button><button className="pa-button primary" onClick={addCase}><Glyph name="plus" size={16} /> Adicionar processo</button></div>
            </div>
            <section className="pa-session" aria-label="Sessão de julgamento">
              <div className="pa-session-info"><div className="pa-session-mark"><Glyph name="calendar" size={20} /></div><div><small>SESSÃO DE JULGAMENTO</small><strong>18ª Sessão Ordinária · 2025</strong><p>Quinta-feira, 12 de junho · sessão compartilhada</p></div></div>
              <div className="pa-session-stats"><div className="pa-session-stat"><small>Na pauta</small><strong>{cases.length}</strong></div><div className="pa-session-stat"><small>Minutados</small><strong>{cases.filter(item => item.status === "Minutado").length}</strong></div><div className="pa-session-stat"><small>Em revisão</small><strong>{cases.filter(item => item.status === "Em revisão").length}</strong></div><div className="pa-session-stat"><small>Estado</small><strong>● AO VIVO</strong></div></div>
            </section>
            <section className="pa-dashboard">
              <aside className="pa-agenda">
                <div className="pa-section-label">SESSÃO ATIVA</div>
                <div className="pa-agenda-date">12 jun<span>2025 · quinta-feira</span></div>
                <nav className="pa-agenda-nav" aria-label="Vistas da sessão">
                  <button className={section === "Pauta atual" ? "active" : ""} onClick={() => setSection("Pauta atual")}><i /> Pauta atual <span className="pa-nav-count">05</span></button>
                  <button className={section === "Todas as sessões" ? "active" : ""} onClick={() => setSection("Todas as sessões")}><i /> Todas as sessões</button>
                  <button className={section === "Acompanhar" ? "active" : ""} onClick={() => setSection("Acompanhar")}><i /> Acompanhar</button>
                </nav>
                <div className="pa-agenda-divider" />
                <div className="pa-section-label">ETAPAS DE TRABALHO</div>
                <div className="pa-legend"><span className="pa-legend-row"><i className="pa-status-dot" /> Minutado</span><span className="pa-legend-row"><i className="pa-status-dot review" /> Em revisão</span><span className="pa-legend-row"><i className="pa-status-dot pending" /> Pendente</span></div>
              </aside>
              <section className="pa-queue" aria-label="Processos da sessão">
                <div className="pa-queue-head"><div className="pa-queue-title"><h2>Processos</h2><span>{visibleCases.length}</span></div><p className="pa-queue-sub">Selecione um item para abrir a ficha.</p><label className="pa-search"><Glyph name="search" size={15} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Buscar processo ou assunto" /></label></div>
                <div className="pa-filter-tabs" role="tablist" aria-label="Filtrar processos">{["Todos", "Minutado", "Em revisão", "Pendente"].map(option => <button key={option} role="tab" aria-selected={filter === option} className={filter === option ? "active" : ""} onClick={() => setFilter(option)}>{option === "Todos" ? "Todos" : option === "Em revisão" ? "Revisão" : option}</button>)}</div>
                <div className="pa-case-list">{visibleCases.map(item => <button key={item.id} className={`pa-case ${selectedId === item.id ? "selected" : ""}`} onClick={() => setSelectedId(item.id)}><span className="pa-case-top"><span className="pa-case-number">{item.item} / {item.process}</span><span className="pa-case-status"><i className={`pa-status-dot ${item.status === "Em revisão" ? "review" : item.status === "Pendente" ? "pending" : ""}`} />{statusLabels[item.status]}</span></span><span className="pa-case-subject">{item.subject}</span><span className="pa-case-meta"><span>{item.rapporteur.replace("Des. Fed. ", "")}</span><span>{item.clerk}</span></span></button>)}
                  {visibleCases.length === 0 && <div style={{ padding: "25px 12px", textAlign: "center", color: "#849188", fontSize: 11 }}>Nenhum processo encontrado.<br /><button style={{ marginTop: 9, border: 0, color: "#4f765d", background: "transparent", cursor: "pointer" }} onClick={() => { setSearch(""); setFilter("Todos"); }}>Limpar filtros</button></div>}
                </div>
              </section>
              {selectedCase && <article className="pa-detail">
                <div className="pa-detail-top"><div><div className="pa-item-kicker">ITEM {selectedCase.item}<b>· {selectedCase.type.toUpperCase()}</b></div><h2>{selectedCase.subject.split(" · ")[0]}</h2><div className="pa-process-id">{selectedCase.process}</div></div><div className="pa-detail-actions"><button className="pa-small-icon" aria-label="Compartilhar processo" onClick={() => { void navigator.clipboard?.writeText(selectedCase.process); showToast("Número do processo copiado."); }}><Glyph name="arrow" size={15} /></button><button className="pa-small-icon" aria-label="Mais opções do processo" onClick={() => showToast("Mais opções do processo")}><Glyph name="dots" /></button></div></div>
                <div className="pa-subject-card"><small>ASSUNTO DO PROCESSO</small><p>{selectedCase.subject}</p></div>
                <div className="pa-fields"><div className="pa-field"><small>Relator</small><strong>{selectedCase.rapporteur}</strong></div><div className="pa-field"><small>Responsável</small><strong className="pa-assignee"><em>{initials(selectedCase.clerk)}</em>{selectedCase.clerk}</strong></div><div className="pa-field"><small>Classe</small><strong>{selectedCase.type}</strong></div><div className="pa-field"><small>Sessão</small><strong>18ª Sessão Ordinária · 2025</strong></div></div>
                <div className="pa-workflow"><div className="pa-workflow-head"><strong>Fluxo de trabalho</strong><span>Atualize a etapa do item</span></div><div className="pa-steps">{statusOrder.map((status, index) => <button key={status} className={`pa-step ${selectedCase.status === status ? "active" : ""}`} onClick={() => setStatus(selectedCase.id, status)}><span><i />{status}</span><small>{index === 0 ? "Aguardando início" : index === 1 ? "Leitura da minuta" : "Pronto para sessão"}</small></button>)}</div></div>
                <div className="pa-detail-footer"><span>Alterações sincronizadas na pauta compartilhada</span><strong>Item {selectedCase.item} de {String(cases.length).padStart(2, "0")}</strong></div>
              </article>}
            </section>
          </div>
        </section>
      </div>
      {toast && <div className="pa-toast" role="status">{toast}</div>}
    </main>
  );
}

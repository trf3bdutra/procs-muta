import { useEffect, useState } from "react";
import "./_group.css";

type Resource = "conformidade" | "diretrizes" | "correspondencias" | "modelos" | "trechos";

const resourceGroups: { label: string; items: { id: Resource; label: string; count?: string }[] }[] = [
  {
    label: "Análise",
    items: [
      { id: "conformidade", label: "Conformidade", count: "2" },
      { id: "diretrizes", label: "Diretrizes" },
      { id: "correspondencias", label: "Correspondências", count: "5" },
    ],
  },
  {
    label: "Redação",
    items: [
      { id: "modelos", label: "Modelos" },
      { id: "trechos", label: "Trechos" },
    ],
  },
];

const resourceTitles: Record<Resource, string> = {
  conformidade: "Conformidade",
  diretrizes: "Diretrizes de redação",
  correspondencias: "Correspondências",
  modelos: "Modelos de voto",
  trechos: "Trechos frequentes",
};

const sampleText =
  "A apelação foi conhecida e teve o pedido analisado. A sentença permanece válida diante do conjunto dos autos.";

function ResourceButton({
  id,
  label,
  count,
  active,
  onClick,
}: {
  id: Resource;
  label: string;
  count?: string;
  active: boolean;
  onClick: (id: Resource) => void;
}) {
  return (
    <button
      type="button"
      className={`rs-resource${active ? " is-active" : ""}`}
      aria-current={active ? "page" : undefined}
      onClick={() => onClick(id)}
    >
      <span className="rs-resource-mark" aria-hidden="true" />
      <span className="rs-resource-label">{label}</span>
      {count ? <span className="rs-count">{count}</span> : null}
    </button>
  );
}

function StatusTag({ children, tone = "review" }: { children: string; tone?: "review" | "ok" | "alert" }) {
  return <span className={`rs-status rs-status-${tone}`}>{children}</span>;
}

export function Reorganized() {
  const [active, setActive] = useState<Resource>("conformidade");
  const [correspondenceState, setCorrespondenceState] = useState<"empty" | "loading" | "results">("empty");
  const [checked, setChecked] = useState<Record<string, string>>({});
  const [selectedModel, setSelectedModel] = useState("Voto — apelação cível");
  const [notice, setNotice] = useState("");

  useEffect(() => {
    if (correspondenceState !== "loading") return;
    const timer = window.setTimeout(() => setCorrespondenceState("results"), 900);
    return () => window.clearTimeout(timer);
  }, [correspondenceState]);

  const announce = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2400);
  };

  const copyText = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      announce("Texto copiado para a área de transferência.");
    } catch {
      announce("Selecione e copie o texto da minuta.");
    }
  };

  const insertText = () => announce("Trecho inserido na Fundamentação.");

  return (
    <main className="rs-shell" aria-label="Apoio do Gerador de Acórdão">
      <style>{`
        .rs-shell {
          --rs-ink: #24352f;
          --rs-muted: #66756d;
          --rs-soft: #f4f6f1;
          --rs-line: #e1e7df;
          --rs-green: #285b43;
          --rs-green-deep: #1e4935;
          --rs-green-pale: #e8f0e9;
          --rs-gold: #a8864d;
          --rs-gold-pale: #f6f0e4;
          width: 100%;
          height: 100%;
          min-height: 100dvh;
          display: flex;
          flex-direction: column;
          overflow: hidden;
          background: #fbfcf8;
          color: var(--rs-ink);
          font: 500 12px/1.45 Figtree, system-ui, sans-serif;
          border-left: 1px solid #dce4dc;
        }
        .rs-shell * { box-sizing: border-box; }
        .rs-top {
          flex: none;
          padding: 17px 16px 0;
          border-bottom: 1px solid var(--rs-line);
          background: #fbfcf8;
        }
        .rs-heading-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
        .rs-kicker {
          margin: 0 0 3px;
          color: var(--rs-muted);
          font-size: 9px;
          line-height: 1.2;
          letter-spacing: .13em;
          font-weight: 800;
          text-transform: uppercase;
        }
        .rs-title { margin: 0; font-size: 17px; line-height: 1.2; letter-spacing: -.025em; font-weight: 700; }
        .rs-state {
          display: inline-flex; align-items: center; gap: 6px;
          border: 1px solid #d7e3d8; border-radius: 999px;
          padding: 4px 7px; color: var(--rs-green); background: #f2f7f1;
          font-size: 9px; line-height: 1; font-weight: 700; white-space: nowrap;
        }
        .rs-state-dot { width: 6px; height: 6px; border-radius: 50%; background: #5e8a65; }
        .rs-process {
          display: flex; align-items: center; justify-content: space-between; gap: 8px;
          margin-top: 13px; padding: 9px 10px; border-radius: 8px;
          background: #f1f4ed; color: #4e5d52;
        }
        .rs-process-label { display: block; margin-bottom: 2px; font-size: 8.5px; line-height: 1; color: #7a867c; letter-spacing: .1em; font-weight: 800; text-transform: uppercase; }
        .rs-process-number { font: 600 10px/1.2 "Source Serif 4", Georgia, serif; color: #38473e; letter-spacing: .01em; }
        .rs-process-type { padding-left: 8px; border-left: 1px solid #d5ddd2; color: #68756b; font-size: 9px; white-space: nowrap; }
        .rs-destination {
          display: flex; align-items: flex-start; gap: 8px;
          margin: 9px 0 12px; padding: 0 1px; color: #56665b;
          font-size: 10px;
        }
        .rs-destination-mark { width: 2px; align-self: stretch; min-height: 22px; border-radius: 2px; background: var(--rs-gold); }
        .rs-destination strong { color: #36473b; font-weight: 700; }
        .rs-destination small { display: block; margin-top: 1px; color: #7a857b; font-size: 9px; }
        .rs-workspace { flex: 1 1 0; min-height: 0; display: flex; overflow: hidden; }
        .rs-nav {
          flex: none; width: 132px; padding: 12px 8px 12px 10px;
          overflow-y: auto; border-right: 1px solid var(--rs-line); background: #f5f7f2;
        }
        .rs-group + .rs-group { margin-top: 17px; }
        .rs-group-title {
          margin: 0 0 6px 8px; color: #89938a; font-size: 8px; line-height: 1.2;
          font-weight: 800; letter-spacing: .14em; text-transform: uppercase;
        }
        .rs-resource {
          width: 100%; display: flex; align-items: center; gap: 7px;
          min-height: 34px; padding: 6px 7px; border: 0; border-radius: 6px;
          background: transparent; color: #526258; text-align: left;
          font: 600 10px/1.25 Figtree, system-ui, sans-serif; cursor: pointer;
          transition: background .16s ease, color .16s ease, transform .16s ease;
        }
        .rs-resource:hover { background: #eaf0e8; color: var(--rs-green-deep); }
        .rs-resource:active { transform: translateY(1px); }
        .rs-resource:focus-visible, .rs-action:focus-visible, .rs-choice:focus-visible, .rs-check:focus-visible, .rs-find:focus-visible {
          outline: 2px solid #a8864d; outline-offset: 2px;
        }
        .rs-resource.is-active { background: var(--rs-green); color: #fff; }
        .rs-resource-mark { width: 5px; height: 5px; border: 1px solid currentColor; border-radius: 2px; opacity: .75; flex: none; }
        .rs-resource.is-active .rs-resource-mark { background: #d7c08e; border-color: #d7c08e; }
        .rs-resource-label { min-width: 0; flex: 1; }
        .rs-count {
          min-width: 17px; padding: 2px 4px; border-radius: 99px; background: rgba(168,134,77,.16);
          color: #80663b; text-align: center; font-size: 8px; font-weight: 800;
        }
        .rs-resource.is-active .rs-count { background: rgba(255,255,255,.18); color: #fff; }
        .rs-content { flex: 1; min-width: 0; overflow-y: auto; overscroll-behavior: contain; padding: 14px 14px 24px; scrollbar-gutter: stable; }
        .rs-content-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 8px; margin-bottom: 11px; }
        .rs-content-title { margin: 0; color: #33463a; font: 600 16px/1.2 "Source Serif 4", Georgia, serif; letter-spacing: -.015em; }
        .rs-content-caption { margin: 4px 0 0; color: #77837a; font-size: 10px; }
        .rs-mini-count { flex: none; padding: 4px 6px; border: 1px solid #e4e9e1; border-radius: 5px; color: #737f75; font-size: 9px; font-weight: 700; }
        .rs-summary {
          display: flex; align-items: center; flex-wrap: wrap; gap: 6px 11px;
          padding: 8px 9px; margin-bottom: 8px; border: 1px solid #e8e8d9; border-radius: 7px;
          background: #faf9f1; color: #697366; font-size: 9px;
        }
        .rs-summary strong { color: #80643b; font-size: 10px; }
        .rs-summary-stat { display: inline-flex; align-items: center; gap: 4px; }
        .rs-stat-dot { width: 5px; height: 5px; border-radius: 50%; background: #b58b4e; }
        .rs-stat-dot.green { background: #5d8965; }
        .rs-check-card, .rs-result-card, .rs-guide-card, .rs-model-card, .rs-snippet-card {
          margin-top: 8px; padding: 10px; border: 1px solid var(--rs-line); border-radius: 8px; background: #fff;
        }
        .rs-check-top { display: flex; align-items: center; justify-content: space-between; gap: 6px; margin-bottom: 5px; }
        .rs-overline { color: #869087; font-size: 8px; font-weight: 800; letter-spacing: .1em; text-transform: uppercase; }
        .rs-status { display: inline-flex; align-items: center; border-radius: 999px; padding: 3px 6px; font-size: 8px; line-height: 1; font-weight: 800; white-space: nowrap; }
        .rs-status-review { color: #8b6b30; background: #f7f0df; }
        .rs-status-ok { color: #3d7450; background: #e9f2e9; }
        .rs-status-alert { color: #955a3a; background: #f7ece5; }
        .rs-check-card h3, .rs-result-card h3, .rs-guide-card h3, .rs-model-card h3, .rs-snippet-card h3 {
          margin: 0; color: #34453a; font-size: 11px; line-height: 1.38; font-weight: 700;
        }
        .rs-check-card p, .rs-result-card p, .rs-guide-card p, .rs-model-card p, .rs-snippet-card p {
          margin: 5px 0 0; color: #66746a; font-size: 10px; line-height: 1.5;
        }
        .rs-check-actions { display: flex; gap: 4px; flex-wrap: wrap; margin-top: 8px; }
        .rs-check {
          padding: 4px 6px; border: 1px solid #dfe5dc; border-radius: 5px;
          background: #fff; color: #667369; font: 600 8px/1.1 Figtree, system-ui, sans-serif; cursor: pointer;
        }
        .rs-check.selected { border-color: #a7c0a8; color: #285b43; background: #edf4ec; }
        .rs-note { margin: 10px 0 0; padding: 8px 9px; border-left: 2px solid #c5a56b; background: #f8f5ec; color: #74684f; font-size: 9px; line-height: 1.45; }
        .rs-search-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin: 0 0 10px; }
        .rs-query { min-width: 0; color: #77827a; font-size: 9px; }
        .rs-find, .rs-action {
          display: inline-flex; align-items: center; justify-content: center; gap: 5px;
          border: 1px solid #dce5dc; border-radius: 6px; padding: 6px 8px;
          background: #fff; color: #355943; font: 700 9px/1.1 Figtree, system-ui, sans-serif; cursor: pointer;
          transition: background .16s ease, border-color .16s ease, transform .16s ease;
        }
        .rs-find:hover, .rs-action:hover { border-color: #adc2af; background: #f1f6f0; }
        .rs-find:active, .rs-action:active { transform: translateY(1px); }
        .rs-find.primary, .rs-action.primary { border-color: var(--rs-green); background: var(--rs-green); color: #fff; }
        .rs-find.primary:hover, .rs-action.primary:hover { background: var(--rs-green-deep); }
        .rs-result-meta { display: flex; align-items: center; justify-content: space-between; gap: 6px; margin-bottom: 5px; }
        .rs-result-id { color: #7e887f; font-size: 8px; font-weight: 700; letter-spacing: .04em; }
        .rs-empty {
          display: flex; flex-direction: column; align-items: flex-start; gap: 7px;
          padding: 18px 12px; border: 1px dashed #d5dfd4; border-radius: 8px; background: #f7f9f5;
        }
        .rs-empty-mark { width: 24px; height: 24px; display: grid; place-items: center; border: 1px solid #dce6da; border-radius: 7px; color: #66816a; font: 600 13px/1 Georgia, serif; }
        .rs-empty h3 { margin: 0; color: #3e5144; font-size: 11px; }
        .rs-empty p { margin: 0; color: #748078; font-size: 9px; line-height: 1.5; }
        .rs-loading { display: grid; gap: 8px; padding: 11px; border: 1px solid #e3e8e1; border-radius: 8px; background: #fff; }
        .rs-skeleton { height: 8px; border-radius: 5px; background: linear-gradient(90deg, #edf1eb 20%, #f5f7f3 50%, #edf1eb 80%); background-size: 220% 100%; animation: rs-shimmer 1.25s ease-in-out infinite; }
        .rs-skeleton.short { width: 45%; } .rs-skeleton.medium { width: 72%; }
        @keyframes rs-shimmer { to { background-position: -220% 0; } }
        .rs-model-choice { display: flex; gap: 7px; align-items: flex-start; }
        .rs-radio { flex: none; width: 13px; height: 13px; margin-top: 1px; border: 1px solid #aab9aa; border-radius: 50%; }
        .rs-model-card.is-selected { border-color: #9bb49c; box-shadow: inset 2px 0 0 #487451; background: #fbfdf9; }
        .rs-model-card.is-selected .rs-radio { border: 4px solid #4e7957; }
        .rs-card-actions { display: flex; justify-content: flex-end; gap: 6px; margin-top: 9px; }
        .rs-quote { margin-top: 7px !important; padding: 8px; border-left: 2px solid #b99a63; background: #f8f6ef; color: #4e5b50 !important; font: 500 10px/1.55 "Source Serif 4", Georgia, serif !important; }
        .rs-toast {
          position: fixed; right: 12px; bottom: 12px; z-index: 5;
          max-width: calc(100% - 24px); padding: 9px 11px; border: 1px solid #d8e4d9; border-radius: 7px;
          background: #285b43; color: #fff; box-shadow: 0 8px 24px rgba(28,51,37,.16);
          font-size: 10px; animation: rs-toast-in .18s ease-out;
        }
        @keyframes rs-toast-in { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
        @media (max-width: 350px) {
          .rs-top { padding: 14px 12px 0; }
          .rs-nav { width: 112px; padding-inline: 6px; }
          .rs-content { padding: 12px 10px 20px; }
          .rs-resource { gap: 5px; padding-inline: 5px; font-size: 9px; }
          .rs-process-number { font-size: 9px; }
          .rs-process-type { font-size: 8px; }
        }
        @media (prefers-reduced-motion: reduce) {
          .rs-shell *, .rs-shell *::before, .rs-shell *::after { animation-duration: .01ms !important; transition-duration: .01ms !important; }
        }
      `}</style>

      <header className="rs-top">
        <div className="rs-heading-row">
          <div>
            <p className="rs-kicker">Gabinete CMT · Gerador</p>
            <h1 className="rs-title">Apoio à minuta</h1>
          </div>
          <span className="rs-state"><span className="rs-state-dot" /> Rascunho</span>
        </div>
        <div className="rs-process" aria-label="Identificação do processo">
          <div>
            <span className="rs-process-label">Processo</span>
            <span className="rs-process-number">0004821-72.2024.8.16.0000</span>
          </div>
          <span className="rs-process-type">Apelação Cível</span>
        </div>
        <div className="rs-destination">
          <span className="rs-destination-mark" aria-hidden="true" />
          <span><strong>Ponto de inserção</strong><small>Fundamentação · após o parágrafo 3</small></span>
        </div>
      </header>

      <div className="rs-workspace">
        <nav className="rs-nav" aria-label="Recursos de apoio">
          {resourceGroups.map((group) => (
            <section className="rs-group" key={group.label} aria-label={group.label}>
              <h2 className="rs-group-title">{group.label}</h2>
              {group.items.map((item) => (
                <ResourceButton
                  key={item.id}
                  {...item}
                  active={active === item.id}
                  onClick={setActive}
                />
              ))}
            </section>
          ))}
        </nav>

        <section className="rs-content" aria-live="polite">
          <div className="rs-content-head">
            <div>
              <h2 className="rs-content-title">{resourceTitles[active]}</h2>
              <p className="rs-content-caption">
                {active === "conformidade" && "Verifique a redação da minuta."}
                {active === "diretrizes" && "Orientações para este tipo de voto."}
                {active === "correspondencias" && "Pontos de conferência do processo."}
                {active === "modelos" && "Escolha uma estrutura para iniciar."}
                {active === "trechos" && "Fórmulas prontas para inserir ou copiar."}
              </p>
            </div>
            {active === "conformidade" ? <span className="rs-mini-count">4 itens</span> : null}
            {active === "correspondencias" ? <span className="rs-mini-count">5 itens</span> : null}
          </div>

          {active === "conformidade" ? (
            <>
              <div className="rs-summary">
                <strong>2 a conferir</strong>
                <span className="rs-summary-stat"><i className="rs-stat-dot green" />1 conforme</span>
                <span className="rs-summary-stat"><i className="rs-stat-dot" />1 revisão</span>
              </div>
              <article className="rs-check-card">
                <div className="rs-check-top"><span className="rs-overline">Fundamentação</span><StatusTag tone="review">{checked.fund || "Conferir"}</StatusTag></div>
                <h3>A minuta enfrenta as questões jurídicas registradas?</h3>
                <p>A presença de texto não comprova enfrentamento suficiente. Confira as questões indicadas no processo.</p>
                <div className="rs-check-actions">
                  {["Conforme", "Inconforme", "Conferir", "N/A"].map((option) => (
                    <button key={option} type="button" className={`rs-check${checked.fund === option ? " selected" : ""}`} onClick={() => setChecked((current) => ({ ...current, fund: option }))}>{option}</button>
                  ))}
                </div>
              </article>
              <article className="rs-check-card">
                <div className="rs-check-top"><span className="rs-overline">Encerramento</span><StatusTag tone="ok">Conforme</StatusTag></div>
                <h3>O resultado está expresso de forma definida?</h3>
                <p>“Nega provimento à apelação” consta na minuta e corresponde ao resultado registrado.</p>
              </article>
              <article className="rs-check-card">
                <div className="rs-check-top"><span className="rs-overline">Estrutura</span><StatusTag tone="alert">Revisão</StatusTag></div>
                <h3>A abertura corresponde à espécie do pronunciamento?</h3>
                <p>Confira a fórmula de abertura antes de finalizar o voto.</p>
              </article>
              <p className="rs-note">A análise do texto não substitui a conferência jurídica do caso.</p>
            </>
          ) : null}

          {active === "diretrizes" ? (
            <>
              <article className="rs-guide-card">
                <div className="rs-check-top"><span className="rs-overline">Fundamentação</span><span className="rs-overline">01</span></div>
                <h3>Apresente a controvérsia antes dos fundamentos</h3>
                <p>Delimite a questão devolvida e enfrente os argumentos relevantes em sequência lógica, com referência objetiva aos autos.</p>
              </article>
              <article className="rs-guide-card">
                <div className="rs-check-top"><span className="rs-overline">Redação</span><span className="rs-overline">02</span></div>
                <h3>Prefira frases diretas e conclusões explícitas</h3>
                <p>Identifique a regra aplicável, conecte-a aos fatos reconhecidos e conclua sobre cada pedido recursal.</p>
              </article>
              <article className="rs-guide-card">
                <div className="rs-check-top"><span className="rs-overline">Dispositivo</span><span className="rs-overline">03</span></div>
                <h3>Faça o dispositivo refletir a fundamentação</h3>
                <p>Indique conhecimento, extensão do provimento e efeitos decorrentes sem acrescentar matéria não examinada.</p>
              </article>
              <p className="rs-note">Diretrizes auxiliam a redação; a adequação depende das particularidades do processo.</p>
            </>
          ) : null}

          {active === "correspondencias" ? (
            <>
              <div className="rs-search-row">
                <span className="rs-query">Minuta · Relatório e Fundamentação</span>
                <button type="button" className="rs-find" onClick={() => setCorrespondenceState("loading")} disabled={correspondenceState === "loading"}>
                  {correspondenceState === "loading" ? "Atualizando" : correspondenceState === "empty" ? "Buscar" : "Atualizar"}
                </button>
              </div>
              {correspondenceState === "empty" ? (
                <div className="rs-empty">
                  <span className="rs-empty-mark" aria-hidden="true">↗</span>
                  <h3>Nenhuma correspondência exibida</h3>
                  <p>Busque referências entre os tópicos do processo e o texto da minuta.</p>
                  <button type="button" className="rs-find primary" onClick={() => setCorrespondenceState("loading")}>Buscar correspondências</button>
                </div>
              ) : null}
              {correspondenceState === "loading" ? (
                <div className="rs-loading" role="status" aria-label="Buscando correspondências">
                  <span className="rs-skeleton short" /><span className="rs-skeleton" /><span className="rs-skeleton medium" />
                  <span className="rs-skeleton short" /><span className="rs-skeleton medium" />
                  <span className="rs-query">Comparando tópicos com a minuta…</span>
                </div>
              ) : null}
              {correspondenceState === "results" ? (
                <>
                  <article className="rs-result-card">
                    <div className="rs-result-meta"><span className="rs-result-id">TÓPICO 02 · DANOS MORAIS</span><StatusTag tone="ok">Localizado</StatusTag></div>
                    <h3>Fundamentação, parágrafo 4</h3>
                    <p>“A prova produzida não demonstra lesão extrapatrimonial indenizável.”</p>
                  </article>
                  <article className="rs-result-card">
                    <div className="rs-result-meta"><span className="rs-result-id">TÓPICO 03 · ÔNUS DA PROVA</span><StatusTag>Conferir</StatusTag></div>
                    <h3>Não localizado na minuta</h3>
                    <p>O tema consta no processo, mas não foi identificado na fundamentação atual.</p>
                  </article>
                  <article className="rs-result-card">
                    <div className="rs-result-meta"><span className="rs-result-id">PEDIDO · HONORÁRIOS</span><StatusTag tone="ok">Localizado</StatusTag></div>
                    <h3>Dispositivo, parágrafo 1</h3>
                    <p>Referência a honorários identificada no encerramento.</p>
                  </article>
                  <article className="rs-result-card">
                    <div className="rs-result-meta"><span className="rs-result-id">PRELIMINAR · CERCEAMENTO</span><StatusTag>Conferir</StatusTag></div>
                    <h3>Correspondência parcial</h3>
                    <p>Há referência à preliminar no relatório; confirme o enfrentamento na fundamentação.</p>
                  </article>
                  <p className="rs-note">Correspondências são referências de navegação, não uma conclusão jurídica.</p>
                </>
              ) : null}
            </>
          ) : null}

          {active === "modelos" ? (
            <>
              {["Voto — apelação cível", "Voto — agravo de instrumento", "Decisão — questão incidental"].map((model, index) => (
                <article key={model} className={`rs-model-card${selectedModel === model ? " is-selected" : ""}`}>
                  <button type="button" className="rs-model-choice" onClick={() => setSelectedModel(model)} aria-pressed={selectedModel === model}>
                    <span className="rs-radio" aria-hidden="true" />
                    <span><h3>{model}</h3><p>{index === 0 ? "Relatório, fundamentação e dispositivo · atualizado em 12/08/2025" : index === 1 ? "Estrutura para tutela recursal e análise colegiada" : "Fundamentação objetiva e dispositivo correspondente"}</p></span>
                  </button>
                </article>
              ))}
              <div className="rs-card-actions"><button type="button" className="rs-action primary" onClick={() => announce(`Modelo “${selectedModel}” selecionado.`)}>Usar modelo selecionado</button></div>
              <p className="rs-note">Escolher um modelo não altera a minuta até a confirmação no editor.</p>
            </>
          ) : null}

          {active === "trechos" ? (
            <>
              <article className="rs-snippet-card">
                <div className="rs-check-top"><span className="rs-overline">Resultado · Apelação</span><span className="rs-overline">1</span></div>
                <h3>Negar provimento</h3>
                <p className="rs-quote">“Ante o exposto, voto por conhecer da apelação e negar-lhe provimento.”</p>
                <div className="rs-card-actions">
                  <button type="button" className="rs-action" onClick={() => void copyText("Ante o exposto, voto por conhecer da apelação e negar-lhe provimento.")}>Copiar</button>
                  <button type="button" className="rs-action primary" onClick={insertText}>Inserir</button>
                </div>
              </article>
              <article className="rs-snippet-card">
                <div className="rs-check-top"><span className="rs-overline">Preliminar</span><span className="rs-overline">2</span></div>
                <h3>Rejeitar preliminar</h3>
                <p className="rs-quote">“A preliminar não merece acolhimento, pois não se verifica prejuízo processual demonstrado.”</p>
                <div className="rs-card-actions">
                  <button type="button" className="rs-action" onClick={() => void copyText("A preliminar não merece acolhimento, pois não se verifica prejuízo processual demonstrado.")}>Copiar</button>
                  <button type="button" className="rs-action primary" onClick={insertText}>Inserir</button>
                </div>
              </article>
              <article className="rs-snippet-card">
                <div className="rs-check-top"><span className="rs-overline">Transição</span><span className="rs-overline">3</span></div>
                <h3>Introduzir análise do mérito</h3>
                <p className="rs-quote">“Passo ao exame das questões devolvidas a esta instância.”</p>
                <div className="rs-card-actions">
                  <button type="button" className="rs-action" onClick={() => void copyText("Passo ao exame das questões devolvidas a esta instância.")}>Copiar</button>
                  <button type="button" className="rs-action primary" onClick={insertText}>Inserir</button>
                </div>
              </article>
            </>
          ) : null}
        </section>
      </div>
      {notice ? <div className="rs-toast" role="status">{notice}</div> : null}
      <span className="rs-sr-only" aria-hidden="true">{sampleText}</span>
      <style>{`.rs-sr-only { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0; }`}</style>
    </main>
  );
}

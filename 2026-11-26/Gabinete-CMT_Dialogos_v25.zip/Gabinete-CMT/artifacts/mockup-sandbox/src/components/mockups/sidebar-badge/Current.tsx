import "./_group.css";

const railItems = ["Pauta", "Decisões", "Triagem"];

function ProfileBadge() {
  return (
    <div className="badge-current">
      <div className="badge-actions">
        <button aria-label="Encerrar sessão">↪</button>
        <span className="jf-ident">
          <b>JUSTIÇA FEDERAL</b>
          <small>TRF DA 3ª REGIÃO</small>
        </span>
        <button aria-label="Recolher barra">‹</button>
      </div>
      <div className="avatar-current">BR</div>
      <div className="name-current">
        <b>Servidor</b>
        <span>Assessoria</span>
      </div>
      <div className="stats-current">
        <div><b>4</b><span>Disponíveis</span><small>na equipe</small></div>
        <div><b>18</b><span>Minutadas</span><small>hoje</small></div>
        <div><b>1</b><span>Meta</span><small>do dia</small></div>
      </div>
      <div className="session-current"><i /> DISPONÍVEL <b>GABINETE CMT · TRMS</b></div>
    </div>
  );
}

function Rail({ compact = false }: { compact?: boolean }) {
  return (
    <aside className={`rail-current ${compact ? "rail-current-compact" : ""}`}>
      <div className="rail-current-top">
        <div className="brand-current"><span>JF</span>{!compact && <b>Gabinete CMT</b>}</div>
        {!compact && <ProfileBadge />}
        {compact && <div className="avatar-compact">BR</div>}
      </div>
      <nav className="nav-current" aria-label="Navegação">
        {railItems.map((item, index) => (
          <div className={index === 0 ? "nav-current-item active" : "nav-current-item"} key={item}>
            <i>{index === 0 ? "▤" : index === 1 ? "◫" : "⌕"}</i>
            {!compact && <span>{item}</span>}
          </div>
        ))}
      </nav>
      <div className="day-shortcuts-current">
        <span aria-label="Notificações">♧</span>
        <span aria-label="Meu dia">◷</span>
        <span aria-label="Entregas do dia">☑</span>
      </div>
    </aside>
  );
}

export function Current() {
  return (
    <main className="sidebar-stage">
      <header className="sidebar-stage-header">
        <div><b>GabCMT</b><span>Barra lateral · estrutura atual</span></div>
        <span className="state-label">referência</span>
      </header>
      <section className="sidebar-stage-views">
        <div className="sidebar-view">
          <span className="view-label">Expandida</span>
          <Rail />
        </div>
        <div className="sidebar-view">
          <span className="view-label">Minimizada</span>
          <Rail compact />
        </div>
      </section>
    </main>
  );
}

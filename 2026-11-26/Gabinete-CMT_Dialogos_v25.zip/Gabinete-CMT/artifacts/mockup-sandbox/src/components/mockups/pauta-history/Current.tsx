import { HistorySample } from "./HistorySample";

export function Current() {
  return <HistorySample />;
}

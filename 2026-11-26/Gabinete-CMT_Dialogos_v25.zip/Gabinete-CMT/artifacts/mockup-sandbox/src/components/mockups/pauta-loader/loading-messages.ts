/** Mensagens de ambientação — não representam etapas reais de inicialização. */
export const LOADING_MESSAGES: readonly string[] = [
  // Rotina do gabinete (15)
  "Preparando votos, relatórios e ementas…",
  "Conferindo se todos os processos estão na pauta certa…",
  "Alinhando as informações da pauta de julgamento…",
  "Sincronizando os dados da equipe…",
  "Separando os processos aptos dos quase aptos…",
  "Conferindo prazos, urgências e pendências…",
  "Preparando os indicadores de produtividade…",
  "Organizando os agravos e embargos de declaração…",
  "Conferindo os paradigmas do gabinete…",
  "Em busca da minuta enxuta e do fundamento preciso…",
  "Verificando se o dispositivo corresponde à conclusão…",
  "Conferindo o que está minutado, corrigido e liberado…",
  "Organizando prioridades sem criar novas pendências…",
  "Atualizando os controles do gabinete…",
  "Preparando tudo para mais um dia na Turma Regional…",
  // Humor jurídico (10)
  "Procurando o voto-fantasma. Ele estava aqui há um minuto.",
  "Aguardando o trânsito em julgado deste carregamento…",
  "Ainda não cabe agravo contra esta tela de carregamento.",
  "Certificando o decurso de três segundos…",
  "Afastando a preliminar de ausência de conexão…",
  "Eliminando duplicidades antes que virem tradição…",
  "Conferindo os IDs. Porque cada documento importa.",
  "Verificando se o prazo é em dias úteis…",
  "O carregamento foi concluso. Falta apenas a decisão.",
  "Localizando o último documento em meio a 400 IDs…",
];

export const MESSAGE_INTERVAL_MS = 3600;

export function shuffleMessages(messages: readonly string[]): string[] {
  const shuffled = [...messages];
  for (let i = shuffled.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

import type { Request, Response, NextFunction } from "express";
import { AccountError, getOrRegisterAccount, type VerifiedIdentity } from "../lib/account-memberships";
import { canAccessGlobalSettings, setAppSession } from "../lib/app-auth";
import { readLocalIdentity } from "../lib/local-auth";
import { readCmAccessSession } from "../lib/cm-access";

export async function resolveVerifiedIdentity(req: Request): Promise<VerifiedIdentity> {
  return readLocalIdentity(req);
}
export function sendAccountError(error: unknown, res: Response) {
  if (res.headersSent) { res.end(); return; }
  res.setHeader("Cache-Control", "no-store");
  if (error instanceof AccountError) res.status(error.status).json({ error: error.message, code: error.code });
  else res.status(503).json({ error: "Não foi possível verificar seu acesso agora. Tente novamente.", code: "auth_unavailable" });
}
export async function approvedSession(req: Request) {
  let identity: VerifiedIdentity;
  try {
    identity = await resolveVerifiedIdentity(req);
  } catch (error) {
    if (error instanceof AccountError && error.status === 401) {
      const cmSession = readCmAccessSession(req);
      if (cmSession) {
        setAppSession(req, cmSession);
        return cmSession;
      }
    }
    throw error;
  }
  const member = await getOrRegisterAccount(identity);
  if (member.status !== "active") throw new AccountError(403, member.status, member.status === "disabled" ? "Seu acesso foi desativado pela Administração." : "Sua conta aguarda aprovação da Administração.");
  if ((identity.role === "equipe" || identity.role === "editor") &&
      (member.role === "equipe" || member.role === "editor") && !member.server) {
    throw new AccountError(403, "pending", "Sua conta aguarda vínculo com um servidor.");
  }
  const result = { userId: identity.userId, sessionId: identity.sessionId, role: identity.role,
    name: member.server || "Administração", ...(member.server ? { server: member.server } : {}),
    issuedAt: Math.floor(Date.now() / 1000), expiresAt: identity.expiresAt };
  setAppSession(req, result);
  return result;
}
export async function requireApprovedAccount(req: Request, res: Response, next: NextFunction) {
  res.setHeader("Cache-Control", "no-store");
  try { await approvedSession(req); next(); } catch (error) { sendAccountError(error, res); }
}
export async function requireAdministration(req: Request, res: Response, next: NextFunction) {
  try {
    const session = await approvedSession(req);
    if (!canAccessGlobalSettings(session.role)) throw new AccountError(403, "admin_required", "Somente a Administração pode realizar esta operação.");
    next();
  } catch (error) { sendAccountError(error, res); }
}

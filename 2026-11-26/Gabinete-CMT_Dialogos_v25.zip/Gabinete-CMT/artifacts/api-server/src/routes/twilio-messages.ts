import { createHash } from "node:crypto";
import { Router, urlencoded } from "express";
import { db, pautaSnapshotsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { ListTwilioMessagesQueryParams, LinkTwilioMessageBody, SendTwilioMessageBody, UpdateTwilioConfigBody } from "@workspace/api-zod";
import { getAppSession } from "../lib/app-auth";
import { normalizeTwilioMessage, twilioAccountPath, twilioNextPageToken, twilioRequest, twilioSendForm, TwilioFailure, verifyTwilioSignature } from "../lib/twilio-messages";
import { upsertMessage, type InboxState } from "../lib/agentmail";
import { requireMessageCenterAccess, withInbox } from "./pauta-mensagens";
import { requireAdministration } from "../middlewares/account-auth";

const router = Router();
const CONFIG_ROW = "twilio-channel-config";
async function readConfig() {
  const [row] = await db.select().from(pautaSnapshotsTable).where(eq(pautaSnapshotsTable.id, CONFIG_ROW));
  const data = (row?.state ?? {}) as Record<string, unknown>;
  return {
    smsNumber: typeof data.smsNumber === "string" ? data.smsNumber : "",
    whatsappNumber: typeof data.whatsappNumber === "string" ? data.whatsappNumber : "",
    ativo: data.ativo === true,
    accountConfigured: /^AC[a-f\d]{32}$/i.test(process.env.TWILIO_ACCOUNT_SID?.trim() ?? ""),
    tokenConfigured: !!process.env.TWILIO_AUTH_TOKEN?.trim(),
    webhookUrl: process.env.TWILIO_WEBHOOK_URL?.trim() ?? "",
  };
}

router.get("/pauta/mensagens/twilio/config", async (req, res) => {
  if (!(await requireMessageCenterAccess(req, res))) return;
  res.setHeader("Cache-Control", "no-store");
  try { res.json(await readConfig()); }
  catch { res.status(500).json({ error: "Não foi possível ler a configuração dos canais." }); }
});

router.put("/pauta/mensagens/twilio/config", requireAdministration, async (req, res) => {
  if (!(await requireMessageCenterAccess(req, res))) return;
  const parsed = UpdateTwilioConfigBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Informe números internacionais válidos, com + e código do país." }); return; }
  const { smsNumber = "", whatsappNumber = "", ativo } = parsed.data;
  if (ativo && (!smsNumber && !whatsappNumber)) { res.status(400).json({ error: "Informe pelo menos um número do gabinete antes de ativar." }); return; }
  if (ativo && (!process.env.TWILIO_WEBHOOK_URL || !process.env.TWILIO_AUTH_TOKEN)) { res.status(400).json({ error: "Configure o endereço público do webhook e as credenciais no servidor antes de ativar." }); return; }
  try {
    const state = { smsNumber, whatsappNumber, ativo, updatedBy: getAppSession(req)?.userId, updatedAt: new Date().toISOString() };
    await db.insert(pautaSnapshotsTable).values({ id: CONFIG_ROW, revision: 1, state }).onConflictDoUpdate({ target: pautaSnapshotsTable.id, set: { state } });
    res.json(await readConfig());
  } catch { res.status(500).json({ error: "Não foi possível salvar os números do gabinete." }); }
});

router.post("/pauta/mensagens/twilio/webhook", urlencoded({ extended: false, limit: "64kb" }), async (req, res) => {
  const body = req.body ?? {};
  const url = process.env.TWILIO_WEBHOOK_URL?.trim() ?? "";
  const token = process.env.TWILIO_AUTH_TOKEN?.trim() ?? "";
  if (!verifyTwilioSignature(url, body, req.get("X-Twilio-Signature") ?? "", token)) { res.status(401).json({ error: "Assinatura Twilio inválida." }); return; }
  if (body.AccountSid !== process.env.TWILIO_ACCOUNT_SID?.trim()) { res.status(403).json({ error: "Conta Twilio não autorizada." }); return; }
  try {
    const config = await readConfig();
    const whatsapp = String(body.To ?? "").startsWith("whatsapp:");
    const to = String(body.To ?? "").replace(/^whatsapp:/, "");
    const expected = whatsapp ? config.whatsappNumber : config.smsNumber;
    if (!config.ativo) { res.type("text/xml").send("<Response/>"); return; }
    if (!expected || to !== expected) { res.status(403).json({ error: "Número de destino não autorizado." }); return; }
    if ((body.SmsStatus || body.MessageStatus || "received") !== "received") { res.type("text/xml").send("<Response/>"); return; }
    const message = normalizeTwilioMessage({ sid: body.MessageSid || body.SmsSid, account_sid: body.AccountSid, from: body.From, to: body.To, body: body.Body, direction: "inbound" });
    await withInbox((state: InboxState) => upsertMessage(state, message));
    res.type("text/xml").send("<Response/>");
  } catch { res.status(503).json({ error: "Recebimento temporariamente indisponível. O provedor pode repetir o evento com segurança." }); }
});

router.get("/pauta/mensagens/twilio", async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  if (!(await requireMessageCenterAccess(req, res))) return;
  const parsed = ListTwilioMessagesQueryParams.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: "Filtros Twilio inválidos." }); return; }
  try {
    const { channel = "sms", phone, q = "", pageToken } = parsed.data;
    const params = new URLSearchParams({ PageSize: "50" });
    if (phone) params.set("To", (channel === "whatsapp" ? "whatsapp:" : "") + phone);
    if (pageToken) params.set("PageToken", pageToken);
    const data = await twilioRequest(twilioAccountPath() + "/Messages.json?" + params);
    const local = await withInbox((state: InboxState) => new Set(state.messages.map((m) => m.id)), false);
    const messages = (Array.isArray(data.messages) ? data.messages : []).filter((raw: any) => {
      const whatsapp = String(raw.from).startsWith("whatsapp:") || String(raw.to).startsWith("whatsapp:");
      return whatsapp === (channel === "whatsapp") && (!q || String(raw.body ?? "").toLocaleLowerCase("pt-BR").includes(q.toLocaleLowerCase("pt-BR")));
    }).map((raw: any) => {
      const message = normalizeTwilioMessage(raw);
      return { id: String(raw.sid), channel, direction: String(raw.direction), from: message.from, to: message.to[0], text: message.text, imported: local.has(message.id), status: String(raw.status) };
    });
    res.json({ messages, nextPageToken: twilioNextPageToken(data.next_page_uri) });
  } catch (error) {
    req.log.warn({ cause: error instanceof TwilioFailure ? error.code : "unavailable" }, "Twilio message consultation failed");
    res.status(502).json({ error: error instanceof TwilioFailure ? error.message : "Não foi possível consultar o Twilio. Confira a conexão e os Secrets do servidor." });
  }
});

router.post("/pauta/mensagens/twilio/vincular", async (req, res) => {
  if (!(await requireMessageCenterAccess(req, res))) return;
  const parsed = LinkTwilioMessageBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Selecione uma mensagem Twilio válida." }); return; }
  const process = String(parsed.data.process ?? "").replace(/\D/g, "");
  if (parsed.data.process && process.length !== 20) { res.status(400).json({ error: "Informe um CNJ completo ou deixe o vínculo vazio." }); return; }
  try {
    if (process) {
      const found = await db.execute(sql`SELECT processo FROM acervo WHERE processo = ${process} LIMIT 1`);
      if (!found.rows?.length) { res.status(400).json({ error: "O CNJ informado não foi encontrado no Acervo do app." }); return; }
    }
    const raw = await twilioRequest(twilioAccountPath() + `/Messages/${parsed.data.sid}.json`);
    if (raw.direction !== "inbound" || raw.sid !== parsed.data.sid) { res.status(400).json({ error: "Somente mensagens recebidas podem ser vinculadas à caixa de entrada." }); return; }
    const message = normalizeTwilioMessage(raw);
    if (process) message.outcome = { process, linkedBy: getAppSession(req)?.userId };
     const added = await withInbox((state: InboxState) => upsertMessage(state, message));
    res.json({ added, id: message.id });
  } catch {
    res.status(502).json({ error: "Não foi possível vincular a mensagem recebida." });
  }
});

router.post("/pauta/mensagens/twilio/enviar", async (req, res) => {
  if (!(await requireMessageCenterAccess(req, res))) return;
  const user = getAppSession(req)?.userId;
  if (!user) { res.status(401).json({ error: "Entre novamente antes de enviar." }); return; }
  const parsed = SendTwilioMessageBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Preencha canal, remetente, destinatário e mensagem corretamente.", safeToRetry: true }); return; }
  const body = parsed.data;
  let form: URLSearchParams;
  try { form = twilioSendForm(body); twilioAccountPath(); }
  catch (error) { res.status(400).json({ error: (error as Error).message, safeToRetry: true }); return; }
  const id = `twilio-send:${body.requestId}`;
  const fingerprint = createHash("sha256").update(JSON.stringify([user, form.toString()])).digest("hex");
  try {
    const inserted = await db.insert(pautaSnapshotsTable).values({
      id, revision: 1, state: { fingerprint, status: "pending" },
    }).onConflictDoNothing().returning();
    if (!inserted.length) {
      const [previous] = await db.select().from(pautaSnapshotsTable).where(eq(pautaSnapshotsTable.id, id));
      const state = previous?.state as Record<string, unknown> | undefined;
      if (state?.fingerprint !== fingerprint) { res.status(409).json({ error: "Identificador de envio já utilizado." }); return; }
      if (state.status === "accepted") { res.json({ sid: state.sid, status: state.deliveryStatus }); return; }
      res.status(409).json({ error: "Este envio já foi solicitado. Confira seu estado no Twilio antes de tentar novamente; não foi disparada outra mensagem." }); return;
    }
    try {
      const result = await twilioRequest(twilioAccountPath() + "/Messages.json", form);
      if (!/^(SM|MM)[a-f\d]{32}$/i.test(String(result.sid))) throw new Error("Twilio receipt unavailable");
      await db.update(pautaSnapshotsTable).set({ state: { fingerprint, status: "accepted", sid: result.sid, deliveryStatus: result.status } }).where(eq(pautaSnapshotsTable.id, id));
      res.json({ sid: result.sid, status: result.status });
    } catch (error) {
      const rejected = error instanceof TwilioFailure && error.status >= 400 && error.status < 500;
      await db.update(pautaSnapshotsTable).set({ state: { fingerprint, status: rejected ? "rejected" : "unknown" } }).where(eq(pautaSnapshotsTable.id, id));
      res.status(rejected ? 400 : 502).json({
        error: rejected ? (error as TwilioFailure).message : "Não foi possível confirmar o envio. Verifique o Twilio antes de reenviar: a mensagem pode ter sido aceita.",
        safeToRetry: rejected,
      });
    }
  } catch {
    res.status(500).json({ error: "Falha ao registrar o envio. Confira o Twilio antes de repetir a solicitação." });
  }
});

export default router;

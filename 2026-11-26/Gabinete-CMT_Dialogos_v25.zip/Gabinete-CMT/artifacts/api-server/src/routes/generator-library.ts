import { Router } from "express";
import { db, pautaSnapshotsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getAppSession } from "../lib/app-auth";
import { canEditGeneratorLibrary, LIBRARY_KEY, readGeneratorLibrary, validateGeneratorLibrary } from "../lib/generator-library";

const router = Router();
const payload = (state: unknown, session: ReturnType<typeof getAppSession>) => ({
  ...readGeneratorLibrary(state), canEditLibrary: canEditGeneratorLibrary(session, state),
});

router.get("/generator-library", async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  const [snapshot] = await db.select().from(pautaSnapshotsTable).where(eq(pautaSnapshotsTable.id, "main"));
  res.json(payload(snapshot?.state, getAppSession(req)));
});

router.put("/generator-library", async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  const session = getAppSession(req);
  if (!session) { res.status(401).json({ error: "Entre no Gabinete." }); return; }
  if (!Number.isSafeInteger(req.body?.baseRevision) || req.body.baseRevision < 0) {
    res.status(400).json({ error: "Informe a revisão da biblioteca." }); return;
  }
  if (Buffer.byteLength(JSON.stringify(req.body), "utf8") > 8 * 1024 * 1024) {
    res.status(413).json({ error: "A biblioteca excede 8 MB." }); return;
  }
  const parsed = validateGeneratorLibrary(req.body.library);
  if ("error" in parsed) { res.status(400).json({ error: parsed.error }); return; }
  const outcome = await db.transaction(async tx => {
    const [snapshot] = await tx.select().from(pautaSnapshotsTable).where(eq(pautaSnapshotsTable.id, "main")).for("update");
    if (!snapshot || !canEditGeneratorLibrary(session, snapshot.state)) return { status: 403, body: { error: "Somente a Assessoria pode editar a biblioteca dos Geradores." } };
    const current = readGeneratorLibrary(snapshot.state);
    if (req.body.baseRevision !== current.revision) return { status: 409, body: { error: "A biblioteca foi alterada por outra pessoa. Recarregue antes de editar.", ...payload(snapshot.state, session) } };
    const state = { ...snapshot.state as Record<string, unknown>, [LIBRARY_KEY]: { revision: current.revision + 1, library: parsed.library } };
    await tx.update(pautaSnapshotsTable).set({ state, revision: snapshot.revision + 1, updatedAt: new Date() }).where(eq(pautaSnapshotsTable.id, "main"));
    return { status: 200, body: payload(state, session) };
  });
  res.status(outcome.status).json(outcome.body);
});

export default router;

import { Router } from "express";
import paragraphSeed from "../data/paragrafos-iniciais.json";
import { db, cmEmentarioTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getAppSession } from "../lib/app-auth";
import {
  canEditCmEmentario,
  CM_EMENTARIO_ID,
  emptyCmEmentarioCatalog,
  readCmEmentarioCatalog,
  validateCmEmentarioCatalog,
} from "../lib/cm-ementario";

const router = Router();
const PARAGRAPH_SEED_VERSION = "paragrafos-iniciais-v1";
const initialParagraphs = (paragraphSeed as { registros?: Array<Record<string, unknown>> }).registros || [];

async function ensureCatalog() {
  return db.transaction(async tx => {
    await tx.insert(cmEmentarioTable).values({
      id: CM_EMENTARIO_ID,
      data: emptyCmEmentarioCatalog(),
      revision: 0,
    }).onConflictDoNothing();
    const [row] = await tx.select().from(cmEmentarioTable)
      .where(eq(cmEmentarioTable.id, CM_EMENTARIO_ID)).for("update");
    const catalog = readCmEmentarioCatalog(row.data);
    if (catalog.paragraphSeedVersion === PARAGRAPH_SEED_VERSION) return row;

    const existing = new Set(catalog.customParagraphs.map(item => String(item.id)));
    const seeded = initialParagraphs
      .filter(item => item && typeof item.id === "string" && typeof item.texto === "string")
      .filter(item => !existing.has(`cm-base-${item.id}`))
      .map(item => ({
        id: `cm-base-${item.id}`,
        origemId: item.id,
        rot: String(item.titulo || item.id),
        sec: String(item.categoria || ""),
        txt: item.texto,
        ementa: "",
        titulo: String(item.titulo || ""),
        categoria: String(item.categoria || ""),
        texto: item.texto,
        status: String(item.status || ""),
        ...(Array.isArray(item.variaveis) ? { variaveis: item.variaveis } : {}),
        nivelTema: String(item.nivelTema || ""),
        nivelEspecificidade: String(item.nivelEspecificidade || ""),
        nivelCategoria: String(item.nivelCategoria || ""),
        nivelSubsecao: String(item.nivelSubsecao || ""),
        ...(typeof item.uso === "string" ? { uso: item.uso } : {}),
        ...(typeof item.especificidadesTags === "string" ? { especificidadesTags: item.especificidadesTags } : {}),
        fonte: String(item.fonte || ""),
      }));
    const nextCatalog = {
      ...catalog,
      paragraphSeedVersion: PARAGRAPH_SEED_VERSION,
      customParagraphs: [...catalog.customParagraphs, ...seeded],
    };
    const parsed = validateCmEmentarioCatalog(nextCatalog);
    if ("error" in parsed) throw new Error(`A base inicial de parágrafos é inválida: ${parsed.error}`);
    const [saved] = await tx.update(cmEmentarioTable).set({
      data: parsed.catalog,
      revision: row.revision + 1,
      updatedAt: new Date(),
    }).where(eq(cmEmentarioTable.id, CM_EMENTARIO_ID)).returning();
    return saved;
  });
}

function snapshot(row: typeof cmEmentarioTable.$inferSelect, session: ReturnType<typeof getAppSession>) {
  return {
    catalog: readCmEmentarioCatalog(row.data),
    revision: row.revision,
    canEditCmEmentario: canEditCmEmentario(session),
    updatedAt: row.updatedAt.toISOString(),
  };
}

router.get("/cm-ementario", async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  const row = await ensureCatalog();
  res.json(snapshot(row, getAppSession(req)));
});

router.put("/cm-ementario", async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  const session = getAppSession(req);
  if (!session) { res.status(401).json({ error: "Entre no Gabinete." }); return; }
  if (!canEditCmEmentario(session)) {
    res.status(403).json({ error: "Somente o Desembargador pode editar o Ementário." });
    return;
  }
  if (!Number.isSafeInteger(req.body?.baseRevision) || req.body.baseRevision < 0) {
    res.status(400).json({ error: "Informe a revisão atual do Ementário." });
    return;
  }
  if (Buffer.byteLength(JSON.stringify(req.body), "utf8") > 4 * 1024 * 1024) {
    res.status(413).json({ error: "O catálogo excede 4 MB." });
    return;
  }
  const parsed = validateCmEmentarioCatalog(req.body.catalog);
  if ("error" in parsed) { res.status(400).json({ error: parsed.error }); return; }

  const outcome = await db.transaction(async tx => {
    await tx.insert(cmEmentarioTable).values({
      id: CM_EMENTARIO_ID,
      data: emptyCmEmentarioCatalog(),
      revision: 0,
    }).onConflictDoNothing();
    const [row] = await tx.select().from(cmEmentarioTable)
      .where(eq(cmEmentarioTable.id, CM_EMENTARIO_ID)).for("update");
    if (req.body.baseRevision !== row.revision) {
      return { status: 409, body: { error: "O Ementário foi alterado em outra sessão. Recarregue antes de editar.", ...snapshot(row, session) } };
    }
    const [saved] = await tx.update(cmEmentarioTable).set({
      data: {
        ...parsed.catalog,
        paragraphSeedVersion: readCmEmentarioCatalog(row.data).paragraphSeedVersion || parsed.catalog.paragraphSeedVersion,
      },
      revision: row.revision + 1,
      updatedAt: new Date(),
      updatedBy: session.userId || null,
    }).where(eq(cmEmentarioTable.id, CM_EMENTARIO_ID)).returning();
    return { status: 200, body: snapshot(saved, session) };
  });
  res.status(outcome.status).json(outcome.body);
});

export default router;

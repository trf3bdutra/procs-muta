import { Router } from "express";
import { readFileSync } from "node:fs";
import { getAppSession } from "../lib/app-auth";
import { prepareUrgencyWhatsappDocument } from "../lib/gabcmt-urgency-whatsapp";
import { urgencyWhatsappDestination, urgencyWhatsappTemplateSid } from "../lib/urgency-whatsapp";
import { chooseEncoding, encodeBody, sendEncoded, type Encoded } from "../lib/compress";
import {
  isGabcmtFeatureAsset,
  prepareGabcmtFeatureDocument,
  type GabcmtFeatureDocument,
} from "../lib/gabcmt-feature-modules";
import {
  isGabcmtDataAsset,
  prepareGabcmtDataDocument,
  type GabcmtDataDocument,
} from "../lib/gabcmt-data-modules";
import { createGabcmtDocumentReader } from "../lib/gabcmt-settings-document";
import { prepareFilterDocument } from "../lib/gabcmt-filter-document";
const router = Router();
router.get("/app/urgency-whatsapp.js", (req, res) => {
  if (!getAppSession(req)) { res.status(401).json({ error: "Autenticação necessária." }); return; }
  res.setHeader("Cache-Control", "no-store, private");
  const destination = JSON.stringify({ ...urgencyWhatsappDestination(), templateSid: urgencyWhatsappTemplateSid() }).replace(/</g, "\\u003c");
  res.type("application/javascript").send(`window.CMT_URGENCY_WHATSAPP_DESTINATION=${destination};\n` +
    readFileSync(new URL("./protected/cmt-urgency-whatsapp.js", import.meta.url), "utf8"));
});
router.get("/app/dialogs/:asset", (req, res) => {
  if (!getAppSession(req)) { res.status(401).json({ error: "Autenticação necessária." }); return; }
  const filename = ({ "runtime.js": "cmt-app-dialogs.js", "frame.css": "cmt-app-dialogs.css" } as Record<string, string>)[String(req.params.asset)];
  if (!filename) { res.status(404).json({ error: "Recurso de diálogo não encontrado." }); return; }
  for (const candidate of [
    new URL(`../protected/${filename}`, import.meta.url),
    new URL(`./protected/${filename}`, import.meta.url),
  ]) {
    try {
      res.setHeader("Cache-Control", "no-store, private");
      res.setHeader("X-Robots-Tag", "noindex, nofollow");
      res.type(filename.endsWith(".js") ? "application/javascript" : "text/css").send(readFileSync(candidate));
      return;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
    }
  }
  res.status(503).json({ error: "O recurso não está disponível." });
});
const PROTECTED_APP_ASSETS: Record<string, string> = {
  "session-transfer.js": "cmt-session-transfer.js",
  "daily-workspace.js": "cmt-daily-workspace.js",
  "daily-workspace.css": "cmt-daily-workspace.css",
  "pauta-side-panel.js": "cmt-pauta-side-panel.js",
  "pauta-side-panel.css": "cmt-pauta-side-panel.css",
  "geradores-ementario.js": "cmt-geradores-ementario.js",
};
router.get("/app/:asset", (req, res, next) => {
  const filename = PROTECTED_APP_ASSETS[String(req.params.asset || "")];
  if (!filename) { next(); return; }
  if (!getAppSession(req)) { res.status(401).json({ error: "Autenticação necessária." }); return; }
  for (const candidate of [
    new URL(`../protected/${filename}`, import.meta.url),
    new URL(`./protected/${filename}`, import.meta.url),
  ]) {
    try {
      res.setHeader("Cache-Control", "no-store, private");
      res.setHeader("X-Robots-Tag", "noindex, nofollow");
      res.type(filename.endsWith(".js") ? "application/javascript" : "text/css").send(readFileSync(candidate));
      return;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
    }
  }
  res.status(503).json({ error: "O recurso não está disponível." });
});
for (const extension of ["js", "css"] as const) {
  router.get(`/app/geradores-biblioteca.${extension}`, (_req, res) => {
    const filename = `cmt-geradores-biblioteca.${extension}`;
    const candidates = [
      new URL(`./protected/${filename}`, import.meta.url),
      new URL(`../../../pauta-compartilhada/public/${filename}`, import.meta.url),
    ];
    for (const candidate of candidates) {
      try {
        const source = readFileSync(candidate);
        res.setHeader("Cache-Control", "no-store, private");
        const body = extension === "css"
           ? source.toString("utf8").replace(/#cmt-ger\b/g, ":is(#cmt-ger,.cmt-ementario-view)")
          : source;
        res.type(extension === "js" ? "application/javascript" : "text/css").send(body);
        return;
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
      }
    }
    res.status(503).json({ error: "Os recursos da biblioteca dos Geradores não estão disponíveis." });
  });
}
router.get("/app/marca-trf3.png", (req, res) => {
  if (!getAppSession(req)) { res.status(401).json({ error: "Autenticação necessária." }); return; }
  for (const candidate of [
    new URL("./protected/marca-trf3.png", import.meta.url),
    new URL("../protected/marca-trf3.png", import.meta.url),
  ]) {
    try {
      const source = readFileSync(candidate);
      res.setHeader("Cache-Control", "private, max-age=86400");
      res.setHeader("X-Robots-Tag", "noindex, nofollow");
      res.type("png").send(source);
      return;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
    }
  }
  res.status(503).json({ error: "A marca do TRF3 não está disponível." });
});
/* A versão de redesign fica em rota de avaliação, sem substituir a aplicação operacional. */
router.get("/app/redesign-avaliacao", (req, res) => {
  if (!getAppSession(req)) { res.status(401).json({ error: "Autenticação necessária." }); return; }
  for (const candidate of [
    new URL("../protected/cmt-redesign-avaliacao.html", import.meta.url),
    new URL("./protected/cmt-redesign-avaliacao.html", import.meta.url),
  ]) {
    try {
      const source = readFileSync(candidate);
      res.setHeader("Cache-Control", "no-store, private");
      res.type("html").send(source);
      return;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
    }
  }
  res.status(503).json({ error: "Prévia do redesign indisponível." });
});
// The build copies this source to the API's PRIVATE output, never to web static assets.
let sourceVersion = "";
/* a página só muda na identidade embutida; guarda as versões já comprimidas por sessão e codificação */
const packed = new Map<string, Encoded>();
const readEditorSource = createGabcmtDocumentReader([
  new URL("../protected/gabcmt.html", import.meta.url),
  new URL("./protected/gabcmt.html", import.meta.url),
]);
let featureSourceVersion = "";
let featureSource: GabcmtFeatureDocument | null = null;
/* os dados embutidos saem antes dos módulos: ids distintos, documento mais leve */
let dataSourceVersion = "";
let dataSource: GabcmtDataDocument | null = null;
function getDataSource(document = readEditorSource()): GabcmtDataDocument {
  if (!dataSource || dataSourceVersion !== document.version) {
    dataSourceVersion = document.version;
    dataSource = prepareGabcmtDataDocument(document.html);
  }
  return dataSource;
}
function getFeatureSource(document = readEditorSource()): GabcmtFeatureDocument {
  if (!featureSource || featureSourceVersion !== document.version) {
    featureSourceVersion = document.version;
    featureSource = prepareGabcmtFeatureDocument(prepareUrgencyWhatsappDocument(getDataSource(document).html));
  }
  return featureSource;
}
const panelBlocks = [
  { asset: "rail.js", tag: "script", id: "cmtx-v37-rrail-script" },
  { asset: "calendar.js", tag: "script", id: "cmt-v265-cal" },
  { asset: "calendar.css", tag: "style", id: "cmt-v265-cal-css" },
] as const;
function readPanelBlock(asset: string): string | null {
  const spec = panelBlocks.find((block) => block.asset === asset);
  if (spec) {
    const escapedId = spec.id.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const match = readEditorSource().html.match(
      new RegExp(`<${spec.tag}\\b(?=[^>]*\\bid=["']${escapedId}["'])[^>]*>([\\s\\S]*?)<\\/${spec.tag}>`, "i"),
    );
    return match?.[1] ?? null;
  }
  const panelFile = ({
    "prontuario.css": "cmt-right-panel.css",
    "workspace.js": "cmt-triagem-workspace.js",
  } as Record<string, string>)[asset];
  if (panelFile) {
    for (const candidate of [
      new URL(`./protected/${panelFile}`, import.meta.url),
      new URL(`../protected/${panelFile}`, import.meta.url),
    ]) {
      try {
        return readFileSync(candidate, "utf8");
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
      }
    }
  }
  return null;
}
router.get("/app/painel-lateral/:asset", (req, res) => {
  if (!getAppSession(req)) {
    res.status(401).json({ error: "Autenticação necessária." });
    return;
  }
  const asset = String(req.params.asset || "");
  if (!/^(rail\.js|calendar\.(js|css)|prontuario\.css|workspace\.js)$/.test(asset)) {
    res.status(404).json({ error: "Recurso do painel lateral não encontrado." });
    return;
  }
  const source = readPanelBlock(asset);
  if (source === null) {
    res.status(503).json({ error: "O recurso do painel lateral não está disponível." });
    return;
  }
  res.setHeader("Cache-Control", "no-store, private, max-age=0");
  res.setHeader("X-Robots-Tag", "noindex, nofollow");
  res.type(asset.endsWith(".js") ? "application/javascript" : "text/css").send(source);
});
router.get("/app/gabcmt-dados/:asset", (req, res) => {
  if (!getAppSession(req)) {
    res.status(401).json({ error: "Autenticação necessária." });
    return;
  }
  const asset = String(req.params.asset || "");
  if (!isGabcmtDataAsset(asset)) {
    res.status(404).json({ error: "Dado do GabCMT não encontrado." });
    return;
  }
  const module = getDataSource().assets[asset];
  if (!module) {
    res.status(404).json({ error: "Este dado não existe na versão atual do GabCMT." });
    return;
  }
  const etag = `"${module.etag}"`;
  res.setHeader("ETag", etag);
  res.setHeader("Cache-Control", "private, max-age=31536000, immutable");
  res.setHeader("X-Robots-Tag", "noindex, nofollow");
  const ifNoneMatch = String(req.headers["if-none-match"] || "");
  if (ifNoneMatch === "*" || ifNoneMatch.split(/\s*,\s*/).includes(etag)) {
    res.status(304).end();
    return;
  }
  if (Buffer.isBuffer(module.content)) {
    res.setHeader("Content-Type", module.contentType);
    res.send(module.content);
    return;
  }
  res.setHeader("Content-Type", `${module.contentType}; charset=utf-8`);
  res.send(module.content);
});
router.get("/app/gabcmt-feature-modules/:asset", (req, res) => {
  if (!getAppSession(req)) {
    res.status(401).json({ error: "Autenticação necessária." });
    return;
  }
  const asset = String(req.params.asset || "");
  if (!isGabcmtFeatureAsset(asset)) {
    res.status(404).json({ error: "Módulo do GabCMT não encontrado." });
    return;
  }
  const source = getFeatureSource();
  const module = source.assets[asset];
  if (!module) {
    res.status(404).json({ error: "Este módulo não existe na versão atual do GabCMT." });
    return;
  }
  const etag = `"${module.etag}"`;
  res.setHeader("ETag", etag);
  res.setHeader("Cache-Control", "private, max-age=31536000, immutable");
  res.setHeader("X-Robots-Tag", "noindex, nofollow");
  const ifNoneMatch = String(req.headers["if-none-match"] || "");
  if (ifNoneMatch === "*" || ifNoneMatch.split(/\s*,\s*/).includes(etag)) {
    res.status(304).end();
    return;
  }
  res.setHeader("Content-Type", `${module.contentType}; charset=utf-8`);
  res.send(module.content);
});
router.get(["/app/gabcmt", "/app/filter"], (req, res) => {
  const session = getAppSession(req)!;
  const filterWorkspace = req.path === "/app/filter";
  const document = readEditorSource();
  if (sourceVersion !== document.version) {
    sourceVersion = document.version;
    packed.clear();
  }
  const identity = JSON.stringify({ authenticated: true, userId: session.userId, role: session.role, name: session.name, server: session.server ?? "" }).replace(/</g, "\\u003c");
  const legacy = JSON.stringify({ nome: session.name, servidor: session.server ?? "", papel: session.role === "administracao" || session.role === "editor" ? "admin" : "servidor" }).replace(/</g, "\\u003c");
  const bootstrap = `<base href="/"><script>window.CMT_AUTH_SESSION=${identity};try{sessionStorage.setItem('cmt:sessao',JSON.stringify(${legacy}));}catch(_){}<\/script>`;
  res.setHeader("Cache-Control", "no-store, private, max-age=0");
  res.setHeader("X-Robots-Tag", "noindex, nofollow");
  const encoding = chooseEncoding(req.headers["accept-encoding"]);
  const key = `${filterWorkspace ? "filter" : "gabinete"}|${encoding}|${bootstrap}`;
  let encoded = packed.get(key);
  if (!encoded) {
    const withoutLazyCalendar = getFeatureSource(document).html
      .replace(/<style\b(?=[^>]*\bid=["']cmt-v265-cal-css["'])[^>]*>[\s\S]*?<\/style>/i, "")
      .replace(/<script\b(?=[^>]*\bid=["']cmt-v265-cal["'])[^>]*>[\s\S]*?<\/script>/i, "");
    const page = filterWorkspace ? prepareFilterDocument(withoutLazyCalendar) : withoutLazyCalendar;
    encoded = encodeBody(page.replace(/<head[^>]*>/i, (head) => `${head}${bootstrap}`), encoding);
    if (packed.size >= 48) packed.delete(packed.keys().next().value as string);
    packed.set(key, encoded);
  }
  sendEncoded(res, encoded, "html");
});
export default router;

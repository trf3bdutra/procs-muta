import { Router, type IRouter, type Request, type Response } from "express";
import { pool } from "@workspace/db";
import { getAppSession } from "../lib/app-auth";
import {
  ensureCentralTables,
  safeInlineJson,
  validateCentralEstado,
} from "../lib/central-store";

const router: IRouter = Router();

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

router.get("/central/estado", async (_req: Request, res: Response): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  try {
    await ensureCentralTables();
    const { rows } = await pool.query("SELECT dados, versao FROM central_estado WHERE id = 'gabinete'");
    const row = rows[0];
    res.json(row
      ? { ...(isRecord(row.dados) ? row.dados : {}), _v: Number(row.versao) }
      : { _v: 0 });
  } catch {
    res.status(500).json({ error: "Não foi possível carregar o estado da Competência." });
  }
});

router.put("/central/estado", async (req: Request, res: Response): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  let bodySize = 0;
  try { bodySize = Buffer.byteLength(JSON.stringify(req.body ?? null), "utf8"); } catch { bodySize = 256 * 1024 + 1; }
  if (bodySize > 256 * 1024) {
    res.status(413).json({ error: "O estado da Competência excede 256 KB." });
    return;
  }
  const parsed = validateCentralEstado(req.body);
  if (!parsed.ok) {
    res.status(400).json({ error: parsed.error });
    return;
  }
  const session = getAppSession(req);
  if (!session) {
    res.status(401).json({ error: "Entre no Gabinete para salvar a Competência." });
    return;
  }
  const client = await pool.connect();
  try {
    await ensureCentralTables();
    await client.query("BEGIN");
    await client.query("SELECT pg_advisory_xact_lock(hashtext('cmt-central-estado'))");
    const { rows } = await client.query(
      "SELECT dados, versao FROM central_estado WHERE id = 'gabinete' FOR UPDATE",
    );
    const currentVersion = Number(rows[0]?.versao ?? 0);
    if (parsed.version !== null && parsed.version !== currentVersion) {
      await client.query("ROLLBACK");
      res.status(409).json({
        error: "versão desatualizada",
        estado: { ...(isRecord(rows[0]?.dados) ? rows[0].dados : {}), _v: currentVersion },
      });
      return;
    }
    const nextVersion = currentVersion + 1;
    await client.query(
      `INSERT INTO central_estado (id, dados, versao, atualizado_em, atualizado_por)
       VALUES ('gabinete', $1::jsonb, $2, now(), $3)
       ON CONFLICT (id) DO UPDATE SET dados = EXCLUDED.dados, versao = EXCLUDED.versao,
         atualizado_em = EXCLUDED.atualizado_em, atualizado_por = EXCLUDED.atualizado_por`,
      [JSON.stringify(parsed.dados), nextVersion, session.name],
    );
    await client.query("COMMIT");
    res.json({ _v: nextVersion });
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    req.log.error({ err: error }, "central: falha ao gravar estado");
    res.status(500).json({ error: "Não foi possível salvar o estado da Competência." });
  } finally {
    client.release();
  }
});

export default router;

import { Router, type IRouter, type Request, type Response } from "express";
import { gzipSync } from "node:zlib";
import { pool } from "@workspace/db";
import { canAccessGlobalSettings, getAppSession } from "../lib/app-auth";
import { requireAdministration } from "../middlewares/account-auth";
import { aplicarDataJudAoImportado, FONTES, FONTE_IDS, MAX_LINHAS, calcular, cnj, mensagemCommit, type AcervoAtual, type FonteId, type Matriz, type Previa } from "../lib/acervo-fontes";
import { completeAcervoLines, isAcervoProcessActive, isDetailedPjeReport, mergePjeRawRows, rawPjeLinesByProcess } from "../lib/central-data";
import { digitos, formatarConsulta, linhaDaPauta, mapearDataJud, padronizarImportado } from "../lib/acervo-normalizacao";
import { applyAcervoToPautaState, type AcervoPautaRecord } from "../lib/acervo-pauta-sync";
import { garantirTabelasAcervo } from "../lib/acervo-tables";
import * as D from "../lib/datajud";
import { projetarAcervoIndice } from "../lib/acervo-indice";
import { publishAutomatedPautaChange } from "./pauta";

/** Acervo importado (padrão 1.0) com a importação unificada de planilhas.
 * - POST /acervo/importar devolve a prévia; grava só com `confirmar: true` (recalculada sob trava).
 * - O acervo é fixo: o processo entra uma vez e nunca sai; cada reimportação atualiza campos e situação.
 * - Aplicar exige uma sessão autenticada, salvo a relação do PJe (atalho da Triagem).
 */
const router: IRouter = Router();
let completeCache: { etag: string; json: string; gzip: Buffer } | null = null;

export function garantirTabelas(): Promise<void> {
  return garantirTabelasAcervo();
}

type PautaChange = {
  before: { revision: number; state: Record<string, unknown> };
  after: { revision: number; state: Record<string, unknown> };
};

async function sincronizarPautaComAcervo(client: { query: (...args: any[]) => Promise<any> }, rows: any[]): Promise<PautaChange | null> {
  if (!rows.length) return null;
  const snapshot = await client.query(
    "SELECT state, revision FROM pauta_snapshots WHERE id = 'main' FOR UPDATE",
  );
  if (!snapshot.rows[0] || !snapshot.rows[0].state || typeof snapshot.rows[0].state !== "object") return null;

  const before = {
    revision: Number(snapshot.rows[0].revision),
    state: snapshot.rows[0].state as Record<string, unknown>,
  };
  const records: AcervoPautaRecord[] = rows.map((row) => {
    const operacional = row.operacional && typeof row.operacional === "object" ? row.operacional : {};
    return {
      processo: row.processo,
      linha: linhaDaPauta(row.importado, {}),
      pauta: operacional.pauta && typeof operacional.pauta === "object" ? operacional.pauta : {},
      pautasPorFicha: operacional.pautasPorFicha && typeof operacional.pautasPorFicha === "object"
        ? operacional.pautasPorFicha
        : {},
    };
  });
  const merged = applyAcervoToPautaState(before.state, records);
  if (!merged.changed) return null;

  const after = { revision: before.revision + 1, state: merged.state };
  await client.query(
    "UPDATE pauta_snapshots SET state = $1::jsonb, revision = $2, updated_at = now() WHERE id = 'main'",
    [JSON.stringify(after.state), after.revision],
  );
  return { before, after };
}

const quem = (req: Request) => { const s = getAppSession(req); return s ? `${s.name}${s.server && s.server !== s.name ? ` (${s.server})` : ""}` : ""; };
function configuracoesDesbloqueadas(req: Request): boolean {
  return !!getAppSession(req);
}

async function lerAtuais(client: { query: typeof pool.query } = pool): Promise<Map<string, AcervoAtual>> {
  const { rows } = await client.query("SELECT processo, importado, situacao, historico_situacao FROM acervo");
  return new Map(rows.map((r) => [r.processo as string, {
    processo: r.processo,
    importado: padronizarImportado(r.importado),
    situacao: r.situacao ?? "",
    historicoSituacao: Array.isArray(r.historico_situacao) ? r.historico_situacao : [],
  }]));
}

/* cache do GET /acervo por versão: a versão muda a cada importação aplicada */
let versao = 0;
let cache: { etag: string; json: string; gzip: Buffer } | null = null;
export function invalidarCacheAcervo(): void {
  versao++;
  cache = null;
  completeCache = null;
}

function validarCorpo(body: unknown): { arquivo: string; matriz: Matriz; fonte: FonteId | null; confirmar: boolean; assinatura: string } | string {
  const b = (body ?? {}) as Record<string, unknown>;
  if (!Array.isArray(b.matriz) || !b.matriz.every((r) => Array.isArray(r))) return "Envie a planilha como `matriz` (lista de linhas).";
  if (b.matriz.length > MAX_LINHAS) return `Planilha acima do limite de ${MAX_LINHAS} linhas.`;
  const fonte = typeof b.fonte === "string" && (FONTE_IDS as string[]).includes(b.fonte) ? b.fonte as FonteId : null;
  if (b.fonte && !fonte) return "Fonte desconhecida.";
  return { arquivo: String(b.arquivo || "").slice(0, 200), matriz: b.matriz as Matriz, fonte, confirmar: b.confirmar === true, assinatura: String(b.assinatura || "") };
}

router.post("/acervo/importar", async (req: Request, res: Response): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  const corpo = validarCorpo(req.body);
  if (typeof corpo === "string") { res.status(400).json({ error: corpo }); return; }
  try {
    await garantirTabelas();
    const agora = new Date().toISOString();
    const previo = calcular(corpo.matriz, corpo.arquivo, await lerAtuais(), agora, corpo.fonte);
    if ("erro" in previo) { res.status(422).json({ error: previo.erro, leitura: previo.leitura }); return; }
    if (!corpo.confirmar) { res.json({ aplicada: false, previa: previo.previa, podeAplicar: previo.previa.fonte === "pje" || configuracoesDesbloqueadas(req) }); return; }
    if (previo.previa.fonte !== "pje" && !canAccessGlobalSettings(getAppSession(req)?.role)) {
      res.status(403).json({ error: "Somente a Administração pode aplicar importações de fontes das Configurações Globais." });
      return;
    }
    if (previo.previa.fonte !== "pje" && !configuracoesDesbloqueadas(req)) { res.status(401).json({ error: "Entre no aplicativo para aplicar esta importação.", code: "authentication_required" }); return; }
    if (corpo.assinatura && corpo.assinatura !== previo.previa.assinatura) { res.status(409).json({ error: "O acervo mudou desde a prévia. Confira a nova prévia antes de gravar.", previa: previo.previa }); return; }

    const client = await pool.connect();
    let aplicado: { previa: Previa; fonteId: number; gravados: number; pautaChange: PautaChange | null };
    try {
      await client.query("BEGIN");
      await client.query("SELECT pg_advisory_xact_lock(hashtext('cmt-acervo-pauta-sync'))");
      await client.query("SELECT pg_advisory_xact_lock(hashtext('cmt-acervo-importado'))");
      const antes = await lerAtuais(client);
      const calc = calcular(corpo.matriz, corpo.arquivo, antes, agora, corpo.fonte);
      if ("erro" in calc) throw Object.assign(new Error(calc.erro), { status: 422 });
      const gravarPorProcesso = new Map(calc.gravar.map((registro) => [registro.processo, registro]));
      if (calc.previa.fonte === "pje") {
        const rawLines = rawPjeLinesByProcess(corpo.matriz);
        const replaceComplete = isDetailedPjeReport(corpo.matriz);
        for (const [processo, linhas] of rawLines) {
          const atual = gravarPorProcesso.get(processo) || antes.get(processo);
          if (!atual) continue;
          const merged = mergePjeRawRows(atual.importado.linhas, linhas, replaceComplete);
          gravarPorProcesso.set(processo, {
            ...atual,
            importado: { ...atual.importado, linhas: merged },
          });
        }
      }
      const gravar = [...gravarPorProcesso.values()];
      if (gravar.length) {
        const lote = gravar.map((r) => ({
          processo: r.processo,
          importado: r.importado,
          situacao: r.situacao,
          historico: r.historicoSituacao,
        }));
        await client.query(
          `INSERT INTO acervo (processo, importado, situacao, historico_situacao)
           SELECT x.processo, x.importado, x.situacao, x.historico
           FROM jsonb_to_recordset($1::jsonb) AS x(processo text, importado jsonb, situacao text, historico jsonb)
           ON CONFLICT (processo) DO UPDATE SET
             importado = EXCLUDED.importado,
             situacao = EXCLUDED.situacao,
             historico_situacao = EXCLUDED.historico_situacao,
             atualizado_em = CASE
               WHEN acervo.importado IS DISTINCT FROM EXCLUDED.importado
                 OR acervo.situacao IS DISTINCT FROM EXCLUDED.situacao
                 OR acervo.historico_situacao IS DISTINCT FROM EXCLUDED.historico_situacao
               THEN now() ELSE acervo.atualizado_em END`,
          [JSON.stringify(lote)],
        );
      }
      const pautaRows = gravar.length
        ? await client.query(
          "SELECT processo, importado, operacional FROM acervo WHERE processo = ANY($1::text[])",
          [gravar.map((r) => r.processo)],
        )
        : { rows: [] };
      const pautaChange = await sincronizarPautaComAcervo(client, pautaRows.rows);
      if (calc.indicadores) {
        await client.query(`INSERT INTO indicadores (referencia, dados) VALUES ($1, $2::jsonb)
          ON CONFLICT (referencia) DO UPDATE SET dados = indicadores.dados || EXCLUDED.dados, atualizado_em = now()`, [calc.previa.referencia, JSON.stringify(calc.indicadores)]);
      }
      const p = calc.previa;
      const ins = await client.query(`INSERT INTO acervo_fontes (fonte, arquivo, referencia, importado_por, linhas, processos, novos, atualizados, divergencias, previa)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10::jsonb) RETURNING id`,
      [p.fonte, p.arquivo, p.referencia, quem(req), p.linhas, p.processos, p.novos, p.atualizados, p.divergencias, JSON.stringify(p)]);
      await client.query("COMMIT");
      aplicado = { previa: p, fonteId: ins.rows[0].id as number, gravados: gravar.length, pautaChange };
    } catch (error) { await client.query("ROLLBACK").catch(() => {}); throw error; }
    finally { client.release(); }
    versao++; cache = null; completeCache = null;
    if (aplicado.pautaChange) {
      publishAutomatedPautaChange(aplicado.pautaChange.before, aplicado.pautaChange.after);
    }
    res.json({ aplicada: true, previa: aplicado.previa, fonteId: aplicado.fonteId, gravados: aplicado.gravados, commit: mensagemCommit(aplicado.previa) });
  } catch (error: any) {
    req.log.warn({ err: error?.message }, "acervo: importação recusada");
    const status = [403, 409, 422, 503].includes(error?.status) ? error.status : 500;
    res.status(status).json({ error: status === 500 ? "Não foi possível processar a importação." : error.message, ...(error?.details ? { details: error.details } : {}) });
  }
});

/* aba Fontes: a importação mais recente de cada fonte */
router.get("/acervo/fontes", requireAdministration, async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  try {
    await garantirTabelas();
    const { rows } = await pool.query(`SELECT DISTINCT ON (fonte) id, fonte, arquivo, referencia, importado_em, importado_por, linhas, processos, novos, atualizados, divergencias
      FROM acervo_fontes ORDER BY fonte, importado_em DESC`);
    const porFonte = new Map(rows.map((r) => [r.fonte as string, r]));
    const total = await pool.query("SELECT count(*)::int AS n, count(*) FILTER (WHERE situacao <> 'baixado')::int AS ativos FROM acervo");
    res.json({
      desbloqueado: configuracoesDesbloqueadas(req),
      acervo: { total: total.rows[0]?.n ?? 0, ativos: total.rows[0]?.ativos ?? 0 },
      fontes: FONTE_IDS.map((f) => { const r = porFonte.get(f); return { fonte: f, rotulo: FONTES[f].rotulo, ...(r ? { id: r.id, arquivo: r.arquivo, referencia: r.referencia, importadoEm: new Date(r.importado_em).toISOString(), importadoPor: r.importado_por, linhas: r.linhas, processos: r.processos, novos: r.novos, atualizados: r.atualizados, divergencias: r.divergencias } : {}) }; }),
    });
  } catch { res.status(500).json({ error: "Fontes indisponíveis." }); }
});

router.get("/acervo/fontes/:id/previa", requireAdministration, async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) { res.status(400).json({ error: "Importação inválida." }); return; }
  try {
    await garantirTabelas();
    const { rows } = await pool.query("SELECT previa, importado_em, importado_por FROM acervo_fontes WHERE id = $1", [id]);
    if (!rows[0]) { res.status(404).json({ error: "Importação não encontrada." }); return; }
    res.json({ previa: rows[0].previa, importadoEm: new Date(rows[0].importado_em).toISOString(), importadoPor: rows[0].importado_por });
  } catch { res.status(500).json({ error: "Prévia indisponível." }); }
});

/* leitura do acervo pelos módulos */
router.get("/acervo", async (req, res): Promise<void> => {
  try {
    await garantirTabelas();
    if (req.query.completo === "1") {
      const aggregate = await pool.query("SELECT count(*)::int AS total, max(atualizado_em) AS cursor FROM acervo");
      const cursor = aggregate.rows[0]?.cursor ? new Date(aggregate.rows[0].cursor).toISOString() : null;
      const etag = `"acervo-completo-${Number(aggregate.rows[0]?.total || 0)}-${cursor ? Date.parse(cursor) : 0}"`;
      res.setHeader("Cache-Control", "private, no-cache");
      res.setHeader("ETag", etag);
      res.setHeader("Vary", "Accept-Encoding");
      if (req.header("If-None-Match") === etag) { res.status(304).end(); return; }
      if (completeCache?.etag !== etag) {
        const { rows } = await pool.query("SELECT processo, importado, operacional, situacao FROM acervo ORDER BY processo");
        const registros = rows.map((row) => {
          const imported = row.importado && typeof row.importado === "object" && !Array.isArray(row.importado)
            ? row.importado as Record<string, unknown>
            : {};
          const operational = row.operacional && typeof row.operacional === "object" && !Array.isArray(row.operacional)
            ? row.operacional as Record<string, unknown>
            : {};
          const processo = String(row.processo);
          const linhas = completeAcervoLines(processo, imported, linhaDaPauta(imported, {}));
          return {
            processo,
            ativo: isAcervoProcessActive(row.situacao),
            linha: linhas[0] || { processo },
            linhas,
            operacional: operational,
          };
        });
        const json = JSON.stringify({ atualizadoEm: cursor, cursor, total: registros.length, registros });
        completeCache = { etag, json, gzip: gzipSync(json, { level: 6 }) };
      }
      res.setHeader("ETag", completeCache.etag);
      res.setHeader("Content-Type", "application/json; charset=utf-8");
      if (/\bgzip\b/.test(req.header("Accept-Encoding") || "")) {
        res.setHeader("Content-Encoding", "gzip");
        res.end(completeCache.gzip);
      } else {
        res.end(completeCache.json);
      }
      return;
    }
    if (req.query.campos === "indice") {
      const desde = typeof req.query.desde === "string" && !Number.isNaN(Date.parse(req.query.desde)) ? new Date(req.query.desde).toISOString() : "";
      const resumo = await pool.query(`
        SELECT processo, situacao, atualizado_em,
          COALESCE(importado #>> '{importado,classe}', importado->>'classe', importado->>'classe_judicial', importado->>'Classe') AS classe,
          COALESCE(importado #>> '{importado,assunto}', importado->>'assunto', importado->>'assunto_judicial', importado->>'Assunto_Principal', importado->>'Assunto') AS assunto,
          COALESCE(
            NULLIF(btrim(importado #>> '{importado,secao}'), ''),
            NULLIF(btrim(importado #>> '{importado,secaoCompetente}'), ''),
            NULLIF(btrim(importado->>'secao'), ''),
            NULLIF(btrim(importado->>'secaoCompetente'), ''),
            NULLIF(btrim(importado->>'Seção Competente'), ''),
            NULLIF(btrim(importado->>'Seção competente'), ''),
            NULLIF(btrim(importado->>'Seção'), '')
          ) AS secao,
          COALESCE(importado #>> '{importado,poloAtivo}', importado->>'poloAtivo', importado->>'polo_ativo', importado->>'Polo_Ativo') AS polo_ativo,
          COALESCE(importado #>> '{importado,poloPassivo}', importado->>'poloPassivo', importado->>'polo_passivo', importado->>'Polo_Passivo') AS polo_passivo,
          COALESCE(importado #>> '{importado,etiquetas}', importado->>'etiquetas', importado->>'Etiquetas Operacionais', importado->>'Etiquetas') AS etiquetas,
          COALESCE(importado #>> '{importado,tarefaAtual}', importado->>'tarefaAtual', importado->>'tarefa_atual') AS tarefa,
          COALESCE(importado #>> '{importado,dataDistribuicao}', importado->>'dataDistribuicao', importado->>'data_distribuição', importado->>'Data_Distribuição') AS distribuicao
        FROM acervo
        ${desde ? "WHERE atualizado_em >= $1" : ""}
        ORDER BY processo`,
      desde ? [desde] : []);
      const agregado = await pool.query(`
        SELECT count(*)::int AS total,
          count(*) FILTER (WHERE situacao <> 'baixado')::int AS ativos,
          max(atualizado_em) AS cursor,
          max(atualizado_em) FILTER (WHERE situacao <> 'baixado') AS atualizado
        FROM acervo`);
      const cursor = agregado.rows[0]?.cursor ? new Date(agregado.rows[0].cursor).toISOString() : "";
      const localRevision = `local-${agregado.rows[0]?.ativos || 0}-${agregado.rows[0]?.cursor ? new Date(agregado.rows[0].cursor).getTime() : 0}`;
      const etag = `"acervo-indice-${localRevision}"`;
      res.setHeader("Cache-Control", "private, no-cache");
      res.setHeader("ETag", etag);
      if (!desde && req.header("If-None-Match") === etag) { res.status(304).end(); return; }
      const registros = resumo.rows
        .map(projetarAcervoIndice);
      res.json({ schema: "gabcmt.acervo.indice", versao: 1, commit: localRevision, cursor: cursor || null, total: Number(agregado.rows[0]?.total || 0), registros });
      return;
    }
    const desde = typeof req.query.desde === "string" && !Number.isNaN(Date.parse(req.query.desde)) ? new Date(req.query.desde).toISOString() : "";
    if (desde) {
        const { rows } = await pool.query("SELECT processo, importado, operacional, situacao, atualizado_em FROM acervo WHERE atualizado_em > $1 ORDER BY processo", [desde]);
      res.setHeader("Cache-Control", "no-store");
        res.json({ versao, desde, total: rows.length, registros: rows.map((r) => ({
          ...r.importado,
          processo: r.processo,
          situacao: r.situacao,
          atualizadoEm: new Date(r.atualizado_em).toISOString(),
          operacional: r.operacional || {},
        })) });
      return;
    }
    const aggregate = await pool.query("SELECT count(*)::int AS total, max(atualizado_em) AS cursor FROM acervo");
    const cursor = aggregate.rows[0]?.cursor ? Date.parse(new Date(aggregate.rows[0].cursor).toISOString()) : 0;
    const etag = `"acervo-${Number(aggregate.rows[0]?.total || 0)}-${cursor}"`;
    res.setHeader("ETag", etag); res.setHeader("Cache-Control", "no-cache");
    if (cache?.etag === etag && req.header("If-None-Match") === etag) { res.status(304).end(); return; }
    if (cache?.etag !== etag) {
      const { rows } = await pool.query("SELECT processo, importado, operacional, situacao, atualizado_em FROM acervo ORDER BY processo");
      const json = JSON.stringify({ schema: "gabcmt.acervo.importado", versao: "1.0", revisao: versao, geradoEm: new Date().toISOString(), total: rows.length,
        registros: rows.map((r) => ({
          ...r.importado,
          processo: r.processo,
          situacao: r.situacao,
          atualizadoEm: new Date(r.atualizado_em).toISOString(),
          operacional: r.operacional || {},
        })) });
      cache = { etag, json, gzip: gzipSync(json, { level: 6 }) };
    }
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    if (/\bgzip\b/.test(req.header("Accept-Encoding") || "")) { res.setHeader("Content-Encoding", "gzip"); res.setHeader("Vary", "Accept-Encoding"); res.end(cache!.gzip); }
    else res.end(cache!.json);
  } catch (error: any) {
    req.log.error({ message: error?.message, code: error?.code }, "acervo: falha na leitura");
    res.status(500).json({ error: error?.message || "Acervo indisponível no banco compartilhado." });
  }
});

/* Consulta local primeiro; processos ausentes são buscados no DataJud e incorporados ao acervo local. */
router.post("/acervo/consultar", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  try {
    await garantirTabelas();
    const pedidos = Array.isArray(req.body?.processos) ? req.body.processos.slice(0, 1000) : [];
    const processos: string[] = [...new Set<string>(pedidos.map((p: unknown) => cnj(String(p ?? ""))).filter((p: string) => digitos(p).length === 20))];
    if (!processos.length) { res.json({ commit: `local-${versao}`, registros: [], naoEncontrados: [] }); return; }
    const buscarLocais = () => pool.query(
      "SELECT processo, importado, operacional FROM acervo WHERE processo = ANY($1::text[])",
      [processos],
    );
    let { rows } = await buscarLocais();
    const faltantes = D.processosAusentesDoAcervo(processos, rows.map((row) => row.processo));
    let dataJud: { solicitados: number; consultados: number; retornados: number; novos: number; alterados: number; aviso?: string } | undefined;
    if (faltantes.length) {
      dataJud = { solicitados: faltantes.length, consultados: 0, retornados: 0, novos: 0, alterados: 0 };
      try {
        // Import dinâmico evita ciclo de inicialização: o serviço DataJud usa o gravador do acervo.
        const serviço = await import("../lib/datajud-servico");
        for (let i = 0; i < faltantes.length; i += 500) {
          const lote = faltantes.slice(i, i + 500);
          const resultado = await serviço.consultaAvulsa(lote);
          dataJud.consultados += lote.length;
          dataJud.retornados += resultado.hits.length;
          dataJud.novos += resultado.acervo?.novos || 0;
          dataJud.alterados += resultado.acervo?.alterados || 0;
          if (resultado.acervoErro) throw new Error(resultado.acervoErro);
        }
      } catch (error) {
        dataJud.aviso = error instanceof Error ? error.message : "Falha ao consultar o DataJud.";
        req.log.warn({ err: dataJud.aviso, processos: faltantes.length }, "acervo: consulta complementar ao DataJud falhou");
      }
      // A consulta DataJud pode ter criado ou enriquecido registros; devolva o estado persistido atual.
      ({ rows } = await buscarLocais());
    }
    const importados = new Map<string, Record<string, unknown>>();
    const operacionais = new Map<string, Record<string, unknown>>();
    for (const row of rows) {
      const key = digitos(row.processo);
      importados.set(key, row.importado || {});
      operacionais.set(key, row.operacional || {});
    }
    const consultado = formatarConsulta(processos, importados, operacionais, {}, `local-${versao}`);
    res.json({
      ...consultado,
      ...(dataJud ? { dataJud } : {}),
    });
  } catch (error: any) {
    req.log.error({ message: error?.message, code: error?.code }, "acervo: falha na consulta local");
    res.status(500).json({ error: "Não foi possível consultar o acervo local." });
  }
});

router.get("/acervo/:processo", async (req, res, next): Promise<void> => {
  const processo = cnj(req.params.processo);
  if (!processo) { next(); return; }
  res.setHeader("Cache-Control", "no-store");
  try {
    await garantirTabelas();
    const { rows } = await pool.query("SELECT processo, importado, operacional, situacao, historico_situacao, criado_em, atualizado_em FROM acervo WHERE processo = $1", [processo]);
    if (!rows[0]) { res.status(404).json({ error: "Processo fora do acervo." }); return; }
    const r = rows[0];
    const imported = r.importado && typeof r.importado === "object" && !Array.isArray(r.importado) ? r.importado : {};
    const operational = r.operacional && typeof r.operacional === "object" && !Array.isArray(r.operacional) ? r.operacional : {};
    const linhas = completeAcervoLines(processo, imported, linhaDaPauta(imported, operational));
    res.json({ processo: r.processo, situacao: r.situacao, historicoSituacao: r.historico_situacao, importado: r.importado, operacional: r.operacional, linha: linhas[0] || { processo }, criadoEm: new Date(r.criado_em).toISOString(), atualizadoEm: new Date(r.atualizado_em).toISOString() });
  } catch (error: any) {
    const status = 500;
    res.status(status).json({ error: error?.message || "Acervo indisponível no banco deste app." });
  }
});

/* DataJud complementa processos já cadastrados; nunca cria nem remove registros do Acervo. */
export async function atualizarAcervoComDataJud(hits: unknown[]): Promise<{ novos: number; alterados: number }> {
  if (!Array.isArray(hits) || hits.length > 1000) throw new Error("Lote DataJud inválido ou acima de 1.000 processos.");
  await garantirTabelas();
  const client = await pool.connect();
  let pautaChange: PautaChange | null = null;
  const processosAfetados = new Set<string>();
  try {
    await client.query("BEGIN");
    await client.query("SELECT pg_advisory_xact_lock(hashtext('cmt-acervo-pauta-sync'))");
    await client.query("SELECT pg_advisory_xact_lock(hashtext('cmt-acervo-datajud-local'))");
    for (const hit of hits as any[]) {
      const source = hit?._source ?? hit ?? {};
      const processo = cnj(String(source.numeroProcesso ?? hit?._id ?? hit?.id ?? ""));
      if (digitos(processo).length !== 20) continue;
      const found = await client.query("SELECT importado FROM acervo WHERE processo = $1 FOR UPDATE", [processo]);
      if (!found.rows[0]) continue;
      const fields = mapearDataJud(hit);
      if (!Object.keys(fields).length) continue;
      const current = found.rows[0].importado && typeof found.rows[0].importado === "object" ? found.rows[0].importado : {};
      const { importado: mesclado, changed } = aplicarDataJudAoImportado(
        current as Record<string, unknown>,
        fields,
        new Date().toISOString(),
      );
      if (!changed) continue;
      const importado = { ...mesclado, processo };
      await client.query(
        "UPDATE acervo SET importado = $2::jsonb, atualizado_em = now() WHERE processo = $1",
        [processo, JSON.stringify(importado)],
      );
      processosAfetados.add(processo);
    }
    if (processosAfetados.size) {
      const changedRows = await client.query(
        "SELECT processo, importado, operacional FROM acervo WHERE processo = ANY($1::text[])",
        [[...processosAfetados]],
      );
      pautaChange = await sincronizarPautaComAcervo(client, changedRows.rows);
    }
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
  if (pautaChange) publishAutomatedPautaChange(pautaChange.before, pautaChange.after);
  if (processosAfetados.size) invalidarCacheAcervo();
  return { novos: 0, alterados: processosAfetados.size };
}

router.get("/indicadores", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  try {
    await garantirTabelas();
    const ref = typeof req.query.referencia === "string" && /^\d{4}-\d{2}-\d{2}$/.test(req.query.referencia) ? req.query.referencia : "";
    const { rows } = ref
      ? await pool.query("SELECT referencia, dados, atualizado_em FROM indicadores WHERE referencia = $1", [ref])
      : await pool.query("SELECT referencia, dados, atualizado_em FROM indicadores ORDER BY referencia DESC LIMIT 24");
    res.json({ indicadores: rows.map((r) => ({ referencia: r.referencia, dados: r.dados, atualizadoEm: new Date(r.atualizado_em).toISOString() })) });
  } catch { res.status(500).json({ error: "Indicadores indisponíveis." }); }
});

export default router;

import { Router, type IRouter } from "express";
import {
  ChangeAccountMembershipBody, CreateServerAccountBody, CreateServerAccountResponse, GetMyAccountResponse,
  GetServerProfileIdentitiesResponse, ListAccountMembershipsResponse, ChangeAccountMembershipResponse,
  ExchangeCmAccessLinkBody, ExchangeCmAccessLinkResponse, GetCmAccessLinkResponse, GetCmLinkSessionResponse,
} from "@workspace/api-zod";
import { accountView, changeMembership, createServerAccount, getOrRegisterAccount, listMemberships, listServerProfileIdentities } from "../lib/account-memberships";
import { approvedSession, requireAdministration, resolveVerifiedIdentity, sendAccountError } from "../middlewares/account-auth";
import { getAppSession } from "../lib/app-auth";
import { revokeLiveAccount } from "../lib/live-access";
import { listLoginServers, loginLocal, logoutLocal } from "../lib/local-auth";
import { createHash } from "node:crypto";
import {
  clearCmSessionCookie,
  createCmAccessLinkToken,
  createCmSessionToken,
  getCmAccessSecret,
  readCmAccessSession,
  setCmSessionCookie,
  verifyCmAccessLinkToken,
} from "../lib/cm-access";
const router: IRouter = Router();
router.use("/auth", (_req, res, next) => {
  res.setHeader("Cache-Control", "no-store, max-age=0");
  // Explicitly invalidate the legacy shared-password cookie; it is never read for access.
  res.append("Set-Cookie", "cmt_app_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0");
  next();
});
const attempts = new Map<string, { count: number; until: number }>();
router.get("/auth/login-options", async (_req, res) => {
  try { res.json({ servers: await listLoginServers() }); }
  catch (error) { sendAccountError(error, res); }
});
router.post("/auth/login", async (req, res) => {
  const body = req.body && typeof req.body === "object" && !Array.isArray(req.body) ? req.body : {};
  const selectorValue = body.role === "equipe" ? body.server : "";
  const ip = `${req.ip || req.socket.remoteAddress || "unknown"}:${createHash("sha256").update(String(selectorValue ?? "").trim().toLocaleLowerCase("pt-BR")).digest("hex")}`;
  const now = Date.now();
  if (attempts.size > 10_000) for (const [key, value] of attempts) if (value.until <= now) attempts.delete(key);
  const previous = attempts.get(ip);
  const current = previous && previous.until > now ? previous : { count: 0, until: now + 15 * 60_000 };
  attempts.set(ip, current);
  if (++current.count > 40) { res.status(429).json({ error: "Muitas tentativas de acesso. Aguarde e tente novamente." }); return; }
  const { password, role, server } = body;
  const keys = Object.keys(body);
  const isTeam = role === "equipe" && typeof server === "string" && server.length > 0 && server.length <= 120 &&
    typeof password === "string" && password.length <= 1024 && keys.every((key) => ["role", "server", "password"].includes(key));
  if (!isTeam || typeof password !== "string" || password.length > 1024) {
    res.status(400).json({ error: "Selecione seu servidor e digite a senha." }); return;
  }
  try {
    /* A própria conta ativa vinculada no banco valida o servidor no login. */
    const result = await loginLocal(req, res, { server: server as string }, password);
    res.json({ authenticated: true, account: { ...accountView(result.account), role: result.accessRole } });
  } catch (error) { sendAccountError(error, res); }
});
router.post("/auth/logout", async (req, res) => {
  try {
    const userId = await logoutLocal(req, res);
    clearCmSessionCookie(req, res);
    if (userId) revokeLiveAccount(userId);
    res.json({ authenticated: false });
  } catch (error) { sendAccountError(error, res); }
});
router.get("/auth/cm-access-link", requireAdministration, (req, res): void => {
  try {
    const token = createCmAccessLinkToken(getCmAccessSecret());
    res.json(GetCmAccessLinkResponse.parse({ path: `/cm#access=${token}`, revocable: true }));
  } catch {
    res.status(503).json({ error: "O link secreto do CM ainda não foi configurado." });
  }
});
const cmExchangeAttempts = new Map<string, { count: number; until: number }>();
router.post("/auth/cm-access/exchange", (req, res): void => {
  const parsed = ExchangeCmAccessLinkBody.safeParse(req.body);
  const rawBody = req.body && typeof req.body === "object" && !Array.isArray(req.body) ? req.body : {};
  if (!parsed.success || Object.keys(rawBody).some((key) => key !== "token")) {
    res.status(400).json({ error: "Link de acesso inválido." });
    return;
  }
  const ip = req.ip || req.socket.remoteAddress || "unknown";
  const now = Date.now();
  if (cmExchangeAttempts.size > 10_000) {
    for (const [key, value] of cmExchangeAttempts) if (value.until <= now) cmExchangeAttempts.delete(key);
  }
  const previous = cmExchangeAttempts.get(ip);
  const current = previous && previous.until > now ? previous : { count: 0, until: now + 15 * 60_000 };
  cmExchangeAttempts.set(ip, current);
  if (++current.count > 40) {
    res.status(429).json({ error: "Muitas tentativas. Aguarde antes de tentar novamente." });
    return;
  }
  try {
    const secret = getCmAccessSecret();
    if (!verifyCmAccessLinkToken(parsed.data.token, secret)) {
      res.status(401).json({ error: "Este link do CM é inválido ou foi revogado." });
      return;
    }
    setCmSessionCookie(req, res, createCmSessionToken(secret));
    res.json(ExchangeCmAccessLinkResponse.parse({ authenticated: true, persistent: true }));
  } catch {
    res.status(503).json({ error: "O acesso secreto do CM ainda não foi configurado." });
  }
});
router.get("/auth/cm-session", (req, res): void => {
  const session = readCmAccessSession(req);
  if (!session) {
    res.status(401).json({ authenticated: false });
    return;
  }
  res.json(GetCmLinkSessionResponse.parse({
    authenticated: true, userId: session.userId, role: session.role, name: session.name,
    server: session.server,
  }));
});
router.get("/auth/account", async (req, res) => {
  try { res.json(GetMyAccountResponse.parse(accountView(await getOrRegisterAccount(await resolveVerifiedIdentity(req))))); }
  catch (error) { sendAccountError(error, res); }
});
router.get("/auth/session", async (req, res) => {
  try {
    const session = await approvedSession(req);
    res.json({ authenticated: true, userId: session.userId, role: session.role, name: session.name, ...(session.server ? { server: session.server } : {}) });
  } catch (error) { sendAccountError(error, res); }
});
router.get("/auth/server-identities", async (req, res): Promise<void> => {
  try {
    await approvedSession(req);
    res.json(GetServerProfileIdentitiesResponse.parse({ identities: await listServerProfileIdentities() }));
  } catch (error) { sendAccountError(error, res); }
});
router.get("/auth/memberships", requireAdministration, async (_req, res) => {
  res.json(ListAccountMembershipsResponse.parse(await listMemberships()));
});
router.post("/auth/memberships", requireAdministration, async (req, res): Promise<void> => {
  const parsed = CreateServerAccountBody.safeParse(req.body);
  if (!parsed.success || Object.keys(req.body ?? {}).some((key) => !["email", "server"].includes(key))) {
    res.status(400).json({ error: "Informe o e-mail institucional e o servidor." }); return;
  }
  try {
    const account = await createServerAccount(getAppSession(req)!.userId!, parsed.data.email, parsed.data.server);
    revokeLiveAccount(account.userId);
    res.json(CreateServerAccountResponse.parse(account));
  } catch (error) { sendAccountError(error, res); }
});
router.patch("/auth/memberships/:userId", requireAdministration, async (req, res) => {
  const parsed = ChangeAccountMembershipBody.safeParse(req.body);
  if (!parsed.success || Object.keys(req.body ?? {}).some((key) => !["status", "role", "server", "adminAccess"].includes(key))) {
    res.status(400).json({ error: "Confira a situação, o perfil e o servidor da conta." }); return;
  }
  try {
    const targetId = String(req.params.userId);
    const updated = await changeMembership(getAppSession(req)!.userId!, targetId, parsed.data);
    revokeLiveAccount(targetId);
    res.json(ChangeAccountMembershipResponse.parse(updated));
  }
  catch (error) { sendAccountError(error, res); }
});
export default router;

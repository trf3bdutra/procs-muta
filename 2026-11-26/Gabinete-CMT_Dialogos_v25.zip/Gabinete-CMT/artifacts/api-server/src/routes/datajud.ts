import { timingSafeEqual } from "node:crypto";
import { Router, type IRouter, type Request, type Response } from "express";
import { getAppSession } from "../lib/app-auth";
import { sendCompressed } from "../lib/compress";
import * as S from "../lib/datajud-servico";
import { ConsultDatajudTriageProcessBody, ConsultDatajudTriageProcessResponse } from "@workspace/api-zod";
import { consultarDatajudTriageProcess } from "../lib/datajud-triagem";
import { conectar } from "../lib/datajud-ao-vivo";
import { requireAdministration } from "../middlewares/account-auth";

/** DataJud (CNJ) para a Central de Comando e para o app.
 * - Linha de base, histórico, eventos e envios ficam no PostgreSQL e valem para todo o gabinete.
 * - A sincronização roda no servidor (botão da Central, agenda interna ou gatilho externo em /datajud/cron).
 * - Montado antes de `padrao.ts`, que mantém a rota antiga `POST /datajud/:tribunal`.
 */
const router: IRouter = Router();
const quem = (req: Request) => { const s = getAppSession(req); return s ? s.name : ""; };
function falha(req: Request, res: Response, e: unknown, contexto: string) {
  const status = e instanceof S.DataJudErro ? e.status : 500;
  if (status >= 500) req.log.error({ err: e instanceof Error ? e.message : String(e) }, `datajud: ${contexto}`);
  res.status(status).json({ ok: false, error: e instanceof Error && (e instanceof S.DataJudErro || status < 500) ? e.message : `Não foi possível ${contexto}.` });
}
router.use("/datajud", (_req, res, next) => { res.setHeader("Cache-Control", "no-store"); next(); });

/* Consulta exclusiva da bancada: leitura DataJud sem cache no banco ou alteração do Acervo. */
router.post("/datajud/triagem/consultar", async (req, res): Promise<void> => {
  const parsed = ConsultDatajudTriageProcessBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ ok: false, error: "Informe o número CNJ com 20 dígitos." });
    return;
  }
  try {
    const result = await consultarDatajudTriageProcess(parsed.data.numero, S.consultarCNJ);
    res.json(ConsultDatajudTriageProcessResponse.parse(result));
  } catch (e) {
    falha(req, res, e, "consultar o processo no DataJud");
  }
});

/* consulta avulsa (compatível com o proxy local): { numeros, alias? } → { hits } */
router.post("/datajud/consulta", async (req, res): Promise<void> => {
  try {
    const b = req.body ?? {};
    const chave = typeof b.chave === "string" && /^[A-Za-z0-9+/=_-]{20,200}$/.test(b.chave) ? b.chave : "";
    res.json(await S.consultaAvulsa(b.numeros, typeof b.alias === "string" && b.alias ? b.alias : S.ALIAS, chave));
  } catch (e) { falha(req, res, e, "consultar o DataJud"); }
});

router.get("/datajud/estado", async (req, res): Promise<void> => {
  const desde = Number(req.query.desde);
  try { sendCompressed(req, res, JSON.stringify(await S.estadoParaCentral(Number.isFinite(desde) && desde > 0 ? desde : undefined)), "json"); }
  catch (e) { falha(req, res, e, "carregar a linha de base do DataJud"); }
});

router.get("/datajud/status", async (req, res): Promise<void> => {
  try { res.json(await S.status()); } catch (e) { falha(req, res, e, "ler a situação do DataJud"); }
});

/* avisos ao vivo (server-sent events): um resumo a cada sincronização que encontrar mudança */
router.get("/datajud/eventos", (req, res) => { conectar(req, res); });

/* inicia em segundo plano; a Central acompanha por /datajud/status */
router.post("/datajud/sincronizar", async (req, res): Promise<void> => {
  if (S.estado.rodando) { res.status(409).json({ ok: false, error: "Já há uma sincronização em andamento.", status: await S.status().catch(() => null) }); return; }
  const numeros = Array.isArray(req.body?.numeros) ? req.body.numeros.map(String).slice(0, 20000) : undefined;
  const autor = quem(req);
  S.sincronizar({ motivo: numeros?.length ? "manual (lista)" : req.body?.completa ? "manual (completa)" : "manual", autor, numeros, completa: !!req.body?.completa })
    .catch((e) => req.log.warn({ err: e instanceof Error ? e.message : String(e) }, "datajud: sincronização manual falhou"));
  await new Promise((r) => setTimeout(r, 50));
  res.status(202).json({ ok: true, iniciada: true });
});
router.post("/datajud/interromper", (_req, res) => { if (S.estado.rodando) S.estado.parar = true; res.json({ ok: true, rodando: S.estado.rodando }); });

router.patch("/datajud/visto", async (req, res): Promise<void> => {
  try {
    const nums = Array.isArray(req.body?.numeros) ? req.body.numeros.map(String) : [];
    res.json({ ok: true, alterados: await S.marcarVisto(nums, req.body?.visto !== false) });
  } catch (e) { falha(req, res, e, "marcar como visto"); }
});

/* notificações */
router.get("/datajud/notificacoes", async (req, res): Promise<void> => {
  try { sendCompressed(req, res, JSON.stringify(await S.painelNotificacoes()), "json"); }
  catch (e) { falha(req, res, e, "carregar as notificações"); }
});
router.put("/datajud/notificacoes/config", requireAdministration, async (req, res): Promise<void> => {
  try {
    const v = req.body?._v;
    const r = await S.gravarConfig(req.body?.config ?? req.body, v == null ? null : Number(v), quem(req));
    res.json({ ok: true, config: r.dados, versao: r.versao });
  } catch (e) { falha(req, res, e, "gravar a configuração das notificações"); }
});
router.post("/datajud/notificacoes/resumo", async (req, res): Promise<void> => {
  const tipo = req.body?.tipo === "semanal" ? "semanal" : "diaria";
  try {
    const r = await S.resumo(tipo, true);
    if (!r) { res.status(409).json({ ok: false, error: "Outro resumo está sendo gerado agora; tente de novo em instantes." }); return; }
    res.json({ ok: true, ...r });
  } catch (e) { falha(req, res, e, "gerar o resumo"); }
});
router.post("/datajud/notificacoes/enviar", async (req, res): Promise<void> => {
  try {
    if (!S.canal()) { res.status(503).json({ ok: false, error: "Nenhum canal de envio configurado no servidor (DATAJUD_AGENTMAIL_INBOX ou NOTIFY_WEBHOOK). Use “Abrir no e-mail”." }); return; }
    const ids = Array.isArray(req.body?.ids) ? req.body.ids.map(Number).filter(Number.isInteger) : undefined;
    res.json({ ok: true, ...(await S.enviarPendentes(ids)) });
  } catch (e) { falha(req, res, e, "enviar as notificações"); }
});
router.post("/datajud/notificacoes/:id/enviado", async (req, res): Promise<void> => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) { res.status(400).json({ ok: false, error: "Envio inválido." }); return; }
  try { await S.marcarEnviado(id, quem(req)); res.json({ ok: true }); } catch (e) { falha(req, res, e, "marcar o envio"); }
});
router.delete("/datajud/notificacoes/enviados", async (req, res): Promise<void> => {
  try { await S.limparEnviados(); res.json({ ok: true }); } catch (e) { falha(req, res, e, "limpar os envios"); }
});
router.post("/datajud/notificacoes/teste", async (req, res): Promise<void> => {
  const email = String(req.body?.email || "").trim().toLowerCase();
  if (!/^[^@\s<>]+@[^@\s<>]+\.[^@\s<>]+$/.test(email)) { res.status(400).json({ ok: false, error: "Informe um e-mail válido." }); return; }
  try {
    const via = await S.entregar({ para: [{ nome: quem(req), email }], assunto: "[GabCMT · DataJud] Mensagem de teste",
      texto: `Teste de entrega das notificações do DataJud, pedido por ${quem(req) || "um usuário do gabinete"} em ${S.fmt(Date.now())}.` });
    res.json({ ok: true, via });
  } catch (e) { falha(req, res, e, "enviar a mensagem de teste"); }
});
router.get("/datajud/pautados", async (req, res): Promise<void> => {
  try { res.json({ ok: true, pautados: await S.pautados() }); } catch (e) { falha(req, res, e, "ler a pauta"); }
});

/* envio avulso (compatível com a Central aberta sozinha e com o proxy local) */
router.post("/notificar", async (req, res): Promise<void> => {
  const b = req.body ?? {};
  const para = (Array.isArray(b.para) ? b.para : []).filter((x: any) => /^[^@\s<>]+@[^@\s<>]+\.[^@\s<>]+$/.test(String(x?.email || ""))).slice(0, 50)
    .map((x: any) => ({ nome: String(x.nome || "").slice(0, 120), email: String(x.email).trim() }));
  if (!para.length || !b.assunto || !b.texto) { res.status(400).json({ ok: false, error: 'Informe "para", "assunto" e "texto".' }); return; }
  if (!S.canal()) { res.json({ ok: true, encaminhado: false, aviso: "Nenhum canal de envio configurado no servidor." }); return; }
  try {
    await S.entregar({ para, assunto: String(b.assunto).slice(0, 300), texto: String(b.texto).slice(0, 200_000), html: b.html ? String(b.html).slice(0, 400_000) : undefined });
    res.json({ ok: true, encaminhado: true });
  } catch (e) { falha(req, res, e, "encaminhar a notificação"); }
});

export default router;

/* Gatilho externo (Replit Scheduled Deployment, cron do servidor etc.), fora do login: exige DATAJUD_CRON_TOKEN.
   Executa o que estiver vencido: sincronização automática e resumos. */
export const datajudCronRouter: IRouter = Router();
datajudCronRouter.post("/datajud/cron", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  const token = String(process.env.DATAJUD_CRON_TOKEN ?? "").trim();
  const dado = String(req.get("x-cron-token") ?? req.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "");
  const ok = token.length >= 16 && dado.length === token.length && timingSafeEqual(Buffer.from(dado), Buffer.from(token));
  if (!ok) { res.status(401).json({ ok: false, error: "Token inválido." }); return; }
  try { res.json({ ok: true, ...(await S.tick("cron")) }); } catch (e) { falha(req, res, e, "executar a agenda do DataJud"); }
});

import { Router, type IRouter, type Response } from "express";
import { createHash, timingSafeEqual } from "node:crypto";
import { eq, sql } from "drizzle-orm";
import type { ReplitConnectors as ReplitConnectorsClient } from "@replit/connectors-sdk";
import {
  GetPautaResponse,
  GetPautaPresenceResponse,
  GetGabnetGameResponse,
  MoveGabnetPlayerBody,
  MoveGabnetPlayerResponse,
  SetGabnetInventoryBody,
  SetGabnetInventoryResponse,
  GetGabnetWorldResponse,
  SetGabnetWorldPlayerBody,
  SetGabnetWorldPlayerResponse,
  SetGabnetWorldSettingsBody,
  SetGabnetWorldSettingsResponse,
  SetGabnetWorldAvatarBody,
  SetGabnetWorldAvatarResponse,
  SavePautaBody,
  SavePautaResponse,
  UpdatePautaPresenceBody,
  UpdatePautaPresenceResponse,
  WatchPautaQueryParams,
} from "@workspace/api-zod";
import { db, pautaSnapshotsTable } from "@workspace/db";
import seedState from "../data/pauta-seed.json";
import { assessoriaNames, LIBRARY_KEY } from "../lib/generator-library";
import {
  mergePautaStates,
  pautaStateEqual,
  protectSharedGabnetState,
} from "./pauta-merge";
import {
  normalizePresenceClient,
  normalizePresenceText,
  summarizePautaPresence,
  type PautaPresenceConnection,
  type PautaPresenceSummary,
} from "../lib/pauta-presence";
import {
  createSettingsSessionToken,
  readCookie,
  SETTINGS_SESSION_COOKIE,
  verifySettingsSessionToken,
} from "../lib/pauta-settings-session";
import {
  canDeleteProcessCards,
  canAccessGlobalSettings,
  getAppSession,
  removesProcessCards,
} from "../lib/app-auth";
import { hasAdminOnlyPautaSettingsChanges } from "../lib/pauta-admin-settings";
import { requireAdministration } from "../middlewares/account-auth";
import { registerLiveAccess, writeLive } from "../lib/live-access";
import {
  applyGabnetAction,
  gabnetLocalDate,
  gabnetMapFromState,
  gabnetMemberId,
  normalizeGabnetGame,
  type GabnetDirection,
} from "../lib/pauta-gabnet";
import {
  isJsonRecord,
  normalizeGabnetAvatar,
  normalizeGabnetPlayerState,
  normalizeGabnetWorld,
} from "../lib/pauta-gabnet-world";
import { sendCompressed } from "../lib/compress";
import { forgetTeamMembers } from "../lib/team-roster-db";
import { collectPautaAcervoPatches } from "../lib/acervo-pauta-sync";
import { applyAcervoToPautaState, type AcervoPautaRecord } from "../lib/acervo-pauta-sync";
import { garantirTabelasAcervo } from "../lib/acervo-tables";
import { linhaDaPauta } from "../lib/acervo-normalizacao";
import { triagemRows } from "../lib/acervo-triagem-sync";
import {
  buildPautaGoogleSheetTabs,
  quoteGoogleSheetRange,
} from "../lib/pauta-google-sheets";

const sharedId = "main";
const googleSheetsConfigId = "pauta-google-sheets";
const googleSheetsLayoutVersion = 2;
let googleSheets: ReplitConnectorsClient | undefined;
type GoogleSheetsConfig = {
  spreadsheetId?: string;
  spreadsheetUrl?: string;
  layoutVersion?: number;
  lastSyncAt?: string;
  lastSyncedRevision?: number;
  processCount?: number;
  sessionCount?: number;
  error?: string;
};
type GoogleSheetsSyncStatus = {
  enabled: boolean;
  autoSync: true;
  spreadsheetId: string | null;
  spreadsheetUrl: string | null;
  lastSyncAt: string | null;
  lastSyncedRevision: number | null;
  processCount: number;
  sessionCount: number;
  error: string | null;
};
const googleSheetsTimers = new WeakMap<object, ReturnType<typeof setTimeout>>();
const googleSheetsRuns = new WeakMap<object, Promise<GoogleSheetsSyncStatus>>();
const listeners = new Set<Response>();
const settingsUnlockAttempts = new Map<string, { count: number; resetAt: number }>();
const settingsUnlockWindowMs = 60_000;
const settingsUnlockMaxAttempts = 5;
const presence = new Map<Response, PautaPresenceConnection>();
let presenceTimer: ReturnType<typeof setTimeout> | null = null;

type PautaSnapshot = {
  revision: number;
  state: Record<string, unknown>;
};

function googleSheetsConfig(value: unknown): GoogleSheetsConfig {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  return value as GoogleSheetsConfig;
}

async function readGoogleSheetsConfig(database: typeof db): Promise<GoogleSheetsConfig> {
  const [row] = await database
    .select({ state: pautaSnapshotsTable.state })
    .from(pautaSnapshotsTable)
    .where(eq(pautaSnapshotsTable.id, googleSheetsConfigId));
  return googleSheetsConfig(row?.state);
}

async function writeGoogleSheetsConfig(
  database: typeof db,
  config: GoogleSheetsConfig,
): Promise<void> {
  await database
    .insert(pautaSnapshotsTable)
    .values({ id: googleSheetsConfigId, revision: 1, state: config })
    .onConflictDoUpdate({
      target: pautaSnapshotsTable.id,
      set: { revision: 1, state: config, updatedAt: new Date() },
    });
}

function googleSheetsStatus(config: GoogleSheetsConfig): GoogleSheetsSyncStatus {
  return {
    enabled: Boolean(config.spreadsheetId),
    autoSync: true,
    spreadsheetId: config.spreadsheetId || null,
    spreadsheetUrl: config.spreadsheetUrl || null,
    lastSyncAt: config.lastSyncAt || null,
    lastSyncedRevision: Number.isInteger(config.lastSyncedRevision)
      ? config.lastSyncedRevision!
      : null,
    processCount: Number(config.processCount) || 0,
    sessionCount: Number(config.sessionCount) || 0,
    error: config.error || null,
  };
}

async function googleSheetsRequest<T = Record<string, unknown>>(
  path: string,
  method = "GET",
  body?: unknown,
): Promise<T> {
  if (!googleSheets) {
    const { ReplitConnectors } = await import("@replit/connectors-sdk");
    googleSheets = new ReplitConnectors();
  }
  const response = await googleSheets.proxy("google-sheet", path, { method, body });
  const raw = await response.text();
  let payload: unknown = {};
  try {
    payload = raw ? JSON.parse(raw) : {};
  } catch {
    payload = {};
  }
  if (!response.ok) {
    const apiError =
      payload && typeof payload === "object" && "error" in payload
        ? (payload as { error?: { message?: string } }).error?.message
        : undefined;
    throw new Error(
      `Google Sheets respondeu HTTP ${response.status}${apiError ? `: ${apiError}` : ""}`,
    );
  }
  return payload as T;
}

function workbookTitle(): string {
  return `Controle de Pauta — Gabinete CMT${process.env.NODE_ENV === "production" ? "" : " (Desenvolvimento)"}`;
}

async function syncPautaGoogleSheetsOnce(
  database: typeof db,
  snapshot?: PautaSnapshot,
): Promise<GoogleSheetsSyncStatus> {
  const current = snapshot ?? await ensureSnapshot(database);
  let config = await readGoogleSheetsConfig(database);

  try {
    if (
      config.spreadsheetId &&
      config.layoutVersion === googleSheetsLayoutVersion &&
      config.lastSyncedRevision === current.revision &&
      config.lastSyncAt &&
      !config.error
    ) {
      return googleSheetsStatus(config);
    }

    if (!config.spreadsheetId) {
      const created = await googleSheetsRequest<{
        spreadsheetId?: string;
        spreadsheetUrl?: string;
      }>("/v4/spreadsheets", "POST", {
        properties: { title: workbookTitle() },
        sheets: [{ properties: { title: "Resumo", index: 0, gridProperties: { frozenRowCount: 4 } } }],
      });
      if (!created.spreadsheetId) {
        throw new Error("A API não retornou o identificador da planilha criada.");
      }
      config = {
        spreadsheetId: created.spreadsheetId,
        spreadsheetUrl:
          created.spreadsheetUrl ||
          `https://docs.google.com/spreadsheets/d/${created.spreadsheetId}/edit`,
      };
      await writeGoogleSheetsConfig(database, config);
    }

    const spreadsheetId = config.spreadsheetId;
    if (!spreadsheetId) throw new Error("A planilha não possui identificador.");
    const id = encodeURIComponent(spreadsheetId);
    const fields = encodeURIComponent("spreadsheetUrl,sheets.properties(sheetId,title)");
    let metadata = await googleSheetsRequest<{
      spreadsheetUrl?: string;
      sheets?: Array<{ properties?: { sheetId?: number; title?: string } }>;
    }>(`/v4/spreadsheets/${id}?fields=${fields}`);
    const tabs = buildPautaGoogleSheetTabs(current.state, new Date().toISOString());
    const existingTitles = new Set(
      (metadata.sheets ?? [])
        .map((sheet) => sheet.properties?.title)
        .filter((title): title is string => Boolean(title)),
    );
    const missingTabs = tabs.filter((tab) => !existingTitles.has(tab.title));
    if (missingTabs.length) {
      await googleSheetsRequest(`/v4/spreadsheets/${id}:batchUpdate`, "POST", {
        requests: missingTabs.map((tab) => ({
          addSheet: {
            properties: {
              title: tab.title,
              gridProperties: {
                frozenRowCount: tab.key === "summary" ? 4 : tab.key === "sessions" ? 1 : 3,
              },
            },
          },
        })),
      });
      metadata = await googleSheetsRequest<{
        spreadsheetUrl?: string;
        sheets?: Array<{ properties?: { sheetId?: number; title?: string } }>;
      }>(
        `/v4/spreadsheets/${id}?fields=${fields}`,
      );
    }

    await googleSheetsRequest(`/v4/spreadsheets/${id}/values:batchClear`, "POST", {
      ranges: tabs.map((tab) => `${quoteGoogleSheetRange(tab.title)}!A:ZZ`),
    });
    await googleSheetsRequest(`/v4/spreadsheets/${id}/values:batchUpdate`, "POST", {
      valueInputOption: "RAW",
      data: tabs.map((tab) => ({
        range: `${quoteGoogleSheetRange(tab.title)}!A1`,
        majorDimension: "ROWS",
        values: tab.values,
      })),
    });

    const processCount = tabs
      .filter((tab) => tab.key.startsWith("session:") || tab.key === "unassigned")
      .reduce((sum, tab) => sum + Math.max(0, tab.values.length - 3), 0);
    config = {
      ...config,
      layoutVersion: googleSheetsLayoutVersion,
      spreadsheetUrl:
        metadata.spreadsheetUrl ||
        config.spreadsheetUrl ||
        `https://docs.google.com/spreadsheets/d/${config.spreadsheetId}/edit`,
      lastSyncAt: new Date().toISOString(),
      lastSyncedRevision: current.revision,
      processCount,
      sessionCount: tabs.filter((tab) => tab.key.startsWith("session:")).length,
      error: undefined,
    };
    await writeGoogleSheetsConfig(database, config);
    return googleSheetsStatus(config);
  } catch (error) {
    config = {
      ...config,
      error: error instanceof Error ? error.message.slice(0, 300) : "Falha na sincronização.",
    };
    await writeGoogleSheetsConfig(database, config);
    throw error;
  }
}

export function syncPautaGoogleSheets(
  database: typeof db = db,
  snapshot?: PautaSnapshot,
): Promise<GoogleSheetsSyncStatus> {
  const key = database as object;
  const active = googleSheetsRuns.get(key);
  if (active) return active;
  const run = syncPautaGoogleSheetsOnce(database, snapshot).finally(() => {
    if (googleSheetsRuns.get(key) === run) googleSheetsRuns.delete(key);
  });
  googleSheetsRuns.set(key, run);
  return run;
}

export async function syncPautaGoogleSheetsIfLayoutOutdated(
  database: typeof db = db,
): Promise<GoogleSheetsSyncStatus | null> {
  const config = await readGoogleSheetsConfig(database);
  if (!config.spreadsheetId || config.layoutVersion === googleSheetsLayoutVersion) {
    return null;
  }
  return syncPautaGoogleSheets(database);
}

export function queuePautaGoogleSheetsSync(database: typeof db = db): void {
  const key = database as object;
  const pending = googleSheetsTimers.get(key);
  if (pending) clearTimeout(pending);
  const timer = setTimeout(() => {
    googleSheetsTimers.delete(key);
    void syncPautaGoogleSheets(database).catch(async (error) => {
      try {
        const { logger } = await import("../lib/logger");
        logger.warn({ err: error }, "Automatic Google Sheets sync failed");
      } catch {
        // The failure is also persisted for the Control de Pauta retry button.
      }
    });
  }, 1800);
  timer.unref();
  googleSheetsTimers.set(key, timer);
}

async function pautaGoogleSheetsStatus(database: typeof db): Promise<GoogleSheetsSyncStatus> {
  return googleSheetsStatus(await readGoogleSheetsConfig(database));
}

async function ensureSnapshot(database: typeof db): Promise<PautaSnapshot> {
  await database
    .insert(pautaSnapshotsTable)
    .values({
      id: sharedId,
      state: seedState as Record<string, unknown>,
      revision: 1,
    })
    .onConflictDoNothing();

  const [row] = await database
    .select()
    .from(pautaSnapshotsTable)
    .where(eq(pautaSnapshotsTable.id, sharedId));

  if (!row) throw new Error("The shared docket snapshot could not be loaded.");
  return GetPautaResponse.parse({ revision: row.revision, state: row.state });
}

type DeltaEvent = {
  kind: "delta";
  revision: number;
  baseRevision: number;
  fields: Record<string, unknown>;
  removed: string[];
  rowChanges?: { index: number; value: unknown }[];
};

function makeDelta(before: PautaSnapshot, after: PautaSnapshot): DeltaEvent {
  const fields: Record<string, unknown> = {};
  const removed: string[] = [];
  let rowChanges: DeltaEvent["rowChanges"];
  for (const key of new Set([...Object.keys(before.state), ...Object.keys(after.state)])) {
    if (!(key in after.state)) {
      removed.push(key);
      continue;
    }
    const previous = before.state[key];
    const current = after.state[key];
    if (pautaStateEqual({ value: previous }, { value: current })) continue;
    if (key === "rows" && Array.isArray(previous) && Array.isArray(current) && previous.length === current.length) {
      const changes = current.flatMap((value, index) =>
        pautaStateEqual({ value: previous[index] }, { value }) ? [] : [{ index, value }]);
      const encoded = JSON.stringify(changes);
      if (encoded.length < JSON.stringify(current).length * 0.8) {
        rowChanges = changes;
        continue;
      }
    }
    fields[key] = current;
  }
  return {
    kind: "delta",
    revision: after.revision,
    baseRevision: before.revision,
    fields,
    removed,
    ...(rowChanges ? { rowChanges } : {}),
  };
}

function sendEvent(response: Response, payload: PautaSnapshot | DeltaEvent): void {
  if (!response.writableEnded) {
    writeLive(response, `data: ${JSON.stringify(payload)}\n\n`);
  }
}

function publishChange(before: PautaSnapshot, after: PautaSnapshot): void {
  const delta = makeDelta(before, after);
  for (const response of listeners) sendEvent(response, delta);
}

export function publishAutomatedPautaChange(
  before: PautaSnapshot,
  after: PautaSnapshot,
): void {
  publishChange(before, after);
  queuePautaGoogleSheetsSync(db);
}

async function savePautaAcervoPatches(tx: any, patches: ReturnType<typeof collectPautaAcervoPatches>["patches"]): Promise<void> {
  if (!patches.length) return;
  // UPDATE ... FROM must see at most one incoming row per CNJ. Otherwise an
  // edit in Triagem and a session can cause PostgreSQL to apply only one scope.
  const byProcess = new Map<string, typeof patches>();
  for (const patch of patches) {
    const group = byProcess.get(patch.processo) ?? [];
    group.push(patch);
    byProcess.set(patch.processo, group);
  }
  if (byProcess.size < patches.length) {
    const groups = [...byProcess.values()];
    while (groups.some((group) => group.length)) {
      await savePautaAcervoPatches(tx, groups.flatMap((group) => group.length ? [group.shift()!] : []));
    }
    return;
  }
  const payload = JSON.stringify(patches);
  await tx.execute(sql`
    WITH incoming AS (
      SELECT processo, COALESCE(set_fields, '{}'::jsonb) AS set_fields,
        COALESCE(remove_fields, ARRAY[]::text[]) AS remove_fields,
        escopo
      FROM jsonb_to_recordset(${payload}::jsonb)
        AS x(processo text, set_fields jsonb, remove_fields text[], escopo text)
    )
    INSERT INTO acervo (processo, importado, operacional)
    SELECT processo, '{"versao":"1.0"}'::jsonb, '{}'::jsonb
    FROM incoming
    ON CONFLICT (processo) DO NOTHING
  `);
  await tx.execute(sql`
    WITH incoming AS (
      SELECT processo, COALESCE(set_fields, '{}'::jsonb) AS set_fields,
        COALESCE(remove_fields, ARRAY[]::text[]) AS remove_fields,
        escopo
      FROM jsonb_to_recordset(${payload}::jsonb)
        AS x(processo text, set_fields jsonb, remove_fields text[], escopo text)
    )
    UPDATE acervo AS target
    SET operacional = jsonb_set(
      COALESCE(target.operacional, '{}'::jsonb),
      '{pautasPorFicha}',
      jsonb_set(
        COALESCE(target.operacional->'pautasPorFicha', '{}'::jsonb),
        ARRAY[incoming.escopo]::text[],
        (COALESCE(target.operacional #> ARRAY['pautasPorFicha', incoming.escopo]::text[], '{}'::jsonb) - incoming.remove_fields) || incoming.set_fields,
        true
      ),
      true
    ),
    atualizado_em = now()
    FROM incoming
    WHERE target.processo = incoming.processo
  `);
}

async function refreshPautaFieldsFromAcervo(tx: any, state: Record<string, unknown>, patches: ReturnType<typeof collectPautaAcervoPatches>["patches"]): Promise<Record<string, unknown>> {
  const processes = [...new Set([
    ...patches.map((patch) => patch.processo),
    ...triagemRows(state).map((row) => String(row.processo ?? "").replace(/\D/g, "")).filter((p) => p.length === 20),
  ])];
  if (!processes.length) return state;
  const result = await tx.execute(sql`
    SELECT processo, importado, operacional
    FROM acervo
    WHERE processo IN (${sql.join(processes.map((process) => sql`${process}`), sql`, `)})
  `);
  const records: AcervoPautaRecord[] = (result.rows ?? []).map((row: any) => {
    const operacional = row.operacional && typeof row.operacional === "object" ? row.operacional : {};
    return {
      processo: row.processo,
      linha: linhaDaPauta(row.importado, {}),
      pauta: operacional.pauta && typeof operacional.pauta === "object" ? operacional.pauta : {},
      pautasPorFicha: operacional.pautasPorFicha && typeof operacional.pautasPorFicha === "object"
        ? operacional.pautasPorFicha
        : {},
    };
  });
  return applyAcervoToPautaState(state, records).state;
}

function sendPresence(response: Response, summary: PautaPresenceSummary): void {
  if (!response.writableEnded) {
    writeLive(response, `event: presence\ndata: ${JSON.stringify(summary)}\n\n`);
  }
}

function publishPresence(): void {
  const summary = GetPautaPresenceResponse.parse(summarizePautaPresence(presence.values()));
  for (const response of listeners) sendPresence(response, summary);
}

function sendGabnet(response: Response, payload: unknown): void {
  if (!response.writableEnded && !response.destroyed) {
    writeLive(response, `event: gabnet\ndata: ${JSON.stringify(payload)}\n\n`);
  }
}

function publishGabnet(payload: unknown): void {
  for (const response of listeners) sendGabnet(response, payload);
}

function schedulePresenceBroadcast(): void {
  if (presenceTimer) return;
  presenceTimer = setTimeout(() => {
    presenceTimer = null;
    publishPresence();
  }, 100);
  presenceTimer.unref?.();
}

export function createPautaRouter(database: typeof db = db): IRouter {
const router: IRouter = Router();

router.get("/pauta/presence", (_req, res): void => {
  res.setHeader("Cache-Control", "no-store");
  res.json(GetPautaPresenceResponse.parse(summarizePautaPresence(presence.values())));
});

router.post("/pauta/presence", (req, res): void => {
  res.setHeader("Cache-Control", "no-store");
  const parsed = UpdatePautaPresenceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const client = normalizePresenceClient(parsed.data.client);
  if (!client) {
    res.status(400).json({ error: "Identificador do navegador inválido." });
    return;
  }
  const who = getAppSession(req)?.server || getAppSession(req)?.name || "";
  let changed = false;

  for (const connection of presence.values()) {
    if (connection.client === client && connection.who !== who) {
      connection.who = who;
      changed = true;
    }
  }

  const summary = UpdatePautaPresenceResponse.parse(summarizePautaPresence(presence.values()));
  res.json(summary);
  if (changed) publishPresence();
});

router.get("/pauta/settings/access", requireAdministration, (req, res): void => {
  res.setHeader("Cache-Control", "no-store");
  const session = getAppSession(req);
  const sessionSecret = process.env.SESSION_SECRET || "";
  const unlocked = !!(
    session?.sessionId &&
    sessionSecret &&
    verifySettingsSessionToken(
      sessionSecret,
      readCookie(req.get("cookie")) || "",
      session.sessionId,
      session.expiresAt,
    )
  );
  res.json({ unlocked });
});

router.post("/pauta/settings/unlock", requireAdministration, (req, res): void => {
  res.setHeader("Cache-Control", "no-store");
  const expected = process.env.ADMIN_LOGIN_PASSWORD;
  if (!expected) {
    res.status(503).json({
      error: "A senha da Administração ainda não foi configurada.",
    });
    return;
  }
  if (expected.length < 6) {
    res.status(503).json({
      error: "A senha da Administração precisa ter pelo menos 6 caracteres.",
    });
    return;
  }

  const now = Date.now();
  const key = req.ip || "unknown";
  const attempt = settingsUnlockAttempts.get(key);
  if (attempt && attempt.resetAt <= now) settingsUnlockAttempts.delete(key);
  const current = settingsUnlockAttempts.get(key);
  if (current && current.count >= settingsUnlockMaxAttempts) {
    res.status(429).json({
      error: "Muitas tentativas. Aguarde um minuto e tente novamente.",
    });
    return;
  }

  const supplied = typeof req.body?.password === "string" ? req.body.password : "";
  const suppliedBytes = Buffer.from(supplied);
  const expectedBytes = Buffer.from(expected);
  const valid =
    suppliedBytes.length === expectedBytes.length &&
    timingSafeEqual(suppliedBytes, expectedBytes);

  if (!valid) {
    const next = current ?? { count: 0, resetAt: now + settingsUnlockWindowMs };
    next.count += 1;
    settingsUnlockAttempts.set(key, next);
    res.status(401).json({ error: "Senha incorreta." });
    return;
  }

  const sessionSecret = process.env.SESSION_SECRET || "";
  if (!sessionSecret) {
    res.status(503).json({
      error: "A sessão segura das Configurações Globais ainda não foi configurada.",
    });
    return;
  }
  const session = getAppSession(req);
  if (!session?.sessionId || !Number.isSafeInteger(session.expiresAt)) {
    res.status(401).json({ error: "A sessão autenticada expirou. Entre novamente." });
    return;
  }

  settingsUnlockAttempts.delete(key);
  const secure =
    req.secure || req.get("x-forwarded-proto")?.split(",")[0].trim() === "https";
  const signedToken = createSettingsSessionToken(
    sessionSecret,
    session.sessionId,
    session.expiresAt,
  );
  const cookieOptions = [
    "HttpOnly",
    "SameSite=Strict",
    ...(secure ? ["Secure"] : []),
  ];
  for (const path of [
    "/api/pauta/settings",
    "/api/pauta/mensagens",
    "/api/acervo",
  ]) {
    res.append(
      "Set-Cookie",
      [
        `${SETTINGS_SESSION_COOKIE}=${signedToken}`,
        `Path=${path}`,
        ...cookieOptions,
      ].join("; "),
    );
  }
  res.status(200).json({ ok: true });
});

router.get("/pauta", async (req, res): Promise<void> => {
  sendCompressed(req, res, JSON.stringify(await ensureSnapshot(database)), "json");
});

router.get("/pauta/sheets/status", requireAdministration, async (_req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  res.json(await pautaGoogleSheetsStatus(database));
});

router.post("/pauta/sheets/sync", requireAdministration, async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  try {
    const snapshot = await ensureSnapshot(database);
    const status = await syncPautaGoogleSheets(database, snapshot);
    req.log.info(
      {
        revision: snapshot.revision,
        processCount: status.processCount,
        sessionCount: status.sessionCount,
      },
      "Control Pauta synced to Google Sheets",
    );
    res.json(status);
  } catch (error) {
    req.log.error({ err: error }, "Control Pauta could not sync to Google Sheets");
    const status = await pautaGoogleSheetsStatus(database).catch(() => ({
      enabled: false,
      autoSync: true as const,
      spreadsheetId: null,
      spreadsheetUrl: null,
      lastSyncAt: null,
      lastSyncedRevision: null,
      processCount: 0,
      sessionCount: 0,
      error: error instanceof Error ? error.message : "Falha na sincronização.",
    }));
    res.status(502).json(status);
  }
});

const catalogWithoutRows = (value: unknown): Record<string, unknown> => {
  const catalog = isJsonRecord(value) ? { ...value } : {};
  delete catalog.rows;
  delete catalog.atualizadoEm;
  return catalog;
};

const stableJson = (value: unknown): string => {
  const sort = (item: unknown): unknown => {
    if (Array.isArray(item)) return item.map(sort);
    if (!isJsonRecord(item)) return item;
    return Object.fromEntries(Object.keys(item).sort().map((key) => [key, sort(item[key])]));
  };
  return JSON.stringify(sort(value)) ?? "";
};

const emptyLegacyMaterias = (): Record<string, unknown> => ({
  version: 1,
  catalogVersion: 0,
  groups: [],
  models: [],
});

const referencesPayload = (state: Record<string, unknown>, revision: number) => {
  const team = isJsonRecord(state.team) ? state.team : {};
  const teamSubjects = Array.isArray(team.subjects) ? team.subjects : [];
  const materias = isJsonRecord(state.materias) ? state.materias : emptyLegacyMaterias();
  const assuntos = isJsonRecord(state.assuntos) ? catalogWithoutRows(state.assuntos) : null;
  const fingerprint = createHash("sha256")
    .update(stableJson({
      assuntos: catalogWithoutRows(state.assuntos),
      teamSubjects,
      materias,
    }))
    .digest("hex");
  return { revision, assuntos, teamSubjects, materias, fingerprint };
};

router.get("/pauta/assuntos", async (req, res): Promise<void> => {
  const snapshot = await ensureSnapshot(database);
  res.setHeader("Cache-Control", "no-store");
  sendCompressed(req, res, JSON.stringify(referencesPayload(snapshot.state, snapshot.revision)), "json");
});

router.put("/pauta/assuntos", requireAdministration, async (req, res): Promise<void> => {
  if (!getAppSession(req)) {
    res.status(401).json({ error: "Entre no Gabinete para salvar as referências." });
    return;
  }
  const body = req.body as Record<string, unknown> | undefined;
  const assuntos = body?.assuntos;
  const teamSubjects = body?.teamSubjects;
  const materias = body?.materias;
  const baseFingerprint = body?.baseFingerprint;
  const baseRevision = body?.baseRevision;
  if (
    !Number.isSafeInteger(baseRevision) ||
    (baseRevision as number) < 0 ||
    typeof baseFingerprint !== "string" ||
    !/^[a-f0-9]{64}$/.test(baseFingerprint) ||
    !isJsonRecord(assuntos) ||
    !Array.isArray(assuntos.subjects) ||
    !assuntos.subjects.length ||
    !Array.isArray(assuntos.ramos) ||
    !Array.isArray(assuntos.procedures) ||
    !Array.isArray(assuntos.models) ||
    !Array.isArray(teamSubjects) ||
    !isJsonRecord(materias) ||
    !Array.isArray(materias.groups) ||
    !Array.isArray(materias.models)
  ) {
    res.status(400).json({
      error: "As referências devem conter listas válidas do catálogo, da equipe e dos grupos/modelos.",
    });
    return;
  }
  const namedLists: Array<[string, string]> = [
    ["subjects", "name"],
    ["ramos", "name"],
    ["procedures", "name"],
    ["models", "title"],
  ];
  for (const [key, label] of namedLists) {
    if (
      (assuntos[key] as unknown[]).some(
        (row) =>
          !isJsonRecord(row) ||
          typeof row[label] !== "string" ||
          !(row[label] as string).trim(),
      )
    ) {
      res.status(400).json({ error: `Há item sem nome ou título na lista "${key}".` });
      return;
    }
  }
  const teamIds = new Set<string>();
  for (const row of teamSubjects) {
    if (
      !isJsonRecord(row) ||
      typeof row.id !== "string" ||
      !row.id.trim() ||
      typeof row.name !== "string" ||
      !row.name.trim() ||
      teamIds.has(row.id)
    ) {
      res.status(400).json({ error: "A árvore da equipe contém assunto sem ID/nome ou com ID repetido." });
      return;
    }
    teamIds.add(row.id);
  }
  for (const [key, label] of [["groups", "name"], ["models", "title"]] as const) {
    const ids = new Set<string>();
    if ((materias[key] as unknown[]).some((row) => {
      if (!isJsonRecord(row) || typeof row.id !== "string" || !row.id.trim() ||
          typeof row[label] !== "string" || !(row[label] as string).trim() ||
          ids.has(row.id)) return true;
      ids.add(row.id);
      return false;
    })) {
      res.status(400).json({ error: `A lista legada "${key}" contém item sem ID/nome ou com ID repetido.` });
      return;
    }
  }
  for (const group of materias.groups) {
    if (
      isJsonRecord(group) &&
      Array.isArray(group.subjectIds) &&
      group.subjectIds.some((id) => typeof id !== "string" || !teamIds.has(id))
    ) {
      res.status(400).json({ error: "Há grupo vinculado a assunto ausente na árvore da equipe." });
      return;
    }
  }
  let legacyFileBytes = 0;
  const addLegacyFile = (file: unknown): boolean => {
    if (!isJsonRecord(file)) return false;
    const encoded = typeof file.base64 === "string" ? file.base64 : "";
    if (!encoded) return true;
    const bytes = Math.floor(encoded.length * 3 / 4);
    if (bytes > 25 * 1024 * 1024) return false;
    legacyFileBytes += bytes;
    return legacyFileBytes <= 100 * 1024 * 1024;
  };
  for (const model of materias.models) {
    if (!isJsonRecord(model)) continue;
    if (model.subjectId && (typeof model.subjectId !== "string" || !teamIds.has(model.subjectId))) {
      res.status(400).json({ error: "Há modelo vinculado a assunto ausente na árvore da equipe." });
      return;
    }
    const revisions = Array.isArray(model.revisions) ? model.revisions : [];
    if (!addLegacyFile(model) || revisions.some((revision) => !addLegacyFile(revision))) {
      res.status(400).json({ error: "Os arquivos dos modelos excedem 25 MB por arquivo ou 100 MB no total." });
      return;
    }
  }

  await ensureSnapshot(database);
  const outcome = await database.transaction(async (tx) => {
    const [current] = await tx
      .select()
      .from(pautaSnapshotsTable)
      .where(eq(pautaSnapshotsTable.id, sharedId))
      .for("update");
    if (!current) throw new Error("The shared docket snapshot is unavailable.");

    const currentReferences = referencesPayload(current.state, current.revision);
    if (
      (baseRevision as number) > current.revision ||
      baseFingerprint !== currentReferences.fingerprint
    ) {
      return {
        conflict: true as const,
        current: currentReferences,
      };
    }

    const originalCatalog = isJsonRecord(current.state.assuntos)
      ? current.state.assuntos
      : {};
    const nextCatalog: Record<string, unknown> = { ...assuntos };
    if (Array.isArray(originalCatalog.rows)) nextCatalog.rows = originalCatalog.rows;
    const originalTeam = isJsonRecord(current.state.team) ? current.state.team : {};
    const nextState = {
      ...current.state,
      assuntos: nextCatalog,
      team: { ...originalTeam, subjects: teamSubjects },
      materias,
    };
    if (pautaStateEqual(nextState, current.state)) {
      return {
        before: null,
        current: referencesPayload(current.state, current.revision),
      };
    }

    const [updated] = await tx
      .update(pautaSnapshotsTable)
      .set({
        state: nextState,
        revision: current.revision + 1,
        updatedAt: new Date(),
      })
      .where(eq(pautaSnapshotsTable.id, sharedId))
      .returning();
    if (!updated) throw new Error("The shared catalog could not be saved.");
    return {
      before: { revision: current.revision, state: current.state } as PautaSnapshot,
      current: referencesPayload(updated.state, updated.revision),
      after: { revision: updated.revision, state: updated.state } as PautaSnapshot,
    };
  });

  if ("conflict" in outcome) {
    res.status(409).json({
      error: "As referências mudaram em outra sessão. Recarregue a versão atual antes de salvar.",
      ...outcome.current,
    });
    return;
  }
  res.json(outcome.current);
  if (outcome.before && "after" in outcome) publishChange(outcome.before, outcome.after);
});

router.get("/pauta/gabnet", async (_req, res): Promise<void> => {
  const snapshot = await ensureSnapshot(database);
  const game = normalizeGabnetGame(
    (snapshot.state.pautaPreferences as Record<string, unknown> | undefined)?.gabnetGame,
    gabnetLocalDate(),
    gabnetMapFromState(snapshot.state),
  );
  res.setHeader("Cache-Control", "no-store");
  res.json(GetGabnetGameResponse.parse({ game }));
});

router.get("/pauta/gabnet/world", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  if (!getAppSession(req)) {
    res.status(401).json({ error: "Entre no Gabinete para acessar o GAB-NET." });
    return;
  }
  const snapshot = await ensureSnapshot(database);
  const preferences = isJsonRecord(snapshot.state.pautaPreferences)
    ? snapshot.state.pautaPreferences
    : {};
  res.json(GetGabnetWorldResponse.parse({
    revision: snapshot.revision,
    world: normalizeGabnetWorld(preferences.gabnetWorld),
  }));
});

router.put("/pauta/gabnet/world/player", async (req, res): Promise<void> => {
  const parsed = SetGabnetWorldPlayerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const session = getAppSession(req);
  if (!session) {
    res.status(401).json({ error: "Entre no Gabinete para salvar o GAB-NET." });
    return;
  }

  await ensureSnapshot(database);
  const outcome = await database.transaction(async (tx) => {
    const [current] = await tx
      .select()
      .from(pautaSnapshotsTable)
      .where(eq(pautaSnapshotsTable.id, sharedId))
      .for("update");
    if (!current) throw new Error("The shared docket snapshot is unavailable.");
    const members = Array.isArray((current.state.team as { members?: unknown } | undefined)?.members)
      ? (current.state.team as { members: unknown[] }).members
      : [];
    const normalizeName = (value: unknown) =>
      normalizePresenceText(String(value ?? ""), 80)
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLocaleUpperCase("pt-BR");
    const member = members.find((candidate) => {
      if (!isJsonRecord(candidate)) return false;
      return canAccessGlobalSettings(session.role)
        ? gabnetMemberId(candidate) === parsed.data.memberId
        : session.role === "equipe" &&
          Boolean(session.server) &&
          normalizeName(candidate.name) === normalizeName(session.server) &&
          gabnetMemberId(candidate) === parsed.data.memberId;
    }) as { id?: unknown; name?: unknown } | undefined;
    if (!member?.name) return { forbidden: true as const };

    const preferences = isJsonRecord(current.state.pautaPreferences)
      ? current.state.pautaPreferences
      : {};
    const world = normalizeGabnetWorld(preferences.gabnetWorld);
    const player = normalizeGabnetPlayerState(parsed.data.player);
    if (!player) return { invalid: true as const };
    world.players[parsed.data.memberId] = player;
    world.revision += 1;
    const nextState: Record<string, unknown> = {
      ...current.state,
      pautaPreferences: { ...preferences, gabnetWorld: world },
    };
    const [updated] = await tx
      .update(pautaSnapshotsTable)
      .set({
        state: nextState,
        revision: current.revision + 1,
        updatedAt: new Date(),
      })
      .where(eq(pautaSnapshotsTable.id, sharedId))
      .returning();
    if (!updated) throw new Error("The GAB-NET profile could not be saved.");
    const result = SetGabnetWorldPlayerResponse.parse({
      revision: updated.revision,
      world,
      memberId: parsed.data.memberId,
    });
    const game = normalizeGabnetGame(
      (preferences.gabnetGame as Record<string, unknown> | undefined),
      gabnetLocalDate(),
      gabnetMapFromState(current.state),
    );
    return { result, game, memberName: String(member.name) };
  });
  if ("forbidden" in outcome) {
    res.status(403).json({ error: "Só é possível editar o próprio perfil de jogo." });
    return;
  }
  if ("invalid" in outcome) {
    res.status(400).json({ error: "Dados do perfil de jogo inválidos." });
    return;
  }
  res.setHeader("Cache-Control", "no-store");
  res.json(outcome.result);
  publishGabnet({
    ...outcome.result,
    game: outcome.game,
    memberName: outcome.memberName,
  });
});

router.put("/pauta/gabnet/world/settings", async (req, res): Promise<void> => {
  const parsed = SetGabnetWorldSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (!canAccessGlobalSettings(getAppSession(req)?.role)) {
    res.status(403).json({ error: "Somente a Administração pode editar os campos do GAB-NET." });
    return;
  }
  await ensureSnapshot(database);
  const outcome = await database.transaction(async (tx) => {
    const [current] = await tx
      .select()
      .from(pautaSnapshotsTable)
      .where(eq(pautaSnapshotsTable.id, sharedId))
      .for("update");
    if (!current) throw new Error("The shared docket snapshot is unavailable.");
    const preferences = isJsonRecord(current.state.pautaPreferences)
      ? current.state.pautaPreferences
      : {};
    const world = normalizeGabnetWorld(preferences.gabnetWorld);
    const settings = normalizeGabnetWorld({ settings: parsed.data.settings }).settings;
    if (!settings) return { invalid: true as const };
    world.settings = settings;
    world.revision += 1;
    const nextState: Record<string, unknown> = {
      ...current.state,
      pautaPreferences: { ...preferences, gabnetWorld: world },
    };
    const [updated] = await tx
      .update(pautaSnapshotsTable)
      .set({
        state: nextState,
        revision: current.revision + 1,
        updatedAt: new Date(),
      })
      .where(eq(pautaSnapshotsTable.id, sharedId))
      .returning();
    if (!updated) throw new Error("The GAB-NET settings could not be saved.");
    return {
      result: SetGabnetWorldSettingsResponse.parse({
        revision: updated.revision,
        world,
        memberId: "settings",
      }),
      game: normalizeGabnetGame(
        preferences.gabnetGame,
        gabnetLocalDate(),
        gabnetMapFromState(current.state),
      ),
    };
  });
  if ("invalid" in outcome) {
    res.status(400).json({ error: "Configurações do GAB-NET inválidas." });
    return;
  }
  res.setHeader("Cache-Control", "no-store");
  res.json(outcome.result);
  publishGabnet({ ...outcome.result, game: outcome.game });
});

router.put("/pauta/gabnet/world/avatar", async (req, res): Promise<void> => {
  const parsed = SetGabnetWorldAvatarBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const session = getAppSession(req);
  if (!session) {
    res.status(401).json({ error: "Entre no Gabinete para editar um avatar." });
    return;
  }
  const avatar = normalizeGabnetAvatar(parsed.data.avatar);
  if (!avatar || !Object.keys(avatar).length) {
    res.status(400).json({ error: "Os dados do avatar são inválidos." });
    return;
  }
  await ensureSnapshot(database);
  const outcome = await database.transaction(async (tx) => {
    const [current] = await tx
      .select()
      .from(pautaSnapshotsTable)
      .where(eq(pautaSnapshotsTable.id, sharedId))
      .for("update");
    if (!current) throw new Error("The shared docket snapshot is unavailable.");
    const members = Array.isArray((current.state.team as { members?: unknown } | undefined)?.members)
      ? (current.state.team as { members: unknown[] }).members
      : [];
    const normalizeName = (value: unknown) =>
      normalizePresenceText(String(value ?? ""), 80)
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLocaleUpperCase("pt-BR");
    const member = members.find((candidate) => {
      if (!isJsonRecord(candidate)) return false;
      return canAccessGlobalSettings(session.role)
        ? gabnetMemberId(candidate) === parsed.data.memberId
        : session.role === "equipe" &&
          Boolean(session.server) &&
          normalizeName(candidate.name) === normalizeName(session.server) &&
          gabnetMemberId(candidate) === parsed.data.memberId;
    }) as { id?: unknown; name?: unknown } | undefined;
    if (!member?.name) return { forbidden: true as const };

    const preferences = isJsonRecord(current.state.pautaPreferences)
      ? current.state.pautaPreferences
      : {};
    const world = normalizeGabnetWorld(preferences.gabnetWorld);
    world.avatars[parsed.data.memberId] = avatar;
    world.revision += 1;
    const nextState: Record<string, unknown> = {
      ...current.state,
      pautaPreferences: { ...preferences, gabnetWorld: world },
    };
    const [updated] = await tx
      .update(pautaSnapshotsTable)
      .set({
        state: nextState,
        revision: current.revision + 1,
        updatedAt: new Date(),
      })
      .where(eq(pautaSnapshotsTable.id, sharedId))
      .returning();
    if (!updated) throw new Error("The GAB-NET avatar could not be saved.");
    return {
      result: SetGabnetWorldAvatarResponse.parse({
        revision: updated.revision,
        world,
        memberId: parsed.data.memberId,
      }),
      game: normalizeGabnetGame(
        preferences.gabnetGame,
        gabnetLocalDate(),
        gabnetMapFromState(current.state),
      ),
      memberName: String(member.name),
    };
  });
  if ("forbidden" in outcome) {
    res.status(403).json({ error: "Só é possível editar o próprio avatar." });
    return;
  }
  res.setHeader("Cache-Control", "no-store");
  res.json(outcome.result);
  publishGabnet({
    ...outcome.result,
    game: outcome.game,
    memberName: outcome.memberName,
  });
});

router.post("/pauta/gabnet/actions", async (req, res): Promise<void> => {
  const parsed = MoveGabnetPlayerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const session = getAppSession(req);
  if ((session?.role !== "equipe" && session?.role !== "editor") || !session.server) {
    res.status(403).json({ error: "Entre com um servidor selecionado para jogar no GAB-NET." });
    return;
  }

  await ensureSnapshot(database);
  const outcome = await database.transaction(async (tx) => {
    const [current] = await tx
      .select()
      .from(pautaSnapshotsTable)
      .where(eq(pautaSnapshotsTable.id, sharedId))
      .for("update");

    if (!current) throw new Error("The shared docket snapshot is unavailable.");

    const team = current.state.team as { members?: unknown } | undefined;
    const members = Array.isArray(team?.members) ? team.members : [];
    const normalizeName = (value: unknown) =>
      normalizePresenceText(String(value ?? ""), 80)
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLocaleUpperCase("pt-BR");
    const member = members.find((candidate) => {
      if (!candidate || typeof candidate !== "object") return false;
      return normalizeName((candidate as { name?: unknown }).name) === normalizeName(session.server);
    }) as { id?: unknown; name?: unknown } | undefined;
    if (!member?.name) {
      return { forbidden: true as const };
    }

    const today = gabnetLocalDate();
    const map = gabnetMapFromState(current.state);
    const preferences = current.state.pautaPreferences &&
      typeof current.state.pautaPreferences === "object" &&
      !Array.isArray(current.state.pautaPreferences)
      ? current.state.pautaPreferences as Record<string, unknown>
      : {};
    let game = normalizeGabnetGame(preferences.gabnetGame, today, map);
    const memberId = gabnetMemberId(member);
    const collected: string[] = [];
    const achievements: string[] = [];
    for (const direction of parsed.data.directions as GabnetDirection[]) {
      const result = applyGabnetAction({
        game,
        map,
        memberId,
        direction,
        now: Date.now(),
      });
      game = result.game;
      collected.push(...result.collected);
      achievements.push(...result.achievements);
    }
    game.revision += 1;

    const nextState: Record<string, unknown> = {
      ...current.state,
      pautaPreferences: {
        ...preferences,
        gabnetGame: game,
      },
    };
    const [updated] = await tx
      .update(pautaSnapshotsTable)
      .set({
        state: nextState,
        revision: current.revision + 1,
        updatedAt: new Date(),
      })
      .where(eq(pautaSnapshotsTable.id, sharedId))
      .returning();
    if (!updated) throw new Error("The shared GAB-NET game could not be saved.");

    return {
      result: MoveGabnetPlayerResponse.parse({
        revision: updated.revision,
        game,
        memberId,
        collected,
        achievements,
      }),
      memberName: String(member.name),
    };
  });

  if ("forbidden" in outcome) {
    res.status(403).json({ error: "O servidor selecionado não tem perfil cadastrado para jogar." });
    return;
  }
  res.setHeader("Cache-Control", "no-store");
  res.json(outcome.result);
  publishGabnet({
    ...outcome.result,
    memberName: outcome.memberName,
  });
});

router.put("/pauta/gabnet/inventory", async (req, res): Promise<void> => {
  const parsed = SetGabnetInventoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (!canAccessGlobalSettings(getAppSession(req)?.role)) {
    res.status(403).json({ error: "Somente a Administração pode ajustar inventários do GAB-NET." });
    return;
  }

  await ensureSnapshot(database);
  const outcome = await database.transaction(async (tx) => {
    const [current] = await tx
      .select()
      .from(pautaSnapshotsTable)
      .where(eq(pautaSnapshotsTable.id, sharedId))
      .for("update");
    if (!current) throw new Error("The shared docket snapshot is unavailable.");

    const members = Array.isArray((current.state.team as { members?: unknown } | undefined)?.members)
      ? (current.state.team as { members: unknown[] }).members
      : [];
    const member = members.find((candidate) => {
      if (!candidate || typeof candidate !== "object") return false;
      return gabnetMemberId(candidate as { id?: unknown; name?: unknown }) === parsed.data.memberId;
    }) as { id?: unknown; name?: unknown } | undefined;
    if (!member?.id || !member.name) return { missing: true as const };

    const today = gabnetLocalDate();
    const map = gabnetMapFromState(current.state);
    const preferences = current.state.pautaPreferences &&
      typeof current.state.pautaPreferences === "object" &&
      !Array.isArray(current.state.pautaPreferences)
      ? current.state.pautaPreferences as Record<string, unknown>
      : {};
    const game = normalizeGabnetGame(preferences.gabnetGame, today, map);
    const inventory = game.inventories[parsed.data.memberId] ||
      (game.inventories[parsed.data.memberId] = {});
    if (parsed.data.quantity === 0) delete inventory[parsed.data.item];
    else inventory[parsed.data.item] = parsed.data.quantity;
    if (!Object.keys(inventory).length) delete game.inventories[parsed.data.memberId];
    const world = normalizeGabnetWorld(preferences.gabnetWorld);
    const player = normalizeGabnetPlayerState(world.players[parsed.data.memberId]) || {
      coins: 35,
      inventory: {},
      owned: [],
      equipped: "",
      visited: [],
      awards: [],
      events: [],
    };
    const itemNames: Record<string, { name: string; kind: "inventory" | "award" }> = {
      cafe: { name: "Café", kind: "inventory" },
      livro: { name: "Livro", kind: "inventory" },
      planta: { name: "Planta", kind: "inventory" },
      documento: { name: "Documento", kind: "inventory" },
      primeiros_passos: { name: "Primeiros passos", kind: "award" },
      explorador: { name: "Explorador", kind: "award" },
      dedicado: { name: "Presença constante", kind: "award" },
    };
    const mappedItem = itemNames[parsed.data.item];
    if (mappedItem.kind === "inventory") {
      const playerInventory = isJsonRecord(player.inventory) ? player.inventory : {};
      if (parsed.data.quantity === 0) delete playerInventory[mappedItem.name];
      else playerInventory[mappedItem.name] = parsed.data.quantity;
      player.inventory = playerInventory;
    } else {
      const awards = Array.isArray(player.awards) ? player.awards as string[] : [];
      player.awards = parsed.data.quantity > 0
        ? [...new Set([...awards, mappedItem.name])]
        : awards.filter((award) => award !== mappedItem.name);
    }
    world.players[parsed.data.memberId] = player;
    world.revision += 1;
    game.revision += 1;

    const nextState: Record<string, unknown> = {
      ...current.state,
      pautaPreferences: { ...preferences, gabnetGame: game, gabnetWorld: world },
    };
    const [updated] = await tx
      .update(pautaSnapshotsTable)
      .set({
        state: nextState,
        revision: current.revision + 1,
        updatedAt: new Date(),
      })
      .where(eq(pautaSnapshotsTable.id, sharedId))
      .returning();
    if (!updated) throw new Error("The shared GAB-NET inventory could not be saved.");

    return {
      result: SetGabnetInventoryResponse.parse({
        revision: updated.revision,
        game,
        memberId: parsed.data.memberId,
      }),
      world,
      memberName: String(member.name),
    };
  });

  if ("missing" in outcome) {
    res.status(400).json({ error: "Servidor não encontrado na lista fixa da equipe." });
    return;
  }
  res.setHeader("Cache-Control", "no-store");
  res.json(outcome.result);
  publishGabnet({
    ...outcome.result,
    world: outcome.world,
    memberName: outcome.memberName,
  });
});

router.put("/pauta", async (req, res): Promise<void> => {
  const parsed = SavePautaBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  await garantirTabelasAcervo();
  await ensureSnapshot(database);

  const outcome = await database.transaction(async (tx) => {
    await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtext('cmt-acervo-pauta-sync'))`);
    const [current] = await tx
      .select()
      .from(pautaSnapshotsTable)
      .where(eq(pautaSnapshotsTable.id, sharedId))
      .for("update");

    if (!current) throw new Error("The shared docket snapshot is unavailable.");

    const { state: mergedState, conflicts } =
      parsed.data.baseRevision < current.revision
        ? mergePautaStates(parsed.data.baseState, parsed.data.state, current.state)
        : { state: parsed.data.state, conflicts: [] };
    const sessionRole = getAppSession(req)?.role;
    const protectedState = protectSharedGabnetState(
      parsed.data.baseState,
      current.state,
      mergedState,
      sessionRole,
    );
    if (protectedState.forbidden) return { forbiddenGabnet: true as const };
    if (!canAccessGlobalSettings(sessionRole) &&
        hasAdminOnlyPautaSettingsChanges(current.state, protectedState.state)) {
      return { forbiddenSettings: true as const };
    }
    let nextState = protectedState.state;
    // This catalog has its own revision and Assessoria-only write endpoint.
    // Legacy clients omit unknown snapshot fields: unrelated saves must never erase it.
    nextState = { ...nextState };
    if (Object.hasOwn(current.state, LIBRARY_KEY)) nextState[LIBRARY_KEY] = current.state[LIBRARY_KEY];
    else delete nextState[LIBRARY_KEY];
    // A regular account cannot grant itself library-editing rights by changing the roster.
    if (!canAccessGlobalSettings(sessionRole) &&
        JSON.stringify(assessoriaNames(nextState)) !== JSON.stringify(assessoriaNames(current.state))) {
      return { forbiddenLibraryRole: true as const };
    }

    if (
      !canDeleteProcessCards(getAppSession(req)?.role) &&
      removesProcessCards(current.state, nextState)
    ) {
      return { forbidden: true as const };
    }

    if (pautaStateEqual(nextState, current.state)) {
      return {
        before: null,
        saved: SavePautaResponse.parse({
          revision: current.revision,
          state: current.state,
          conflicts,
        }),
      };
    }

    const acervoPatches = collectPautaAcervoPatches(current.state, nextState);
    nextState = acervoPatches.state;
    await savePautaAcervoPatches(tx, acervoPatches.patches);
    nextState = await refreshPautaFieldsFromAcervo(tx, nextState, acervoPatches.patches);

    const [updated] = await tx
      .update(pautaSnapshotsTable)
      .set({
        state: nextState,
        revision: current.revision + 1,
        updatedAt: new Date(),
      })
      .where(eq(pautaSnapshotsTable.id, sharedId))
      .returning();

    if (!updated) throw new Error("The shared docket snapshot could not be saved.");
    return {
      before: { revision: current.revision, state: current.state } as PautaSnapshot,
      saved: SavePautaResponse.parse({
        revision: updated.revision,
        state: updated.state,
        conflicts,
      }),
    };
  });

  if ("forbidden" in outcome) {
    res.status(403).json({
      error: "A exclusão de cards de processo é exclusiva da Administração.",
    });
    return;
  }
  if ("forbiddenGabnet" in outcome) {
    res.status(403).json({
      error: "Somente a Administração pode alterar a planta do GAB-NET.",
    });
    return;
  }
  if ("forbiddenSettings" in outcome) {
    res.status(403).json({
      error: "Somente a Administração pode alterar Configurações Globais.",
    });
    return;
  }
  if ("forbiddenLibraryRole" in outcome) {
    res.status(403).json({ error: "Somente a Administração pode alterar os vínculos de Assessoria da equipe." });
    return;
  }

  res.json(outcome.saved);
  if (outcome.before) {
    forgetTeamMembers();
    publishChange(outcome.before, outcome.saved);
    if (database === db) queuePautaGoogleSheetsSync(database);
  }
});

router.get("/pauta/events", async (req, res): Promise<void> => {
  const parsed = WatchPautaQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const snapshot = await ensureSnapshot(database);
  res.status(200);
  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  registerLiveAccess(req, res);
  listeners.add(res);
  const connection = {
    client: normalizePresenceClient(parsed.data.client),
    who: getAppSession(req)?.server || getAppSession(req)?.name || "",
  };
  presence.set(res, connection);
  if (parsed.data.after !== undefined && parsed.data.after === snapshot.revision) {
    writeLive(res, ": up-to-date\n\n");
  } else {
    sendEvent(res, snapshot);
  }
  publishPresence();

  const heartbeat = setInterval(() => {
    if (!res.writableEnded) writeLive(res, ": keep-alive\n\n");
  }, 20_000);
  heartbeat.unref();

  res.on("close", () => {
    clearInterval(heartbeat);
    listeners.delete(res);
    if (presence.delete(res)) schedulePresenceBroadcast();
  });
});

return router;
}

export default createPautaRouter();

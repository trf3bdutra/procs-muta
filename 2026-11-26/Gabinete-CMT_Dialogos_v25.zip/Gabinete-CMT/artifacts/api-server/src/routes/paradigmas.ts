import { Router, type Request, type Response } from "express";
import { chooseEncoding, encodeBody, sendEncoded, type Encoded } from "../lib/compress";
import {
  jurisprudenciaSource, jurisprudenciaIndex, jurisprudenciaModels,
  jurisprudenciaDetail, normalizeJulgado, jurisprudenciaBuscaIntegral, validArquivoAnual, jurisprudenciaEnriquecidos,
} from "../lib/github-jurisprudencia";

const router = Router();
// Prévias sem campos vazios: o índice tem 33 mil linhas e cada chave vazia pesa no download.
function compacto(row: Record<string, any>) {
  for (const k of Object.keys(row)) {
    const v = row[k];
    if (v === "" || v == null || (Array.isArray(v) && !v.length)) delete row[k];
  }
  return row;
}
const packed = new Map<string, { expires: number; body: Encoded }>();
async function catalog(req: Request, res: Response, kind: "precedentes" | "modelos") {
  try {
    const encoding = chooseEncoding(req.headers["accept-encoding"]);
    const key = `${kind}:${encoding}`;
    let item = packed.get(key);
    if (!item || item.expires <= Date.now()) {
      const rows = kind === "precedentes"
        ? (await jurisprudenciaIndex()).map(row => compacto(normalizeJulgado(row)))
        : await jurisprudenciaModels();
      const data = { source: jurisprudenciaSource, total: rows.length, [kind === "precedentes" ? "registros" : "modelos"]: rows };
      item = { expires: Date.now() + 60_000, body: encodeBody(JSON.stringify(data), encoding) };
      packed.set(key, item);
    }
    res.setHeader("Cache-Control", "private, max-age=60");
    sendEncoded(res, item.body, "json");
  } catch (error) {
    req.log.warn({ err: error, catalog: kind }, "geradores: leitura do GitHub falhou");
    res.status(503).json({ error: "Não foi possível consultar o acervo público do GitHub. Tente novamente.", source: jurisprudenciaSource });
  }
}

router.get("/paradigmas/precedentes", (req, res) => catalog(req, res, "precedentes"));
router.get("/paradigmas/modelos", (req, res) => catalog(req, res, "modelos"));
router.get("/paradigmas/inteiro-teor/:chave", async (req, res) => {
  try {
    const detail = await jurisprudenciaDetail(String(req.params.chave || "").slice(0, 200));
    if (!detail) { res.status(404).json({ error: "Julgado não encontrado no repositório." }); return; }
    res.setHeader("Cache-Control", "private, max-age=300");
    sendEncoded(res, encodeBody(JSON.stringify(detail), chooseEncoding(req.headers["accept-encoding"])), "json");
  } catch (error) {
    req.log.warn({ err: error }, "geradores: leitura de inteiro teor falhou");
    res.status(503).json({ error: "Não foi possível consultar o texto do julgado no GitHub." });
  }
});

// Busca no texto integral: o navegador pede um arquivo anual por vez (acordaos/2022, monocraticas/2021…)
// e mostra o progresso; os arquivos ficam no cache do servidor, nunca são enviados inteiros ao navegador.
router.get("/paradigmas/busca-integral", async (req, res) => {
  const arquivo = String(req.query.arquivo || ""), q = String(req.query.q || "").slice(0, 300);
  if (!validArquivoAnual(arquivo)) { res.status(400).json({ error: "Arquivo anual inválido." }); return; }
  try {
    const out = await jurisprudenciaBuscaIntegral(arquivo, q);
    res.setHeader("Cache-Control", "private, max-age=60");
    sendEncoded(res, encodeBody(JSON.stringify(out), chooseEncoding(req.headers["accept-encoding"])), "json");
  } catch (error) {
    req.log.warn({ err: error, arquivo }, "geradores: busca integral falhou");
    res.status(503).json({ error: "Não foi possível pesquisar o texto integral agora. Tente novamente." });
  }
});

// Julgados dos últimos 24 meses com ementa completa, temas, súmulas e citações (busca e aderência dos Similares).
let ricosPack: { expires: number; key: string; body: Encoded } | null = null;
router.get("/paradigmas/enriquecidos", async (req, res) => {
  try {
    const encoding = chooseEncoding(req.headers["accept-encoding"]);
    if (!ricosPack || ricosPack.expires <= Date.now() || ricosPack.key !== encoding) {
      const data = await jurisprudenciaEnriquecidos();
      ricosPack = { expires: Date.now() + 10 * 60_000, key: encoding, body: encodeBody(JSON.stringify(data), encoding) };
    }
    res.setHeader("Cache-Control", "private, max-age=600");
    sendEncoded(res, ricosPack.body, "json");
  } catch (error) {
    req.log.warn({ err: error }, "geradores: julgados enriquecidos falharam");
    res.status(503).json({ error: "Não foi possível preparar os julgados recentes agora." });
  }
});

// Compatibilidade: a aderência automática do Prontuário usa só o índice compacto.
router.get("/paradigmas/teor-busca", (_req, res) => {
  res.json({ hits: {}, scope: "indice", fullTextSearch: false, source: jurisprudenciaSource });
});

export default router;

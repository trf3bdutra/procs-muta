import { Router } from "express";
import { jurisprudenciaSource } from "../lib/github-jurisprudencia";

/** Bancos editoriais canônicos do Gerador.
 * Este endpoint não consulta Postgres, seeds, modelos de precedentes,
 * parágrafos pessoais nem snapshots do Prontuário.
 */
const router = Router();
const ROOT = `https://raw.githubusercontent.com/${jurisprudenciaSource.repository}/${jurisprudenciaSource.branch}/`;
const CATALOGS = { modelos: "data/modelos.json", trechos: "data/paragrafos.json" } as const;
type Catalog = keyof typeof CATALOGS;

router.get("/catalogos-gerador/:catalogo", async (req, res) => {
  const key = req.params.catalogo as Catalog;
  const path = CATALOGS[key];
  res.setHeader("Cache-Control", "no-store, private");
  if (!path) { res.status(404).json({ error: "Catálogo inexistente." }); return; }
  try {
    const response = await fetch(ROOT + path, {
      headers: { Accept: "application/json" }, signal: AbortSignal.timeout(12_000), cache: "no-store",
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const mime = response.headers.get("content-type") || "";
    if (!/json|text\/plain|octet-stream/i.test(mime)) throw new Error("Resposta Git não é JSON");
    const body = await response.text();
    if (Buffer.byteLength(body, "utf8") > 12 * 1024 * 1024) throw new Error("Catálogo demasiado grande");
    const value = JSON.parse(body);
    const rows = Array.isArray(value) ? value :
      Array.isArray(value?.registros) ? value.registros :
      key === "modelos" && Array.isArray(value?.modelos) ? value.modelos :
      key === "trechos" && Array.isArray(value?.paragrafos) ? value.paragrafos :
      key === "trechos" && Array.isArray(value?.trechos) ? value.trechos : null;
    if (!rows) throw new Error("Formato Git incompatível");
    const ids = new Set<string>();
    const records = rows.filter((row: unknown): row is Record<string,unknown> => {
      if (!row || typeof row !== "object" || Array.isArray(row)) return false;
      const id = String((row as Record<string,unknown>).id ?? "").trim();
      if (!id || ids.has(id)) return false;
      ids.add(id); return true;
    });
    res.json({ source: { repository: jurisprudenciaSource.repository, branch: jurisprudenciaSource.branch, path }, registros: records, total: records.length });
  } catch (error) {
    req.log.warn({ err: error, catalogo: key }, "Catálogo canônico Git indisponível");
    res.status(503).json({ error: "Catálogo Git indisponível. Nenhuma fonte alternativa será utilizada.", registros: [], total: 0 });
  }
});
export default router;

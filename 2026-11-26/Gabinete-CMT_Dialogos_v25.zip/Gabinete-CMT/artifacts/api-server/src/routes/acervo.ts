import { Router, type IRouter } from "express";
import { GetAcervoCentralQueryParams, GetAcervoCentralResponse } from "@workspace/api-zod";
import { pool } from "@workspace/db";
import { garantirTabelasAcervo } from "../lib/acervo-tables";

const router: IRouter = Router();
const CLASSE = `COALESCE(
  NULLIF(btrim(importado #>> '{importado,classe}'), ''),
  NULLIF(btrim(importado #>> '{importado,classe_judicial}'), ''),
  NULLIF(btrim(importado->>'classe'), ''),
  NULLIF(btrim(importado->>'classe_judicial'), ''),
  NULLIF(btrim(importado->>'Classe'), ''),
  NULLIF(btrim(importado->>'Classe Processual'), ''),
  'Não informado'
)`;
const SECAO = `COALESCE(
  NULLIF(btrim(importado #>> '{importado,secao}'), ''),
  NULLIF(btrim(importado #>> '{importado,secaoCompetente}'), ''),
  NULLIF(btrim(importado->>'secao'), ''),
  NULLIF(btrim(importado->>'secaoCompetente'), ''),
  NULLIF(btrim(importado->>'Seção Competente'), ''),
  NULLIF(btrim(importado->>'Seção competente'), ''),
  NULLIF(btrim(importado->>'Seção'), ''),
  'Não informado'
)`;

router.get("/acervo/central", async (req, res): Promise<void> => {
  const query = GetAcervoCentralQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: "Parâmetro de atualização inválido." });
    return;
  }

  res.setHeader("Cache-Control", "no-store");
  try {
    await garantirTabelasAcervo();
    const [summary, byClass, bySection] = await Promise.all([
      pool.query("SELECT count(*)::int AS total, now() AS consultado_em FROM acervo"),
      pool.query(`SELECT ${CLASSE} AS category, count(*)::int AS count FROM acervo GROUP BY 1 ORDER BY 2 DESC, 1`),
      pool.query(`SELECT ${SECAO} AS category, count(*)::int AS count FROM acervo GROUP BY 1 ORDER BY 2 DESC, 1`),
    ]);
    const statistics = GetAcervoCentralResponse.parse({
      total: Number(summary.rows[0]?.total ?? 0),
      sourceUpdatedAt: summary.rows[0]?.consultado_em ?? new Date(),
      byClass: byClass.rows.map((row) => ({ category: String(row.category), count: Number(row.count) })),
      bySection: bySection.rows.map((row) => ({ category: String(row.category), count: Number(row.count) })),
    });
    res.json(statistics);
  } catch (error) {
    req.log.error({ err: error }, "acervo: falha ao calcular estatísticas locais");
    res.status(500).json({ error: "Não foi possível consultar as estatísticas do Acervo deste app." });
  }
});

export default router;

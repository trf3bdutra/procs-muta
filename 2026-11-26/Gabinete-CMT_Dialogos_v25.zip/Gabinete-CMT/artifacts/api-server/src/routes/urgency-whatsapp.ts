import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, pautaSnapshotsTable } from "@workspace/db";
import { ForwardUrgencyWhatsappBody } from "@workspace/api-zod";
import { getAppSession } from "../lib/app-auth";
import { canaisDisponiveis, enviarTwilio } from "../lib/envio";
import { coerceTwilioConfig } from "../lib/twilio";
import { urgencyWhatsappDestination, urgencyWhatsappTemplateSid, forwardingText, forwardOnce, linkedUrgency } from "../lib/urgency-whatsapp";
import { isUrgencyImageTokenValid } from "../lib/urgency-whatsapp-media-token";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const router = Router();
router.get("/pauta/urgencias/whatsapp-image", (req, res): void => {
  const token = String(req.query.token || "");
  if (!isUrgencyImageTokenValid(token)) { res.status(404).end(); return; }
  try {
    const image = readFileSync(resolve(process.cwd(), "../../attached_assets/image_1793906096132.png"));
    res.setHeader("Cache-Control", "private, no-store, max-age=0");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.type("png").send(image);
  } catch {
    res.status(404).end();
  }
});

router.post("/pauta/urgencias/whatsapp", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  const session = getAppSession(req);
  if (!session?.userId) { res.status(401).json({ error: "Autenticação necessária." }); return; }
  const parsed = ForwardUrgencyWhatsappBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Informe o card, a abertura e uma mensagem válida." }); return; }
  const { monoId, openingId, mode, customText, contentVariables } = parsed.data;
  try {
    const [snapshot] = await db.select({ state: pautaSnapshotsTable.state }).from(pautaSnapshotsTable).where(eq(pautaSnapshotsTable.id, "main"));
    if (!snapshot) { res.status(409).json({ error: "Salve o card antes de encaminhar." }); return; }
    let urgency: Record<string, unknown>, body: string;
    try {
      urgency = linkedUrgency(snapshot.state, monoId);
      body = mode === "template" ? "" : forwardingText(mode, customText, urgency, snapshot.state);
    } catch (error) { res.status(400).json({ error: (error as Error).message }); return; }
    const template = mode === "template" ? { contentSid: urgencyWhatsappTemplateSid(), variables: contentVariables } : undefined;
    if (template && !template.contentSid) {
      res.status(503).json({ error: "Modelo WhatsApp não configurado no servidor." }); return;
    }
    if (contentVariables && (Object.keys(contentVariables).length > 100 ||
      Object.entries(contentVariables).some(([key, value]) => !/^[1-9]\d*$/.test(key) || !value.trim() || value.length > 1500))) {
      res.status(400).json({ error: "Variáveis inválidas: use chaves numéricas e valores de texto preenchidos, com até 1.500 caracteres." }); return;
    }
    const [configRow] = await db.select({ state: pautaSnapshotsTable.state }).from(pautaSnapshotsTable).where(eq(pautaSnapshotsTable.id, "mensagens-twilio-config"));
    const config = coerceTwilioConfig(configRow?.state);
    if (!canaisDisponiveis(config).whatsapp) {
      res.status(503).json({ error: "WhatsApp não configurado: confira as credenciais Twilio e o número de origem em Configurações › Comunicação." }); return;
    }
    const key = `urgency-whatsapp:${openingId}`;
    const destination = urgencyWhatsappDestination();
    const payload = {
      status: "sending", monoId, urgencyId: urgency.id, processo: urgency.processo,
      recipient: destination.number, test: destination.test, text: body, mode,
      ...(template ? { contentSid: template.contentSid, contentVariables: template.variables || {} } : {}),
      by: session.userId, at: new Date().toISOString(),
    };
    const result = await forwardOnce(key, payload, {
      claim: async (id, state) => (await db.insert(pautaSnapshotsTable).values({ id, state, revision: 1 })
        .onConflictDoNothing().returning({ id: pautaSnapshotsTable.id })).length === 1,
      read: async (id) => {
        const [row] = await db.select({ state: pautaSnapshotsTable.state }).from(pautaSnapshotsTable)
          .where(eq(pautaSnapshotsTable.id, id));
        if (row?.state.monoId !== monoId || row?.state.by !== session.userId) throw new Error("Identificador de abertura já utilizado.");
        return row.state;
      },
      finish: async (id, state) => { await db.update(pautaSnapshotsTable).set({ state, updatedAt: new Date() }).where(eq(pautaSnapshotsTable.id, id)); },
      send: () => enviarTwilio("whatsapp", config.whatsappNumber, destination.number, body, template),
    });
    res.json({ status: "accepted", acceptedAt: result.acceptedAt, providerId: result.providerId,
      message: "Mensagem enviada à Twilio para encaminhamento por WhatsApp. A entrega ao destinatário ainda não foi confirmada." });
  } catch (error) {
    req.log.warn({ err: error }, "Urgency WhatsApp forwarding was not confirmed");
    res.status(502).json({ error: (error as Error).message || "O encaminhamento não foi confirmado. Não repita sem conferir o resultado." });
  }
});
export default router;

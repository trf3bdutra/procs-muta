import { createHash } from "node:crypto";
import {
  Router,
  type IRouter,
  type Request,
  type Response as ExpressResponse,
} from "express";
import { eq } from "drizzle-orm";
import { db, pautaSnapshotsTable } from "@workspace/db";
import {
  ConsultAgentMailInboxQueryParams,
  PreviewAgentMailSelectionQueryParams,
  ImportAgentMailSelectionBody,
  GetAgentMailRetentionAugust2026Response,
  DeleteAgentMailBeforeAugust2026Body,
  DeleteAgentMailBeforeAugust2026Response,
} from "@workspace/api-zod";
import { canAccessGlobalSettings, getAppSession } from "../lib/app-auth";
import { requireAdministration } from "../middlewares/account-auth";
import {
  agentMailConsultationPath,
  signAgentMailSelection,
  verifyAgentMailSelection,
  selectedAgentMailMessages,
} from "../lib/agentmail-consultation";
import {
  AGENTMAIL_COMUNICACAO_INBOX,
  agentMailCommunicationListPath,
  agentMailCommunicationRequest,
  AgentMailCommunicationError,
} from "../lib/agentmail-comunicacao";
import seedState from "../data/pauta-seed.json";
import {
  allowInboxMessages,
  agentMailRetentionSummary,
  coerceInbox,
  EMAIL_RETENTION_CUTOFF,
  emptyInbox,
  manualMessage,
  mergeAgentMailMessage,
  normalizeAgentMailMessage,
  patchMessage,
  removeAgentMailBeforeAugust2026,
  removeInboxMessages,
  sortInboxMessages,
  upsertMessage,
  verifySvixSignature,
  type InboxMessage,
  type InboxState,
} from "../lib/agentmail";
import {
  carlosMutaEvidence,
  isCarlosMutaRelatoria,
  manualLinkRejection,
  resolveCarlosMutaMessage,
} from "../lib/agentmail-carlos-muta";
import {
  corSolicitacao,
  linhaAlertaSolicitacao,
  lerSolicitacao,
  resumoSolicitacao,
} from "../lib/solicitacao";
import {
  avisar,
  canaisDisponiveis,
  emailValido,
  enviarEmail,
  enviarTwilio,
  telefoneE164,
  type Canal,
  type Destinatario,
} from "../lib/envio";
import {
  coerceTwilioConfig,
  normalizeTwilioMessage,
  verifyTwilioSignature,
} from "../lib/twilio";
import {
  buildSessionEmailIndex,
  classifySessionEmail,
  requireSingleActiveSession,
} from "../lib/agentmail-session-scope";
import { canAccessPautaSettings } from "../lib/pauta-settings-access";
import { publishAutomatedPautaChange } from "./pauta";

const router: IRouter = Router();
const INBOX_ROW = "mensagens-agentmail";
const MAIN_ROW = "main";
const CARLOS_MUTA_BACKFILL_ROW = "agentmail-carlos-muta-backfill";
const TWILIO_CONFIG_ROW = "mensagens-twilio-config";
const SECRET_CACHE_MS = 60_000;
const AGENTMAIL_API_ORIGIN = "https://api.agentmail.to";

let webhookSecretCache: { secret: string; expiresAt: number } | null = null;

async function agentMailRequest(
  path: string,
  options: RequestInit = {},
): Promise<Response> {
  const apiKey = process.env.AGENTMAIL_ENTRADA_KEY?.trim();
  if (!apiKey) {
    throw new Error("A chave de entrada do AgentMail não está configurada no servidor.");
  }
  const headers = new Headers(options.headers);
  headers.set("Authorization", `Bearer ${apiKey}`);
  return fetch(new URL(path, AGENTMAIL_API_ORIGIN), { ...options, headers });
}

async function canAccessMessageCenter(req: Request): Promise<boolean> {
  const session = getAppSession(req);
  if (!session) return false;
  if (canAccessGlobalSettings(session.role)) return true;
  const [row] = await db.select({ state: pautaSnapshotsTable.state })
    .from(pautaSnapshotsTable)
    .where(eq(pautaSnapshotsTable.id, MAIN_ROW));
  return canAccessPautaSettings(session, row?.state);
}

export async function requireMessageCenterAccess(req: Request, res: ExpressResponse): Promise<boolean> {
  if (!getAppSession(req)) {
    res.status(401).json({ error: "Entre novamente para acessar a Central de mensagens." });
    return false;
  }
  try {
    if (await canAccessMessageCenter(req)) return true;
  } catch (error) {
    req.log.error({ err: error }, "Could not validate access to the AgentMail message center");
    res.status(503).json({ error: "Não foi possível validar seu acesso agora. Tente novamente." });
    return false;
  }
  res.status(403).json({ error: "A Central de mensagens é restrita à Assessoria e à Administração." });
  return false;
}

function requireInboxRetentionAdmin(req: Request, res: ExpressResponse): boolean {
  const session = getAppSession(req);
  if (!session) {
    res.status(401).json({ error: "Entre novamente para administrar a caixa de mensagens." });
    return false;
  }
  if (!canAccessGlobalSettings(session.role)) {
    res.status(403).json({ error: "A limpeza do histórico da caixa é restrita à Administração." });
    return false;
  }
  return true;
}

export async function withInbox<T>(
  fn: (state: InboxState) => T | Promise<T>,
  write = true,
): Promise<T> {
  return db.transaction(async (tx) => {
    await tx
      .insert(pautaSnapshotsTable)
      .values({
        id: INBOX_ROW,
        state: emptyInbox() as unknown as Record<string, unknown>,
        revision: 1,
      })
      .onConflictDoNothing();

    const rows = write
      ? await tx
          .select()
          .from(pautaSnapshotsTable)
          .where(eq(pautaSnapshotsTable.id, INBOX_ROW))
          .for("update")
      : await tx
          .select()
          .from(pautaSnapshotsTable)
          .where(eq(pautaSnapshotsTable.id, INBOX_ROW));
    const row = rows[0];
    if (!row) throw new Error("A caixa compartilhada não pôde ser carregada.");

    const state = coerceInbox(row.state);
    const result = await fn(state);
    if (write) {
      await tx
        .update(pautaSnapshotsTable)
        .set({
          state: state as unknown as Record<string, unknown>,
          revision: row.revision + 1,
          updatedAt: new Date(),
        })
        .where(eq(pautaSnapshotsTable.id, INBOX_ROW));
    }
    return result;
  });
}

type Snapshot = { revision: number; state: Record<string, unknown> };

function record(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
}

function brazilDate(date: Date): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Cuiaba",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

function addDays(date: string, days: number): string {
  const parsed = new Date(`${date}T12:00:00.000Z`);
  parsed.setUTCDate(parsed.getUTCDate() + days);
  return parsed.toISOString().slice(0, 10);
}

function messageDate(date: string): string {
  const parsed = new Date(date);
  return Number.isNaN(parsed.getTime())
    ? ""
    : parsed.toLocaleString("pt-BR", {
        timeZone: "America/Cuiaba",
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
}

function dashboardAlert(
  state: Record<string, unknown>,
  id: string,
  title: string,
  text: string,
  now: Date,
): boolean {
  const preferences = record(state.pautaPreferences);
  const alerts = Array.isArray(preferences.globalDashboardAlerts)
    ? (preferences.globalDashboardAlerts as Record<string, unknown>[])
    : [];
  const start = brazilDate(now);
  const alert = {
    id,
    title,
    text,
    type: "Sessão",
    level: "atencao",
    start,
    end: addDays(start, 30),
    enabled: true,
    dashboard: true,
    notify: true,
    countUnread: true,
    everyone: true,
    recipients: [],
    order: 0,
    version: 1,
    createdAt: now.toISOString(),
    origem: "Central de mensagens · AgentMail",
  };
  const existing = alerts.findIndex((item) => item && item.id === id);
  if (existing >= 0) {
    const previous = record(alerts[existing]);
    if (
      previous.title === alert.title &&
      previous.text === alert.text &&
      previous.end === alert.end &&
      previous.enabled === true &&
      previous.dashboard === true &&
      previous.notify === true &&
      previous.everyone === true &&
      previous.countUnread === true
    ) {
      return false;
    }
    alerts[existing] = { ...previous, ...alert, createdAt: previous.createdAt ?? alert.createdAt };
  } else {
    alerts.unshift(alert);
  }
  preferences.globalDashboardAlerts = alerts;
  state.pautaPreferences = preferences;
  return true;
}

async function linkCarlosMutaMessage(
  messageId: string,
  manualSelection?: { processNumber: string; session: string; by: string },
): Promise<{
  handled: boolean;
  linked?: boolean;
  needsReview?: boolean;
  reason?: string;
}> {
  const result = await db.transaction(async (tx) => {
    await tx
      .insert(pautaSnapshotsTable)
      .values({
        id: INBOX_ROW,
        state: emptyInbox() as unknown as Record<string, unknown>,
        revision: 1,
      })
      .onConflictDoNothing();
    await tx
      .insert(pautaSnapshotsTable)
      .values({
        id: MAIN_ROW,
        state: seedState as Record<string, unknown>,
        revision: 1,
      })
      .onConflictDoNothing();

    const [inboxRow] = await tx
      .select()
      .from(pautaSnapshotsTable)
      .where(eq(pautaSnapshotsTable.id, INBOX_ROW))
      .for("update");
    const [pautaRow] = await tx
      .select()
      .from(pautaSnapshotsTable)
      .where(eq(pautaSnapshotsTable.id, MAIN_ROW))
      .for("update");
    if (!inboxRow || !pautaRow) return null;

    const inbox = coerceInbox(inboxRow.state);
    const message = inbox.messages.find((item) => item.id === messageId);
    if (!message) return { handled: false, reason: "A mensagem não está mais na caixa do app. Atualize a lista." };
    const rejected = manualLinkRejection(message, Boolean(manualSelection));
    if (rejected) return { handled: false, reason: rejected };

    const pautaState = record(pautaRow.state);
    const now = new Date();
    let association = manualSelection
      ? resolveCarlosMutaMessage(message, pautaState, manualSelection)
      : resolveCarlosMutaMessage(message, pautaState);
    if (!manualSelection && association.kind === "linked") {
      const scope = classifySessionEmail(
        message,
        buildSessionEmailIndex(pautaState, brazilDate(now)),
      );
      const activeSession = requireSingleActiveSession(scope, association.session);
      if (!activeSession.ok) {
        association = {
          kind: "review",
          processNumber: association.processNumber,
          reason: activeSession.reason,
        };
      }
    }
    if (association.kind === "ignore") return null;

    const previousStatus = message.status;
    const previousUpdatedBy = message.updatedBy;
    const previousOutcome = record(message.outcome);
    const actor = manualSelection?.by || "AgentMail automático";
    const noticeId = `agentmail-carlos-muta-${createHash("sha256")
      .update(message.id)
      .digest("hex")
      .slice(0, 24)}`;
    const before: Snapshot = {
      revision: pautaRow.revision,
      state: structuredClone(pautaState),
    };
    let pautaChanged = false;
    const processText =
      association.kind === "linked"
        ? `${association.formattedProcessNumber}${association.item ? ` · item ${association.item}` : ""}${association.session ? ` · sessão ${association.session}` : ""}`
        : association.processNumber
          ? association.processNumber
          : "processo ainda não identificado";

    if (association.kind === "linked") {
      const row = association.row;
      const allRows = Array.isArray(pautaState.rows)
        ? (pautaState.rows as Record<string, unknown>[])
        : [];
      /* A escolha manual pode corrigir um vínculo automático anterior.
         Retira só o vínculo desta mensagem do card antigo; o histórico fica
         preservado para auditoria. */
      if (manualSelection) {
        for (const previousRow of allRows) {
          if (previousRow === row) continue;
          const previousLinks = Array.isArray(previousRow._agentMailLinks)
            ? (previousRow._agentMailLinks as Record<string, unknown>[])
            : [];
          const removedLinks = previousLinks.filter((link) => link?.messageId === message.id);
          if (!removedLinks.length) continue;
          previousRow._agentMailLinks = previousLinks.filter(
            (link) => link?.messageId !== message.id,
          );
          const alertLines = String(previousRow.Alertas ?? "").split("\n");
          for (const oldLink of removedLinks) {
            const oldAlert = String(oldLink.alerta ?? "");
            const alertIndex = oldAlert ? alertLines.indexOf(oldAlert) : -1;
            if (alertIndex >= 0) alertLines.splice(alertIndex, 1);
          }
          previousRow.Alertas = alertLines.filter(Boolean).join("\n");
          const previousHistory = Array.isArray(previousRow._pautaHistory)
            ? (previousRow._pautaHistory as Record<string, unknown>[])
            : [];
          previousRow._pautaHistory = [
            ...previousHistory,
            {
              at: now.toISOString(),
              action: `Solicitação redirecionada para ${association.formattedProcessNumber}${association.session ? ` · sessão ${association.session}` : ""}`,
              session: String(record(message.outcome).sessao ?? ""),
              by: actor,
              sourceMessageId: message.id,
            },
          ];
          pautaChanged = true;
        }
      }
      const links = Array.isArray(row._agentMailLinks)
        ? (row._agentMailLinks as Record<string, unknown>[])
        : [];
      const existingLink = links.find((link) => link?.messageId === message.id);
      if (!existingLink) {
        /* a solicitação lida da mensagem vai para o card: tipo no título, quem pede e como falar com ele na descrição */
        const solicitacao = lerSolicitacao(message.subject, message.text || message.preview);
        const canal = message.source === "twilio"
          ? message.channel === "whatsapp" ? "WhatsApp" : "SMS"
          : "E-mail";
        row._agentMailLinks = [
          ...links,
          {
            messageId: message.id,
            receivedAt: message.receivedAt,
            relator: "Desembargador Carlos Muta",
            canal,
            solicitacao,
          },
        ];
        const resumo = resumoSolicitacao(solicitacao);
        const description = [
          `${canal} recebido em ${messageDate(message.receivedAt) || "data não informada"}`,
          resumo,
          "Consulte a Comunicação para ver a mensagem",
        ].filter(Boolean).join(" · ");
        const line = linhaAlertaSolicitacao(solicitacao, canal, description);
        const ultimo = (row._agentMailLinks as Record<string, unknown>[]).at(-1);
        if (ultimo) ultimo.alerta = line;
        const currentAlerts = String(row.Alertas ?? "").trim();
        row.Alertas = currentAlerts ? `${currentAlerts}\n${line}` : line;
        const history = Array.isArray(row._pautaHistory)
          ? (row._pautaHistory as Record<string, unknown>[])
          : [];
        row._pautaHistory = [
          ...history,
          {
            at: now.toISOString(),
            action: `${solicitacao.rotulo} (${canal}) vinculada ${manualSelection ? "manualmente" : "automaticamente"} · Relatoria Des. Carlos Muta`,
            session: association.session,
            by: actor,
            sourceMessageId: message.id,
          },
        ];
        pautaChanged = true;
      } else if (
        manualSelection &&
        (String(existingLink.session ?? "") !== association.session ||
          String(existingLink.processNumber ?? "") !== association.formattedProcessNumber)
      ) {
        existingLink.session = association.session;
        existingLink.processNumber = association.formattedProcessNumber;
        existingLink.item = association.item;
        const history = Array.isArray(row._pautaHistory)
          ? (row._pautaHistory as Record<string, unknown>[])
          : [];
        row._pautaHistory = [
          ...history,
          {
            at: now.toISOString(),
            action: `Vínculo da solicitação confirmado em ${association.formattedProcessNumber}${association.session ? ` · sessão ${association.session}` : ""}`,
            session: association.session,
            by: actor,
            sourceMessageId: message.id,
          },
        ];
        pautaChanged = true;
      }

      pautaChanged =
        dashboardAlert(
          pautaState,
          noticeId,
          manualSelection
            ? "E-mail do AgentMail vinculado ao processo"
            : "E-mail de sessão registrado automaticamente",
          `${processText} · Relatoria do Des. Carlos Muta. ${manualSelection ? "Vínculo feito pela equipe." : "Registrado automaticamente e aviso enviado ao CMT e à assessoria."} Consulte a Central de mensagens para ver o e-mail.`,
          now,
        ) || pautaChanged;
      message.status = "registrada";
      message.outcome = {
        ...record(message.outcome),
        autoCarlosMuta: true,
        ...(manualSelection ? { vinculadaManualmente: true } : {}),
        alertas: [lerSolicitacao(message.subject, message.text || message.preview).rotulo],
        solicitacao: lerSolicitacao(message.subject, message.text || message.preview),
        processo: association.formattedProcessNumber,
        item: association.item,
        sessao: association.session,
        lido: { processo: association.processNumber },
        em: now.toISOString(),
      };
    } else {
      const title = "E-mail do AgentMail precisa de conferência";
      const text = `Relatoria do Des. Carlos Muta · ${association.reason} Consulte a Central de mensagens para revisar a associação.`;
      pautaChanged = dashboardAlert(pautaState, noticeId, title, text, now);
      message.status = "pendente";
      message.outcome = {
        ...record(message.outcome),
        autoCarlosMuta: true,
        ...(manualSelection ? { vinculadaManualmente: true } : {}),
        motivo: association.reason,
        lido: association.processNumber
          ? { processo: association.processNumber }
          : {},
      };
    }

    const sameExistingOutcome =
      previousUpdatedBy === actor &&
      previousOutcome.autoCarlosMuta === true &&
      previousStatus === (association.kind === "linked" ? "registrada" : "pendente") &&
      (association.kind === "linked"
        ? previousOutcome.processo === association.formattedProcessNumber &&
          previousOutcome.sessao === association.session &&
          previousOutcome.item === association.item
        : previousOutcome.motivo === association.reason);
    if (
      sameExistingOutcome &&
      !pautaChanged &&
      (association.kind !== "linked" ||
        (Array.isArray(association.row._agentMailLinks) &&
          (association.row._agentMailLinks as Record<string, unknown>[]).some(
            (link) => link?.messageId === message.id,
          )))
    ) {
      /* Repetir o mesmo vínculo manual é uma operação idempotente, não um conflito. */
      return manualSelection
        ? { before: null, after: null, linked: true }
        : null;
    }

    message.updatedAt = now.toISOString();
    message.updatedBy = actor;
    await tx
      .update(pautaSnapshotsTable)
      .set({
        state: inbox as unknown as Record<string, unknown>,
        revision: inboxRow.revision + 1,
        updatedAt: now,
      })
      .where(eq(pautaSnapshotsTable.id, INBOX_ROW));

    let after: Snapshot | null = null;
    if (pautaChanged) {
      const [updated] = await tx
        .update(pautaSnapshotsTable)
        .set({
          state: pautaState,
          revision: pautaRow.revision + 1,
          updatedAt: now,
        })
        .where(eq(pautaSnapshotsTable.id, MAIN_ROW))
        .returning();
      if (updated) {
        after = { revision: updated.revision, state: updated.state };
      }
    }
    return {
      before: pautaChanged ? before : null,
      after,
      linked: association.kind === "linked",
      reason: association.kind === "review" ? association.reason : undefined,
    };
  });

  if (result?.before && result.after) {
    publishAutomatedPautaChange(result.before, result.after);
  }
  return result
    ? {
        handled: true,
        linked: result.linked,
        needsReview: !result.linked,
        ...(result.reason ? { reason: result.reason } : {}),
      }
    : { handled: false };
}

async function hydrateWebhookMessage(message: InboxMessage): Promise<InboxMessage> {
  if (message.text || !message.inboxId) return message;
  try {
    const response = await agentMailRequest(
      `/v0/inboxes/${encodeURIComponent(message.inboxId)}/messages/${encodeURIComponent(message.id)}`,
      { method: "GET", headers: { Accept: "application/json" } },
    );
    if (!response.ok) return message;
    const detail = (await response.json()) as Record<string, unknown>;
    const hydrated = normalizeAgentMailMessage({
      ...detail,
      inbox_id: detail.inbox_id ?? message.inboxId,
      message_id: detail.message_id ?? message.id,
    });
    return hydrated
      ? { ...hydrated, receivedAt: message.receivedAt || hydrated.receivedAt }
      : message;
  } catch {
    return message;
  }
}

async function readWebhookSecret(): Promise<string | null> {
  const configuredSecret = process.env.AGENTMAIL_WEBHOOK_SECRET?.trim();
  if (configuredSecret) return configuredSecret;

  const inbox = process.env.AGENTMAIL_INBOX_ID?.trim();
  const webhookId = process.env.AGENTMAIL_WEBHOOK_ID?.trim();
  if (!inbox || !webhookId) return null;
  if (webhookSecretCache && webhookSecretCache.expiresAt > Date.now()) {
    return webhookSecretCache.secret;
  }

  const response = await agentMailRequest(
    `/v0/inboxes/${encodeURIComponent(inbox)}/webhooks/${encodeURIComponent(webhookId)}`,
    { method: "GET", headers: { Accept: "application/json" } },
  );
  if (!response.ok) return null;

  const result = (await response.json()) as { secret?: unknown };
  if (typeof result.secret !== "string" || !result.secret) return null;
  webhookSecretCache = {
    secret: result.secret,
    expiresAt: Date.now() + SECRET_CACHE_MS,
  };
  return result.secret;
}

async function consultationContext(req: Request, res: ExpressResponse) {
  if (!(await requireMessageCenterAccess(req, res))) return null;
  const userId = getAppSession(req)?.userId;
  if (!userId) {
    res.status(401).json({ error: "Entre novamente para consultar a caixa." });
    return null;
  }
  const inboxId = process.env.AGENTMAIL_INBOX_ID?.trim();
  const secret = process.env.SESSION_SECRET || "";
  if (!inboxId || !secret) {
    res.status(503).json({ error: "A caixa de entrada ainda não está configurada." });
    return null;
  }
  return { inboxId, secret, userId };
}

async function consultationRequest(path: string, options: RequestInit = {}) {
  const response = await agentMailRequest(path, {
    ...options,
    signal: AbortSignal.timeout(20_000),
  });
  if (!response.ok) throw new Error(`AgentMail indisponível (HTTP ${response.status}).`);
  return response.json() as Promise<Record<string, unknown>>;
}

router.get("/pauta/mensagens/agentmail/consulta", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store, private");
  const context = await consultationContext(req, res);
  if (!context) return;
  const parsed = ConsultAgentMailInboxQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Busca ou paginação inválida." });
    return;
  }
  const query = parsed.data.q?.trim() || "";
  try {
    const data = await consultationRequest(
      agentMailConsultationPath(context.inboxId, query, parsed.data.pageToken),
      { headers: { Accept: "application/json" } },
    );
    const [local] = await db.select({ state: pautaSnapshotsTable.state })
      .from(pautaSnapshotsTable).where(eq(pautaSnapshotsTable.id, INBOX_ROW));
    const imported = new Set(coerceInbox(local?.state).messages.map((message) => message.id));
    const messages = (Array.isArray(data.messages) ? data.messages : []).flatMap((raw) => {
      const message = normalizeAgentMailMessage({ ...record(raw), inbox_id: context.inboxId });
      if (!message) return [];
      return [{
        id: message.id, from: message.from, subject: message.subject,
        preview: message.preview, receivedAt: message.receivedAt,
        imported: imported.has(message.id),
        selectionToken: signAgentMailSelection({
          inboxId: context.inboxId, messageId: message.id, query, userId: context.userId,
        }, context.secret),
      }];
    });
    res.json({
      inboxId: context.inboxId, query, messages,
      nextPageToken: typeof data.next_page_token === "string" && data.next_page_token
        ? data.next_page_token : null,
    });
  } catch (error) {
    req.log.error({ err: error }, "AgentMail read-only consultation failed");
    res.status(502).json({ error: "Não foi possível consultar o AgentMail. Nenhum e-mail foi importado. Tente novamente." });
  }
});

router.get("/pauta/mensagens/agentmail/preview", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store, private");
  const context = await consultationContext(req, res);
  if (!context) return;
  const parsed = PreviewAgentMailSelectionQueryParams.safeParse(req.query);
  const selection = parsed.success
    ? verifyAgentMailSelection(parsed.data.token, context.secret, context.userId, context.inboxId)
    : null;
  if (!selection) {
    res.status(400).json({ error: "A consulta expirou. Busque novamente." });
    return;
  }
  try {
    const raw = await consultationRequest(
      `/v0/inboxes/${encodeURIComponent(context.inboxId)}/messages/${encodeURIComponent(selection.messageId)}`,
      { headers: { Accept: "application/json" } },
    );
    const message = normalizeAgentMailMessage({
      ...raw, inbox_id: context.inboxId, message_id: selection.messageId,
    });
    if (!message) throw new Error("AgentMail returned an invalid message.");
    res.json({
      subject: message.subject, from: message.from, text: message.text || message.preview,
      receivedAt: message.receivedAt,
    });
  } catch (error) {
    req.log.error({ err: error }, "AgentMail remote preview failed");
    res.status(502).json({ error: "Não foi possível ler o e-mail no AgentMail." });
  }
});

router.post("/pauta/mensagens/agentmail/importar", async (req, res): Promise<void> => {
  const context = await consultationContext(req, res);
  if (!context) return;
  const parsed = ImportAgentMailSelectionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Informe a busca e selecione entre 1 e 50 resultados." });
    return;
  }
  let ids: string[];
  try {
    ids = selectedAgentMailMessages(
      parsed.data.selectionTokens, parsed.data.query,
      context.secret, context.userId, context.inboxId,
    );
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : "Seleção inválida." });
    return;
  }
  try {
    const data = await consultationRequest(
      `/v0/inboxes/${encodeURIComponent(context.inboxId)}/messages/batch-get`,
      {
        method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ message_ids: ids }),
      },
    );
    const expected = new Set(ids);
    const hydrated = new Map<string, InboxMessage>();
    for (const raw of Array.isArray(data.messages) ? data.messages : []) {
      const message = normalizeAgentMailMessage({ ...record(raw), inbox_id: context.inboxId });
      if (message && expected.has(message.id)) hydrated.set(message.id, message);
    }
    // All-or-nothing: do not persist a partial batch or an unselected provider result.
    if (hydrated.size !== expected.size) throw new Error("AgentMail did not return every selected message.");
    const result = await withInbox((state) => {
      const counts = { added: 0, updated: 0, unchanged: 0, total: 0 };
      allowInboxMessages(state, ids);
      for (const id of ids) {
        const result = mergeAgentMailMessage(state, hydrated.get(id)!, false);
        counts[result === "inserted" ? "added" : result === "updated" ? "updated" : "unchanged"] += 1;
      }
      sortInboxMessages(state);
      counts.total = state.messages.length;
      return counts;
    });
    res.json(result);
  } catch (error) {
    req.log.error({ err: error }, "AgentMail selected import failed");
    res.status(502).json({ error: "Não foi possível importar a seleção. Nenhuma importação parcial foi feita; tente novamente." });
  }
});

router.get("/pauta/mensagens/status", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  try {
    const allowed = await canAccessMessageCenter(req);
    const info = await withInbox(
      (state) => ({
        ...(allowed
          ? {
              count: state.messages.length,
              novas: state.messages.filter((message) => message.status === "nova").length,
              lastEventAt: state.lastEventAt || null,
              lastSyncAt: state.lastSyncAt || null,
            }
          : { lastEventAt: null, lastSyncAt: null }),
      }),
      false,
    );
    const inbox = process.env.AGENTMAIL_INBOX_ID || null;
    res.json({
      provider: "agentmail",
      /* Return only whether the server-side inbound key exists; never expose it. */
      apiKey: Boolean(process.env.AGENTMAIL_ENTRADA_KEY?.trim()),
      inbox,
      webhookSecret: Boolean(
        process.env.AGENTMAIL_WEBHOOK_SECRET || process.env.AGENTMAIL_WEBHOOK_ID,
      ),
      webhookPath: "/api/pauta/mensagens/agentmail/webhook",
      ...info,
    });
  } catch (error) {
    req.log.error({ err: error }, "Could not read the AgentMail inbox snapshot");
    res.status(500).json({ error: "Não foi possível ler a caixa de mensagens." });
  }
});

router.get("/pauta/mensagens", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  if (!(await canAccessMessageCenter(req).catch(() => false))) {
    res.json({
      messages: [],
      lastEventAt: null,
      lastSyncAt: null,
      now: new Date().toISOString(),
    });
    return;
  }

  const since = typeof req.query.since === "string" ? req.query.since : "";
  /* ?relator=carlos-muta: Caixa de entrada das Configurações, só e-mails cuja relatoria é do Des. Fed. Carlos Muta
     (Gab. A). As contagens dizem quantas mensagens ficaram de fora do filtro, sem expor o conteúdo delas. */
  const relator = typeof req.query.relator === "string" ? req.query.relator : "";
  const onlyCarlosMuta = relator === "carlos-muta";
  const includeAll = req.query.scope === "all";
  try {
    const [mainSnapshot] = await db
      .select({ state: pautaSnapshotsTable.state })
      .from(pautaSnapshotsTable)
      .where(eq(pautaSnapshotsTable.id, MAIN_ROW));
    const sessionIndex = buildSessionEmailIndex(
      record(mainSnapshot?.state),
      brazilDate(new Date()),
    );
    const result = await withInbox(
      (state) => {
        const inScope = onlyCarlosMuta
          ? state.messages.filter((message) => isCarlosMutaRelatoria(message))
          : state.messages;
        const classified = inScope.map((message) => ({
          ...message,
          canal: message.source === "twilio" ? message.channel || "sms" : "email",
          evidenciaGabineteA: carlosMutaEvidence(message),
          solicitacao: lerSolicitacao(message.subject, message.text || message.preview),
          relatoriaCarlosMuta: isCarlosMutaRelatoria(message),
          sessionScope: classifySessionEmail(message, sessionIndex),
        }));
        const related = includeAll ? classified : classified.filter(
          (message) => message.sessionScope.kind !== "unrelated",
        );
        return {
          messages: related
            .filter(
              (message) =>
                !since || message.updatedAt > since || message.receivedAt > since,
            ),
          sessionCounts: {
            sessions: classified.filter((message) => message.sessionScope.kind === "session").length,
            review: classified.filter((message) => message.sessionScope.kind === "review").length,
            excluded: classified.filter((message) => message.sessionScope.kind === "unrelated").length,
            total: state.messages.length,
          },
          ...(onlyCarlosMuta
            ? {
                filter: "carlos-muta",
                counts: {
                  total: state.messages.length,
                  inFilter: inScope.length,
                  outOfFilter: state.messages.length - inScope.length,
                },
              }
            : {}),
          lastEventAt: state.lastEventAt || null,
          lastSyncAt: state.lastSyncAt || null,
          now: new Date().toISOString(),
        };
      },
      false,
    );
    res.json(result);
  } catch (error) {
    req.log.error({ err: error }, "Could not list AgentMail messages");
    res.status(500).json({ error: "Não foi possível ler a caixa de mensagens." });
  }
});

router.post(
  "/pauta/mensagens/agentmail/webhook",
  async (
    req: Request & { rawBody?: Buffer },
    res,
  ): Promise<void> => {
    const rawBody = req.rawBody;
    if (!rawBody) {
      res.status(400).json({ error: "O corpo original do webhook não foi preservado." });
      return;
    }

    let secret: string | null;
    try {
      secret = await readWebhookSecret();
    } catch (error) {
      req.log.error({ err: error }, "Could not load the AgentMail webhook verifier");
      res.status(503).json({ error: "Não foi possível validar o webhook." });
      return;
    }
    if (!secret) {
      res.status(503).json({ error: "Webhook do AgentMail ainda não configurado." });
      return;
    }

    const signatureHeaders = {
      id: req.get("svix-id") || req.get("webhook-id") || "",
      timestamp: req.get("svix-timestamp") || req.get("webhook-timestamp") || "",
      signature: req.get("svix-signature") || req.get("webhook-signature") || "",
    };
    let valid = verifySvixSignature(secret, signatureHeaders, rawBody);
    if (!valid && !process.env.AGENTMAIL_WEBHOOK_SECRET) {
      webhookSecretCache = null;
      try {
        const refreshedSecret = await readWebhookSecret();
        if (refreshedSecret) {
          secret = refreshedSecret;
          valid = verifySvixSignature(secret, signatureHeaders, rawBody);
        }
      } catch {
        /* A bad signature remains a rejection; never trust the parsed payload. */
      }
    }
    if (!valid) {
      res.status(401).json({ error: "Assinatura inválida." });
      return;
    }

    const body = (req.body ?? {}) as Record<string, unknown>;
    const message =
      body.message && typeof body.message === "object"
        ? (body.message as Record<string, unknown>)
        : null;
    if (body.event_type !== "message.received" || !message) {
      res.json({ ok: true, ignored: true });
      return;
    }

    const inboxFilter = process.env.AGENTMAIL_INBOX_ID?.trim();
    const received = normalizeAgentMailMessage(message);
    if (!received || (inboxFilter && received.inboxId && received.inboxId !== inboxFilter)) {
      res.json({ ok: true, ignored: true });
      return;
    }

    try {
      const normalized = await hydrateWebhookMessage(received);
      const created = await withInbox((state) => {
        const added = upsertMessage(state, normalized);
        state.lastEventAt = new Date().toISOString();
        return added;
      });
      const automaticLink = await linkCarlosMutaMessage(normalized.id);
      req.log.info(
        {
          messageId: normalized.id,
          created,
          autoLinked: automaticLink.linked === true,
          needsReview: automaticLink.needsReview === true,
        },
        "AgentMail message received",
      );
      res.json({
        ok: true,
        created,
        autoLinked: automaticLink.linked === true,
        needsReview: automaticLink.needsReview === true,
      });
    } catch (error) {
      req.log.error(
        { err: error, messageId: received.id },
        "Could not store an AgentMail message",
      );
      res.status(500).json({ error: "Falha ao gravar a mensagem." });
    }
  },
);

/* ───────── SMS e WhatsApp (Twilio) ─────────
   Webhook público, autenticado pela assinatura X-Twilio-Signature com TWILIO_AUTH_TOKEN. Configure na Twilio
   (número SMS e remetente do WhatsApp) a URL https://<endereço>/api/pauta/mensagens/twilio/webhook, método POST. */
function publicUrl(req: Request): string {
  const proto = (req.get("x-forwarded-proto") || req.protocol || "https").split(",")[0].trim();
  const host = (req.get("x-forwarded-host") || req.get("host") || "").split(",")[0].trim();
  return `${proto}://${host}${req.originalUrl}`;
}

async function readTwilioConfig() {
  const [row] = await db
    .select({ state: pautaSnapshotsTable.state })
    .from(pautaSnapshotsTable)
    .where(eq(pautaSnapshotsTable.id, TWILIO_CONFIG_ROW));
  return coerceTwilioConfig(row?.state);
}

router.get("/pauta/mensagens/twilio/config", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  if (!(await requireMessageCenterAccess(req, res))) return;
  try {
    const config = await readTwilioConfig();
    const proto = (req.get("x-forwarded-proto") || req.protocol || "https").split(",")[0].trim();
    const host = (req.get("x-forwarded-host") || req.get("host") || "").split(",")[0].trim();
    res.json({
      ...config,
      /* só se o token e a conta existem no servidor; nunca o valor */
      tokenConfigured: Boolean(process.env.TWILIO_AUTH_TOKEN?.trim()),
      accountConfigured: Boolean(process.env.TWILIO_ACCOUNT_SID?.trim()),
      webhookUrl: process.env.TWILIO_WEBHOOK_URL?.trim() || `${proto}://${host}/api/pauta/mensagens/twilio/webhook`,
    });
  } catch (error) {
    req.log.error({ err: error }, "Could not read the Twilio settings");
    res.status(500).json({ error: "Não foi possível ler a configuração do SMS e WhatsApp." });
  }
});

router.put("/pauta/mensagens/twilio/config", requireAdministration, async (req, res): Promise<void> => {
  if (!(await requireMessageCenterAccess(req, res))) return;
  const body = (req.body ?? {}) as Record<string, unknown>;
  const config = coerceTwilioConfig({
    ...body,
    updatedAt: new Date().toISOString(),
    updatedBy: typeof body.by === "string" ? body.by : "",
  });
  if (config.ativo && !config.smsNumber && !config.whatsappNumber) {
    res.status(400).json({ error: "Informe ao menos um número (SMS ou WhatsApp) para ativar o canal." });
    return;
  }
  try {
    await db
      .insert(pautaSnapshotsTable)
      .values({ id: TWILIO_CONFIG_ROW, state: config as unknown as Record<string, unknown>, revision: 1 })
      .onConflictDoUpdate({
        target: pautaSnapshotsTable.id,
        set: { state: config as unknown as Record<string, unknown> },
      });
    res.json(config);
  } catch (error) {
    req.log.error({ err: error }, "Could not save the Twilio settings");
    res.status(500).json({ error: "Não foi possível gravar a configuração do SMS e WhatsApp." });
  }
});

/* ───────── Envio: e-mail (AgentMail), SMS e WhatsApp (Twilio) ───────── */
/* Histórico de saída compartilhado (o que o gabinete enviou por e-mail, SMS ou WhatsApp, inclusive avisos) */
const HISTORICO_ROW = "mensagens-historico-saida";
const HISTORICO_MAX = 600;
type Saida = {
  id: string; at: string; canal: Canal; para: string[]; assunto: string; texto: string;
  processo: string; by: string; origem: "envio" | "aviso"; ok: boolean; erro?: string;
};
function coerceSaidas(state: unknown): Saida[] {
  const lista = state && typeof state === "object" && Array.isArray((state as { saidas?: unknown }).saidas)
    ? (state as { saidas: unknown[] }).saidas : [];
  return lista.filter((x): x is Saida => Boolean(x && typeof x === "object" && typeof (x as Saida).id === "string"));
}
async function registrarSaidas(novas: Omit<Saida, "id" | "at">[]): Promise<void> {
  if (!novas.length) return;
  const agora = new Date().toISOString();
  const [row] = await db.select({ state: pautaSnapshotsTable.state }).from(pautaSnapshotsTable)
    .where(eq(pautaSnapshotsTable.id, HISTORICO_ROW));
  const itens = novas.map((n, i) => ({
    ...n, id: createHash("sha1").update(`${agora}|${i}|${n.canal}|${n.para.join(",")}|${n.assunto}`).digest("hex").slice(0, 16),
    at: agora, texto: n.texto.slice(0, 4000),
  }));
  const state = { saidas: [...itens, ...coerceSaidas(row?.state)].slice(0, HISTORICO_MAX) };
  await db.insert(pautaSnapshotsTable).values({ id: HISTORICO_ROW, state, revision: 1 })
    .onConflictDoUpdate({ target: pautaSnapshotsTable.id, set: { state } });
}

router.get("/pauta/mensagens/historico", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  if (!(await requireMessageCenterAccess(req, res))) return;
  try {
    const [row] = await db.select({ state: pautaSnapshotsTable.state }).from(pautaSnapshotsTable)
      .where(eq(pautaSnapshotsTable.id, HISTORICO_ROW));
    const grupo = String(req.query.canal ?? "");
    const saidas = coerceSaidas(row?.state).filter((s) =>
      grupo === "email" ? s.canal === "email" : grupo === "tel" ? s.canal !== "email" : true);
    res.json({ saidas });
  } catch (error) {
    req.log.error({ err: error }, "Could not read the outgoing history");
    res.status(500).json({ error: "Não foi possível ler o histórico de envios." });
  }
});

/* Caixa institucional separada das solicitações; leitura sob demanda, sem importar mensagens para o banco do app. */
router.get("/pauta/mensagens/email/caixa", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  if (!(await requireMessageCenterAccess(req, res))) return;
  const query = typeof req.query.q === "string" ? req.query.q.trim() : "";
  const pageToken = typeof req.query.pageToken === "string" ? req.query.pageToken : "";
  if (query.length > 200 || pageToken.length > 2_000) {
    res.status(400).json({ error: "A busca ou o marcador da página é inválido." });
    return;
  }
  try {
    const response = await agentMailCommunicationRequest(
      agentMailCommunicationListPath(query, pageToken),
    );
    const payload = await response.json() as Record<string, unknown>;
    const messages = Array.isArray(payload.messages) ? payload.messages : [];
    const address = (value: unknown): string => {
      const values = Array.isArray(value) ? value : value == null ? [] : [value];
      return values.map((item) => {
        if (typeof item === "string") return item;
        if (!item || typeof item !== "object") return "";
        const entry = item as Record<string, unknown>;
        const email = String(entry.email ?? entry.address ?? "").trim();
        const name = String(entry.name ?? "").trim();
        return name && email ? `${name} <${email}>` : email || name;
      }).filter(Boolean).join(", ");
    };
    res.json({
      inbox: AGENTMAIL_COMUNICACAO_INBOX,
      query,
      messages: messages.map((message) => {
        const item = message && typeof message === "object" ? message as Record<string, unknown> : {};
        const labels = Array.isArray(item.labels) ? item.labels.map(String) : [];
        return {
          id: String(item.message_id ?? ""),
          threadId: String(item.thread_id ?? ""),
          from: address(item.from),
          to: address(item.to),
          subject: String(item.subject ?? "(sem assunto)"),
          preview: String(item.preview ?? ""),
          timestamp: String(item.timestamp ?? item.created_at ?? ""),
          unread: labels.includes("unread"),
        };
      }).filter((message) => message.id),
      nextPageToken: typeof payload.next_page_token === "string" ? payload.next_page_token : null,
    });
  } catch (error) {
    const status = error instanceof AgentMailCommunicationError ? error.status : 502;
    req.log.warn({ status }, "Could not read the communication AgentMail inbox");
    res.status(status === 503 ? 503 : 502).json({
      error: status === 401 || status === 403
        ? `AgentMail negou acesso à caixa ${AGENTMAIL_COMUNICACAO_INBOX} (HTTP ${status}).`
        : status === 404
          ? `A caixa ${AGENTMAIL_COMUNICACAO_INBOX} não foi encontrada no AgentMail.`
          : status === 429
            ? "AgentMail limitou temporariamente a consulta. Tente novamente em instantes."
            : "Não foi possível consultar a caixa de e-mail do gabinete.",
    });
  }
});

router.get("/pauta/mensagens/email/caixa/mensagem", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  if (!(await requireMessageCenterAccess(req, res))) return;
  const messageId = typeof req.query.messageId === "string" ? req.query.messageId : "";
  if (!messageId || messageId.length > 500) {
    res.status(400).json({ error: "Informe o identificador da mensagem." });
    return;
  }
  try {
    const path = `/v0/inboxes/${encodeURIComponent(AGENTMAIL_COMUNICACAO_INBOX)}/messages/${encodeURIComponent(messageId)}`;
    const response = await agentMailCommunicationRequest(path);
    const payload = await response.json() as Record<string, unknown>;
    const address = (value: unknown): string => {
      const values = Array.isArray(value) ? value : value == null ? [] : [value];
      return values.map((item) => {
        if (typeof item === "string") return item;
        if (!item || typeof item !== "object") return "";
        const entry = item as Record<string, unknown>;
        const email = String(entry.email ?? entry.address ?? "").trim();
        const name = String(entry.name ?? "").trim();
        return name && email ? `${name} <${email}>` : email || name;
      }).filter(Boolean).join(", ");
    };
    res.json({
      inbox: AGENTMAIL_COMUNICACAO_INBOX,
      id: String(payload.message_id ?? messageId),
      from: address(payload.from),
      to: address(payload.to),
      cc: address(payload.cc),
      subject: String(payload.subject ?? "(sem assunto)"),
      timestamp: String(payload.timestamp ?? payload.created_at ?? ""),
      text: String(payload.text ?? payload.extracted_text ?? payload.preview ?? ""),
      attachments: Array.isArray(payload.attachments)
        ? payload.attachments.map((file) => {
            const item = file && typeof file === "object" ? file as Record<string, unknown> : {};
            return { name: String(item.filename ?? "Anexo"), size: Number(item.size ?? 0) };
          })
        : [],
    });
  } catch (error) {
    const status = error instanceof AgentMailCommunicationError ? error.status : 502;
    req.log.warn({ status }, "Could not read a communication email");
    res.status(status === 404 ? 404 : status === 503 ? 503 : 502).json({
      error: status === 404
        ? "Esta mensagem não foi encontrada na caixa gabinete-cmt."
        : status === 401 || status === 403
          ? `AgentMail negou acesso à caixa ${AGENTMAIL_COMUNICACAO_INBOX} (HTTP ${status}).`
          : "Não foi possível abrir esta mensagem.",
    });
  }
});

router.get("/pauta/mensagens/canais", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  if (!(await requireMessageCenterAccess(req, res))) return;
  const config = await readTwilioConfig().catch(() => coerceTwilioConfig({}));
  res.json({ canais: canaisDisponiveis(config.ativo ? config : {}), caixaEmail: AGENTMAIL_COMUNICACAO_INBOX });
});

/* Saída da Comunicação: uma mensagem para endereços ou telefones digitados (o painel já chamava esta rota). */
router.post("/pauta/mensagens/enviar", async (req, res): Promise<void> => {
  if (!(await requireMessageCenterAccess(req, res))) return;
  const body = (req.body ?? {}) as Record<string, unknown>;
  const canal = (["email", "sms", "whatsapp"].includes(String(body.canal)) ? String(body.canal) : "email") as Canal;
  const para = (Array.isArray(body.to) ? body.to : [body.to]).map((v) => String(v ?? "").trim()).filter(Boolean).slice(0, 50);
  const assunto = String(body.subject ?? "").trim().slice(0, 250);
  const texto = String(body.text ?? "").trim().slice(0, 20_000);
  if (!para.length || !texto || (canal === "email" && !assunto)) {
    res.status(400).json({ error: "Informe destinatário, assunto (no e-mail) e mensagem." });
    return;
  }
  try {
    if (canal === "email") {
      const invalidos = para.filter((e) => !emailValido(e));
      if (invalidos.length) { res.status(400).json({ error: `E-mail inválido: ${invalidos.join(", ")}` }); return; }
      const idempotencyKey = typeof body.idempotencyKey === "string"
        && /^[A-Za-z0-9._~-]{1,128}$/.test(body.idempotencyKey)
        ? body.idempotencyKey
        : undefined;
      await enviarEmail(para, assunto, texto, idempotencyKey);
    } else {
      const config = await readTwilioConfig();
      const de = canal === "whatsapp" ? config.whatsappNumber : config.smsNumber;
      for (const t of para) await enviarTwilio(canal, de, telefoneE164(t), assunto ? `${assunto}\n${texto}` : texto);
    }
    await registrarSaidas([{ canal, para, assunto, texto, processo: String(body.processNumber ?? ""), by: String(body.by ?? ""), origem: "envio", ok: true }])
      .catch((err) => req.log.warn({ err }, "Could not record the outgoing history"));
    res.json({ ok: true, canal, enviados: para.length });
  } catch (error) {
    req.log.warn({ err: error, canal }, "Could not send a message");
    await registrarSaidas([{ canal, para, assunto, texto, processo: String(body.processNumber ?? ""), by: String(body.by ?? ""), origem: "envio", ok: false, erro: (error as Error).message }])
      .catch(() => undefined);
    res.status(502).json({ error: (error as Error).message });
  }
});

/* Avisos: o mesmo texto para várias pessoas por e-mail, SMS e/ou WhatsApp, conforme os contatos de cada uma. */
router.post("/pauta/mensagens/avisar", async (req, res): Promise<void> => {
  if (!(await requireMessageCenterAccess(req, res))) return;
  const body = (req.body ?? {}) as Record<string, unknown>;
  const canais = (Array.isArray(body.canais) ? body.canais : [])
    .map(String).filter((c): c is Canal => c === "email" || c === "sms" || c === "whatsapp");
  const destinatarios = (Array.isArray(body.destinatarios) ? body.destinatarios : [])
    .slice(0, 100)
    .map((d) => d && typeof d === "object" ? (d as Destinatario) : {});
  const titulo = String(body.titulo ?? "").trim().slice(0, 200);
  const texto = String(body.texto ?? "").trim().slice(0, 4_000);
  if (!canais.length || !destinatarios.length || !titulo || !texto) {
    res.status(400).json({ error: "Informe título, mensagem, canais e destinatários." });
    return;
  }
  try {
    const config = await readTwilioConfig();
    const resultado = await avisar(canais, destinatarios, titulo, texto, config.ativo ? config : {});
    await registrarSaidas(resultado.map((x) => ({
      canal: x.canal, para: [x.para], assunto: titulo, texto, processo: "", by: String(body.by ?? ""),
      origem: "aviso" as const, ok: x.ok, ...(x.erro ? { erro: x.erro } : {}),
    }))).catch((err) => req.log.warn({ err }, "Could not record the notice history"));
    res.json({
      enviados: resultado.filter((r) => r.ok).length,
      falhas: resultado.filter((r) => !r.ok).map((r) => ({ canal: r.canal, para: r.para, erro: r.erro })),
    });
  } catch (error) {
    req.log.error({ err: error }, "Could not send notices");
    res.status(500).json({ error: "Não foi possível enviar os avisos." });
  }
});

router.post("/pauta/mensagens/twilio/webhook", async (req, res): Promise<void> => {
  const token = process.env.TWILIO_AUTH_TOKEN?.trim();
  if (!token) {
    res.status(503).type("text/plain").send("Twilio ainda não configurada.");
    return;
  }
  const params = (req.body ?? {}) as Record<string, unknown>;
  /* a Twilio assina a URL exata cadastrada nela; atrás do proxy, a URL de TWILIO_WEBHOOK_URL é a referência */
  const assinatura = req.get("x-twilio-signature") || "";
  const urls = [process.env.TWILIO_WEBHOOK_URL?.trim(), publicUrl(req)].filter((u): u is string => Boolean(u));
  if (!urls.some((u) => verifyTwilioSignature(token, u, params, assinatura))) {
    res.status(403).type("text/plain").send("Assinatura inválida.");
    return;
  }
  const empty = '<?xml version="1.0" encoding="UTF-8"?><Response></Response>';
  try {
    const config = await readTwilioConfig();
    const received = normalizeTwilioMessage(params);
    const to = String(params.To ?? "").replace(/^whatsapp:/i, "");
    const ours = [config.smsNumber, config.whatsappNumber].filter(Boolean);
    /* canal desligado ou número que não é o do gabinete: aceita e ignora (a Twilio não deve reenviar) */
    if (!received || !config.ativo || (ours.length && !ours.includes(to))) {
      res.type("text/xml").send(empty);
      return;
    }
    const created = await withInbox((state) => {
      const added = upsertMessage(state, received);
      state.lastEventAt = new Date().toISOString();
      return added;
    });
    const automaticLink = await linkCarlosMutaMessage(received.id);
    req.log.info(
      { messageId: received.id, channel: received.channel, created, autoLinked: automaticLink.linked === true },
      "Twilio message received",
    );
    res.type("text/xml").send(empty);
  } catch (error) {
    req.log.error({ err: error }, "Could not store a Twilio message");
    res.status(500).type("text/plain").send("Falha ao gravar a mensagem.");
  }
});

router.post("/pauta/mensagens/sync", async (req, res): Promise<void> => {
  if (!(await requireMessageCenterAccess(req, res))) return;
  // Old cached clients must not silently import the entire mailbox.
  res.status(409).json({
    error: "A importação integral foi desativada. Use Consultar e selecionar no AgentMail, aplique uma busca e adicione somente os e-mails selecionados.",
  });
});

router.post("/pauta/mensagens/:id/carlos-muta-link", async (req, res): Promise<void> => {
  if (!(await requireMessageCenterAccess(req, res))) return;
  const body = record(req.body);
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const processNumber = String(body.processNumber ?? "").replace(/\D/g, "");
  const session = String(body.session ?? "").trim();
  const by = String(body.by ?? "Equipe").trim().slice(0, 120) || "Equipe";
  if (processNumber.length !== 20 || !/^\d{2}\/\d{2}\/\d{4}$/.test(session)) {
    res.status(400).json({
      error: "Informe o número CNJ completo e a data da sessão para vincular o e-mail.",
    });
    return;
  }
  try {
    const linked = await linkCarlosMutaMessage(String(rawId), {
      processNumber,
      session,
      by,
    });
    if (!linked.handled || !linked.linked) {
      res.status(linked.handled ? 422 : 409).json({
        error:
          linked.reason ??
          "A mensagem já foi tratada ou não pôde ser vinculada a esse card.",
      });
      return;
    }
    res.json({ ok: true, linked: true });
  } catch (error) {
    req.log.error({ err: error }, "Could not manually link Carlos Muta message");
    res.status(500).json({ error: "Falha ao vincular o e-mail ao processo." });
  }
});

router.post("/pauta/mensagens", async (req, res): Promise<void> => {
  if (!(await requireMessageCenterAccess(req, res))) return;
  const message = manualMessage((req.body ?? {}) as Record<string, unknown>);
  if (!message) {
    res.status(400).json({ error: "Cole o texto da mensagem." });
    return;
  }

  try {
    await withInbox((state) => upsertMessage(state, message));
    req.log.info({ messageId: message.id, source: "manual" }, "Manual inbox message added");
    res.json({ ok: true, message });
  } catch (error) {
    req.log.error({ err: error }, "Could not store a manual inbox message");
    res.status(500).json({ error: "Falha ao gravar a mensagem." });
  }
});

router.get("/pauta/mensagens/retencao/agosto-2026", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  if (!requireInboxRetentionAdmin(req, res)) return;
  try {
    const summary = await withInbox(agentMailRetentionSummary, false);
    res.json(
      GetAgentMailRetentionAugust2026Response.parse({
        cutoff: EMAIL_RETENTION_CUTOFF,
        ...summary,
      }),
    );
  } catch (error) {
    req.log.error({ err: error }, "Could not read AgentMail retention counts");
    res.status(500).json({ error: "Não foi possível conferir a caixa local." });
  }
});

router.post("/pauta/mensagens/retencao/agosto-2026", async (req, res): Promise<void> => {
  if (!requireInboxRetentionAdmin(req, res)) return;
  const parsed = DeleteAgentMailBeforeAugust2026Body.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Confirme a data fixa de corte: 01/08/2026." });
    return;
  }
  try {
    const result = await withInbox(removeAgentMailBeforeAugust2026);
    const response = DeleteAgentMailBeforeAugust2026Response.parse({
      cutoff: EMAIL_RETENTION_CUTOFF,
      ...result,
    });
    req.log.info(
      { deletedCount: response.deleted, remainingEmails: response.total },
      "Pre-August 2026 AgentMail messages removed from the local app inbox",
    );
    res.json(response);
  } catch (error) {
    req.log.error({ err: error }, "Could not prune old AgentMail messages");
    res.status(500).json({ error: "Não foi possível limpar as mensagens antigas da caixa local." });
  }
});

/* Exclusão em lote: só da caixa do app (a cópia no AgentMail fica); os ids excluídos não voltam pela sincronização. */
router.delete("/pauta/mensagens", async (req, res): Promise<void> => {
  if (!(await requireMessageCenterAccess(req, res))) return;
  const rawIds = ((req.body ?? {}) as Record<string, unknown>).ids;
  if (!Array.isArray(rawIds) || rawIds.length < 1 || rawIds.length > 500 ||
      !rawIds.every((id) => typeof id === "string" && id.trim().length > 0 && id.length <= 500)) {
    res.status(400).json({ error: "Selecione entre 1 e 500 mensagens para excluir." });
    return;
  }
  const ids = [...new Set((rawIds as string[]).map((id) => id.trim()))];
  try {
    const result = await withInbox((state) => removeInboxMessages(state, ids));
    req.log.info({ deletedCount: result.deletedIds.length, missingCount: result.notFoundIds.length }, "Messages removed from the application inbox");
    res.json({
      ok: true,
      deleted: result.deletedIds.length,
      deletedIds: result.deletedIds,
      notFound: result.notFoundIds.length,
    });
  } catch (error) {
    req.log.error({ err: error }, "Could not delete messages from the application inbox");
    res.status(500).json({ error: "Não foi possível excluir as mensagens da caixa do app." });
  }
});

router.patch("/pauta/mensagens/:id", async (req, res): Promise<void> => {
  if (!(await requireMessageCenterAccess(req, res))) return;
  const body = (req.body ?? {}) as Record<string, unknown>;
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  try {
    const result = await withInbox((state) =>
      patchMessage(
        state,
        String(rawId),
        {
          status: typeof body.status === "string" ? body.status : undefined,
          outcome:
            body.outcome && typeof body.outcome === "object"
              ? (body.outcome as Record<string, unknown>)
              : undefined,
          by: typeof body.by === "string" ? body.by : undefined,
        },
        typeof body.ifStatus === "string" ? body.ifStatus : undefined,
      ),
    );
    if (!result.ok) {
      const error =
        result.code === 409
          ? "A mensagem já foi tratada por outro navegador."
          : result.code === 404
            ? "Mensagem não encontrada."
            : "Situação inválida.";
      res.status(result.code).json({ error, message: result.message });
      return;
    }

    req.log.info(
      { messageId: result.message.id, status: result.message.status },
      "AgentMail message triage updated",
    );
    res.json({ ok: true, message: result.message });
  } catch (error) {
    req.log.error({ err: error }, "Could not update AgentMail message triage");
    res.status(500).json({ error: "Falha ao atualizar a mensagem." });
  }
});

async function backfillImportedCarlosMutaMessages(): Promise<void> {
  try {
    await db
      .insert(pautaSnapshotsTable)
      .values({
        id: CARLOS_MUTA_BACKFILL_ROW,
        state: { status: "pending" },
        revision: 1,
      })
      .onConflictDoNothing();
    const [marker] = await db
      .select()
      .from(pautaSnapshotsTable)
      .where(eq(pautaSnapshotsTable.id, CARLOS_MUTA_BACKFILL_ROW));
    if (!marker || record(marker.state).completedAt) return;

    const messageIds = await withInbox(
      (state) =>
        state.messages
          .filter(
            (message) =>
              message.source === "agentmail" &&
              ["nova", "pendente", "registrada"].includes(message.status) &&
              isCarlosMutaRelatoria(message),
          )
          .map((message) => message.id),
      false,
    );

    let linked = 0;
    let needsReview = 0;
    for (const messageId of messageIds) {
      const result = await linkCarlosMutaMessage(messageId);
      if (result.linked) linked += 1;
      if (result.needsReview) needsReview += 1;
    }

    const completedAt = new Date().toISOString();
    await db
      .update(pautaSnapshotsTable)
      .set({
        state: {
          status: "completed",
          completedAt,
          scanned: messageIds.length,
          linked,
          needsReview,
        },
        revision: marker.revision + 1,
        updatedAt: new Date(completedAt),
      })
      .where(eq(pautaSnapshotsTable.id, CARLOS_MUTA_BACKFILL_ROW));
    console.info("AgentMail Carlos Muta historical scan completed", {
      scanned: messageIds.length,
      linked,
      needsReview,
    });
  } catch (error) {
    console.warn("AgentMail Carlos Muta historical scan could not complete", error);
  }
}

const backfillTimer = setTimeout(() => {
  void backfillImportedCarlosMutaMessages();
}, 1_500);
backfillTimer.unref();

export default router;

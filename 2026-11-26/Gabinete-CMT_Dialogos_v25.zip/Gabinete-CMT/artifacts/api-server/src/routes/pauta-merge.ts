type JsonRecord = Record<string, unknown>;
type Missing = { __missing: true };
type MergeValue = unknown | Missing;

const MISSING: Missing = { __missing: true };

export type PautaConflict = {
  path: (string | number)[];
  localExists: boolean;
  localValue?: unknown;
  remoteExists: boolean;
  remoteValue?: unknown;
};

export type PautaMergeResult = {
  state: JsonRecord;
  conflicts: PautaConflict[];
};

function isMissing(value: MergeValue): value is Missing {
  return (
    typeof value === "object" &&
    value !== null &&
    "__missing" in value &&
    value.__missing === true
  );
}

function clone<T>(value: T): T {
  if (value === undefined) return value;
  return JSON.parse(JSON.stringify(value)) as T;
}

function isRecord(value: unknown): value is JsonRecord {
  return (
    typeof value === "object" &&
    value !== null &&
    !Array.isArray(value)
  );
}

function equal(a: MergeValue, b: MergeValue): boolean {
  if (isMissing(a) || isMissing(b)) return isMissing(a) && isMissing(b);
  if (Object.is(a, b)) return true;
  if (Array.isArray(a) && Array.isArray(b)) {
    return a.length === b.length && a.every((item, i) => equal(item, b[i]));
  }
  if (!isRecord(a) || !isRecord(b)) return false;
  const aKeys = Object.keys(a);
  if (aKeys.length !== Object.keys(b).length) return false;
  return aKeys.every(
    (key) => Object.prototype.hasOwnProperty.call(b, key) && equal(a[key], b[key]),
  );
}

export function pautaStateEqual(
  first: Record<string, unknown>,
  second: Record<string, unknown>,
): boolean {
  return equal(first, second);
}

export function protectSharedGabnetState(
  baseState: Record<string, unknown>,
  currentState: Record<string, unknown>,
  nextState: Record<string, unknown>,
  role: string | undefined,
): { state: Record<string, unknown>; forbidden: boolean } {
  const basePreferences = isRecord(baseState.pautaPreferences)
    ? baseState.pautaPreferences
    : {};
  const currentPreferences = isRecord(currentState.pautaPreferences)
    ? currentState.pautaPreferences
    : {};
  const nextPreferences = isRecord(nextState.pautaPreferences)
    ? nextState.pautaPreferences
    : {};
  const has = (record: JsonRecord, key: string) =>
    Object.prototype.hasOwnProperty.call(record, key);
  const gabnetWasChanged =
    has(nextPreferences, "gabnet") &&
    (!has(basePreferences, "gabnet") ||
      !equal(nextPreferences.gabnet, basePreferences.gabnet));

  if (
    role !== "administracao" && role !== "editor" &&
    gabnetWasChanged &&
    (!has(currentPreferences, "gabnet") ||
      !equal(nextPreferences.gabnet, currentPreferences.gabnet))
  ) {
    return { state: nextState, forbidden: true };
  }

  const preferences = { ...nextPreferences };
  if (!gabnetWasChanged) {
    if (has(currentPreferences, "gabnet")) {
      preferences.gabnet = currentPreferences.gabnet;
    } else {
      delete preferences.gabnet;
    }
  }
  if (has(currentPreferences, "gabnetGame")) {
    preferences.gabnetGame = currentPreferences.gabnetGame;
  } else {
    delete preferences.gabnetGame;
  }
  if (has(currentPreferences, "gabnetWorld")) {
    preferences.gabnetWorld = currentPreferences.gabnetWorld;
  } else {
    delete preferences.gabnetWorld;
  }

  return {
    state: { ...nextState, pautaPreferences: preferences },
    forbidden: false,
  };
}

function identity(value: unknown): string | null {
  if (!isRecord(value)) return null;
  const processNumber = value["Processo"];
  if (typeof processNumber === "string" && processNumber) {
    const entries = Array.isArray(value._pautaEntries) ? value._pautaEntries : [];
    const sessions = entries
      .map((entry) =>
        isRecord(entry) && typeof entry.session === "string" && entry.session
          ? entry.session
          : null,
      )
      .filter((session): session is string => session !== null);
    const destination = value["Sessão Destino"];
    if (typeof destination === "string" && destination) sessions.push(destination);
    const scope = [...new Set(sessions)].sort();
    return `process:${processNumber}:${JSON.stringify(scope)}`;
  }
  const id = value["id"];
  if (typeof id === "string" || typeof id === "number") {
    return `id:${String(id)}`;
  }
  return null;
}

function putOrDelete(target: JsonRecord, key: string, value: MergeValue): void {
  if (isMissing(value)) delete target[key];
  else target[key] = clone(value);
}

function mergeKeyedArray(
  base: unknown[],
  local: unknown[],
  remote: unknown[],
  path: (string | number)[],
  conflicts: PautaConflict[],
): unknown[] | null {
  const all = [...base, ...local, ...remote];
  if (!all.every((item) => identity(item) !== null)) return null;

  const toMap = (items: unknown[]) =>
    new Map(items.map((item) => [identity(item)!, item] as const));
  const baseMap = toMap(base);
  const localMap = toMap(local);
  const remoteMap = toMap(remote);
  const orderedIds = [
    ...remote.map((item) => identity(item)!),
    ...local.map((item) => identity(item)!),
    ...base.map((item) => identity(item)!),
  ];
  const ids = [...new Set(orderedIds)];
  const result: unknown[] = [];

  for (const id of ids) {
    const b: MergeValue = baseMap.has(id) ? baseMap.get(id)! : MISSING;
    const l: MergeValue = localMap.has(id) ? localMap.get(id)! : MISSING;
    const r: MergeValue = remoteMap.has(id) ? remoteMap.get(id)! : MISSING;
    const item = mergeValue(b, l, r, [...path, result.length], conflicts);
    if (!isMissing(item)) result.push(item);
  }
  return result;
}

function mergeValue(
  base: MergeValue,
  local: MergeValue,
  remote: MergeValue,
  path: (string | number)[],
  conflicts: PautaConflict[],
): MergeValue {
  if (equal(local, base)) return isMissing(remote) ? MISSING : clone(remote);
  if (equal(remote, base)) return isMissing(local) ? MISSING : clone(local);
  if (equal(local, remote)) return isMissing(local) ? MISSING : clone(local);

  if (
    !isMissing(base) &&
    !isMissing(local) &&
    !isMissing(remote) &&
    Array.isArray(base) &&
    Array.isArray(local) &&
    Array.isArray(remote)
  ) {
    const keyed = mergeKeyedArray(base, local, remote, path, conflicts);
    if (keyed) return keyed;

    const length = Math.max(base.length, local.length, remote.length);
    const merged: unknown[] = [];
    for (let index = 0; index < length; index += 1) {
      const b: MergeValue = index < base.length ? base[index] : MISSING;
      const l: MergeValue = index < local.length ? local[index] : MISSING;
      const r: MergeValue = index < remote.length ? remote[index] : MISSING;
      const value = mergeValue(b, l, r, [...path, index], conflicts);
      if (!isMissing(value)) merged.push(value);
    }
    return merged;
  }

  if (
    !isMissing(base) &&
    !isMissing(local) &&
    !isMissing(remote) &&
    isRecord(base) &&
    isRecord(local) &&
    isRecord(remote)
  ) {
    const keys = new Set([
      ...Object.keys(base),
      ...Object.keys(local),
      ...Object.keys(remote),
    ]);
    const merged: JsonRecord = {};
    for (const key of keys) {
      const b: MergeValue = key in base ? base[key] : MISSING;
      const l: MergeValue = key in local ? local[key] : MISSING;
      const r: MergeValue = key in remote ? remote[key] : MISSING;
      putOrDelete(merged, key, mergeValue(b, l, r, [...path, key], conflicts));
    }
    return merged;
  }

  conflicts.push({
    path,
    localExists: !isMissing(local),
    ...(!isMissing(local) ? { localValue: clone(local) } : {}),
    remoteExists: !isMissing(remote),
    ...(!isMissing(remote) ? { remoteValue: clone(remote) } : {}),
  });
  return isMissing(remote) ? MISSING : clone(remote);
}

export function mergePautaStates(
  base: JsonRecord,
  local: JsonRecord,
  remote: JsonRecord,
): PautaMergeResult {
  const conflicts: PautaConflict[] = [];
  const state = mergeValue(base, local, remote, [], conflicts);
  if (!isRecord(state)) {
    throw new Error("The merged docket state must be an object.");
  }
  return { state, conflicts };
}

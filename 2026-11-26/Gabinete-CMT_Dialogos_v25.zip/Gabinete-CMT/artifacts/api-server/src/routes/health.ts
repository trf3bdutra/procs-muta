import { Router, type IRouter } from "express";
import { HealthCheckResponse } from "@workspace/api-zod";

const router: IRouter = Router();

const respondHealth = (_req: unknown, res: any) => {
  const data = HealthCheckResponse.parse({ status: "ok" });
  res.json(data);
};

/* The artifact router probes the service root (/api), while standalone checks
   use /api/healthz. Keep both paths healthy. */
router.get("/", respondHealth);
router.get("/healthz", respondHealth);

export default router;

import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import pautaRouter from "./pauta";
import acervoRouter from "./acervo";
import acervoImportadoRouter from "./acervo-importado";
import pautaMensagensRouter from "./pauta-mensagens";
import twilioMessagesRouter from "./twilio-messages";
import urgencyWhatsappRouter from "./urgency-whatsapp";
import padraoRouter from "../lib/padrao";
import { requireApprovedAccount } from "../middlewares/account-auth";
import gabcmtRouter from "./gabcmt";
import paradigmasRouter from "./paradigmas";
import generatorLibraryRouter from "./generator-library";
import generatorCatalogsRouter from "./generator-catalogs";
import cmEmentarioRouter from "./cm-ementario";
import datajudRouter, { datajudCronRouter } from "./datajud";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
// Gatilho externo da agenda do DataJud: autenticado pelo DATAJUD_CRON_TOKEN, não pelo login.
router.use(datajudCronRouter);
router.use((req, res, next) => {
  // AgentMail authenticates this inbound webhook with its own signature.
  // A Twilio (SMS e WhatsApp) também: X-Twilio-Signature conferida na própria rota.
  if ((req.method === "POST" && (req.path === "/pauta/mensagens/agentmail/webhook" ||
      req.path === "/pauta/mensagens/twilio/webhook")) ||
      (req.method === "GET" && req.path === "/pauta/urgencias/whatsapp-image")) {
    next();
    return;
  }

  void requireApprovedAccount(req, res, next);
});
router.use(gabcmtRouter);
// Paradigmas: somente leitura; sem a cópia local do banco, responde 503 com mensagem clara (antes caía em 404).
router.use(paradigmasRouter);
router.use(generatorLibraryRouter);
router.use(generatorCatalogsRouter);
router.use(cmEmentarioRouter);
router.use(pautaRouter);
router.use(urgencyWhatsappRouter);
router.use(acervoRouter);
router.use(acervoImportadoRouter);
router.use(pautaMensagensRouter);
// consulta, vínculo e envio manual da Twilio (config e webhook ficam na rota da Comunicação, registrada antes)
router.use(twilioMessagesRouter);
// antes do padrão: /datajud/consulta, /estado etc. não podem cair em POST /datajud/:tribunal
router.use(datajudRouter);
router.use(padraoRouter);

export default router;
import app from "./app";
import { logger } from "./lib/logger";
import { iniciarAgendaDataJud } from "./lib/datajud-servico";
import { syncPautaGoogleSheetsIfLayoutOutdated } from "./routes/pauta";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  iniciarAgendaDataJud();
  void syncPautaGoogleSheetsIfLayoutOutdated()
    .then((status) => {
      if (!status) return;
      logger.info(
        { revision: status.lastSyncedRevision, processCount: status.processCount, sessionCount: status.sessionCount },
        "Google Sheets workbook layout updated",
      );
    })
    .catch((error) => {
      logger.warn({ err: error }, "Could not update Google Sheets workbook layout");
    });
});

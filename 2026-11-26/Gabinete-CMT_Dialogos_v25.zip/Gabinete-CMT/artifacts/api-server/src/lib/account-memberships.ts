import { randomUUID } from "node:crypto";
import { eq, and, sql, isNotNull } from "drizzle-orm";
import { db, accountMembershipsTable as accounts, accountAuditTable as audit, localCredentialsTable as credentials, localSessionsTable as sessions } from "@workspace/db";
import { loadTeamMembers } from "./team-roster-db";
import { canonicalServer, isValidEmail, normalizeEmail, rosterFrom, serverForEmail, serverProfileIdentitiesFromAccounts } from "./team-roster";
import { AccountError, accountPasswordSecretKey, enforceLastAdministrator, validateMembershipChange, type MembershipChange } from "./account-policy";

export type VerifiedIdentity = {
  userId: string;
  email: string;
  name: string;
  role: "equipe" | "editor" | "administracao";
  sessionId: string;
  expiresAt: number;
};
export const accountEnvironment = () => process.env.NODE_ENV === "production" ? "production" : "development";
export { AccountError } from "./account-policy";
export const accountView = (row: typeof accounts.$inferSelect) => ({
  userId: row.userId, email: row.email, name: row.name,
  status: row.status as MembershipChange["status"], role: row.role as MembershipChange["role"], server: row.server,
  adminAccess: row.role === "administracao" || row.adminAccess,
});
export async function getOrRegisterAccount(identity: VerifiedIdentity) {
  const [existing] = await db.select().from(accounts).where(and(eq(accounts.userId, identity.userId), eq(accounts.environment, accountEnvironment())));
  if (!existing || existing.email !== identity.email) throw new AccountError(403, "unregistered", "Esta conta não foi criada pelo responsável pelo gabinete. Não há cadastro público.");
  return existing;
}
export async function listMemberships() {
  const team = await loadTeamMembers();
  const rows = await db.select().from(accounts).where(eq(accounts.environment, accountEnvironment())).orderBy(accounts.createdAt);
  /* suggestedServer: o servidor cujo e-mail cadastrado na equipe é o da conta */
  return { members: rows.map((row) => ({ ...accountView(row), suggestedServer: row.server ? null : serverForEmail(team, row.email) })), roster: rosterFrom(team) };
}
export async function listServerProfileIdentities() {
  const rows = await db.select({
    server: accounts.server,
    email: accounts.email,
    role: accounts.role,
    status: accounts.status,
  }).from(accounts).where(and(
    eq(accounts.environment, accountEnvironment()),
    eq(accounts.status, "active"),
    sql`${accounts.role} in ('equipe','editor')`,
    isNotNull(accounts.server),
  )).orderBy(accounts.server, accounts.email);
  return serverProfileIdentitiesFromAccounts(rows);
}
export async function createServerAccount(actorId: string, rawEmail: unknown, rawServer: unknown) {
  const email = normalizeEmail(rawEmail);
  const server = canonicalServer(rawServer);
  if (!isValidEmail(email) || !server) {
    throw new AccountError(400, "invalid_server_account", "Informe o e-mail institucional e o servidor.");
  }
  const passwordSecretKey = accountPasswordSecretKey("equipe", server);
  const configuredServerPassword = passwordSecretKey ? process.env[passwordSecretKey] : undefined;
  if (!passwordSecretKey || !configuredServerPassword || configuredServerPassword.length < 6) {
    throw new AccountError(503, "password_unavailable", "A senha necessária para este acesso precisa estar configurada nos Secrets.");
  }
  const team = await loadTeamMembers();
  const member = team.find((item) => item.name === server);
  if (!member || member.email !== email) {
    throw new AccountError(400, "server_email_mismatch", "O e-mail precisa ser o cadastrado para esse servidor em Configurações Globais › Servidores.");
  }
  const environment = accountEnvironment();
  return db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(7210467)`);
    const [actor] = await tx.select().from(accounts).where(and(
      eq(accounts.userId, actorId),
      eq(accounts.environment, environment),
    ));
    if (!actor || actor.status !== "active" || (actor.role !== "administracao" && actor.role !== "editor" && !actor.adminAccess)) {
      throw new AccountError(403, "admin_required", "Somente a Administração pode criar acessos de servidor.");
    }
    const matchingEmails = await tx.select().from(accounts).where(and(
      eq(accounts.environment, environment),
      sql`lower(trim(${accounts.email})) = ${email}`,
    ));
    if (matchingEmails.length > 1) {
      throw new AccountError(409, "duplicate_email", "Há mais de uma conta com esse e-mail. Corrija o vínculo antes de continuar.");
    }
    const existing = matchingEmails[0];
    if (existing?.role === "administracao" || (existing?.role === "editor" && server !== "BRUNO")) {
      throw new AccountError(409, "account_role_conflict", "Esse e-mail já pertence a uma conta da Administração.");
    }
    if (existing?.server && canonicalServer(existing.server) !== server) {
      throw new AccountError(409, "account_server_conflict", "Esse e-mail já está vinculado a outro servidor.");
    }
    const occupying = await tx.select().from(accounts).where(and(
      eq(accounts.environment, environment),
      sql`upper(trim(${accounts.server})) = ${server}`,
    ));
    if (occupying.some((account) => account.userId !== existing?.userId)) {
      throw new AccountError(409, "server_account_conflict", "Este servidor já está vinculado a outra conta.");
    }

    const userId = existing?.userId ?? randomUUID();
    const now = new Date();
    const values = {
      userId,
      environment,
      email,
      name: member.name,
      status: "active",
      role: "equipe",
      server: member.name,
      adminAccess: server === "BRUNO" || !!existing?.adminAccess,
      updatedAt: now,
    };
    const [account] = existing
      ? await tx.update(accounts).set(values).where(eq(accounts.userId, userId)).returning()
      : await tx.insert(accounts).values(values).returning();
    await tx.insert(credentials).values({
      userId,
      environment,
      passwordSecretKey,
      failedAttempts: 0,
      lockedUntil: null,
    }).onConflictDoUpdate({
      target: credentials.userId,
      set: { environment, passwordSecretKey, failedAttempts: 0, lockedUntil: null },
    });
    await tx.delete(sessions).where(eq(sessions.userId, userId));
    await tx.insert(audit).values({
      id: randomUUID(),
      environment,
      actorId,
      targetId: userId,
      action: "membership:create:equipe",
    });
    return accountView(account!);
  });
}
export async function changeMembership(actorId: string, targetId: string, change: MembershipChange) {
  const team = await loadTeamMembers();
  return db.transaction(async (tx) => {
    // Serialize grants and revocations to protect the final administrator.
    await tx.execute(sql`select pg_advisory_xact_lock(7210467)`);
    const all = await tx.select().from(accounts).where(eq(accounts.environment, accountEnvironment()));
    const actor = all.find((a) => a.userId === actorId);
    if (actor?.status !== "active" || (actor.role !== "administracao" && actor.role !== "editor" && !actor.adminAccess)) {
      throw new AccountError(403, "admin_required", "Somente a Administração pode gerenciar contas.");
    }
    const target = all.find((a) => a.userId === targetId);
    if (!target) throw new AccountError(404, "not_found", "Conta não encontrada.");
    /* conta de equipe sem servidor escolhido: vincula ao servidor com o mesmo e-mail na equipe do app */
    if (change.role === "equipe" && !change.server) change = { ...change, server: serverForEmail(team, target.email) };
    validateMembershipChange(actorId, targetId, change, rosterFrom(team));
    const normalized = { ...change, adminAccess: change.role === "administracao" || change.role === "editor" ? false : change.adminAccess ?? target.adminAccess };
    enforceLastAdministrator(all, targetId, normalized);
    if (change.server && all.some((a) => a.userId !== targetId && a.server === change.server)) {
      throw new AccountError(409, "staff_owned", "Esse servidor já está associado a outra conta. Desvincule a outra conta primeiro.");
    }
    const [updated] = await tx.update(accounts).set({ ...normalized, updatedAt: new Date() }).where(eq(accounts.userId, targetId)).returning();
    const passwordSecretKey = accountPasswordSecretKey(updated!.role, updated!.server);
    if (!passwordSecretKey) throw new AccountError(400, "invalid_password_profile", "Não há uma senha configurada para esse perfil e servidor.");
    await tx.update(credentials).set({ passwordSecretKey, failedAttempts: 0, lockedUntil: null }).where(eq(credentials.userId, targetId));
    await tx.delete(sessions).where(eq(sessions.userId, targetId));
    await tx.insert(audit).values({ id: randomUUID(), environment: accountEnvironment(), actorId, targetId, action: `membership:${change.status}:${change.role}` });
    return accountView(updated!);
  });
}

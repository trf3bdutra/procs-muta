import { pool } from "@workspace/db";

let ready: Promise<void> | null = null;

export function garantirTabelasAcervo(): Promise<void> {
  ready ??= pool.query(`
    CREATE TABLE IF NOT EXISTS acervo (
      processo text PRIMARY KEY,
      importado jsonb NOT NULL DEFAULT '{"versao":"1.0"}'::jsonb,
      operacional jsonb NOT NULL DEFAULT '{}'::jsonb,
      situacao text NOT NULL DEFAULT 'em tramitação',
      historico_situacao jsonb NOT NULL DEFAULT '[]'::jsonb,
      criado_em timestamptz NOT NULL DEFAULT now(),
      atualizado_em timestamptz NOT NULL DEFAULT now()
    );
    CREATE INDEX IF NOT EXISTS acervo_situacao_idx ON acervo (situacao);
    CREATE INDEX IF NOT EXISTS acervo_atualizado_idx ON acervo (atualizado_em);
    ALTER TABLE acervo ADD COLUMN IF NOT EXISTS operacional jsonb NOT NULL DEFAULT '{}'::jsonb;
    CREATE TABLE IF NOT EXISTS acervo_fontes (
      id serial PRIMARY KEY,
      fonte text NOT NULL,
      arquivo text NOT NULL DEFAULT '',
      referencia text NOT NULL DEFAULT '',
      importado_em timestamptz NOT NULL DEFAULT now(),
      importado_por text NOT NULL DEFAULT '',
      linhas integer NOT NULL DEFAULT 0,
      processos integer NOT NULL DEFAULT 0,
      novos integer NOT NULL DEFAULT 0,
      atualizados integer NOT NULL DEFAULT 0,
      divergencias integer NOT NULL DEFAULT 0,
      previa jsonb NOT NULL DEFAULT '{}'::jsonb
    );
    CREATE INDEX IF NOT EXISTS acervo_fontes_fonte_idx ON acervo_fontes (fonte, importado_em);
    CREATE TABLE IF NOT EXISTS indicadores (
      referencia text PRIMARY KEY,
      dados jsonb NOT NULL DEFAULT '{}'::jsonb,
      atualizado_em timestamptz NOT NULL DEFAULT now()
    );
  `).then(() => undefined).catch((error) => {
    ready = null;
    throw error;
  });
  return ready;
}

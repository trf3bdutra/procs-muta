export type CentralEstadoDados = {
  conv: Array<Record<string, unknown>>;
  impPer: Record<string, unknown>;
  impAdvJ: Record<string, unknown>;
};

const isRecord = (value: unknown): value is Record<string, unknown> =>
  !!value && typeof value === "object" && !Array.isArray(value);

export function validateCentralEstado(value: unknown):
  | { ok: true; version: number | null; dados: CentralEstadoDados }
  | { ok: false; error: string } {
  if (!isRecord(value)) return { ok: false, error: "O estado compartilhado deve ser um objeto." };
  const rawVersion = value._v;
  if (rawVersion !== undefined && rawVersion !== null &&
      (!Number.isInteger(rawVersion) || Number(rawVersion) < 0)) {
    return { ok: false, error: "A versão enviada é inválida." };
  }

  const rawConv = value.conv ?? [];
  if (!Array.isArray(rawConv)) return { ok: false, error: "conv deve ser uma lista." };
  const sections = new Set(["1ª Seção", "2ª Seção", "3ª Seção", "Todas"]);
  for (const item of rawConv) {
    const date = isRecord(item) && typeof item.d === "string"
      ? new Date(`${item.d}T00:00:00.000Z`)
      : null;
    if (!isRecord(item) || typeof item.d !== "string" ||
        !/^\d{4}-\d{2}-\d{2}$/.test(item.d) ||
        !date || !Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== item.d ||
        typeof item.s !== "string" || !sections.has(item.s)) {
      return { ok: false, error: "Cada convocação precisa de uma data válida e uma Seção permitida." };
    }
  }

  const impPer = value.impPer ?? {};
  if (!isRecord(impPer)) return { ok: false, error: "impPer deve ser um objeto." };
  const impAdvJ = value.impAdvJ ?? {};
  if (!isRecord(impAdvJ) ||
      Object.entries(impAdvJ).some(([oab, judge]) =>
        !oab.trim() || oab.length > 80 || !["jean", "ney", "?"].includes(String(judge)))) {
    return { ok: false, error: "impAdvJ deve mapear cada OAB para jean, ney ou ?." };
  }

  return {
    ok: true,
    version: rawVersion == null ? null : Number(rawVersion),
    dados: {
      conv: rawConv as Array<Record<string, unknown>>,
      impPer,
      impAdvJ,
    },
  };
}

export function centralCnjKey(value: unknown): string {
  const digits = String(value ?? "").replace(/\D/g, "");
  return /^\d{20}$/.test(digits) ? digits : "";
}

export function normalizeCentralBatch(value: unknown):
  | { ok: true; records: Array<{ processo: string; dados: Record<string, unknown> }> }
  | { ok: false; error: string } {
  if (!isRecord(value) || !Array.isArray(value.registros)) {
    return { ok: false, error: "Envie registros como uma lista." };
  }
  if (value.registros.length > 60_000) {
    return { ok: false, error: "O lote contém processos demais." };
  }
  const seen = new Set<string>();
  const records: Array<{ processo: string; dados: Record<string, unknown> }> = [];
  for (const raw of value.registros) {
    if (!isRecord(raw)) return { ok: false, error: "Cada registro deve ser um objeto." };
    const processo = centralCnjKey(raw.processo);
    if (!processo) return { ok: false, error: "Há um processo com número CNJ inválido." };
    if (seen.has(processo)) return { ok: false, error: "O lote contém números CNJ duplicados." };
    seen.add(processo);
    const { processo: _processo, ...dados } = raw;
    records.push({ processo, dados });
  }
  return { ok: true, records };
}

export function safeInlineJson(value: unknown): string {
  return JSON.stringify(value ?? null)
    .replace(/<\//g, "<\\/")
    .replace(/</g, "\\u003c")
    .replace(/\u2028/g, "\\u2028")
    .replace(/\u2029/g, "\\u2029");
}

type JsonRecord = Record<string, unknown>;

export type GabnetWorld = {
  revision: number;
  settings: JsonRecord | null;
  players: Record<string, JsonRecord>;
  avatars: Record<string, JsonRecord>;
};

const emptyWorld = (): GabnetWorld => ({
  revision: 0,
  settings: null,
  players: {},
  avatars: {},
});

function isRecord(value: unknown): value is JsonRecord {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

function safeText(value: unknown, max: number): string {
  return typeof value === "string"
    ? value.replace(/[\u0000-\u001f\u007f]/g, "").slice(0, max)
    : "";
}

function cleanStringList(value: unknown, maxItems: number, maxLength: number): string[] {
  return Array.isArray(value)
    ? [...new Set(value.filter((item): item is string => typeof item === "string")
      .map((item) => safeText(item, maxLength))
      .filter(Boolean))].slice(0, maxItems)
    : [];
}

function cleanInventory(value: unknown): Record<string, number> {
  if (!isRecord(value)) return {};
  return Object.fromEntries(
    Object.entries(value)
      .filter(([name, quantity]) =>
        safeText(name, 80) === name &&
        Number.isFinite(Number(quantity)) &&
        Number(quantity) > 0,
      )
      .slice(0, 200)
      .map(([name, quantity]) => [name, Math.min(9999, Math.floor(Number(quantity)))]),
  );
}

export function normalizeGabnetPlayerState(value: unknown): JsonRecord | null {
  if (!isRecord(value)) return null;
  return {
    coins: Math.max(0, Math.min(999999, Math.floor(Number(value.coins) || 0))),
    inventory: cleanInventory(value.inventory),
    owned: cleanStringList(value.owned, 200, 80),
    equipped: safeText(value.equipped, 80),
    visited: cleanStringList(value.visited, 50, 80),
    awards: cleanStringList(value.awards, 500, 120),
    events: cleanStringList(value.events, 500, 240),
  };
}

function cleanSettings(value: unknown): JsonRecord | null {
  if (!isRecord(value)) return null;
  const items = Array.isArray(value.items)
    ? value.items.slice(0, 200).flatMap((item): JsonRecord[] => {
        if (!isRecord(item)) return [];
        const id = safeText(item.id, 80);
        const name = safeText(item.name, 80);
        if (!id || !name) return [];
        return [{
          id,
          name,
          type: ["accessory", "consumable", "collectible"].includes(String(item.type))
            ? String(item.type)
            : "collectible",
          icon: safeText(item.icon, 12),
          price: Math.max(0, Math.min(999999, Math.floor(Number(item.price) || 0))),
          desc: safeText(item.desc ?? item.description, 200),
          energy: Math.max(0, Math.min(100, Math.floor(Number(item.energy) || 0))),
          shop: item.shop !== false,
        }];
      })
    : [];
  const history = Array.isArray(value.history)
    ? value.history.slice(-200).flatMap((entry): JsonRecord[] => {
        if (!isRecord(entry)) return [];
        return [{
          person: safeText(entry.person, 80),
          text: safeText(entry.text, 240),
          when: safeText(entry.when, 80),
        }];
      })
    : [];
  const decorations = Array.isArray(value.decorations)
    ? value.decorations.slice(0, 300).flatMap((item): JsonRecord[] => {
        if (!isRecord(item)) return [];
        const id = safeText(item.id, 80);
        const type = safeText(item.type, 40);
        const x = Number(item.x);
        const y = Number(item.y);
        if (!id || !type || !Number.isFinite(x) || !Number.isFinite(y)) return [];
        return [{ id, type, x: Math.max(0, Math.min(1536, x)), y: Math.max(0, Math.min(1024, y)) }];
      })
    : [];
  return { items, history, decorations };
}

export function normalizeGabnetAvatar(value: unknown): JsonRecord | null {
  if (!isRecord(value)) return null;
  const allowed = [
    "skin", "hair", "hairStyle", "shirt", "accent", "outfit",
    "outfitColor", "pants", "pantsColor", "glasses", "accessory", "headwear", "badge",
  ];
  const result: JsonRecord = {};
  for (const key of allowed) {
    const candidate = value[key];
    if (typeof candidate === "string") {
      const text = safeText(candidate, 40);
      if (/^#[0-9a-f]{3,8}$/i.test(text) || /^[a-z0-9_-]+$/i.test(text)) {
        result[key] = text;
      }
    }
  }
  return result;
}

export function normalizeGabnetWorld(value: unknown): GabnetWorld {
  if (!isRecord(value)) return emptyWorld();
  const players: Record<string, JsonRecord> = {};
  if (isRecord(value.players)) {
    for (const [id, player] of Object.entries(value.players).slice(0, 40)) {
      if (!id || id.length > 120) continue;
      const clean = normalizeGabnetPlayerState(player);
      if (clean) players[id] = clean;
    }
  }
  const avatars: Record<string, JsonRecord> = {};
  if (isRecord(value.avatars)) {
    for (const [id, avatar] of Object.entries(value.avatars).slice(0, 40)) {
      if (!id || id.length > 120) continue;
      const clean = normalizeGabnetAvatar(avatar);
      if (clean && Object.keys(clean).length) avatars[id] = clean;
    }
  }
  return {
    revision: Math.max(0, Math.floor(Number(value.revision) || 0)),
    settings: cleanSettings(value.settings),
    players,
    avatars,
  };
}

export function isJsonRecord(value: unknown): value is JsonRecord {
  return isRecord(value);
}

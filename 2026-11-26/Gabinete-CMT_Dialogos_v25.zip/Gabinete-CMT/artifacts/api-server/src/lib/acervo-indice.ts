export type AcervoIndiceRow = {
  processo: string;
  situacao: string;
  atualizado_em: Date | string;
  classe?: string | null;
  assunto?: string | null;
  secao?: string | null;
  polo_ativo?: string | null;
  polo_passivo?: string | null;
  etiquetas?: string | null;
  tarefa?: string | null;
  distribuicao?: string | null;
};

export function projetarAcervoIndice(row: AcervoIndiceRow) {
  return {
    processo: row.processo,
    classe: row.classe || "",
    assunto: row.assunto || "",
    secao: row.secao || "",
    poloAtivo: row.polo_ativo || "",
    poloPassivo: row.polo_passivo || "",
    etiquetas: row.etiquetas ? String(row.etiquetas).split(/[;|\n]+/).map((x) => x.trim()).filter(Boolean) : [],
    tarefa: row.tarefa || "",
    distribuicao: row.distribuicao || "",
    situacao: row.situacao,
    ativo: row.situacao !== "baixado",
    atualizadoEm: new Date(row.atualizado_em).toISOString(),
  };
}

export type MembershipChange = {
  status: "pending" | "active" | "disabled";
  role: "equipe" | "editor" | "administracao";
  server: string | null;
  adminAccess?: boolean;
};
export class AccountError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string, message: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}
export type AccountRoleRecord = { userId: string; status: string; role: string; adminAccess?: boolean };
export function isBrunoAccountTarget(email: unknown, server: unknown, brunoEmail: unknown): boolean {
  const normalizeEmail = (value: unknown) => String(value ?? "").trim().toLowerCase();
  const normalizeServer = (value: unknown) => String(value ?? "").trim().replace(/\s+/g, " ").toLocaleUpperCase("pt-BR");
  return normalizeEmail(brunoEmail) !== "" &&
    normalizeEmail(email) === normalizeEmail(brunoEmail) &&
    normalizeServer(server) === "BRUNO";
}
export function accountPasswordSecretKey(role: string, server: unknown): string | null {
  const normalizedServer = String(server ?? "").trim().replace(/\s+/g, " ").toLocaleUpperCase("pt-BR");
  if (role === "administracao") return "ADMIN_LOGIN_PASSWORD";
  if ((role === "editor" || role === "equipe") && normalizedServer === "BRUNO") return "TEAM_LOGIN_PASSWORD";
  if (role === "equipe") return "TEAM_LOGIN_PASSWORD";
  return null;
}
export function resolveServerLoginMode(input: {
  teamPasswordMatches: boolean;
  adminPasswordMatches: boolean;
  selectedServerHasAdminAccess: boolean;
  selectedServerIsBruno?: boolean;
  selectedServerRole?: string | null;
  selectedServerPasswordMatches?: boolean;
}) {
  if (input.selectedServerIsBruno) {
    const accountCanAdminister = input.selectedServerRole === "editor" || input.selectedServerHasAdminAccess;
    return accountCanAdminister && input.selectedServerPasswordMatches
      ? { accessRole: "administracao" as const, useSelectedAccount: true }
      : null;
  }
  if (input.selectedServerRole === "editor") return null;
  if (input.adminPasswordMatches && input.selectedServerRole !== "editor" && input.selectedServerHasAdminAccess) {
    return { accessRole: "administracao" as const, useSelectedAccount: true };
  }
  if (input.teamPasswordMatches && input.selectedServerRole !== "editor") {
    return { accessRole: "equipe" as const, useSelectedAccount: true };
  }
  if (input.adminPasswordMatches) {
    return { accessRole: "administracao" as const, useSelectedAccount: false };
  }
  return null;
}
export function validateMembershipChange(actorId: string, targetId: string, change: MembershipChange, roster: readonly string[]) {
  if (actorId === targetId) throw new AccountError(403, "self_change", "Peça a outro administrador para alterar seu acesso.");
  if (change.server !== null && !roster.includes(change.server)) throw new AccountError(400, "invalid_staff", "Selecione um servidor cadastrado.");
  if (change.status === "active" && (change.role === "equipe" || change.role === "editor") && !change.server) throw new AccountError(400, "staff_required", "Associe a conta a um servidor antes de aprovar.");
  if (change.role === "administracao" && change.server !== null) throw new AccountError(400, "admin_server", "Uma conta de Administração não deve ser vinculada a um servidor.");
  if (change.role === "editor") {
    throw new AccountError(403, "editor_removed", "Use a conta da Assessoria de BRUNO com acesso administrativo.");
  }
  if (change.adminAccess === true && (change.role !== "equipe" || change.server !== "BRUNO")) {
    throw new AccountError(400, "invalid_admin_access", "O acesso administrativo adicional está reservado à conta de servidor BRUNO.");
  }
}
export function enforceLastAdministrator(accounts: AccountRoleRecord[], targetId: string, change: MembershipChange) {
  const target = accounts.find((account) => account.userId === targetId);
  const hasAdminAccess = (account: AccountRoleRecord) =>
    account.status === "active" && (account.role === "administracao" || account.role === "editor" || account.adminAccess === true);
  const targetRemainsAdmin = change.status === "active" &&
    (change.role === "administracao" || change.role === "editor" || (change.role === "equipe" && change.adminAccess === true));
  if (target && hasAdminAccess(target) && !targetRemainsAdmin &&
      accounts.filter(hasAdminAccess).length <= 1) {
    throw new AccountError(409, "last_admin", "Não é possível remover a última Administração ativa.");
  }
}
export function checkBootstrap(previousOwner: string | undefined, candidate: string, activeAdministrators: number) {
  if (previousOwner) {
    if (previousOwner !== candidate) throw new AccountError(409, "bootstrap_used", "O bootstrap deste ambiente já foi utilizado por outra conta.");
    return false; // NEVER grant again after a previous grant was revoked.
  }
  if (activeAdministrators > 0) throw new AccountError(409, "admin_exists", "Já existe Administração ativa. Use o gerenciamento de contas.");
  return true;
}

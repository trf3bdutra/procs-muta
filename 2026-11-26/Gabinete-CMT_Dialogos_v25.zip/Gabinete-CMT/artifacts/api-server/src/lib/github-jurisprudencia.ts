import { gunzipSync } from "node:zlib";

// Public, read-only source. No credential, browser setting or request parameter can change this host.
export const jurisprudenciaSource = Object.freeze({
  repository: "brndutra/trf3-muta-jurisprudencia",
  branch: "main",
  url: "https://github.com/brndutra/trf3-muta-jurisprudencia",
  readOnly: true,
});
const ROOT = `https://raw.githubusercontent.com/${jurisprudenciaSource.repository}/${jurisprudenciaSource.branch}/`;
const TTL = 5 * 60_000;
type Row = Record<string, any>;
type CacheEntry = { value: unknown; expires: number; bytes: number };
const cache = new Map<string, CacheEntry>();
const pending = new Map<string, Promise<unknown>>();
const MAX_CACHE_BYTES = 160 * 1024 * 1024;

export function decodeGithubJson(bytes: Uint8Array): unknown {
  const raw = bytes[0] === 0x1f && bytes[1] === 0x8b
    ? gunzipSync(bytes, { maxOutputLength: 120 * 1024 * 1024 }) : bytes;
  return JSON.parse(Buffer.from(raw).toString("utf8"));
}

export function validJurisprudenciaPath(path: string): boolean {
  return /^(dados\/indice|modelos\/modelos)\.json\.gz$/.test(path)
    || /^dados\/(acordaos|monocraticas)\/(?:19|20)\d{2}\.json\.gz$/.test(path);
}

export async function githubJurisprudenciaFile(path: string): Promise<unknown> {
  if (!validJurisprudenciaPath(path)) throw new Error("Arquivo fora do catálogo público permitido.");
  const entry = cache.get(path);
  if (entry && entry.expires > Date.now()) return entry.value;
  if (pending.has(path)) return pending.get(path)!;
  const job = (async () => {
    const response = await fetch(ROOT + path, {
      headers: { Accept: "application/octet-stream" },
      signal: AbortSignal.timeout(30_000),
    });
    if (!response.ok) throw new Error(`GitHub indisponível para ${path} (HTTP ${response.status}).`);
    const body = response.body;
    if (!body) throw new Error("GitHub devolveu um arquivo vazio.");
    const parts: Uint8Array[] = [];
    let size = 0;
    const reader = body.getReader();
    try {
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > 24 * 1024 * 1024) throw new Error("Arquivo público excede o limite de leitura.");
        parts.push(value);
      }
    } finally { await reader.cancel().catch(() => {}); }
    const value = decodeGithubJson(Buffer.concat(parts));
    const bytes = Buffer.byteLength(JSON.stringify(value));
    cache.delete(path);
    for (const [key, item] of cache) {
      const total = [...cache.values()].reduce((sum, x) => sum + x.bytes, 0);
      if (item.expires <= Date.now() || total + bytes > MAX_CACHE_BYTES) cache.delete(key);
    }
    if (bytes <= MAX_CACHE_BYTES) cache.set(path, { value, bytes, expires: Date.now() + TTL });
    return value;
  })();
  pending.set(path, job);
  try { return await job; } finally { pending.delete(path); }
}

const CONTEUDOS = new Set(["integral", "apenas_acordao", "apenas_ementa"]);

export function normalizeJulgado(row: Row, full = false): Row {
  const tipo = row.t || (String(row.id).startsWith("A") ? "A" : "M");
  const status = String(row.conteudo_texto || row.k || "");
  const conteudo = CONTEUDOS.has(status) ? status : "";
  const out: Row = {
    id: String(row.id),
    processo: row.numero_processo || row.n || "",
    classe: row.classe || row.cl || "",
    classeSigla: row.classe_sigla || row.c || "",
    pronunciamento: tipo === "A" ? "Acórdão" : "Decisão monocrática",
    orgao: row.orgao_julgador || row.o || "",
    relator: row.relator || "CARLOS MUTA",
    // relator | "relator para o acórdão (relator originário diverso)"
    atuacao: String(row.atuacao_muta || row.a || "relator"),
    dataJulgamento: row.data_julgamento_iso || row.data_decisao_iso || row.d || "",
    dataPublicacao: row.data_publicacao || row.p || "",
    veiculo: row.publicacao_veiculo || row.v || "",
    assunto: row.assunto || row.assunto_principal || "",
    temas: row.temas || row.tema || [],
    palavrasChave: row.palavras_chave || row.palavrasChave || [],
    ementa: full ? String(row.ementa || "") : String(row.e || ""),
    resultado: row.resultado_colegiado || row.dispositivo || row.r || "",
    ano: String(row.y || (row.data_julgamento_iso || row.data_decisao_iso || row.d || "").slice(0, 4)),
    tipo, previa: !full, conteudo,
    // conteudo_texto é um rótulo de situação ("integral" etc.), não o texto.
    inteiroTeor: full ? !!row.inteiro_teor : conteudo === "integral",
  };
  if (full) {
    out.partes = Array.isArray(row.partes)
      ? row.partes.filter((p: Row) => p && p.nome).map((p: Row) => ({ polo: String(p.polo || ""), nome: String(p.nome) }))
      : [];
    out.sha256InteiroTeor = row.sha256_inteiro_teor || "";
    out.sha256Ementa = row.sha256_ementa || "";
    out.seq = row.seq ?? null;
  }
  return out;
}

/* ── busca no texto integral, um arquivo anual por chamada ──
   Mesma sintaxe da tela: termos obrigatórios, "frase exata" e -exclusão, sem diferenciar acentos. */
const ACENTOS: Record<string, string> = { a: "aáàâãä", e: "eéèêë", i: "iíìîï", o: "oóòôõö", u: "uúùûü", c: "cç", n: "nñ" };
function semAcento(s: string) { return s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase(); }
function rxTermo(t: string) {
  const b = semAcento(t).replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
    // "1.102" e "1102" casam um com o outro (temas, súmulas, leis)
    .replace(/(\d)\\\.(?=\d{3}(?!\d))/g, "$1")
    .replace(/\d{4,}/g, n => n.replace(/(\d)(?=(\d{3})+$)/g, "$1\\.?"))
    .replace(/[aeioucn]/g, c => "[" + ACENTOS[c] + ACENTOS[c].toUpperCase() + "]").replace(/\s+/g, "\\s+");
  return new RegExp(b, "i");
}
export function parseConsulta(q: string) {
  const inc: string[] = [], exc: string[] = [];
  const re = /(-?)"([^"]+)"|(-?)(\S+)/g; let m: RegExpExecArray | null;
  while ((m = re.exec(String(q).slice(0, 300))) && inc.length + exc.length < 16) {
    const neg = m[1] || m[3], t = (m[2] || m[4] || "").trim();
    if (!t || t === "-") continue;
    (neg ? exc : inc).push(t);
  }
  return { inc, exc, rxInc: inc.map(rxTermo), rxExc: exc.map(rxTermo) };
}
export function casaConsulta(texto: string, c: ReturnType<typeof parseConsulta>) {
  if (!texto) return false;
  for (const r of c.rxExc) if (r.test(texto)) return false;
  for (const r of c.rxInc) if (!r.test(texto)) return false;
  return true;
}
function trecho(texto: string, rx: RegExp, larg = 160) {
  const m = rx.exec(texto); if (!m) return "";
  const i = Math.max(0, m.index - larg), f = Math.min(texto.length, m.index + m[0].length + larg);
  return (i ? "…" : "") + texto.slice(i, f).replace(/\s+/g, " ") + (f < texto.length ? "…" : "");
}
export function validArquivoAnual(arquivo: string) { return /^(acordaos|monocraticas)\/(?:19|20)\d{2}$/.test(arquivo); }
const MAX_HITS = 3000;
export async function jurisprudenciaBuscaIntegral(arquivo: string, q: string) {
  if (!validArquivoAnual(arquivo)) throw new Error("Arquivo anual inválido.");
  const c = parseConsulta(q);
  if (!c.rxInc.length) return { arquivo, hits: {}, total: 0, truncado: false };
  const data = await githubJurisprudenciaFile(`dados/${arquivo}.json.gz`) as Row;
  const records: Row[] = Array.isArray(data) ? data : data?.registros;
  if (!Array.isArray(records)) throw new Error("O arquivo anual do GitHub não tem o formato esperado.");
  const hits: Record<string, string> = {}; let total = 0;
  for (const r of records) {
    const it = String(r.inteiro_teor || ""), t = (r.ementa ? r.ementa + "\n" : "") + it;
    if (!casaConsulta(t, c)) continue;
    total++;
    if (total <= MAX_HITS) hits[String(r.id)] = trecho(it && c.rxInc[0].test(it) ? it : t, c.rxInc[0]);
  }
  return { arquivo, hits, total, truncado: total > MAX_HITS };
}

export async function jurisprudenciaIndex(): Promise<Row[]> {
  const rows = await githubJurisprudenciaFile("dados/indice.json.gz");
  if (!Array.isArray(rows) || !rows.every(row => row && typeof row.id === "string")) {
    throw new Error("O índice do GitHub não tem o formato esperado.");
  }
  return rows;
}

export async function jurisprudenciaModels(): Promise<Row[]> {
  const data = await githubJurisprudenciaFile("modelos/modelos.json.gz") as Row;
  if (!Array.isArray(data?.modelos) || !data.modelos.every((row: Row) => row?.id && row?.nome)) {
    throw new Error("O banco de modelos do GitHub não tem o formato esperado.");
  }
  return data.modelos;
}

export async function jurisprudenciaDetail(key: string) {
  const rows = await jurisprudenciaIndex();
  const digits = key.replace(/\D/g, "");
  const meta = rows.find(row => row.id === key) ||
    (digits.length === 20 ? rows.find(row => String(row.n).replace(/\D/g, "") === digits) : null);
  if (!meta) return null;
  const year = String(meta.y || String(meta.d).slice(0, 4));
  const folder = meta.t === "A" ? "acordaos" : "monocraticas";
  const data = await githubJurisprudenciaFile(`dados/${folder}/${year}.json.gz`) as Row;
  const records = Array.isArray(data) ? data : data?.registros;
  if (!Array.isArray(records)) throw new Error("O arquivo anual do GitHub não tem o formato esperado.");
  const record = records.find((row: Row) => row.id === meta.id);
  if (!record) return null;
  return {
    chave: meta.id,
    inteiroTeor: String(record.inteiro_teor || record.ementa || record.dispositivo || ""),
    registro: normalizeJulgado({ ...meta, ...record }, true),
    source: jurisprudenciaSource,
  };
}

/* ── v272 · julgados recentes enriquecidos (últimos 24 meses) ──
   O índice só tem ~380 caracteres de prévia. Para os julgados recentes, o servidor lê os arquivos anuais e devolve,
   por registro, a ementa sem o cabeçalho do PJe, os temas e súmulas citados e os dispositivos/jurisprudência do rodapé.
   Monocráticas: o começo da decisão (relatório) no lugar da ementa. Usado na busca e na aderência dos Similares. */
export function limparEmentaPje(e: string): string {
  const t = String(e || "");
  const m = /^\s*E\s?M\s?E\s?N\s?T\s?A\s*[:.]?\s*$/im.exec(t);
  return (m ? t.slice(m.index + m[0].length) : t).trim();
}
function inicioDecisao(it: string): string {
  const t = String(it || "");
  // pula o cabeçalho do PJe (tribunal, partes, advogados): a decisão começa em "Vistos", "Trata-se" ou "Cuida-se"
  const k = t.search(/\b(?:Vistos|Trata-se|Cuida-se)\b/i);
  return (k >= 0 ? t.slice(k) : t).replace(/^\s*Vistos[^.\n]*\.\s*/i, "").trim();
}
export function citacoesDe(texto: string) {
  const t = String(texto || ""), temas = new Set<string>(), sumulas = new Set<string>();
  for (const m of t.matchAll(/\bTema\s*(?:n\.?\s*[º°o]?\s*)?(\d{1,4}(?:\.\d{3})?)(?:\s*(?:do|\/)\s*(STF|STJ))?/gi)) {
    temas.add(m[1].replace(/\./g, "") + (m[2] ? "/" + m[2].toUpperCase() : ""));
    if (temas.size >= 16) break;
  }
  for (const m of t.matchAll(/\bS[úu]mula(?:\s+Vinculante)?\s*(?:n\.?\s*[º°o]?\s*)?(\d{1,4})(?:\s*(?:do|da|\/)\s*(STF|STJ|TFR|TRF3?))?/gi)) {
    sumulas.add(m[1] + (m[2] ? "/" + m[2].toUpperCase() : ""));
    if (sumulas.size >= 12) break;
  }
  const disp = (/Dispositivos?\s+relevantes?\s+citados?:\s*([^\n]+)/i.exec(t) || [])[1] || "";
  const jur = (/Jurisprud[êe]ncia\s+relevante\s+citada:\s*([^\n]+)/i.exec(t) || [])[1] || "";
  return { temas: [...temas], sumulas: [...sumulas], dispositivos: disp.trim().slice(0, 700), jurisprudencia: jur.trim().slice(0, 900) };
}
export function enriquecer(meta: Row, rec: Row): Row {
  const tipo = meta.t || (String(meta.id).startsWith("A") ? "A" : "M");
  const it = String(rec.inteiro_teor || "");
  const base = tipo === "A" ? limparEmentaPje(rec.ementa || "") : inicioDecisao(it);
  const cit = citacoesDe((rec.ementa || "") + "\n" + it);
  return { id: String(meta.id), ementa: base.slice(0, tipo === "A" ? 3200 : 2200), ...cit };
}
let RICOS: { value: Row; expires: number } | null = null;
let RICOS_PEND: Promise<Row> | null = null;
export async function jurisprudenciaEnriquecidos(meses = 24, agora = new Date()): Promise<Row> {
  if (RICOS && RICOS.expires > Date.now()) return RICOS.value;
  if (RICOS_PEND) return RICOS_PEND;
  RICOS_PEND = (async () => {
    const corte = new Date(agora); corte.setMonth(corte.getMonth() - meses);
    const desde = corte.toISOString().slice(0, 10);
    const rows = await jurisprudenciaIndex();
    const porArquivo = new Map<string, Row[]>();
    for (const r of rows) {
      const d = String(r.d || ""); if (!d || d < desde) continue;
      const arq = `${r.t === "A" ? "acordaos" : "monocraticas"}/${String(r.y || d.slice(0, 4))}`;
      if (!porArquivo.has(arq)) porArquivo.set(arq, []);
      porArquivo.get(arq)!.push(r);
    }
    const out: Row[] = [];
    for (const [arq, metas] of [...porArquivo.entries()].sort()) {
      const data = await githubJurisprudenciaFile(`dados/${arq}.json.gz`) as Row;
      const recs: Row[] = Array.isArray(data) ? data : data?.registros;
      if (!Array.isArray(recs)) continue;
      const porId = new Map(recs.map(x => [String(x.id), x]));
      for (const m of metas) { const rec = porId.get(String(m.id)); if (rec) out.push(enriquecer(m, rec)); }
    }
    const value = { desde, meses, total: out.length, registros: out, source: jurisprudenciaSource };
    RICOS = { value, expires: Date.now() + 6 * 60 * 60_000 };
    return value;
  })();
  try { return await RICOS_PEND; } finally { RICOS_PEND = null; }
}
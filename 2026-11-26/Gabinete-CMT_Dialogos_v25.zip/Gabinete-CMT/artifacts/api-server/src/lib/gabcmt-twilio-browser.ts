export const twilioBrowserScript = String.raw`(() => {
  'use strict';
  async function request(path, options) {
    const r = await fetch('/api/pauta/mensagens/twilio' + path, { credentials:'same-origin', ...options });
    const d = await r.json(); if (!r.ok) { const error = new Error(d.error || 'Twilio indisponível.'); error.safeToRetry=d.safeToRetry===true; throw error; } return d;
  }
  function mount(box) {
    if (!box || box.dataset.mounted) return;
    box.dataset.mounted = 'true';
    box.innerHTML = '<h3>SMS e WhatsApp · Twilio</h3><p class="cr-note">Consulte as mensagens da conta e vincule as recebidas à caixa do app. O envio é manual e pode ter custo na Twilio. WhatsApp exige remetente habilitado e pode exigir um modelo aprovado fora da janela de atendimento.</p><form data-tw-query><label>Canal<select name="channel"><option value="sms">SMS</option><option value="whatsapp">WhatsApp</option></select></label><label>Seu número Twilio (com código do país)<input name="phone" placeholder="+5567999999999" pattern="[+][1-9][0-9]{7,14}"></label><label>Buscar texto na página consultada<input name="q" maxlength="500"></label><button type="submit" class="cr-btn">Consultar mensagens</button></form><p role="status" data-tw-status></p><div data-tw-list></div><button type="button" class="cr-btn" data-tw-more hidden>Carregar mais</button><details><summary>Enviar mensagem</summary><form data-tw-send><label>Canal<select name="channel"><option value="sms">SMS</option><option value="whatsapp">WhatsApp</option></select></label><label>Remetente Twilio<input name="from" required placeholder="+5567999999999" pattern="[+][1-9][0-9]{7,14}"></label><label>Destinatário<input name="to" required placeholder="+5567999999999" pattern="[+][1-9][0-9]{7,14}"></label><label>Mensagem<textarea name="text" required maxlength="1600" rows="4"></textarea></label><button type="submit" class="cr-btn pri">Revisar e enviar</button><p role="status" data-tw-send-status></p></form></details>';
    const query = box.querySelector('[data-tw-query]'), list = box.querySelector('[data-tw-list]'), status = box.querySelector('[data-tw-status]'), more = box.querySelector('[data-tw-more]');
    let cursor = '', active = null, busy = false;
    async function load(next) {
      if(busy) return; busy=true; query.querySelector('button').disabled=true; more.disabled=true;
      if(!next){active=Object.fromEntries(new FormData(query));cursor='';list.replaceChildren();}
      status.textContent='Consultando o Twilio…';
      try {
        const params=new URLSearchParams(active); if(next&&cursor)params.set('pageToken',cursor);
        const d=await request('?'+params.toString()); cursor=d.nextPageToken||'';
        d.messages.forEach(function(m) {
          const row=document.createElement('article'), heading=document.createElement('b'), text=document.createElement('p'), label=document.createElement('label'), process=document.createElement('input'), button=document.createElement('button');
          heading.textContent=m.channel+' · '+m.direction+' · '+m.from+' → '+m.to;
          text.textContent=m.text; label.textContent='CNJ para vincular (opcional)';process.placeholder='0000000-00.0000.0.00.0000';label.append(process);
          button.type='button';button.className='cr-btn';button.textContent=m.imported?'Já vinculada':'Vincular à caixa do app';button.disabled=m.imported||m.direction!=='inbound';
          button.onclick=async function(){button.disabled=true;try{await request('/vincular',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sid:m.id,process:process.value})});button.textContent='Vinculada à caixa do app';if(window.CMTCfg2Painel)window.CMTCfg2Painel.mail(true);}catch(e){status.textContent=e.message;button.disabled=false;}};
          row.append(heading,text,label,button);list.append(row);
        });
        more.hidden=!cursor;status.textContent=d.messages.length?'Consulta concluída. Ler não importa mensagens.':'Nenhuma correspondência nesta página.'+(cursor?' Há outras páginas disponíveis.':'');
      }catch(e){status.textContent=e.message;}finally{busy=false;query.querySelector('button').disabled=false;more.disabled=false;}
    }
    query.onsubmit=function(e){e.preventDefault();load(false);};more.onclick=function(){load(true);};
    const send=box.querySelector('[data-tw-send]'), sendStatus=box.querySelector('[data-tw-send-status]');
    request('/config').then(function(config){
      function fill(form,name){const value=form.channel.value==='whatsapp'?config.whatsappNumber:config.smsNumber;if(!form.elements[name].value)form.elements[name].value=value||'';}
      fill(query,'phone');fill(send,'from');
      query.channel.addEventListener('change',function(){query.phone.value='';fill(query,'phone');});
      send.channel.addEventListener('change',function(){send.from.value='';fill(send,'from');});
    }).catch(function(){});
    let sendId=null, fingerprint=null, sending=false;
    send.onsubmit=async function(e){
      e.preventDefault();if(sending)return;
      const body=Object.fromEntries(new FormData(send));
      if(!confirm('Enviar '+body.channel+' de '+body.from+' para '+body.to+'?\n\n'+body.text+'\n\nEsta ação pode gerar cobrança pela Twilio.'))return;
      const key=JSON.stringify(body);if(key!==fingerprint||!sendId){fingerprint=key;sendId=crypto.randomUUID();}
      body.requestId=sendId;sending=true;send.querySelector('button').disabled=true;sendStatus.textContent='Solicitando o envio…';
      try{const d=await request('/enviar',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});sendStatus.textContent='Aceita pelo Twilio: '+d.sid+' · '+d.status+'. A entrega será confirmada pelo provedor.';send.reset();fingerprint=null;sendId=null;}
      catch(error){sendStatus.textContent=error.message;if(error.safeToRetry)sendId=null;}
      finally{sending=false;send.querySelector('button').disabled=false;}
    };
  }
  window.CMTTwilio={mount};
})();`;

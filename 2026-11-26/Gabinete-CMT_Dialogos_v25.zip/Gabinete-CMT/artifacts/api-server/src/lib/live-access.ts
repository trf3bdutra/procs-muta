import type { Request, Response } from "express";
import { db, accountMembershipsTable } from "@workspace/db";
import { and, eq } from "drizzle-orm";
import { accountEnvironment } from "./account-memberships";
import { getAppSession } from "./app-auth";
import { readLocalIdentity } from "./local-auth";

type Stream = { request: Request; role: string; server?: string; queue: Promise<void> };
const streams = new WeakMap<Response, Stream>();
const connected = new Set<Response>();
export function registerLiveAccess(req: Request, res: Response) {
  const member = getAppSession(req)!;
  streams.set(res, { request: req, role: member.role, server: member.server, queue: Promise.resolve() });
  connected.add(res);
  res.on("close", () => { connected.delete(res); streams.delete(res); });
}
export function revokeLiveAccount(userId: string) {
  for (const res of connected) {
    if (getAppSession(streams.get(res)?.request ?? { headers: {} })?.userId !== userId) continue;
    if (!res.writableEnded) {
      res.write("event: access-revoked\ndata: {}\n\n");
      res.end();
    }
  }
}
export function writeLive(res: Response, payload: string) {
  const stream = streams.get(res);
  if (!stream || res.writableEnded || res.destroyed) return;
  // Preserve event order while checking authorization immediately before every delivery.
  stream.queue = stream.queue.then(async () => {
    if (res.writableEnded || res.destroyed) return;
    try {
      const member = getAppSession(stream.request);
      if (!member?.userId || !member.sessionId || member.expiresAt * 1000 <= Date.now()) throw Error("expired");
      const [[current], session] = await Promise.all([
        db.select().from(accountMembershipsTable).where(and(eq(accountMembershipsTable.userId, member.userId), eq(accountMembershipsTable.environment, accountEnvironment()))),
        readLocalIdentity(stream.request),
      ]);
       if (current?.status !== "active" || session.role !== stream.role || current.server !== (stream.server ?? null) ||
          session.sessionId !== member.sessionId || session.expiresAt * 1000 <= Date.now()) throw Error("revoked");
      if (!res.writableEnded && !res.destroyed) res.write(payload);
    } catch {
      if (!res.writableEnded) res.write("event: access-revoked\ndata: {}\n\n");
      res.end();
    }
  }).catch(() => { if (!res.writableEnded) res.end(); });
}

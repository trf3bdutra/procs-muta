export type PautaPresenceConnection = {
  client: string;
  who: string;
};

export type PautaPresenceSummary = {
  count: number;
  people: { who: string; count: number }[];
  unidentified: number;
};

export function normalizePresenceText(value: unknown, maxLength: number): string {
  const raw = Array.isArray(value) ? value[0] : value;
  if (typeof raw !== "string") return "";
  return raw.replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, maxLength);
}

export function normalizePresenceClient(value: unknown): string {
  const client = normalizePresenceText(value, 64);
  return /^[\w-]{6,64}$/.test(client) ? client : "";
}

export function summarizePautaPresence(
  connections: Iterable<PautaPresenceConnection>,
): PautaPresenceSummary {
  const clients = new Map<string, string>();
  let unidentifiedConnections = 0;
  let anonymousConnectionIndex = 0;

  for (const connection of connections) {
    if (!connection.client) {
      if (connection.who) {
        clients.set(`connection:${anonymousConnectionIndex++}`, connection.who);
      } else {
        unidentifiedConnections += 1;
      }
      continue;
    }

    const previous = clients.get(connection.client);
    if (previous === undefined || (!previous && connection.who)) {
      clients.set(connection.client, connection.who);
    }
  }

  const peopleByName = new Map<string, { who: string; count: number }>();
  let unidentified = unidentifiedConnections;

  for (const who of clients.values()) {
    if (!who) {
      unidentified += 1;
      continue;
    }

    const key = who
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLocaleUpperCase("pt-BR");
    const existing = peopleByName.get(key);
    if (existing) existing.count += 1;
    else peopleByName.set(key, { who, count: 1 });
  }

  const people = [...peopleByName.values()].sort((a, b) =>
    a.who.localeCompare(b.who, "pt-BR"),
  );

  return {
    count: people.length + unidentified,
    people,
    unidentified,
  };
}

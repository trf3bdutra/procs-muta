type Json = Record<string, unknown>;
type CandidateRule = { id: string; titulo: string; pattern: RegExp };
export type DatajudTriageMovement = {
  data: string | null;
  codigo: number | null;
  nome: string;
  complementos: string[];
  regras: Array<{ id: string; titulo: string }>;
};

/* The attached notebook identifies candidates from movement names/complements.
   Code and date stay in the returned evidence; they are not treated as legal meaning. */
const rules: readonly CandidateRule[] = [
  { id: "R01", titulo: "Interposição", pattern: /\b(recurso|apelacao|agravo|embargos)\b/ },
  { id: "R02", titulo: "Decisão", pattern: /(decisao|sentenca|julgament|acordao)/ },
  { id: "R03", titulo: "Intimação", pattern: /(intima|ciencia|publicacao|expedicao)/ },
  { id: "R04", titulo: "Prazos", pattern: /(decurso|prazo|suspensao)/ },
  { id: "R05", titulo: "Preparo", pattern: /(preparo|custas|desercao|gratuidade|justica gratuita)/ },
  { id: "R06", titulo: "Representação", pattern: /(procuracao|substabelec|representacao|mandato)/ },
  { id: "R07", titulo: "Saneamento", pattern: /(regularizacao|emenda|sanear|saneamento)/ },
  { id: "R08", titulo: "Admissibilidade anterior", pattern: /(nao conhec|conheciment|admissib)/ },
  { id: "R09", titulo: "Fato superveniente", pattern: /(desistencia|perda de objeto|prejudicad|extincao)/ },
];

function object(value: unknown): Json {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Json : {};
}

function digits(value: unknown): string {
  return String(value ?? "").replace(/\D/g, "");
}

function normalizeText(value: string): string {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

function movementCode(movement: Json): number | null {
  const national = object(movement.movimentoNacional);
  const raw = movement.codigo ?? national.codigo;
  if (raw == null || raw === "") return null;
  const code = Number(raw);
  return Number.isInteger(code) && code >= 0 ? code : null;
}

function movementName(movement: Json): string {
  const national = object(movement.movimentoNacional);
  return String(movement.nome ?? national.nome ?? "").trim();
}

function movementComplements(movement: Json): string[] {
  if (!Array.isArray(movement.complementosTabelados)) return [];
  return movement.complementosTabelados
    .map((value) => {
      if (typeof value === "string") return value.trim();
      const item = object(value);
      const details = [item.nome, item.descricao, item.valor]
        .filter((part) => part != null && String(part).trim() !== "")
        .map((part) => String(part).trim());
      if (details.length) return [...new Set(details)].join(" · ");
      if (item.codigo != null) return `Código ${String(item.codigo)}`;
      try { return JSON.stringify(item); } catch { return ""; }
    })
    .filter(Boolean);
}

function matchedRules(text: string) {
  return rules
    .filter((rule) => rule.pattern.test(text))
    .map(({ id, titulo }) => ({ id, titulo }));
}

export function buildDatajudTriageResult(numero: string, sourceRecords: unknown[]) {
  const registros = sourceRecords.filter((record) => {
    const source = object(record);
    return digits(source.numeroProcesso) === numero;
  });
  const movimentos: DatajudTriageMovement[] = registros.flatMap((record) => {
    const source = object(record);
    if (!Array.isArray(source.movimentos)) return [];
    return source.movimentos.flatMap((rawMovement) => {
      const movement = object(rawMovement);
      const nome = movementName(movement);
      const complementos = movementComplements(movement);
      const codigo = movementCode(movement);
      const regras = matchedRules(normalizeText(`${nome} ${complementos.join(" ")}`));
      if (!regras.length) return [];
      const rawDate = movement.dataHora ?? movement.data;
      return [{
        data: rawDate == null || rawDate === "" ? null : String(rawDate),
        codigo,
        nome,
        complementos,
        regras,
      }];
    });
  });
  return {
    ok: true as const,
    numero,
    status: registros.length ? "encontrado" as const : "nao_localizado" as const,
    registros,
    movimentos,
  };
}

export async function consultarDatajudTriageProcess(
  numero: string,
  consulta: (numeros: string[]) => Promise<unknown[]> = async () => {
    throw new Error("A função de consulta DataJud deve ser informada pelo serviço.");
  },
) {
  if (!/^\d{20}$/.test(numero)) {
    throw new Error("Informe o número CNJ com 20 dígitos.");
  }
  const records = await consulta([numero]);
  return buildDatajudTriageResult(numero, records);
}

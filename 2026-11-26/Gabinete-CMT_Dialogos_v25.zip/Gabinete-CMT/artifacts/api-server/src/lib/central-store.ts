import { pool } from "@workspace/db";
export { centralCnjKey, normalizeCentralBatch, safeInlineJson, validateCentralEstado } from "./central-contract";

let tablesReady: Promise<void> | null = null;

export function ensureCentralTables(): Promise<void> {
  tablesReady ??= pool.query(`
    CREATE TABLE IF NOT EXISTS central_estado (
      id text PRIMARY KEY,
      dados jsonb NOT NULL,
      versao integer NOT NULL DEFAULT 0,
      atualizado_em timestamptz NOT NULL DEFAULT now(),
      atualizado_por text NOT NULL DEFAULT ''
    );
  `).then(() => undefined).catch((error) => {
    tablesReady = null;
    throw error;
  });
  return tablesReady;
}

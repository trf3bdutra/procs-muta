import { createHash, createHmac, randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import type { Request, Response } from "express";
import { and, eq, or, sql } from "drizzle-orm";
import { db, accountAuditTable as audit, accountMembershipsTable as accounts, localCredentialsTable as credentials, localSessionsTable as sessions } from "@workspace/db";
import { AccountError, accountEnvironment, type VerifiedIdentity } from "./account-memberships";
import { accountPasswordSecretKey, isBrunoAccountTarget, resolveServerLoginMode } from "./account-policy";
import { loginServersFromLinkedAccounts, normalizeLoginServer } from "./login-options";
import { loadTeamMembers } from "./team-roster-db";
import { revokeLiveAccount } from "./live-access";

export const LOCAL_SESSION_COOKIE = "cmt_local_session";
const SESSION_SECONDS = 7 * 24 * 60 * 60;
const hash = (value: string) => createHash("sha256").update(value).digest("hex");
const BRUNO_ADMIN_CONSOLIDATION_ACTION = "local:bruno-single-assessoria-admin";
export function passwordMatches(input: string, expected: string): boolean {
  const digest = (value: string) => createHash("sha256").update(value).digest();
  return timingSafeEqual(digest(input), digest(expected));
}
function configuredPassword(key: string) {
  const isPasswordSecretKey = ["ADMIN_LOGIN_PASSWORD", "TEAM_LOGIN_PASSWORD"].includes(key);
  const password = isPasswordSecretKey ? process.env[key] : undefined;
  if (!password || password.length < 6) throw new AccountError(503, "password_unavailable", "A senha local desta conta precisa ser configurada nos Secrets com pelo menos 6 caracteres.");
  return password;
}
function stamp(key: string, password: string) {
  const secret = process.env.SESSION_SECRET;
  if (!secret || secret.length < 24) throw new AccountError(503, "auth_unavailable", "A proteção das sessões precisa ser configurada nos Secrets.");
  return createHmac("sha256", secret).update(`${key}\0${password}`).digest("hex");
}
function cookieToken(req: Request) {
  const entry = req.headers.cookie?.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${LOCAL_SESSION_COOKIE}=`));
  const token = entry?.slice(LOCAL_SESSION_COOKIE.length + 1);
  return token && /^[a-f0-9]{64}$/.test(token) ? token : null;
}
function setCookie(req: Request, res: Response, token: string, seconds: number) {
  const secure = req.secure || req.get("x-forwarded-proto")?.split(",")[0]?.trim() === "https" || process.env.NODE_ENV === "production";
  res.append("Set-Cookie", `${LOCAL_SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${seconds}${secure ? "; Secure" : ""}`);
}
async function consolidateBrunoAdminAccount(userId: string, environment: string, brunoEmail: string) {
  const consolidated = await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(7210467)`);
    const [current] = await tx.select({ account: accounts, credential: credentials })
      .from(accounts)
      .innerJoin(credentials, and(eq(credentials.userId, accounts.userId), eq(credentials.environment, environment)))
      .where(and(eq(accounts.userId, userId), eq(accounts.environment, environment)))
      .for("update");
    if (!current || !isBrunoAccountTarget(current.account.email, current.account.server, brunoEmail)) {
      throw new AccountError(409, "bruno_account_changed", "O vínculo de BRUNO mudou; entre novamente após a conferência da conta.");
    }
    if (current.account.status !== "active" ||
        (current.account.role !== "equipe" && current.account.role !== "editor") ||
        !["TEAM_LOGIN_PASSWORD", "BDUTRA_LOGIN_PASSWORD"].includes(current.credential.passwordSecretKey)) {
      throw new AccountError(409, "bruno_account_changed", "O cadastro de BRUNO não corresponde ao perfil esperado; nenhuma sessão foi criada.");
    }
    if (current.account.role === "equipe" && current.account.adminAccess &&
        current.credential.passwordSecretKey === "TEAM_LOGIN_PASSWORD") {
      return current;
    }
    const [account] = await tx.update(accounts).set({
      role: "equipe",
      adminAccess: true,
      updatedAt: new Date(),
    }).where(and(eq(accounts.userId, userId), eq(accounts.environment, environment))).returning();
    const [credential] = await tx.update(credentials).set({
      passwordSecretKey: "TEAM_LOGIN_PASSWORD",
      failedAttempts: 0,
      lockedUntil: null,
    }).where(and(eq(credentials.userId, userId), eq(credentials.environment, environment))).returning();
    await tx.delete(sessions).where(and(eq(sessions.userId, userId), eq(sessions.environment, environment)));
    await tx.insert(audit).values({
      id: randomUUID(),
      environment,
      actorId: "workspace-owner",
      targetId: userId,
      action: BRUNO_ADMIN_CONSOLIDATION_ACTION,
    });
    return { account: account!, credential: credential! };
  });
  revokeLiveAccount(userId);
  return consolidated;
}
export async function readLocalIdentity(req: Request): Promise<VerifiedIdentity> {
  const token = cookieToken(req);
  if (!token) throw new AccountError(401, "signed_out", "Entre para acessar o Gabinete CMT.");
  const [record] = await db.select({ session: sessions, credential: credentials, account: accounts })
    .from(sessions).innerJoin(credentials, eq(credentials.userId, sessions.userId))
    .innerJoin(accounts, eq(accounts.userId, sessions.userId))
    .where(and(eq(sessions.tokenHash, hash(token)), eq(sessions.environment, accountEnvironment()),
      eq(credentials.environment, accountEnvironment()), eq(accounts.environment, accountEnvironment())));
  const accessRole = record?.session.accessRole === "equipe" || record?.session.accessRole === "editor" || record?.session.accessRole === "administracao"
    ? record.session.accessRole
    : record?.account.role;
  const credentialKey = record && accountPasswordSecretKey(record.account.role, record.account.server);
  const brunoAdminSession = accessRole === "administracao" && record?.account.role === "equipe" &&
    normalizeLoginServer(record.account.server) === "BRUNO" && record.account.adminAccess;
  const accessKey = brunoAdminSession
    ? "TEAM_LOGIN_PASSWORD"
    : accessRole && accountPasswordSecretKey(accessRole, record?.account.server);
  const accessIsAllowed = !!record && !!accessRole && (
    (accessRole === record.account.role && record.account.role !== "editor") ||
    (accessRole === "administracao" && record.account.role === "equipe" && record.account.adminAccess)
  );
  if (!record || !accessKey || !credentialKey || !accessIsAllowed ||
      record.credential.passwordSecretKey !== credentialKey ||
      record.session.expiresAt.getTime() <= Date.now() ||
      record.session.credentialStamp !== stamp(accessKey, configuredPassword(accessKey))) {
    throw new AccountError(401, "signed_out", "Sua sessão terminou. Entre novamente.");
  }
  return { userId: record.account.userId, email: record.account.email, name: record.account.name,
     role: accessRole as "equipe" | "editor" | "administracao",
    sessionId: record.session.tokenHash, expiresAt: Math.floor(record.session.expiresAt.getTime() / 1000) };
}
export async function listLoginServers() {
  const linked = await db.select({
    server: accounts.server,
    role: accounts.role,
    status: accounts.status,
    passwordSecretKey: credentials.passwordSecretKey,
  })
    .from(accounts).innerJoin(credentials, eq(credentials.userId, accounts.userId))
    .where(and(
      eq(accounts.environment, accountEnvironment()),
      eq(credentials.environment, accountEnvironment()),
    ))
    .orderBy(accounts.createdAt);
  return loginServersFromLinkedAccounts(linked);
}

type LocalLoginSelector = { server: string };

export async function loginLocal(req: Request, res: Response, selector: LocalLoginSelector, password: string) {
  const environment = accountEnvironment();
  const candidates = await db.select({ account: accounts, credential: credentials })
    .from(accounts).innerJoin(credentials, eq(credentials.userId, accounts.userId))
    .where(and(or(eq(accounts.role, "equipe"), eq(accounts.role, "editor")), eq(accounts.status, "active"),
      eq(accounts.environment, environment), eq(credentials.environment, environment)))
    .orderBy(accounts.createdAt);
  const selectedServer = normalizeLoginServer(selector.server);
  const serverRecord = candidates.find(({ account }) => normalizeLoginServer(account.server) === selectedServer);
  const brunoServerSelected = selectedServer === "BRUNO";
  let brunoEmail = "";
  if (brunoServerSelected) {
    const bruno = (await loadTeamMembers()).find((member) => normalizeLoginServer(member.name) === "BRUNO");
    brunoEmail = String(bruno?.email || "").trim();
  }
  const approvedBrunoAccount = !!serverRecord && brunoServerSelected &&
    (serverRecord.account.role === "equipe" || serverRecord.account.role === "editor") &&
    isBrunoAccountTarget(serverRecord.account.email, serverRecord.account.server, brunoEmail);
  const teamPassword = configuredPassword("TEAM_LOGIN_PASSWORD");
  const adminPassword = process.env.ADMIN_LOGIN_PASSWORD;
  const adminPasswordConfigured = typeof adminPassword === "string" && adminPassword.length >= 6;
  if (adminPasswordConfigured && passwordMatches(teamPassword, adminPassword)) {
    throw new AccountError(503, "password_collision", "As senhas da Equipe e da Administração precisam ser diferentes.");
  }
  const storedPasswordSecretKey = serverRecord &&
    accountPasswordSecretKey(serverRecord.account.role, serverRecord.account.server);
  const legacyBrunoCredential = !!serverRecord && approvedBrunoAccount &&
    (serverRecord.account.role === "equipe" || serverRecord.account.role === "editor") &&
    serverRecord.credential.passwordSecretKey === "BDUTRA_LOGIN_PASSWORD";
  const expectedStoredKey = storedPasswordSecretKey;
  const brunoPasswordMatches = !!serverRecord && approvedBrunoAccount &&
    (serverRecord.account.role === "editor" || serverRecord.account.adminAccess) &&
    !!expectedStoredKey &&
    (serverRecord.credential.passwordSecretKey === expectedStoredKey || legacyBrunoCredential) &&
    passwordMatches(password, teamPassword);
  const mode = resolveServerLoginMode({
    teamPasswordMatches: passwordMatches(password, teamPassword),
    adminPasswordMatches: adminPasswordConfigured && passwordMatches(password, adminPassword!),
    selectedServerHasAdminAccess: serverRecord?.account.adminAccess === true,
    selectedServerIsBruno: brunoServerSelected,
    selectedServerRole: serverRecord?.account.role ?? null,
    selectedServerPasswordMatches: brunoPasswordMatches,
  });
  const [adminRecord] = mode && !mode.useSelectedAccount
    ? await db.select({ account: accounts, credential: credentials })
      .from(accounts).innerJoin(credentials, eq(credentials.userId, accounts.userId))
      .where(and(eq(accounts.role, "administracao"), eq(accounts.status, "active"),
        eq(accounts.environment, environment), eq(credentials.environment, environment)))
      .limit(1)
    : [];
  let record = mode?.useSelectedAccount ? serverRecord : adminRecord;
  const accessRole = mode?.accessRole;
  if (mode?.accessRole === "administracao" && !record) {
    throw new AccountError(503, "admin_account_unavailable", "A conta de Administração ainda não está ativa neste ambiente.");
  }
  if (record?.credential.lockedUntil && record.credential.lockedUntil.getTime() > Date.now()) {
    throw new AccountError(429, "rate_limited", "Muitas tentativas. Aguarde 15 minutos e tente novamente.");
  }
  const brunoAdminSession = !!mode?.useSelectedAccount && approvedBrunoAccount && accessRole === "administracao";
  const accessPasswordSecret = brunoAdminSession
    ? "TEAM_LOGIN_PASSWORD"
    : accessRole && record && accountPasswordSecretKey(accessRole, record.account.server);
  const accountPasswordSecret = record &&
    accountPasswordSecretKey(record.account.role, record.account.server);
  const legacyBrunoStoredCredential = brunoAdminSession && !!record &&
    (record.account.role === "equipe" || record.account.role === "editor") &&
    record.credential.passwordSecretKey === "BDUTRA_LOGIN_PASSWORD";
  if (record && (!accessPasswordSecret || !accountPasswordSecret ||
      (record.credential.passwordSecretKey !== accountPasswordSecret && !legacyBrunoStoredCredential))) {
    throw new AccountError(503, "auth_unavailable", "O perfil desta conta não tem senha configurada.");
  }
  const expected = accessPasswordSecret ? configuredPassword(accessPasswordSecret) : "unavailable-account-password";
  const matches = !!record && !!accessRole && passwordMatches(password, expected);
  if (!record || !matches || !accessRole) {
    const failedRecord = record ?? serverRecord;
    if (failedRecord) await db.update(credentials).set({
      failedAttempts: sql`case when ${credentials.lockedUntil} <= now() then 1 else ${credentials.failedAttempts} + 1 end`,
      lockedUntil: sql`case when ${credentials.lockedUntil} <= now() then null when ${credentials.failedAttempts} >= 4 then now() + interval '15 minutes' else null end`,
    }).where(eq(credentials.userId, failedRecord.account.userId));
    throw new AccountError(401, "invalid_credentials", "Servidor ou senha inválidos.");
  }
  if (record.account.status === "disabled") throw new AccountError(403, "disabled", "Seu acesso foi desativado pela Administração.");
  if (brunoAdminSession && (record.account.role !== "equipe" || !record.account.adminAccess ||
      record.credential.passwordSecretKey !== "TEAM_LOGIN_PASSWORD")) {
    record = await consolidateBrunoAdminAccount(record.account.userId, environment, brunoEmail);
  }
  const oldToken = cookieToken(req);
  if (oldToken) await db.delete(sessions).where(eq(sessions.tokenHash, hash(oldToken)));
  const token = randomBytes(32).toString("hex");
  await db.transaction(async (tx) => {
    await tx.update(credentials).set({ failedAttempts: 0, lockedUntil: null }).where(eq(credentials.userId, record.account.userId));
    await tx.delete(sessions).where(sql`${sessions.expiresAt} <= now()`);
    await tx.insert(sessions).values({ tokenHash: hash(token), userId: record.account.userId, environment: accountEnvironment(),
      credentialStamp: stamp(accessPasswordSecret!, expected), accessRole, expiresAt: new Date(Date.now() + SESSION_SECONDS * 1000) });
  });
  setCookie(req, res, token, SESSION_SECONDS);
  return { account: record.account, accessRole };
}
export async function logoutLocal(req: Request, res: Response) {
  const token = cookieToken(req);
  const removed = token ? await db.delete(sessions).where(and(eq(sessions.tokenHash, hash(token)), eq(sessions.environment, accountEnvironment()))).returning({ userId: sessions.userId }) : [];
  setCookie(req, res, "", 0);
  return removed[0]?.userId;
}

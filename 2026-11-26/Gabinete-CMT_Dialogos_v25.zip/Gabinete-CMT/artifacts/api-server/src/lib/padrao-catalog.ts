/* Padrão (/padrao) · funções puras para montar catálogos locais, entregar mudanças incrementais
   por revisão e pesquisar precedentes no contrato esperado pelo gerador em /api/shared. */

export type PadraoRecord = Record<string, unknown> & { id: string };

export type PadraoCatalog = {
  revision: number;
  updatedAt: string;
  version: string;
  collections: Record<string, PadraoRecord[]>;
  precedents: PadraoRecord[];
};

export type PadraoChange = {
  collection: string;
  recordId: string;
  record: PadraoRecord;
  deleted: false;
  revision: number;
};

export class PadraoCatalogError extends Error {
  kind: "unavailable" | "invalid-response";
  constructor(kind: "unavailable" | "invalid-response", message?: string) {
    super(message || kind);
    this.kind = kind;
  }
}

/* catálogos simples, na ordem do gerador; "paradigmas" reúne os modelos (Modelo e Modelo-matriz) */
export const PADRAO_COLLECTIONS = ["assuntos", "jurisprudencia", "paragrafos", "normas", "redacao"] as const;
const MAX_RECORDS = 50_000;

const isObject = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);

function records(bank: unknown): PadraoRecord[] {
  if (!isObject(bank) || !Array.isArray(bank.registros)) return [];
  const out: PadraoRecord[] = [];
  for (const r of bank.registros) {
    if (!isObject(r)) continue;
    const id = typeof r.id === "string" || typeof r.id === "number" ? String(r.id).trim() : "";
    if (!id || id.length > 300) continue;
    out.push({ ...r, id });
  }
  return out;
}

export function buildPadraoCatalog(raw: unknown): PadraoCatalog {
  if (!isObject(raw) || raw.schema !== "gabcmt.catalogos" || !isObject(raw.bancos) || !isObject(raw.catalogos)) {
    throw new PadraoCatalogError("invalid-response", "Arquivo de catálogos fora do formato gabcmt.catalogos.");
  }
  const bancos = raw.bancos as Record<string, unknown>;
  const catalogos = raw.catalogos as Record<string, unknown>;
  const modelos = [...records(bancos["Modelo"]), ...records(bancos["Modelo-matriz"])].map((r) => ({ ...r, tipo: "Modelo" }));
  const precedents = records(bancos["Precedente"]).map((r) => ({ ...r, tipo: "Precedente" }));
  const collections: Record<string, PadraoRecord[]> = { paradigmas: dedupe(modelos) };
  for (const c of PADRAO_COLLECTIONS) collections[c] = dedupe(records(catalogos[c]));
  const total = Object.values(collections).reduce((n, l) => n + l.length, 0) + precedents.length;
  if (total > MAX_RECORDS) throw new PadraoCatalogError("invalid-response", "Catálogo excede o limite de registros.");
  const rev = Number(raw.source_revision);
  const updatedAt = typeof raw.atualizado_em === "string" ? raw.atualizado_em : "";
  const revision = Number.isSafeInteger(rev) && rev > 0 ? rev : Date.parse(updatedAt) || 1;
  return { revision, updatedAt, version: String(raw.versao ?? ""), collections, precedents: dedupe(precedents) };
}

function dedupe(list: PadraoRecord[]): PadraoRecord[] {
  const map = new Map<string, PadraoRecord>();
  for (const r of list) map.set(r.id, r);
  return [...map.values()];
}

/* entrega incremental: o gerador guarda a revisão; se já está nela, nada a enviar.
   julgados=excluir (padrão): bancos sem os precedentes, que vêm pela pesquisa;
   julgados=somente: só os precedentes (exportação completa); julgados=incluir: tudo. */
export function padraoCatalogChanges(cat: PadraoCatalog, sinceRevision: number, julgados = "excluir") {
  const since = Number.isFinite(sinceRevision) ? sinceRevision : 0;
  if (since >= cat.revision) return { revision: cat.revision, changes: [] as PadraoChange[] };
  const changes: PadraoChange[] = [];
  const push = (collection: string, list: PadraoRecord[]) => {
    for (const record of list) changes.push({ collection, recordId: record.id, record, deleted: false, revision: cat.revision });
  };
  if (julgados !== "somente") for (const [c, list] of Object.entries(cat.collections)) push(c, list);
  if (julgados === "somente" || julgados === "incluir") push("paradigmas", cat.precedents);
  return { revision: cat.revision, changes };
}

/* ───────── pesquisa dos precedentes: mesma gramática da busca do gerador ───────── */
const Nh = (s: unknown) => String(s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
const T = (s: unknown) => String(s ?? "").trim();
const CAMPOS: Record<string, number> = {
  processo: 8, nomeModelo: 8, assunto: 5, especificidadesTags: 4, temas: 4, tese: 3, causaPedir: 2, preliminares: 2,
  fundamentacao: 1, textoModelo: 1, resultado: 1, honorarios: 1, especificidades: 1, primeiroGrau: 1, processosAssociados: 1,
  parteNotavel: 1, jurisprudenciaCitada: 3, dispositivosCitados: 3, ementaIntegral: 1, ementaCabecalho: 1, inteiroTeor: 1,
  julgadorOrigem: 3, orgaoJulgador: 2,
};
const ESCOPOS: Record<string, string[]> = {
  tudo: Object.keys(CAMPOS),
  tese: ["tese", "fundamentacao", "causaPedir", "ementaIntegral"],
  assunto: ["assunto", "temas", "especificidadesTags", "ementaCabecalho"],
  citacoes: ["jurisprudenciaCitada", "dispositivosCitados"],
  numero: ["processo", "processosAssociados", "primeiroGrau"],
  resultado: ["resultado", "honorarios"],
  integral: ["inteiroTeor", "ementaIntegral", "textoModelo"],
};
const PREF: Record<string, string[]> = {
  tese: ["tese", "fundamentacao"], tag: ["especificidadesTags", "temas"], tema: ["temas", "especificidadesTags"], assunto: ["assunto"],
  proc: ["processo", "processosAssociados"], res: ["resultado"], cit: ["jurisprudenciaCitada"], disp: ["dispositivosCitados"],
  ementa: ["ementaIntegral", "ementaCabecalho"], it: ["inteiroTeor"], integra: ["inteiroTeor"],
};
type Term = { t: string; neg: boolean; frase: boolean; campos: string[] | null };

export function parsePadraoQuery(q: string): Term[] {
  const out: Term[] = [];
  const re = /(-)?(?:([A-Za-z]+):)?(?:"([^"]*)"?|(\S+))/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(q))) {
    const pk = m[2] && PREF[Nh(m[2])] ? Nh(m[2]) : null;
    let raw = m[3] !== undefined ? m[3] : m[4] || "";
    if (m[2] && !pk) raw = m[2] + ":" + raw;
    const t = Nh(raw).trim();
    if (t) out.push({ t, neg: !!m[1], frase: m[3] !== undefined, campos: pk ? PREF[pk] : null });
    if (out.length >= 24) break;
  }
  return out;
}

const escRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
/* texto normalizado por registro e campo, calculado uma vez (o catálogo é imutável entre leituras) */
const NORM = new WeakMap<PadraoRecord, Map<string, string>>();
function texto(x: PadraoRecord, c: string) {
  let m = NORM.get(x);
  if (!m) { m = new Map(); NORM.set(x, m); }
  let t = m.get(c);
  if (t === undefined) {
    const v = x[c];
    t = Nh(Array.isArray(v) ? v.join(" ; ") : typeof v === "object" && v ? JSON.stringify(v) : v);
    m.set(c, t);
  }
  return t;
}
function casa(x: PadraoRecord, terms: Term[], campos: string[], any: boolean): number | null {
  let score = 0, hit = false;
  for (const t of terms) {
    const cs = t.campos || campos;
    const hits = cs.filter((c) => texto(x, c).includes(t.t));
    if (t.neg) { if (hits.length) return null; continue; }
    if (!hits.length) { if (any) continue; return null; }
    hit = true;
    const wb = new RegExp("(^|[^a-z0-9])" + escRe(t.t) + "($|[^a-z0-9])");
    for (const c of hits) score += (CAMPOS[c] || 1) * (wb.test(texto(x, c)) ? 1.6 : 1) * (t.frase ? 1.3 : 1);
  }
  return hit || !terms.some((t) => !t.neg) ? score : null;
}
const curado = (x: PadraoRecord) => T(x.statusCuradoria) !== "bruto";
const lista = (v: unknown) => T(v).split("|").map(T).filter(Boolean);
const classeDe = (x: PadraoRecord) => T(x.classe || x.especie);
const classeCasa = (x: PadraoRecord, c: string) => {
  const a = Nh(classeDe(x)), b = Nh(c), s = Nh(x.classeSigla);
  return !!b && (a === b || a.includes(b) || b.includes(a) && !!a || (!!s && s === b));
};

export function searchPadraoPrecedents(cat: PadraoCatalog, params: Record<string, unknown>) {
  const q = T(params.q).slice(0, 240);
  const modo = T(params.modo) === "similar" ? "similar" : "busca";
  const offset = Math.max(0, Math.min(1_000_000, Number(params.offset) || 0));
  const limit = Math.max(1, Math.min(100, Number(params.limit) || 25));
  const campos = ESCOPOS[T(params.escopo)] || ESCOPOS.tudo;
  const terms = modo === "similar"
    ? q.split("|").map((p) => Nh(p).trim()).filter((p) => p.length >= 2).slice(0, 12).map((t) => ({ t, neg: false, frase: true, campos: null }))
    : parsePadraoQuery(q);
  const pron = lista(params.pronunciamentos), classes = lista(params.classes), ass = lista(params.assuntos), cur = lista(params.curadoria);
  const classeProc = T(params.classeProcesso);
  const Q: { x: PadraoRecord; i: number; score: number }[] = [];
  cat.precedents.forEach((x, i) => {
    if (x.pronunciamento === "Despacho") return;
    const score = terms.length ? casa(x, terms, campos, modo === "similar") : 0;
    if (score !== null) Q.push({ x, i, score });
  });
  const passa = (x: PadraoRecord, exc = "") =>
    (exc === "pron" || !pron.length || pron.includes(T(x.pronunciamento)))
    && (exc === "classe" || ((!classes.length || classes.some((c) => classeCasa(x, c))) && (!classeProc || classeCasa(x, classeProc))))
    && (exc === "ass" || !ass.length || ass.includes(T(x.assunto)))
    && (exc === "cur" || !cur.length || cur.includes(curado(x) ? "curado" : "bruto"));
  const conta = (exc: string, key: (x: PadraoRecord) => string) => {
    const m: Record<string, number> = {};
    for (const { x } of Q) if (passa(x, exc)) { const k = key(x); m[k] = (m[k] || 0) + 1; }
    return m;
  };
  const cu = conta("cur", (x) => (curado(x) ? "curado" : "bruto"));
  const facets = {
    pronunciamentos: conta("pron", (x) => T(x.pronunciamento)),
    classes: conta("classe", (x) => classeDe(x) || "(sem classe)"),
    assuntos: conta("ass", (x) => T(x.assunto)),
    curadoria: { curado: cu.curado || 0, bruto: cu.bruto || 0 },
  };
  const porData = T(params.ordem) === "data";
  const R = Q.filter(({ x }) => passa(x)).sort((a, b) =>
    porData
      ? T(b.x.data).localeCompare(T(a.x.data)) || a.i - b.i
      : (b.score - a.score) || ((curado(b.x) ? 0.5 : 0) - (curado(a.x) ? 0.5 : 0)) || a.i - b.i);
  const page = R.slice(offset, offset + limit).map(({ x }) => x);
  return { records: page, offset, total: R.length, hasMore: offset + page.length < R.length, facets: modo === "busca" ? facets : null };
}

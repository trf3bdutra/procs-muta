import { createHmac, timingSafeEqual } from "node:crypto";

export type AgentMailSelection = {
  inboxId: string;
  messageId: string;
  query: string;
  userId: string;
  expiresAt: number;
};

export function signAgentMailSelection(
  selection: Omit<AgentMailSelection, "expiresAt">,
  secret: string,
  now = Date.now(),
): string {
  if (!secret) throw new Error("A assinatura da consulta não está configurada.");
  const payload = Buffer.from(JSON.stringify({
    ...selection, expiresAt: now + 30 * 60_000,
  })).toString("base64url");
  const signature = createHmac("sha256", secret).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

export function verifyAgentMailSelection(
  token: string,
  secret: string,
  userId: string,
  inboxId: string,
  now = Date.now(),
): AgentMailSelection | null {
  if (!secret || token.length > 12_000) return null;
  const [payload, signature, extra] = token.split(".");
  if (!payload || !signature || extra !== undefined) return null;
  const expected = createHmac("sha256", secret).update(payload).digest();
  const actual = Buffer.from(signature, "base64url");
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) return null;
  try {
    const value = JSON.parse(Buffer.from(payload, "base64url").toString()) as AgentMailSelection;
    return value.userId === userId && value.inboxId === inboxId
      && typeof value.messageId === "string" && !!value.messageId
      && typeof value.query === "string"
      && Number.isFinite(value.expiresAt) && value.expiresAt > now
      ? value : null;
  } catch {
    return null;
  }
}

export function selectedAgentMailMessages(
  tokens: string[],
  query: string,
  secret: string,
  userId: string,
  inboxId: string,
): string[] {
  if (!query.trim() || tokens.length < 1 || tokens.length > 50) {
    throw new Error("Busque um texto e selecione entre 1 e 50 e-mails filtrados.");
  }
  const ids = new Set<string>();
  for (const token of tokens) {
    const selection = verifyAgentMailSelection(token, secret, userId, inboxId);
    if (!selection || selection.query !== query.trim()) {
      throw new Error("A seleção expirou ou pertence a outra busca. Busque novamente.");
    }
    ids.add(selection.messageId);
  }
  return [...ids];
}

export function agentMailConsultationPath(inboxId: string, query: string, pageToken = ""): string {
  const params = new URLSearchParams({ limit: "30" });
  if (pageToken) params.set("page_token", pageToken);
  if (query.trim()) {
    params.set("q", query.trim());
  } else {
    // Browsing includes every category that the inbound key is authorized to read.
    for (const flag of ["spam", "trash", "blocked", "unauthenticated"]) params.set(`include_${flag}`, "true");
  }
  return `/v0/inboxes/${encodeURIComponent(inboxId)}/messages${query.trim() ? "/search" : ""}?${params}`;
}

import type { AcervoPautaRecord, AcervoPautaPatch } from "./acervo-pauta-sync";

type RecordData = Record<string, unknown>;
const record = (value: unknown): value is RecordData => !!value && typeof value === "object" && !Array.isArray(value);
const digits = (value: unknown) => String(value ?? "").replace(/\D/g, "");
const same = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);
const empty = (v: unknown) => v == null || v === "" || (Array.isArray(v) && !v.length);
const fields = {
  classe: "classe_judicial", assunto: "Assunto", partes: "Partes",
  tarefa: "tarefa_atual", etiquetas: "etiquetas",
} as const;

export function triagemRows(state: RecordData): RecordData[] {
  const team = record(state.team) ? state.team : {};
  const triagem = record(team.triagem) ? team.triagem : {};
  return Array.isArray(triagem.rows) ? triagem.rows.filter(record) : [];
}

function scope(row: RecordData) { return `triagem:${String(row.id || digits(row.processo))}`; }

/** Same official Acervo, but triage workflow/checklist and assignments remain its own. */
export function applyAcervoToTriagem(state: RecordData, records: AcervoPautaRecord[]) {
  const rows = triagemRows(state);
  if (!rows.length || !records.length) return { state, changed: false };
  const byProcess = new Map(records.map((r) => [digits(r.processo), r]));
  let changed = false;
  const next = rows.map((row) => {
    const source = byProcess.get(digits(row.processo));
    if (!source) return row;
    const managed = record(row._acervoManagedTriagem) ? row._acervoManagedTriagem : {};
    const scoped = source.pautasPorFicha?.[scope(row)];
    const overrides = record(scoped) ? scoped : {};
    const nextManaged = { ...managed };
    const updated = { ...row };
    let rowChanged = false;
    for (const [field, canonical] of Object.entries(fields)) {
      const incoming = source.linha[canonical];
      if (!empty(incoming) && (empty(row[field]) || same(row[field], managed[field]) || same(row[field], incoming))) {
        if (!same(updated[field], incoming)) { updated[field] = structuredClone(incoming); rowChanged = true; }
        if (!same(nextManaged[field], incoming)) { nextManaged[field] = structuredClone(incoming); rowChanged = true; }
      }
      if (Object.hasOwn(overrides, canonical) && !same(updated[field], overrides[canonical])) {
        updated[field] = structuredClone(overrides[canonical]);
        rowChanged = true;
      }
    }
    if (!rowChanged) return row;
    changed = true;
    return { ...updated, _acervoManagedTriagem: nextManaged };
  });
  if (!changed) return { state, changed: false };
  const team = state.team as RecordData;
  return { state: { ...state, team: { ...team, triagem: { ...(team.triagem as RecordData), rows: next } } }, changed: true };
}

export function collectTriagemAcervoPatches(before: RecordData, next: RecordData): AcervoPautaPatch[] {
  const previous = new Map(triagemRows(before).map((r) => [`${digits(r.processo)}:${scope(r)}`, r]));
  const patches: AcervoPautaPatch[] = [];
  for (const row of triagemRows(next)) {
    const processo = digits(row.processo);
    if (processo.length !== 20) continue;
    const prior = previous.get(`${processo}:${scope(row)}`);
    if (!prior) continue;
    const managed = record(row._acervoManagedTriagem) ? row._acervoManagedTriagem : {};
    const patch: AcervoPautaPatch = { processo, escopo: scope(row), setFields: {}, removeFields: [] };
    for (const [field, canonical] of Object.entries(fields)) {
      if (same(prior[field], row[field])) continue;
      if (Object.hasOwn(managed, field) && same(row[field], managed[field])) patch.removeFields.push(canonical);
      else patch.setFields[canonical] = row[field] ?? "";
    }
    if (Object.keys(patch.setFields).length || patch.removeFields.length) patches.push(patch);
  }
  return patches;
}

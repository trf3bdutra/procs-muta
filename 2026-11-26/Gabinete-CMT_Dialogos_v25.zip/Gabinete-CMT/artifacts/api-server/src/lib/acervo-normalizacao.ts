type Json = any;
type Mapa = Map<string, Json>;

const vazio = (v: unknown) =>
  v == null || v === "" || (Array.isArray(v) && !v.length) ||
  (typeof v === "object" && !Array.isArray(v) && !Object.keys(v as object).length);
const copia = <T>(v: T): T => v == null ? v : JSON.parse(JSON.stringify(v));
const objeto = (v: unknown): Json => v && typeof v === "object" && !Array.isArray(v) ? v : {};
const primeiro = (...v: unknown[]) => v.find((x) => !vazio(x));

export const digitos = (v: unknown) => String(v ?? "").replace(/\D/g, "");
export const idDe = (processo: unknown) => `acv-${digitos(processo)}`;

export function cnj(v: unknown): string {
  const d = digitos(v);
  return d.length === 20 ? `${d.slice(0, 7)}-${d.slice(7, 9)}.${d.slice(9, 13)}.${d.slice(13, 14)}.${d.slice(14, 16)}.${d.slice(16)}` : String(v ?? "");
}

const IMPORTADOS = new Set([
  "id", "processo", "Processo", "classe", "classe_judicial", "Classe", "Código_Classe", "classeCodigo",
  "assunto", "assunto_judicial", "Assunto", "Assunto_Principal", "Assuntos_do_Processo", "Código_Assunto_Principal", "assuntoCodigo", "assuntos",
  "poloAtivo", "polo_ativo", "Polo_Ativo", "poloPassivo", "polo_passivo", "Polo_Passivo", "Partes",
  "etiquetas", "Etiquetas", "Etiquetas Originais", "Etiquetas Operacionais", "tarefaAtual", "tarefa_atual", "data_entrada_tarefa",
  "dataEntradaTarefa", "dataDistribuicao", "data_distribuição", "Data_Distribuição", "Data_Distribuição_1G", "dataDistribuicao1g",
  "dataUltimaDistribuicao", "dataUltimaMovimentacao", "Data_Última_Movimentação", "Última_Movimentação",
  "ultimaMovimentacao", "ultimo_movimento", "valorCausa", "valor_causa", "Valor_da_Causa", "prioridade", "dpu", "mpf",
  "advogadoPoloAtivo", "advogadoPoloPassivo", "advogado_pa", "advogado_pp", "nivelSigilo", "Consta_Acervo_Sigiloso",
  "secaoOrigem", "Seção de Origem", "assuntos", "fontes", "origens", "divergencias", "atualizadoEm", "atualizado_em",
  "situacao", "historicoSituacao", "historico_situacao", "importado", "operacional", "dataJudAtualizadoEm",
]);

const ALIASES: Record<string, string[]> = {
  classe: ["classe", "classe_judicial", "Classe"],
  assunto: ["assunto", "assunto_judicial", "Assunto_Principal", "Assunto"],
  assuntos: ["assuntos", "Assuntos_do_Processo"],
  poloAtivo: ["poloAtivo", "polo_ativo", "Polo_Ativo"],
  poloPassivo: ["poloPassivo", "polo_passivo", "Polo_Passivo"],
  etiquetas: ["etiquetas", "Etiquetas Operacionais", "Etiquetas", "Etiquetas Originais"],
  tarefaAtual: ["tarefaAtual", "tarefa_atual"],
  dataEntradaTarefa: ["dataEntradaTarefa", "data_entrada_tarefa"],
  dataDistribuicao: ["dataDistribuicao", "data_distribuição", "Data_Distribuição"],
  dataDistribuicao1g: ["dataDistribuicao1g", "dt_distribuicao_1g"],
  dataUltimaDistribuicao: ["dataUltimaDistribuicao"],
  dataUltimaMovimentacao: ["dataUltimaMovimentacao", "Data_Última_Movimentação"],
  ultimaMovimentacao: ["ultimaMovimentacao", "ultimo_movimento", "Última_Movimentação"],
  valorCausa: ["valorCausa", "valor_causa", "Valor_da_Causa"],
  prioridade: ["prioridade"],
  dpu: ["dpu", "DPU (controle)"],
  mpf: ["mpf", "MPF"],
  advogadoPoloAtivo: ["advogadoPoloAtivo", "advogado_pa"],
  advogadoPoloPassivo: ["advogadoPoloPassivo", "advogado_pp"],
  secaoOrigem: ["secaoOrigem", "Seção de Origem"],
};

export function padronizarImportado(registro: Json): Json {
  const raw = objeto(registro);
  const saved = objeto(raw.importado);
  const result: Json = { ...saved, id: raw.id || saved.id || idDe(raw.processo), processo: cnj(raw.processo ?? raw.Processo) };
  for (const [field, names] of Object.entries(ALIASES)) {
    const value = primeiro(saved[field], ...names.map((key) => raw[key]));
    if (!vazio(value)) result[field] = value;
  }
  if (!result.fontes && Array.isArray(raw.fontes)) result.fontes = raw.fontes;
  if (!result.atualizadoEm) result.atualizadoEm = raw.atualizado_em || raw.atualizadoEm || "";
  return result;
}

const semOcultos = (v: unknown) => !/^#+$/.test(String(v ?? "").trim());

export function partesDe(imp: Json): string {
  return [imp?.poloAtivo, imp?.poloPassivo].filter((x) => !vazio(x) && semOcultos(x)).join(" x ");
}

export function etiquetasDe(imp: Json): string[] {
  const raw = imp?.etiquetas;
  if (Array.isArray(raw)) return raw.map(String).map((x) => x.trim()).filter(Boolean);
  const text = String(raw ?? "").trim();
  if (!text) return [];
  return (/[;|\n]/.test(text) ? text.split(/[;|\n]+/) : text.split(/,\s+/)).map((x) => x.trim()).filter(Boolean);
}

export function linhaDaPauta(imp: Json, op: Json = {}): Json {
  const row = { ...objeto(imp) };
  delete row.importado;
  delete row.operacional;
  const technical = objeto(row._);
  delete row._;
  for (const [innerKey, value] of Object.entries(technical)) if (row[innerKey] === undefined) row[innerKey] = value;
  const imported = padronizarImportado(imp);
  const fill = (key: string, value: unknown) => { if (!vazio(value)) row[key] = value; };
  fill("Processo", imported.processo);
  fill("classe_judicial", imported.classe);
  fill("assunto_judicial", imported.assunto);
  fill("Assunto", imported.assunto);
  fill("polo_ativo", imported.poloAtivo);
  fill("polo_passivo", imported.poloPassivo);
  fill("etiquetas", imported.etiquetas);
  fill("tarefa_atual", imported.tarefaAtual);
  fill("data_entrada_tarefa", imported.dataEntradaTarefa);
  fill("data_distribuição", imported.dataDistribuicao);
  fill("ultimo_movimento", imported.ultimaMovimentacao);
  fill("Data_Última_Movimentação", imported.dataUltimaMovimentacao);
  fill("valor_causa", imported.valorCausa);
  fill("Partes", partesDe(imported));
  for (const [key, value] of Object.entries(objeto(op?.pauta))) row[key] = copia(value);
  return row;
}

export function triagemDe(imp: Json, op: Json): Json {
  const imported = padronizarImportado(imp);
  const et = etiquetasDe(imported);
  const sec = et.map((t) => t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().match(/^([1-4])[aªº°]?\s*secao$/)).find(Boolean);
  const src: Json = {};
  const put = (k: string, v: unknown) => { if (!vazio(v) && semOcultos(v)) src[k] = String(v).slice(0, 300); };
  put("ultimo_movimento", imported.ultimaMovimentacao);
  put("Data_Última_Movimentação", imported.dataUltimaMovimentacao);
  put("tarefa_atual", imported.tarefaAtual);
  put("valor_causa", imported.valorCausa);
  put("advogado_pa", imported.advogadoPoloAtivo);
  put("advogado_pp", imported.advogadoPoloPassivo);
  put("Seção de Origem", imported.secaoOrigem);
  const triagem: Json = {
    classe: imported.classe || "",
    assunto: imported.assunto || "",
    partes: partesDe(imported),
    etiquetas: et,
    tarefa: imported.tarefaAtual || "",
    entradaTarefa: imported.dataEntradaTarefa || "",
    distribuicao: imported.dataDistribuicao || "",
    prioridade: /^(sim|s|true|1)$/i.test(String(imported.prioridade || "")) ? "Prioridade no PJe" : "",
    src,
  };
  if (sec) triagem.secao = `${sec[1]}ª Seção`;
  const salvo = objeto(op).triagem || objeto(objeto(op).tecnico)._triagem;
  if (salvo && typeof salvo === "object") triagem.salvo = salvo;
  return triagem;
}

export function basicoDe(imp: Json): Json {
  const imported = padronizarImportado(imp);
  return {
    classe: imported.classe || "",
    assunto: imported.assunto || "",
    partes: partesDe(imported),
    distribuicao: imported.dataDistribuicao || "",
    ultimaMovimentacao: imported.dataUltimaMovimentacao || "",
  };
}

export function formatarConsulta(processos: string[], importados: Mapa, operacionais: Mapa, _corr: Json, commit: string, repo = "") {
  const vistos = new Set<string>(), registros: Json[] = [], naoEncontrados: string[] = [];
  for (const requested of processos) {
    const d = digitos(requested);
    if (d.length !== 20 || vistos.has(d)) continue;
    vistos.add(d);
    const raw = importados.get(d);
    if (!raw) { naoEncontrados.push(cnj(d)); continue; }
    const op = operacionais.get(d) || objeto(raw.operacional);
    const linha = linhaDaPauta(raw, {});
    const chavesOp = new Set<string>(Object.keys(objeto(op?.pauta)));
    for (const values of Object.values(objeto(op?.pautasPorFicha))) {
      for (const key of Object.keys(objeto(values))) chavesOp.add(key);
    }
    for (const key of Object.keys(linha)) {
      if (!IMPORTADOS.has(key) && !["_", "atualizadoEm", "id"].includes(key)) chavesOp.add(key);
    }
    const imported = padronizarImportado(raw);
    registros.push({
      processo: cnj(d),
      linha,
      chavesOp: [...chavesOp],
      operacional: op,
      triagem: triagemDe(imported, op),
      basico: basicoDe(imported),
    });
  }
  return { commit, ...(repo ? { repo } : {}), registros, naoEncontrados };
}

export function mapearDataJud(hit: Json): Json {
  const source = objeto(hit?._source ?? hit);
  const parties: Json[] = Array.isArray(source.partes) ? source.partes : [];
  const role = (p: Json) => String(p?.polo?.nome ?? p?.polo ?? p?.tipoParte ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  const names = (wanted: RegExp) => parties.filter((p) => wanted.test(role(p))).map((p) => String(p?.nome ?? p?.nomeParte ?? "").trim()).filter(Boolean).join("; ");
  const movements = Array.isArray(source.movimentos) ? source.movimentos : [];
  const timestamp = (value: unknown) => {
    const text = String(value ?? "").trim();
    const compact = text.match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/);
    if (compact) return Date.UTC(+compact[1], +compact[2] - 1, +compact[3], +compact[4], +compact[5], +compact[6]);
    const compactDate = text.match(/^(\d{4})(\d{2})(\d{2})$/);
    if (compactDate) return Date.UTC(+compactDate[1], +compactDate[2] - 1, +compactDate[3]);
    const parsed = Date.parse(text);
    return Number.isFinite(parsed) ? parsed : 0;
  };
  const dataCivil = (value: unknown) => {
    const text = String(value ?? "");
    const compact = text.match(/^(\d{4})(\d{2})(\d{2})/);
    return compact ? `${compact[1]}-${compact[2]}-${compact[3]}` : text.slice(0, 10);
  };
  const ordenarMovimentos = [...movements].sort((a, b) =>
    timestamp(b?.dataHora || b?.data) - timestamp(a?.dataHora || a?.data)
  );
  const latest = ordenarMovimentos[0];
  const classe = objeto(source.classe);
  const className = classe.nome || classe.descricao || "";
  const subjects: Json[] = Array.isArray(source.assuntos) ? source.assuntos : [];
  const subject = subjects.map((x: Json) => x?.nome || x?.descricao).filter(Boolean).join("; ");
  const amount = source.valorCausa?.valor ?? source.valorCausa;
  const orgao = objeto(source.orgaoJulgador);
  const movimentoDataJud = (movimento: Json) => ({
    dataHora: String(movimento?.dataHora || movimento?.data || ""),
    codigo: movimento?.codigo ?? movimento?.movimentoNacional?.codigo ?? null,
    nome: String(movimento?.nome || movimento?.movimentoNacional?.nome || "").trim(),
    complementos: (Array.isArray(movimento?.complementosTabelados) ? movimento.complementosTabelados : [])
      .map((item: Json) => ({
        codigo: item?.codigo ?? null,
        nome: String(item?.nome || item?.descricao || "").trim(),
      }))
      .filter((item: Json) => item.nome),
  });
  const dataJudDoc = {
    id: String(hit?._id || source.grau || "principal"),
    grau: String(source.grau || ""),
    classe: {
      codigo: classe.codigo ?? classe.id ?? null,
      nome: String(className || ""),
    },
    orgaoJulgador: {
      id: orgao.id ?? null,
      codigo: orgao.codigo ?? orgao.codigoOrgao ?? null,
      nome: String(orgao.nome || ""),
    },
    nivelSigilo: source.nivelSigilo ?? null,
    dataAjuizamento: source.dataAjuizamento ?? null,
    dataHoraUltimaAtualizacao: source.dataHoraUltimaAtualizacao ?? null,
    dataCarga: source["@timestamp"] ?? null,
    assuntos: subjects.map((item) => ({
      codigo: item?.codigo ?? item?.id ?? null,
      nome: String(item?.nome || item?.descricao || "").trim(),
    })).filter((item) => item.nome),
    partes: parties.map((p) => ({
      polo: String(p?.polo?.nome ?? p?.polo ?? p?.tipoParte ?? "").trim(),
      nome: String(p?.nome ?? p?.nomeParte ?? "").trim(),
    })).filter((p) => p.nome),
    valorCausa: source.valorCausa ?? null,
    movimentos: ordenarMovimentos.slice(0, 20).map(movimentoDataJud).filter((item) => item.nome || item.dataHora),
  };
  return {
    ...(className ? { classe: String(className) } : {}),
    ...(subject ? { assunto: subject } : {}),
    ...(names(/ativo/).length ? { poloAtivo: names(/ativo/) } : {}),
    ...(names(/passivo/).length ? { poloPassivo: names(/passivo/) } : {}),
    ...(source.dataAjuizamento ? { dataDistribuicao: dataCivil(source.dataAjuizamento) } : {}),
    ...(latest?.nome ? { ultimaMovimentacao: String(latest.nome) } : {}),
    ...(latest?.dataHora || latest?.data ? { dataUltimaMovimentacao: dataCivil(latest.dataHora || latest.data) } : {}),
    ...(amount != null ? { valorCausa: String(amount) } : {}),
    datajud: { documentos: [dataJudDoc] },
  };
}

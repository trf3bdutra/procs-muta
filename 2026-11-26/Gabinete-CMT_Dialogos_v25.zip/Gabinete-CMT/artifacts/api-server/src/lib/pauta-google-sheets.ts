export type PautaGoogleSheetTab = {
  key: string;
  title: string;
  values: string[][];
};

type JsonRecord = Record<string, unknown>;
const MAX_GOOGLE_SHEETS_CELL_LENGTH = 48_000;

const isRecord = (value: unknown): value is JsonRecord =>
  Boolean(value) && typeof value === "object" && !Array.isArray(value);

const text = (value: unknown): string => {
  let formatted = "";
  if (typeof value === "string") formatted = value.trim();
  else if (typeof value === "number" || typeof value === "boolean") formatted = String(value);
  else if (Array.isArray(value)) formatted = value.map(text).filter(Boolean).join("; ");
  else if (isRecord(value)) {
    formatted = Object.entries(value)
      .map(([key, item]) => {
        const formatted = text(item);
        return formatted ? `${key}: ${formatted}` : "";
      })
      .filter(Boolean)
      .join("; ");
  }
  if (formatted.length <= MAX_GOOGLE_SHEETS_CELL_LENGTH) return formatted;
  const marker = "… [texto truncado]";
  return `${formatted.slice(0, MAX_GOOGLE_SHEETS_CELL_LENGTH - marker.length)}${marker}`;
};

const rowProcess = (row: JsonRecord): string =>
  text(row.Processo ?? row.processo ?? row.CNJ ?? row.cnj);

const sessionName = (value: unknown): string => {
  if (typeof value === "string" || typeof value === "number") return text(value);
  if (!isRecord(value)) return "";
  return text(value.label ?? value.nome ?? value.date ?? value.data ?? value.id);
};

const rowEntries = (row: JsonRecord): JsonRecord[] =>
  Array.isArray(row._pautaEntries)
    ? row._pautaEntries.filter(isRecord)
    : [];

const entrySession = (entry: JsonRecord): string =>
  sessionName(entry.session ?? entry.sessao ?? entry["Sessão"]);

const field = (row: JsonRecord, ...names: string[]): string => {
  for (const name of names) {
    const value = text(row[name]);
    if (value) return value;
  }
  return "";
};

const PROCESS_COLUMNS: Array<[string, (row: JsonRecord, entry: JsonRecord) => unknown]> = [
  ["Item da pauta", (row, entry) => entry.item ?? row["Item (Pauta de Julgamento)"] ?? row.item],
  ["Processo CNJ", (row) => rowProcess(row)],
  ["Sessão", (_row, entry) => entrySession(entry)],
  ["Tipo de julgamento", (row, entry) => entry.tipoJulgamento ?? entry.tipo_julgamento ?? row["Tipo de julgamento"] ?? row["Tipo de Julgamento"]],
  ["Status na pauta", (row, entry) => entry.status ?? row["Status de Julgamento"] ?? row.status ?? row.JULGAMENTO],
  ["Classe processual", (row) => field(row, "classe_judicial", "Classe", "Classe processual")],
  ["Assunto", (row) => field(row, "Assunto", "assunto", "assunto_judicial")],
  ["Tema", (row) => row.Tema],
  ["Tópico-síntese", (row) => row["Tópico-síntese"]],
  ["Seção", (row) => row["Seção"]],
  ["Seção de origem", (row) => row["Seção de Origem"]],
  ["Seção competente", (row) => row["Seção competente"]],
  ["Partes", (row) => field(row, "Partes", "partes")],
  ["Polo ativo", (row) => row.polo_ativo],
  ["Polo passivo", (row) => row.polo_passivo],
  ["Advogado · polo ativo", (row) => row.advogado_pa],
  ["Advogado · polo passivo", (row) => row.advogado_pp],
  ["Servidor", (row) => field(row, "SERVIDOR", "Servidor", "servidor")],
  ["Corretor/revisor", (row) => field(row, "CORRETOR", "Corretor", "REVISOR", "Revisor")],
  ["Tarefa atual", (row) => row.tarefa_atual],
  ["Data de distribuição", (row) => row.Data_Distribuição ?? row.data_distribuição ?? row.data_distribuicao],
  ["Entrada na tarefa", (row) => row.data_entrada_tarefa],
  ["Última movimentação · data", (row) => row.Data_Última_Movimentação ?? row["Última_Movimentação"]],
  ["Última movimentação", (row) => row.ultimo_movimento],
  ["Meta", (row) => row.META],
  ["Prioridade", (row) => row.prioridade],
  ["Etiquetas", (row) => row.Etiquetas ?? row.etiquetas],
  ["Regularidade", (row) => row.Regularidade ?? row["Regularidade Manual"]],
  ["Tempestividade", (row) => row.Tempestividade],
  ["Preparo", (row) => row.Preparo],
  ["Representação", (row) => row.Representação ?? row["Observação da Representação"]],
  ["Observação da representação", (row) => row["Observação da Representação"]],
  ["Alegações", (row) => row.Alegações],
  ["Preliminares", (row) => row["Prelim."]],
  ["Contrarrazões", (row) => row["Contrarrazões - Situação"] ?? row["Contrarrazões Ausentes"]],
  ["MPF · ID do parecer", (row) => row["ID do Parecer MPF"]],
  ["MPF · sem ID", (row) => row["MPF - Sem ID"]],
  ["MPF · custos legis", (row) => row["MPF - Custos Legis"] ?? row.MPF],
  ["MPF · informação adicional", (row) => row["MPF - Info adicional"]],
  ["DPU", (row) => row["DPU (controle)"] ?? row.dpu],
  ["Mídias", (row) => row["Mídias Necessárias"] ?? row.Mídias],
  ["ID da procuração", (row) => row["ID da Procuração"]],
  ["Observações", (row) => row.Observações],
  ["Observação complementar", (row) => row["Observação Complementar"]],
  ["Especificidades", (row) => row._pautaSpecificities],
  ["Intercorrências e alertas", (row) => row.Intercorrências],
  ["Incidentes registrados", (row) => row._pautaIncidents],
  ["Ocorrências", (row) => row._ocorrencias],
  ["Histórico da pauta", (row) => row._pautaHistory],
  ["Sentença · ID", (row) => row["Sentença - ID"]],
  ["Sentença · sem ID", (row) => row["Sentença - Sem ID"]],
  ["Sentença · decisão", (row) => row["Sentença - Decisão"]],
  ["Sentença · resultado", (row) => row["Sentença - Resultado"]],
  ["Sentença · fundamento", (row) => row["Sentença - Fundamento"]],
  ["Voto · resultado", (row) => row["Voto - Resultado"]],
  ["Voto · tópico", (row) => row["Voto - Tópico"]],
  ["Voto · descrição", (row) => row["Voto - Descrição"]],
  ["Voto · honorários", (row) => row["Voto - Honorários"]],
  ["Revisão · mérito", (row) => row["Rev - Mérito"]],
  ["Revisão · atenção", (row) => row["Rev - Atenção"] ?? row["Rev - Nota de atenção"]],
  ["Revisão · ementa", (row) => row["Rev - Ementa"]],
  ["Revisão · subementa", (row) => row["Rev - Subementa"] ?? row["Revisão da subementa"]],
  ["Revisão · honorários", (row) => row["Rev - Honorários"]],
  ["Revisão · IDs", (row) => row["Rev - IDs"]],
  ["Minutado", (row) => row.MINUTADO],
  ["Minutado por", (row) => row._minutadoBy],
  ["Sessão da minuta", (row) => row._minutadoSession],
  ["Corrigido", (row) => row.CORRIGIDO],
  ["Liberado", (row) => row.LIBERADO],
  ["Incluído em", (_row, entry) => entry.includedAt],
  ["Julgado", (_row, entry) => entry.julgado],
  ["Data do julgamento", (_row, entry) => entry.julgadoEm],
  ["Encerrado", (_row, entry) => entry.closed],
  ["Próxima sessão", (_row, entry) => entry.next],
  ["Avanço automático", (_row, entry) => entry.autoNext],
];

const PROCESS_HEADERS = PROCESS_COLUMNS.map(([header]) => header);

function processValues(row: JsonRecord, entry: JsonRecord): string[] {
  return PROCESS_COLUMNS.map(([, read]) => text(read(row, entry)));
}

function sessionDate(details: JsonRecord, label: string): string {
  const configured = text(details.date ?? details.data);
  if (configured) return configured;
  const match = label.match(/^(\d{1,2})[/. -](\d{1,2})[/. -](\d{4})$/);
  return match ? `${match[3]}-${match[2].padStart(2, "0")}-${match[1].padStart(2, "0")}` : label;
}

function safeSheetTitle(label: string): string {
  const date = label.match(/^(\d{1,2})[/. -](\d{1,2})[/. -](\d{4})$/);
  const readable = date
    ? `Sessão ${date[1].padStart(2, "0")}-${date[2].padStart(2, "0")}-${date[3]}`
    : `Sessão ${label}`;
  return readable.replace(/[\[\]:*?/\\']/g, "-").slice(0, 100);
}

function uniqueTitle(title: string, used: Set<string>): string {
  let candidate = title;
  let suffix = 2;
  while (used.has(candidate.toLocaleLowerCase("pt-BR"))) {
    const ending = ` (${suffix++})`;
    candidate = `${title.slice(0, 100 - ending.length)}${ending}`;
  }
  used.add(candidate.toLocaleLowerCase("pt-BR"));
  return candidate;
}

/**
 * Converts the shared Pauta snapshot into a managed workbook layout:
 * a summary, session inventory, one detailed process tab per session, and unassigned processes.
 */
export function buildPautaGoogleSheetTabs(
  state: JsonRecord,
  syncedAt: string,
): PautaGoogleSheetTab[] {
  const rows = Array.isArray(state.rows)
    ? state.rows.filter(isRecord).filter((row) => rowProcess(row))
    : [];
  const details = isRecord(state.sessionDetails) ? state.sessionDetails : {};
  const labels = new Set<string>();

  if (Array.isArray(state.sessions)) {
    for (const session of state.sessions) {
      const label = sessionName(session);
      if (label) labels.add(label);
    }
  }
  for (const label of Object.keys(details)) if (label.trim()) labels.add(label.trim());

  const sessionsByRow = new Map<string, Array<{ row: JsonRecord; entry: JsonRecord }>>();
  const unassigned: Array<{ row: JsonRecord; entry: JsonRecord }> = [];
  for (const row of rows) {
    const entries = rowEntries(row);
    const assigned = entries
      .map((entry) => ({ session: entrySession(entry), entry }))
      .filter((item) => item.session);

    if (assigned.length) {
      for (const item of assigned) {
        labels.add(item.session);
        const current = sessionsByRow.get(item.session) ?? [];
        current.push({ row, entry: item.entry });
        sessionsByRow.set(item.session, current);
      }
      continue;
    }

    const destination = sessionName(row["Sessão Destino"] ?? row["Nova sessão de destino"]);
    if (destination && destination !== "—" && destination !== "-") {
      labels.add(destination);
      const current = sessionsByRow.get(destination) ?? [];
      current.push({ row, entry: { session: destination, item: row["Item (Pauta de Julgamento)"], status: row["Status de Julgamento"] } });
      sessionsByRow.set(destination, current);
    } else {
      unassigned.push({ row, entry: {} });
    }
  }

  const usedTitles = new Set<string>(["resumo", "sessões"]);
  const sessionTabs: PautaGoogleSheetTab[] = [];
  const summaryRows: string[][] = [
    ["Sessão", "Data", "Processos na pauta", "Preparação", "Prazo das minutas", "Liberação dos votos", "Peço-dia", "Gabinete", "Situação"],
  ];
  const sessionRows: string[][] = [[
    "Sessão",
    "Data",
    "Gabinete/órgão",
    "Situação",
    "Início da preparação",
    "Entrega das minutas",
    "Modo do prazo das minutas",
    "Liberação dos votos",
    "Modo de liberação",
    "Peço-dia",
    "Data de inativação",
    "Processos na pauta",
    "Servidores designados",
    "Corretores designados",
  ]];

  for (const label of [...labels].sort((a, b) => {
    const da = sessionDate(isRecord(details[a]) ? details[a] as JsonRecord : {}, a);
    const db = sessionDate(isRecord(details[b]) ? details[b] as JsonRecord : {}, b);
    return da.localeCompare(db, "pt-BR") || a.localeCompare(b, "pt-BR");
  })) {
    const sessionDetails = isRecord(details[label]) ? details[label] as JsonRecord : {};
    const assignedRows = sessionsByRow.get(label) ?? [];
    const seen = new Set<string>();
    const values = assignedRows
      .filter(({ row }) => {
        const key = rowProcess(row).replace(/\D/g, "") || rowProcess(row);
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .map(({ row, entry }) => processValues(row, entry));
    const title = uniqueTitle(safeSheetTitle(label), usedTitles);
    const date = sessionDate(sessionDetails, label);
    const inactive = sessionDetails.inativa === true ||
      sessionDetails.inativa === 1 ||
      ["true", "1", "sim"].includes(text(sessionDetails.inativa).toLocaleLowerCase("pt-BR"));
    const servers = [...new Set(assignedRows
      .map(({ row }) => field(row, "SERVIDOR", "Servidor", "servidor"))
      .filter(Boolean))].sort((a, b) => a.localeCompare(b, "pt-BR"));
    const reviewers = [...new Set(assignedRows
      .map(({ row }) => field(row, "CORRETOR", "Corretor", "REVISOR", "Revisor"))
      .filter(Boolean))].sort((a, b) => a.localeCompare(b, "pt-BR"));

    sessionTabs.push({
      key: `session:${label}`,
      title,
      values: [
        ["Sessão", label, "Data", date, "Gabinete", text(sessionDetails.gabinete)],
        [],
        PROCESS_HEADERS,
        ...values,
      ],
    });
    summaryRows.push([
      label,
      date,
      String(seen.size),
      text(sessionDetails.prepStart),
      text(sessionDetails.minutasDeadline ?? sessionDetails.minutasPrazo),
      text(sessionDetails.releaseDeadline ?? sessionDetails.liberacaoPrazo),
      text(sessionDetails.pecoDia),
      text(sessionDetails.gabinete),
      inactive ? "Inativa" : "Ativa",
    ]);
    sessionRows.push([
      label,
      date,
      text(sessionDetails.gabinete),
      inactive ? "Inativa" : "Ativa",
      text(sessionDetails.prepStart),
      text(sessionDetails.minutasDeadline ?? sessionDetails.minutasPrazo),
      text(sessionDetails.minutasMode),
      text(sessionDetails.releaseDeadline ?? sessionDetails.liberacaoPrazo),
      text(sessionDetails.releaseMode),
      text(sessionDetails.pecoDia),
      text(sessionDetails.inativadaEm),
      String(seen.size),
      servers.join("; "),
      reviewers.join("; "),
    ]);
  }

  const tabs: PautaGoogleSheetTab[] = [{
    key: "summary",
    title: "Resumo",
    values: [
      ["CONTROLE DE PAUTA · GABINETE CMT"],
      ["Atualização automática", syncedAt],
      ["Espelho da Pauta no app; alterações manuais nesta planilha serão substituídas na próxima sincronização."],
      ...summaryRows,
    ],
  }, {
    key: "sessions",
    title: "Sessões",
    values: sessionRows,
  }, ...sessionTabs];

  if (unassigned.length) {
    const seen = new Set<string>();
    const values = unassigned
      .filter(({ row }) => {
        const key = rowProcess(row).replace(/\D/g, "") || rowProcess(row);
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .map(({ row, entry }) => processValues(row, entry));
    tabs.push({
      key: "unassigned",
      title: "Sem sessão",
      values: [["Processos sem sessão vinculada"], [], PROCESS_HEADERS, ...values],
    });
  }

  return tabs;
}

export function quoteGoogleSheetRange(title: string): string {
  return `'${title.replace(/'/g, "''")}'`;
}

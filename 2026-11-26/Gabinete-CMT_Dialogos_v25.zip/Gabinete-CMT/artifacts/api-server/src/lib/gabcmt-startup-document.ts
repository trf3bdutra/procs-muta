/**
 * The legacy boot guard treats any single-segment URL as a public profile.
 * Explicit application routes must not inherit its 30-second visibility mask.
 */
export function prepareStartupDocument(html: string): string {
  return html.replace(
    /(<script\b[^>]*\bid=["']cmt-route-boot["'][^>]*>)([\s\S]*?)(<\/script>)/i,
    (_, opening: string, source: string, closing: string) => {
      const routes = "sign-in|gabinete|cmt|padrao|accounts|api|visualizacao-avancada";
      const applicationRoutes = routes + "|cm|pauta|mono|controle-de-pauta|controle-de-decisoes|tria|triagem|filter|sessions|sessoes|serv-user|servidor|datajud-triagem";
      return opening + source.replace(`^(${routes})$`, `^(${applicationRoutes})$`) + closing;
    },
  );
}

type JsonObject = Record<string, unknown>;

export const CM_EMENTARIO_ID = "main";
export const emptyCmEmentarioCatalog = () => ({
  paragraphSeedVersion: "",
  modelOverrides: [] as Array<{ id: string; patch: JsonObject }>,
  paragraphOverrides: [] as Array<{ id: string; patch: JsonObject }>,
  customModels: [] as JsonObject[],
  customParagraphs: [] as JsonObject[],
});

function duplicates(rows: Array<{ id?: unknown }>): boolean {
  const ids = new Set<string>();
  for (const row of rows) {
    const id = String(row.id ?? "");
    if (ids.has(id)) return true;
    ids.add(id);
  }
  return false;
}

function isObject(value: unknown): value is JsonObject {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

const MODEL_LIMITS: Record<string, number> = {
  nome: 300, tema: 500, especie: 200, resultado: 160, tipo: 80, fase: 80,
  abertura: 4000, ementa_modelo: 12000, modelo: 40000,
};
const PARAGRAPH_LIMITS: Record<string, number> = { txt: 12000, ementa: 12000, rot: 300, sec: 120 };
const PARAGRAPH_METADATA_LIMITS: Record<string, number> = {
  origemId: 200, status: 100, nivelTema: 300, nivelEspecificidade: 300,
  nivelCategoria: 200, nivelSubsecao: 200, uso: 1000, especificidadesTags: 1000,
  fonte: 500, titulo: 300, categoria: 300, texto: 12000,
};
const MODEL_FIELDS = new Set([...Object.keys(MODEL_LIMITS), "palavras_chave"]);

function onlyKeys(value: JsonObject, allowed: Set<string>): boolean {
  return Object.keys(value).every(key => allowed.has(key));
}
function validId(value: unknown): value is string {
  return typeof value === "string" && value.trim() === value && value.length > 0 && value.length <= 200;
}
function readTextFields(value: unknown, limits: Record<string, number>, allowed = new Set(Object.keys(limits))): JsonObject | null {
  if (!isObject(value) || !onlyKeys(value, allowed)) return null;
  const result: JsonObject = {};
  for (const [key, max] of Object.entries(limits)) {
    if (!Object.prototype.hasOwnProperty.call(value, key)) continue;
    if (typeof value[key] !== "string" || value[key].length > max) return null;
    result[key] = value[key];
  }
  return result;
}
function readParagraphVariables(value: unknown): unknown[] | null {
  if (!Array.isArray(value) || value.length > 100) return null;
  const result: unknown[] = [];
  for (const item of value) {
    if (typeof item === "string") {
      if (item.length > 120) return null;
      result.push(item);
      continue;
    }
    if (!isObject(item) || !onlyKeys(item, new Set(["campo", "rotulo", "preencher_manualmente"])) ||
        typeof item.campo !== "string" || item.campo.length > 120 ||
        typeof item.rotulo !== "string" || item.rotulo.length > 300 ||
        (item.preencher_manualmente !== undefined && typeof item.preencher_manualmente !== "boolean")) {
      return null;
    }
    result.push({
      campo: item.campo,
      rotulo: item.rotulo,
      ...(item.preencher_manualmente !== undefined ? { preencher_manualmente: item.preencher_manualmente } : {}),
    });
  }
  return result;
}
function readModelFields(value: unknown): JsonObject | null {
  if (!isObject(value) || !onlyKeys(value, MODEL_FIELDS)) return null;
  const result = readTextFields(value, MODEL_LIMITS, MODEL_FIELDS);
  if (!result) return null;
  if (Object.prototype.hasOwnProperty.call(value, "palavras_chave")) {
    const words = value.palavras_chave;
    if (!Array.isArray(words) || words.length > 50 ||
        words.some(word => typeof word !== "string" || word.length > 120)) return null;
    result.palavras_chave = words;
  }
  return result;
}
function readOverrides(value: unknown, parsePatch: (value: unknown) => JsonObject | null) {
  if (!Array.isArray(value) || value.length > 5000) return null;
  const result: Array<{ id: string; patch: JsonObject }> = [];
  for (const row of value) {
    if (!isObject(row) || !onlyKeys(row, new Set(["id", "patch"])) || !validId(row.id)) return null;
    const patch = parsePatch(row.patch);
    if (!patch || Object.keys(patch).length === 0) return null;
    result.push({ id: row.id, patch });
  }
  return result;
}
function readCustomModels(value: unknown) {
  if (!Array.isArray(value) || value.length > 500) return null;
  const result: JsonObject[] = [];
  for (const row of value) {
    if (!isObject(row) || !onlyKeys(row, new Set(["id", ...MODEL_FIELDS])) ||
        !validId(row.id) || !row.id.startsWith("cm-")) return null;
    const fields = readModelFields(Object.fromEntries(Object.entries(row).filter(([key]) => key !== "id")));
    if (!fields || typeof fields.nome !== "string" || !fields.nome.trim()) return null;
    if (!(String(fields.modelo || "").trim() || String(fields.ementa_modelo || "").trim())) return null;
    result.push({ id: row.id, ...fields });
  }
  return result;
}
function readCustomParagraphs(value: unknown) {
  if (!Array.isArray(value) || value.length > 500) return null;
  const result: JsonObject[] = [];
  const allowed = new Set([
    "id", ...Object.keys(PARAGRAPH_LIMITS), ...Object.keys(PARAGRAPH_METADATA_LIMITS), "variaveis",
  ]);
  for (const row of value) {
    if (!isObject(row) || !onlyKeys(row, allowed) ||
        !validId(row.id) || !row.id.startsWith("cm-")) return null;
    const rawFields = Object.fromEntries(Object.entries(row).filter(([key]) => key !== "id"));
    const fields = readTextFields(rawFields, { ...PARAGRAPH_LIMITS, ...PARAGRAPH_METADATA_LIMITS }, allowed);
    if (!fields || typeof fields.txt !== "string" || !fields.txt.trim()) return null;
    if (Object.prototype.hasOwnProperty.call(rawFields, "variaveis")) {
      const variables = readParagraphVariables(rawFields.variaveis);
      if (!variables) return null;
      fields.variaveis = variables;
    }
    result.push({ id: row.id, ...fields });
  }
  return result;
}

export function validateCmEmentarioCatalog(value: unknown):
  | { catalog: ReturnType<typeof emptyCmEmentarioCatalog> }
  | { error: string } {
  if (!isObject(value) || !onlyKeys(value, new Set([
    "paragraphSeedVersion", "modelOverrides", "paragraphOverrides", "customModels", "customParagraphs",
  ]))) {
    return { error: "O catálogo do Ementário está inválido." };
  }
  if (value.paragraphSeedVersion !== undefined &&
      (typeof value.paragraphSeedVersion !== "string" || value.paragraphSeedVersion.length > 80)) {
    return { error: "A versão da base de parágrafos está inválida." };
  }
  const modelOverrides = readOverrides(value.modelOverrides, readModelFields);
  const paragraphOverrides = readOverrides(value.paragraphOverrides, input => readTextFields(input, PARAGRAPH_LIMITS));
  const customModels = readCustomModels(value.customModels);
  const customParagraphs = readCustomParagraphs(value.customParagraphs);
  if (!modelOverrides || !paragraphOverrides || !customModels || !customParagraphs) {
    return { error: "Há registros com campos inválidos ou acima do limite." };
  }
  if (modelOverrides.some(row => (row.patch.nome !== undefined && !String(row.patch.nome).trim()) ||
      (row.patch.modelo !== undefined && row.patch.ementa_modelo !== undefined &&
        !String(row.patch.modelo).trim() && !String(row.patch.ementa_modelo).trim())) ||
      paragraphOverrides.some(row => row.patch.txt !== undefined && !String(row.patch.txt).trim())) {
    return { error: "Nomes e textos do catálogo não podem ficar em branco." };
  }
  const catalog = {
    paragraphSeedVersion: String(value.paragraphSeedVersion || ""),
    modelOverrides, paragraphOverrides, customModels, customParagraphs,
  };
  if (duplicates(catalog.modelOverrides) || duplicates(catalog.paragraphOverrides) ||
      duplicates(catalog.customModels) || duplicates(catalog.customParagraphs)) {
    return { error: "Há registros repetidos no catálogo." };
  }
  if (catalog.customModels.some(row => !String(row.id).startsWith("cm-")) ||
      catalog.customParagraphs.some(row => !String(row.id).startsWith("cm-"))) {
    return { error: "Modelos e parágrafos novos precisam de identificador próprio." };
  }
  return { catalog };
}

export function readCmEmentarioCatalog(value: unknown) {
  const validated = validateCmEmentarioCatalog(value);
  return "catalog" in validated ? validated.catalog : emptyCmEmentarioCatalog();
}

export function canEditCmEmentario(session: { userId?: string; role?: string; server?: string } | null): boolean {
  return session?.userId === "cm-link" && session.role === "equipe" && session.server === "CM";
}

export function mergeCmEmentarioModels(canonical: unknown[], catalogValue: unknown): JsonObject[] {
  const catalog = readCmEmentarioCatalog(catalogValue);
  const overrides = new Map(catalog.modelOverrides.map(row => [row.id, row.patch]));
  const base: JsonObject[] = canonical.filter(isObject).map((row): JsonObject => {
    const patch = overrides.get(String(row.id));
    return { ...row, ...(patch || {}), ...(patch ? { _personalizado: true } : {}) };
  });
  const seen = new Set(base.map(row => String(row.id)));
  for (const row of catalog.customModels) {
    const model: JsonObject = { frequencia: 0, periodo: [], blocos: [], ...row, _origem: "cm", _personalizado: true };
    if (!seen.has(String(model.id))) {
      seen.add(String(model.id));
      base.push(model);
    }
  }
  return base;
}

export function mergeCmEmentarioParagraphs(canonical: unknown[], catalogValue: unknown): JsonObject[] {
  const catalog = readCmEmentarioCatalog(catalogValue);
  const overrides = new Map(catalog.paragraphOverrides.map(row => [row.id, row.patch]));
  const base: JsonObject[] = canonical.filter(isObject).map(row => {
    const id = String(row.id ?? "");
    const patch = overrides.get(id);
    return {
      ...row,
      id,
      txt: String(patch?.txt ?? row.txt ?? row.texto ?? row.conteudo ?? ""),
      ementa: String(patch?.ementa ?? row.ementa ?? row.ementaCorrespondente ?? ""),
      rot: String(patch?.rot ?? row.rot ?? row.nome ?? row.titulo ?? id),
      sec: String(patch?.sec ?? row.sec ?? row.secao ?? row.nivelCategoria ?? ""),
      _origem: patch ? "cm" : "git",
      ...(patch ? { _personalizado: true } : {}),
    };
  }).filter(row => String(row.txt).trim());
  const seen = new Set(base.map(row => String(row.id)));
  for (const row of catalog.customParagraphs) {
    if (seen.has(String(row.id))) continue;
    seen.add(String(row.id));
    base.push({ ...row, _origem: "cm", _personalizado: true });
  }
  return base;
}

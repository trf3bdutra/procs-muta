/** App-owned mailbox UI, kept outside the user-edited GabCMT source document. */
export const agentMailBrowserScript = String.raw`(() => {
  'use strict';
  if (window.CMTAgentMailBrowser) return;
  const D = document, API = '/api/pauta/mensagens/agentmail/';
  const s = { rows: [], selected: new Map(), query: '', next: null, loaded: false, busy: false, importing: false, dirty: false, request: null, generation: 0 };
  let dlg, list, form, input, error, info, selection, more, add, all, clear, close, browse;
  const node = (tag, text, cls) => { const e = D.createElement(tag); if (text) e.textContent = text; if (cls) e.className = cls; return e; };
  const button = (text, fn, cls) => { const e = node('button', text, cls); e.type = 'button'; e.addEventListener('click', fn); return e; };
  const date = (v) => { const d = new Date(v); return Number.isNaN(d.getTime()) ? '' : d.toLocaleString('pt-BR'); };
  async function json(path, options) {
    const r = await fetch(API + path, Object.assign({credentials: 'same-origin', headers: {'Content-Type':'application/json', Accept:'application/json'}, cache:'no-store'}, options || {}));
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || 'Não foi possível concluir a operação.');
    return j;
  }
  function controls() {
    const blocked = s.busy || s.importing || s.dirty || !s.query;
    selection.textContent = s.selected.size + ' selecionado(s)';
    add.disabled = blocked || !s.selected.size;
    add.textContent = s.importing ? 'Adicionando…' : 'Adicionar selecionados à caixa do app';
    all.disabled = blocked || !s.rows.some(x => !x.imported);
    clear.disabled = s.importing || !s.selected.size;
    more.disabled = s.busy || s.importing || s.dirty;
    more.hidden = !s.next;
    close.disabled = s.importing;
    browse.disabled = s.importing;
    input.disabled = s.importing;
    form.querySelector('[type=submit]').disabled = s.importing;
    list.querySelectorAll('input[type=checkbox]').forEach(c => {
      const row = s.rows.find(x => x.id === c.dataset.id);
      c.disabled = blocked || !!row?.imported;
      c.checked = s.selected.has(c.dataset.id);
    });
  }
  function render() {
    list.replaceChildren();
    if (!s.rows.length) list.append(node('p', s.busy ? 'Consultando o AgentMail…' : 'Nenhum e-mail encontrado.', 'amb-muted'));
    for (const row of s.rows) {
      const article = node('article', '', 'amb-mail');
      const label = node('label', '', 'amb-mail-head');
      const check = node('input'); check.type = 'checkbox'; check.dataset.id = row.id; check.setAttribute('aria-label', 'Selecionar ' + (row.subject || 'e-mail sem assunto'));
      check.addEventListener('change', () => {
        if (check.checked) {
          if (s.selected.size >= 50) { check.checked = false; error.textContent = 'Selecione no máximo 50 e-mails por importação.'; return; }
          s.selected.set(row.id, row.selectionToken);
        } else s.selected.delete(row.id);
        controls();
      });
      const heading = node('span');
      heading.append(node('strong', row.subject || '(sem assunto)'), node('small', row.from + ' · ' + date(row.receivedAt)));
      if (row.imported) heading.append(node('small', 'Já está na caixa do app', 'amb-imported'));
      label.append(check, heading); article.append(label, node('p', row.preview || 'Sem prévia.', 'amb-preview'));
      const detail = node('details'), summary = node('summary', 'Ler e-mail sem importar'), text = node('pre', '', 'amb-text');
      detail.append(summary, text);
      let fetched = false;
      detail.addEventListener('toggle', async () => {
        if (!detail.open || fetched) return;
        text.textContent = 'Lendo e-mail…';
        try {
          const j = await json('preview?' + new URLSearchParams({token:row.selectionToken}));
          text.textContent = j.text || '(sem texto)'; fetched = true;
        } catch (e) { text.textContent = e.message + ' Feche e abra para tentar novamente.'; }
      });
      article.append(detail); list.append(article);
    }
    info.textContent = s.dirty ? 'O texto foi alterado. Clique em Buscar para aplicar o novo filtro.' :
      s.busy ? 'Consultando o AgentMail, sem gravar na caixa do app…' :
      (s.query ? 'Busca aplicada: “' + s.query + '” · ' : 'Caixa completa · ') + s.rows.length + ' carregado(s)' +
      (s.next ? ' · há mais resultados' : s.loaded ? ' · fim dos resultados' : '') +
      (!s.query ? '. Informe um texto e busque para habilitar a seleção.' : '');
    controls();
  }
  async function load(reset) {
    if (s.importing) return;
    if (reset) {
      s.request?.abort(); s.generation++; s.query = input.value.trim();
      s.rows = []; s.selected.clear(); s.next = null; s.dirty = false; s.loaded = false;
    }
    const generation = s.generation;
    const controller = new AbortController(); s.request = controller;
    s.busy = true; error.textContent = ''; render();
    try {
      const params = new URLSearchParams({q:s.query});
      if (!reset && s.next) params.set('pageToken', s.next);
      const data = await json('consulta?' + params, {signal:controller.signal});
      if (generation !== s.generation) return;
      const known = new Set(s.rows.map(x => x.id));
      for (const row of data.messages || []) if (!known.has(row.id)) { s.rows.push(row); known.add(row.id); }
      s.next = data.nextPageToken || null; s.loaded = true;
    } catch (e) { if (generation === s.generation && e.name !== 'AbortError') error.textContent = e.message; }
    finally { if (generation === s.generation) { s.busy = false; render(); } }
  }
  async function importSelected() {
    if (s.busy || s.importing || s.dirty || !s.query || !s.selected.size) return;
    const ids = new Set(s.selected.keys()), tokens = Array.from(s.selected.values());
    s.importing = true; error.textContent = ''; controls();
    try {
      const result = await json('importar', {method:'POST', body:JSON.stringify({query:s.query, selectionTokens:tokens})});
      for (const row of s.rows) if (ids.has(row.id)) row.imported = true;
      s.selected.clear(); render();
      info.textContent = 'Adicionados: ' + result.added + ' · atualizados: ' + result.updated + ' · já existentes: ' + result.unchanged + '. Os demais e-mails não foram importados.';
      try { await window.CMTCfg2Painel?.mail?.(true); } catch (_) {}
    } catch (e) { error.textContent = e.message; }
    finally { s.importing = false; controls(); }
  }
  function mount() {
    if (dlg) return;
    const style = node('style');
    style.textContent = '.amb-dialog{width:min(960px,94vw);max-height:88vh;border:1px solid #bed0d4;border-radius:14px;padding:0;background:#f5f8f9;color:#173f48;font:14px Figtree,system-ui,sans-serif}.amb-dialog::backdrop{background:#071c27b3}.amb-shell{display:flex;flex-direction:column;max-height:86vh}.amb-head,.amb-search,.amb-tools,.amb-foot{padding:14px 20px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}.amb-head{background:#173f48;color:white;justify-content:space-between}.amb-head h2{margin:0;font-size:19px}.amb-head p{margin:5px 0 0;font-size:12px}.amb-dialog button{border:1px solid #b3c8cc;border-radius:7px;background:white;color:#173f48;padding:8px 11px;font:600 12px Figtree,system-ui,sans-serif;cursor:pointer}.amb-dialog button:disabled{opacity:.45;cursor:default}.amb-dialog .amb-primary{background:#176050;color:white;border-color:#176050}.amb-search input{flex:1;min-width:170px;border:1px solid #b3c8cc;border-radius:7px;padding:10px;font:inherit;background:white;color:#173f48}.amb-tools{padding-top:0;padding-bottom:5px}.amb-list{overflow:auto;min-height:80px;padding:8px 20px;overscroll-behavior:contain}.amb-mail{padding:12px;margin:0 0 9px;background:white;border:1px solid #d9e3e6;border-radius:8px}.amb-mail-head{display:flex;gap:10px;align-items:flex-start;cursor:pointer}.amb-mail-head input{margin-top:3px;accent-color:#176050}.amb-mail strong,.amb-mail small{display:block;overflow-wrap:anywhere}.amb-mail small{margin-top:5px;color:#5a7179}.amb-imported{color:#176050!important}.amb-preview,.amb-muted{font-size:12px;color:#5a7179;white-space:pre-wrap;overflow-wrap:anywhere}.amb-mail summary{font-size:12px;cursor:pointer}.amb-text{font:12px/1.6 Figtree,system-ui,sans-serif;white-space:pre-wrap;overflow-wrap:anywhere;max-height:280px;overflow:auto}.amb-status,.amb-error,.amb-note{margin:0;padding:5px 20px;font-size:12px;overflow-wrap:anywhere}.amb-error{color:#a12b2b;min-height:1em}.amb-foot{border-top:1px solid #d9e3e6;justify-content:space-between}.amb-note{color:#5a7179;padding-bottom:10px}';
    D.head.append(style);
    dlg = node('dialog', '', 'amb-dialog'); dlg.setAttribute('aria-label', 'Consultar e selecionar e-mails do AgentMail');
    const shell = node('div', '', 'amb-shell'), head = node('header', '', 'amb-head'), title = node('div');
    title.append(node('h2', 'Entrada · AgentMail'), node('p', 'Consulte a caixa completa. Só a seleção filtrada será adicionada ao app.'));
    close = button('Fechar', () => dlg.close()); head.append(title, close);
    form = node('form', '', 'amb-search');
    input = node('input'); input.type = 'search'; input.maxLength = 500; input.placeholder = 'Buscar texto no assunto, remetente ou corpo…'; input.setAttribute('aria-label', 'Texto para filtrar e-mails');
    const submit = node('button', 'Buscar', 'amb-primary'); submit.type = 'submit';
    browse = button('Ver caixa completa', () => { input.value = ''; load(true); });
    form.append(input, submit, browse); form.addEventListener('submit', e => { e.preventDefault(); load(true); });
    input.addEventListener('input', () => {
      s.selected.clear(); s.dirty = input.value.trim() !== s.query; controls();
      info.textContent = 'Clique em Buscar para aplicar o texto. A seleção anterior foi limpa.';
    });
    const tools = node('div', '', 'amb-tools');
    all = button('Selecionar filtrados carregados (até 50)', () => {
      s.selected.clear(); for (const row of s.rows) if (!row.imported && s.selected.size < 50) s.selected.set(row.id, row.selectionToken); controls();
    });
    clear = button('Limpar seleção', () => { s.selected.clear(); controls(); });
    selection = node('span'); tools.append(all, clear, selection);
    info = node('p', '', 'amb-status'); info.setAttribute('role', 'status');
    error = node('p', '', 'amb-error'); error.setAttribute('role', 'alert');
    list = node('div', '', 'amb-list');
    const foot = node('footer', '', 'amb-foot');
    more = button('Carregar mais resultados', () => load(false));
    add = button('Adicionar selecionados à caixa do app', importSelected, 'amb-primary');
    foot.append(more, add);
    shell.append(head, form, tools, info, error, list,
      node('p', 'Busca textual do AgentMail: assunto, remetente, destinatários e corpo. Spam, lixeira e mensagens bloqueadas aparecem na consulta completa quando permitidos pela chave, mas não na busca. A leitura exibe até 20 mil caracteres.', 'amb-note'), foot);
    dlg.append(shell); D.body.append(dlg);
    dlg.addEventListener('cancel', e => { if (s.importing) e.preventDefault(); });
    dlg.addEventListener('close', () => { s.request?.abort(); s.busy = false; });
  }
  function open() { mount(); if (!dlg.open) dlg.showModal(); input.focus(); if (!s.loaded) load(true); else render(); }
  window.addEventListener('click', e => {
    const target = e.target instanceof Element ? e.target.closest('[data-ml-go="sync"],[data-agentmail-browser]') : null;
    if (!target || !target.closest('#cmt-cfgr,#cfg2-painel')) return;
    e.preventDefault(); e.stopImmediatePropagation(); open();
  }, true);
  window.CMTAgentMailBrowser = {open};
})();`;

export function prepareAgentMailBrowser(html: string): string {
  if (!html.includes("cmt-cfgr-caixa")) return html;
  const oldDescription = "E-mails da caixa AgentMail com relatoria do <b>Des. Fed. Carlos Muta (Gab. A)</b>. Na primeira abertura, o histórico é sincronizado automaticamente; mensagens novas chegam pelo webhook. Só é registrada automaticamente a mensagem vinculada a um único CNJ e a uma sessão ativa (hoje ou futura, não arquivada); casos ambíguos ficam para conferência.";
  const prepared = html
    .replace("if(sincronizarHistorico){mail.autoSyncStarted=true;void sincronizarMail(true);}", "mail.autoSyncStarted=true;")
    .replace("fetch('/api/pauta/mensagens?relator=carlos-muta'", "fetch('/api/pauta/mensagens?scope=all'")
    .replace(oldDescription, "Caixa do app: e-mails já adicionados. Consulte o AgentMail para buscar no histórico completo e adicionar somente os resultados filtrados que selecionar. A consulta e a leitura não importam mensagens.")
    .replace("Sincronizar com AgentMail", "Consultar e selecionar no AgentMail");
  if (prepared.includes('id="cmt-agentmail-browser"')) return prepared;
  // The legacy document contains printable HTML strings with their own </body>.
  // Only the final closing tag belongs to the actual outer document.
  const closingBody = prepared.toLowerCase().lastIndexOf("</body>");
  if (closingBody < 0) return prepared;
  return prepared.slice(0, closingBody)
    + `<script id="cmt-agentmail-browser">${agentMailBrowserScript}</script>`
    + prepared.slice(closingBody);
}

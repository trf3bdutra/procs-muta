/**
 * Layout belongs to the responsive stylesheet, not the two legacy timers.
 * Keep their data updates and delegated session controls intact.
 */
export function prepareStableSessionHeader(html: string): string {
  return html.replace(
    /(<script\b[^>]*\bid=["'](cmt-mod-enhancements|cmt-v122-controles-js)["'][^>]*>)([\s\S]*?)(<\/script>)/g,
    (_, opening: string, id: string, payload: string, closing: string) => {
      const encoded = id === "cmt-mod-enhancements";
      const original: string = encoded ? JSON.parse(payload) : payload;
      const code = encoded
        ? original.replace(
            /      const viewportWidth = window\.innerWidth \|\| document\.documentElement\.clientWidth;\r?\n[\s\S]*?        refDates\.style\.setProperty\('grid-template-columns', gridTemplate, 'important'\);\r?\n      \}\r?\n/,
            "",
          )
        : original.replace(
            /^  \{const n=innerWidth<=900\?2:innerWidth<=1180\?3:5;[^\n]+\}\r?\n/m,
            "",
          );
      return opening + (encoded ? JSON.stringify(code).replace(/<\/script/gi, "<\\/script") : code) + closing;
    },
  );
}

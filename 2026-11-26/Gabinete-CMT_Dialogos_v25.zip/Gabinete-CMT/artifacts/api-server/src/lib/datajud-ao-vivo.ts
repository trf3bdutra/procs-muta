/* Avisos ao vivo do DataJud para as Centrais abertas (server-sent events).
   Entre instâncias, o recado passa pelo PostgreSQL (LISTEN/NOTIFY): só um resumo pequeno viaja;
   cada navegador busca depois apenas os processos que mudaram (GET /datajud/estado?desde=). */
import type { Request, Response } from "express";
import { pool } from "@workspace/db";
import { logger } from "./logger";
import { registerLiveAccess } from "./live-access";

const CANAL = "datajud_eventos";
const clientes = new Set<Response>();
type Cliente = { query: (sql: string) => Promise<unknown>; release: (destruir?: boolean) => void; on: (evento: string, fn: (...a: any[]) => void) => unknown };
let ouvinte: Cliente | null = null, ligando: Promise<void> | null = null, ultimo = "";

function difundir(payload: string) {
  ultimo = payload;
  for (const res of clientes) if (!res.writableEnded && !res.destroyed) res.write(`event: datajud\ndata: ${payload}\n\n`);
}
async function escutar(): Promise<void> {
  if (ouvinte || ligando) return ligando ?? undefined;
  ligando = (async () => {
    try {
      const c = (await pool.connect()) as unknown as Cliente;
      c.on("notification", (m: { channel: string; payload?: string }) => { if (m.channel === CANAL && m.payload) difundir(m.payload); });
      c.on("error", (e: Error) => { logger.warn({ err: e.message }, "datajud: escuta ao vivo caiu"); try { c.release(true); } catch { /* já liberado */ } ouvinte = null; if (clientes.size) setTimeout(() => { void escutar(); }, 5000).unref(); });
      await c.query(`LISTEN ${CANAL}`);
      ouvinte = c;
    } catch (e) { logger.warn({ err: e instanceof Error ? e.message : String(e) }, "datajud: sem LISTEN; avisos ao vivo só nesta instância"); }
    finally { ligando = null; }
  })();
  return ligando;
}
function parar() {
  if (clientes.size || !ouvinte) return;
  const c = ouvinte; ouvinte = null;
  c.query(`UNLISTEN ${CANAL}`).catch(() => {}).finally(() => c.release());
}

export function conectar(req: Request, res: Response) {
  res.status(200);
  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();
  registerLiveAccess(req, res);                 // conta desativada = fluxo encerrado
  clientes.add(res);
  void escutar();
  res.write(`retry: 15000\n: conectado\n\n`);
  const batida = setInterval(() => { if (!res.writableEnded) res.write(": keep-alive\n\n"); }, 25_000);
  batida.unref();
  res.on("close", () => { clearInterval(batida); clientes.delete(res); setTimeout(parar, 60_000).unref(); });
}

/* chamado ao fim de cada sincronização; payload pequeno (NOTIFY aceita até 8 000 bytes) */
export async function publicar(dados: Record<string, unknown>) {
  let payload = JSON.stringify(dados);
  if (payload.length > 7500) payload = JSON.stringify({ ...dados, top: [] });
  try { await pool.query("SELECT pg_notify($1, $2)", [CANAL, payload]); if (!ouvinte) difundir(payload); }
  catch { difundir(payload); }
}
export const aoVivo = () => ({ conectados: clientes.size, escutando: !!ouvinte, ultimo: ultimo ? JSON.parse(ultimo) : null });

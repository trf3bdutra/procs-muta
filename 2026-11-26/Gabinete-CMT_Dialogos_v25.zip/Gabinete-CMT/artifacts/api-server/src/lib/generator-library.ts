type JsonObject = Record<string, unknown>;
const object = (value: unknown): value is JsonObject =>
  !!value && typeof value === "object" && !Array.isArray(value);
const name = (value: unknown) => String(value ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toUpperCase();

export const LIBRARY_KEY = "generatorLibrary";
export const emptyGeneratorLibrary = () => ({
  paragrafos: [], modelos: [], modelosOcultos: [],
  paradigmasProprios: [], paradigmasOcultos: [], padraoMuta: null,
});

export function assessoriaNames(state: unknown): string[] {
  const team = object(state) && object(state.team) ? state.team : {};
  const members = Array.isArray(team.members) ? team.members : [];
  return [...new Set(members.filter(object).filter(member =>
    name(member.name) !== "CM" && !/DESEMBARGADOR|^CM$/.test(name(member.hierarchy)) &&
    (typeof member.assessoria === "boolean" ? member.assessoria : /^(CJ|ASSESSOR)/.test(name(member.hierarchy))),
  ).map(member => name(member.name)).filter(Boolean))].sort();
}

export function canEditGeneratorLibrary(session: { server?: string } | null, state: unknown): boolean {
  // The authenticated canonical server identity is supplied by the backend, never by the request body.
  return !!session?.server && assessoriaNames(state).includes(name(session.server));
}

export function readGeneratorLibrary(state: unknown) {
  const stored = object(state) && object(state[LIBRARY_KEY]) ? state[LIBRARY_KEY] : {};
  const revision = Number.isSafeInteger(stored.revision) && Number(stored.revision) >= 0 ? Number(stored.revision) : 0;
  return { library: object(stored.library) ? stored.library : emptyGeneratorLibrary(), revision };
}

export function validateGeneratorLibrary(value: unknown): { library: JsonObject } | { error: string } {
  if (!object(value)) return { error: "A biblioteca deve ser um objeto." };
  const library: JsonObject = { ...emptyGeneratorLibrary(), ...value };
  const lists = ["paragrafos", "modelos", "paradigmasProprios"] as const;
  for (const key of lists) {
    const rows = library[key];
    if (!Array.isArray(rows) || rows.length > (key === "paragrafos" ? 500 : 5000)) return { error: `Lista inválida ou muito extensa: ${key}.` };
    const seen = new Set<string>();
    for (const row of rows) {
      if (!object(row) || typeof row.id !== "string" || !row.id.trim() || row.id.length > 200 || seen.has(row.id)) return { error: `Há ID ausente ou duplicado em ${key}.` };
      seen.add(row.id);
      if (key === "paragrafos" && (typeof row.txt !== "string" || !row.txt.trim())) return { error: "Preencha o texto do parágrafo." };
      if (key === "modelos" && (typeof row.nome !== "string" || !row.nome.trim())) return { error: "Preencha o nome do modelo." };
      if (key === "paradigmasProprios" && !String(row.ementa || row.tese || "").trim()) return { error: "Preencha a ementa ou a tese do paradigma." };
    }
  }
  for (const key of ["modelosOcultos", "paradigmasOcultos"]) {
    const rows = library[key];
    if (!Array.isArray(rows) || rows.length > 10000 || rows.some(id => typeof id !== "string" || !id.trim() || id.length > 200) || new Set(rows).size !== rows.length) return { error: `Lista de ocultos inválida: ${key}.` };
  }
  const padrao = library.padraoMuta;
  if (padrao !== null && (!object(padrao) || !object(padrao.redacao) || !Array.isArray(padrao.redacao.registros) || !padrao.roteiros)) {
    return { error: "O Padrão Muta precisa conter roteiros e registros de redação." };
  }
  return { library };
}

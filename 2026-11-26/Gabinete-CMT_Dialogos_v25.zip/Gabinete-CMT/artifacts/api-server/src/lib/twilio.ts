import { createHmac, timingSafeEqual } from "node:crypto";
import type { InboxMessage } from "./agentmail";

/* mesmo teto de texto da caixa (agentmail.ts › MAX_TEXT); sem import de valor para os testes por strip-types */
const MAX_TEXT = 20_000;

/**
 * SMS e WhatsApp pela Twilio: as mensagens recebidas entram na mesma caixa da Comunicação (pauta_snapshots ›
 * mensagens-agentmail), com source "twilio" e o canal de origem. O token da conta fica só no servidor
 * (TWILIO_AUTH_TOKEN); a assinatura X-Twilio-Signature é conferida em toda chamada do webhook.
 */

export type TwilioChannel = "sms" | "whatsapp";

const str = (value: unknown): string =>
  typeof value === "string" ? value.trim() : value == null ? "" : String(value).trim();

/** Assinatura da Twilio: HMAC-SHA1 (base64) da URL completa seguida dos parâmetros POST em ordem alfabética. */
export function verifyTwilioSignature(
  authToken: string,
  url: string,
  params: Record<string, unknown>,
  signature: string,
): boolean {
  if (!authToken || !url || !signature) return false;
  const data =
    url +
    Object.keys(params)
      .sort()
      .map((key) => key + str(params[key]))
      .join("");
  const expected = createHmac("sha1", authToken).update(data, "utf8").digest();
  const received = Buffer.from(signature, "base64");
  return received.length === expected.length && timingSafeEqual(received, expected);
}

export function twilioChannel(from: string): TwilioChannel {
  return /^whatsapp:/i.test(from) ? "whatsapp" : "sms";
}

/** Número sem o prefixo do canal, para mostrar e comparar ("whatsapp:+5567..." → "+5567..."). */
export const bareNumber = (value: string): string => str(value).replace(/^whatsapp:/i, "");

export function normalizeTwilioMessage(
  params: Record<string, unknown>,
  nowIso = new Date().toISOString(),
): (InboxMessage & { channel: TwilioChannel }) | null {
  const sid = str(params.MessageSid ?? params.SmsMessageSid);
  const from = str(params.From);
  if (!sid || !from) return null;
  const channel = twilioChannel(from);
  const text = str(params.Body).slice(0, MAX_TEXT);
  const media = Math.max(0, Number(params.NumMedia) || 0);
  const label = channel === "whatsapp" ? "WhatsApp" : "SMS";
  const profile = str(params.ProfileName);

  return {
    id: `twilio-${sid}`,
    source: "twilio",
    channel,
    inboxId: bareNumber(str(params.To)),
    threadId: bareNumber(from),
    from: profile ? `${profile} <${bareNumber(from)}>` : bareNumber(from),
    to: [bareNumber(str(params.To))].filter(Boolean),
    subject: `${label} de ${profile || bareNumber(from)}`.slice(0, 500),
    text,
    preview: text.slice(0, 280),
    receivedAt: nowIso,
    attachments: Array.from({ length: Math.min(media, 10) }, (_, i) => ({
      filename: `midia-${i + 1}`,
      contentType: str(params[`MediaContentType${i}`]).slice(0, 200),
      size: 0,
    })),
    status: "nova",
    updatedAt: nowIso,
  };
}

/** Configuração não secreta dos canais, gravada pela Comunicação (Configurações globais). */
export type TwilioConfig = {
  ativo: boolean;
  smsNumber: string;
  whatsappNumber: string;
  updatedAt?: string;
  updatedBy?: string;
};

export function coerceTwilioConfig(value: unknown): TwilioConfig {
  const o = value && typeof value === "object" ? (value as Record<string, unknown>) : {};
  const phone = (v: unknown) => bareNumber(str(v)).replace(/[^\d+]/g, "").slice(0, 20);
  return {
    ativo: o.ativo === true,
    smsNumber: phone(o.smsNumber),
    whatsappNumber: phone(o.whatsappNumber),
    updatedAt: str(o.updatedAt) || undefined,
    updatedBy: str(o.updatedBy).slice(0, 80) || undefined,
  };
}

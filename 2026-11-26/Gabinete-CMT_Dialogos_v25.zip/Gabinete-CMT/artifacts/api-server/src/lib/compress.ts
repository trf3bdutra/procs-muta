import { brotliCompressSync, constants, gzipSync } from "node:zlib";
import type { Request, Response } from "express";

/* Respostas grandes (o gabcmt.html tem ~7,8 MB e o estado da pauta passa de centenas de KB)
   saem comprimidas quando o navegador aceita: br (~3,3× menor) ou gzip. Sem middleware global,
   para não interferir nos fluxos de eventos (text/event-stream). */
const MIN_BYTES = 8 * 1024;

export type Encoded = { encoding: "br" | "gzip" | ""; body: Buffer };

export function chooseEncoding(acceptEncoding: string | undefined): "br" | "gzip" | "" {
  const accept = String(acceptEncoding ?? "").toLowerCase();
  const accepts = (name: string) => accept.split(",").some((part) => {
    const [token, ...params] = part.trim().split(";");
    if (token.trim() !== name) return false;
    const q = params.map((p) => p.trim()).find((p) => p.startsWith("q="));
    return !q || Number(q.slice(2)) > 0;
  });
  if (accepts("br")) return "br";
  if (accepts("gzip")) return "gzip";
  return "";
}

export function encodeBody(body: string | Buffer, encoding: "br" | "gzip" | ""): Encoded {
  const raw = typeof body === "string" ? Buffer.from(body, "utf8") : body;
  if (!encoding || raw.length < MIN_BYTES) return { encoding: "", body: raw };
  if (encoding === "br") {
    return {
      encoding,
      body: brotliCompressSync(raw, {
        params: { [constants.BROTLI_PARAM_QUALITY]: 4, [constants.BROTLI_PARAM_SIZE_HINT]: raw.length },
      }),
    };
  }
  return { encoding, body: gzipSync(raw, { level: 6 }) };
}

export function sendEncoded(res: Response, encoded: Encoded, type: string): void {
  res.setHeader("Vary", "Accept-Encoding");
  res.type(type);
  if (encoded.encoding) res.setHeader("Content-Encoding", encoded.encoding);
  res.send(encoded.body);
}

export function sendCompressed(req: Request, res: Response, body: string, type: string): void {
  sendEncoded(res, encodeBody(body, chooseEncoding(req.headers["accept-encoding"])), type);
}

/**
 * Migrate the legacy embedded board at document assembly time, preserving its
 * data, permissions and delegated actions, but never delivering its old modal.
 */
export function preparePendingPanel(html: string): string {
  return html.replace(
    /(<script\b[^>]*\bid=["']cmt-mod-enhancements["'][^>]*>)([\s\S]*?)(<\/script>)/,
    (_, opening: string, payload: string, closing: string) => {
      const code: string = JSON.parse(payload);
      if (code.includes("mount: renderPendingPanel")) return opening + payload + closing;
      const start = code.indexOf("  const T = window.PautaTeam;", code.indexOf("window.PautaPendencias?.decorateFooter"));
      const api = code.indexOf("  window.PautaPendencias = {", start);
      const end = code.indexOf("\n})();", api);
      if (start < 0 || api < start || end < api) throw new Error("Pending board module was not found.");
      let board = code.slice(start, end);
      const legacyRender = /  function renderDialog\(\) \{[\s\S]*?\n  \}\n/;
      if (!legacyRender.test(board)) throw new Error("Pending board renderer was not found.");
      board = board.replace(legacyRender, `  function renderPendingPanel(container) {
    if (!container) return window.CMTRail?.openPanel?.('pend', { force: true });
    const before = team().pendingIssues.length;
    team().pendingIssues = purgeOldDone(team().pendingIssues);
    if (team().pendingIssues.length !== before) void persist('');
    let panel = container.querySelector(':scope > [data-pending-panel]');
    if (!panel) {
      panel = document.createElement('section');
      panel.className = 'pc-modal pnd-modal';
      panel.setAttribute('data-pending-panel', '');
      panel.setAttribute('aria-label', 'Pendências compartilhadas');
      panel.innerHTML = '<div class="pndb" data-pnd-root></div>';
      container.appendChild(panel);
    }
    paint();
    return true;
  }
`);
      const legacySummary = /return \`<div class="pnb-bar">[\s\S]*?\n\s*<div class="pnb-tools">/;
      if (!legacySummary.test(board)) throw new Error("Pending board summary header was not found.");
      board = board.replace(legacySummary, 'return `<div class="pnb-tools">');
      const toolbarEnd = /(<div class="pnb-view"[\s\S]*?<\/div>)(\n\s*<\/div>\n\s*<div data-pnd-body>)/;
      if (!toolbarEnd.test(board)) throw new Error("Pending board filter toolbar was not found.");
      board = board.replace(
        toolbarEnd,
        '$1<button type="button" class="pnb-btn pri" data-pnd="new">＋ Nova pendência</button><button type="button" class="pnb-btn pnb-head-close" data-footer-pending-close aria-label="Fechar Pendências" title="Fechar Pendências">×</button>$2',
      );
      board = board.replaceAll("renderDialog", "renderPendingPanel")
        .replace("document.querySelector('#app-modal [data-pnd-root]')", "document.querySelector('#cmt-footer-pending:not([hidden]) [data-pnd-root]')")
        .replace("open: renderPendingPanel,", "open: () => window.CMTRail?.openPanel?.('pend', { force: true }),\n    mount: renderPendingPanel,\n    refresh: paint,");
      // The same controls also appear in small issue forms; retain their
      // existing modal styling while making it available to the shared board.
      board = board.replaceAll("#app-modal ", ":is(#app-modal,#cmt-footer-pending) ");
      // Footer launchers own the bell; the old pill wrapper would move it back.
      board = board.replace(/  function ensurePendingFooterButton\(\) \{[\s\S]*?\n  \}\n/,
        "  function ensurePendingFooterButton() { return true; }\n");
      const updated = code.slice(0, start) + board + code.slice(end);
      return opening + JSON.stringify(updated).replace(/<\/script/gi, "<\\/script") + closing;
    },
  );
}

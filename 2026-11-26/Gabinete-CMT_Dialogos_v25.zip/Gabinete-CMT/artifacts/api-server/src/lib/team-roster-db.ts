import { eq } from "drizzle-orm";
import { db, pautaSnapshotsTable } from "@workspace/db";
import { rosterFrom, teamMembersFromState, type TeamMemberRef } from "./team-roster";

/* Lê a equipe cadastrada na pauta compartilhada. Fica em memória por alguns segundos: é usada no login,
   na lista de servidores e na gestão de contas, e a equipe muda raramente. */
const TTL_MS = 15_000;
let cache: { at: number; members: TeamMemberRef[] } | null = null;

export async function loadTeamMembers(): Promise<TeamMemberRef[]> {
  if (cache && Date.now() - cache.at < TTL_MS) return cache.members;
  const [row] = await db.select({ state: pautaSnapshotsTable.state })
    .from(pautaSnapshotsTable).where(eq(pautaSnapshotsTable.id, "main"));
  const members = teamMembersFromState(row?.state);
  cache = { at: Date.now(), members };
  return members;
}

export async function loadTeamRoster(): Promise<string[]> {
  return rosterFrom(await loadTeamMembers());
}

export function forgetTeamMembers(): void {
  cache = null;
}

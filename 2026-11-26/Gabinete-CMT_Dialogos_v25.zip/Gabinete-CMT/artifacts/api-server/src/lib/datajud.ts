/* DataJud (API pública do CNJ) — regras puras, sem banco nem rede:
   normalização dos documentos, comparação entre duas leituras, regras de aviso pelos códigos da
   Tabela Processual Unificada (TPU), pauta e designação do servidor, roteamento, texto dos e-mails e agenda com fuso.
   Os mesmos critérios rodam na Central (modo autônomo) — manter os dois em sintonia. */

export const DATAJUD_PUBLIC_KEY = "cDZHYzlZa0JadVREZDJCendQbXY6SkJlTzNjLV9TRENyQk1RdnFKZGRQdw==";
export const DATAJUD_FIELDS = ["numeroProcesso", "grau", "classe", "orgaoJulgador", "dataAjuizamento", "dataHoraUltimaAtualizacao",
  "@timestamp", "movimentos", "nivelSigilo", "formato", "sistema", "assuntos", "partes", "valorCausa"];
export const MAX_MOV = 10;

export type Mov = { t: number; n: string; c: number | null; cp: string; grau?: string };
export type Doc = { grau: string; classe: string; orgao: string; upd: number | null; ts: number | null; nMov: number; mv: Mov[]; sig: number };
export type Capa = { k: string; t: string; de: string; para: string };
export type Proc = { g?: Doc[]; at: number; nf: boolean; last?: number; chg: number | null; novos: Mov[]; cad?: boolean; capa?: Capa[]; seen: boolean };
export type Run = {
  ini: number; fim: number | null; motivo: string; origem: string; escopo: string; autor?: string; modo?: "completa" | "leve"; desde?: number | null;
  consultados: number; encontrados: number; naoLoc: number; prim: number; atual: string[]; sumidos: string[];
  cad: number; novosMov: number; erros: number; erro: string | null; base: number; interrompido?: boolean; eventos?: number;
};

const isRecord = (v: unknown): v is Record<string, any> => !!v && typeof v === "object" && !Array.isArray(v);
export const digitos = (v: unknown) => String(v ?? "").replace(/\D/g, "");
export const cnjFmt = (n: string) => n.replace(/^(\d{7})(\d{2})(\d{4})(\d)(\d{2})(\d{4})$/, "$1-$2.$3.$4.$5.$6");
export const nrm = (s: unknown) => String(s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();

export function processosAusentesDoAcervo(processos: unknown[], existentes: unknown[]): string[] {
  const presentes = new Set(existentes.map(digitos).filter((n) => n.length === 20));
  return [...new Set(processos.map(digitos).filter((n) => n.length === 20 && !presentes.has(n)))];
}

/* datas do DataJud: ISO (com ou sem fuso) ou compacto "AAAAMMDDhhmmss" (horário de Brasília) */
export function djTime(v: unknown): number | null {
  if (v == null || v === "") return null;
  if (typeof v === "number") return v > 1e12 ? v : v * 1000;
  const s = String(v).trim(), m = s.match(/^(\d{4})(\d{2})(\d{2})(\d{2})?(\d{2})?(\d{2})?$/);
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], +(m[4] || 0) + 3, +(m[5] || 0), +(m[6] || 0));
  const t = Date.parse(/[zZ]|[+-]\d{2}:?\d{2}$/.test(s) || !/T\d/.test(s) ? s : s + "-03:00");
  return Number.isFinite(t) ? t : null;
}

export function normalizarDoc(raw: unknown): { num: string; doc: Doc } | null {
  const s = isRecord(raw) && isRecord(raw._source) ? raw._source : raw;
  if (!isRecord(s)) return null;
  const num = digitos(s.numeroProcesso);
  if (num.length !== 20) return null;
  const mv: Mov[] = (Array.isArray(s.movimentos) ? s.movimentos : []).map((x: any) => ({
    t: djTime(x?.dataHora) ?? 0,
    n: String(x?.nome || x?.movimentoNacional?.nome || ("Movimento " + (x?.codigo ?? ""))).trim(),
    c: x?.codigo == null || x.codigo === "" || !Number.isFinite(+x.codigo) ? null : +x.codigo,
    cp: (Array.isArray(x?.complementosTabelados) ? x.complementosTabelados : [])
      .map((c: any) => String(c?.nome || c?.descricao || "").trim()).filter(Boolean).slice(0, 3).join("; "),
  })).filter((m: Mov) => m.t > 0).sort((a: Mov, b: Mov) => b.t - a.t);
  return { num, doc: { grau: String(s.grau || ""), classe: String(s.classe?.nome || ""), orgao: String(s.orgaoJulgador?.nome || ""),
    upd: djTime(s.dataHoraUltimaAtualizacao), ts: djTime(s["@timestamp"]), nMov: mv.length, mv: mv.slice(0, MAX_MOV), sig: +s.nivelSigilo || 0 } };
}

/* desde: leitura leve — o CNJ devolve só os documentos recarregados depois desse instante (campo @timestamp) */
export function corpoConsulta(nums: readonly string[], desde?: number | null) {
  return { size: Math.min(10000, nums.length * 4), _source: DATAJUD_FIELDS,
    query: { bool: { should: nums.map((n) => ({ match: { numeroProcesso: n } })), minimum_should_match: 1,
      ...(desde ? { filter: [{ range: { "@timestamp": { gte: new Date(desde).toISOString() } } }] } : {}) } } };
}

/** Divide lotes que excederam o tempo de consulta sem alterar a ordem dos processos. */
export function dividirLoteDataJud<T>(itens: readonly T[], minimo = 25): [T[], T[]] | null {
  if (itens.length <= minimo) return null;
  const meio = Math.ceil(itens.length / 2);
  return [itens.slice(0, meio), itens.slice(meio)];
}

export const maxMov = (g?: Doc[]) => Math.max(0, ...(g || []).flatMap((d) => d.mv.map((m) => m.t)));
export const maxUpd = (g?: Doc[]) => Math.max(0, ...(g || []).map((d) => d.upd || 0));
export const sumMov = (g?: Doc[]) => (g || []).reduce((a, d) => a + (d.nMov || 0), 0);
export const ultimoMov = (g?: Doc[]): Mov | null => {
  let b: Mov | null = null;
  for (const d of g || []) for (const m of d.mv) if (!b || m.t > b.t) b = { ...m, grau: d.grau };
  return b;
};

/* capa: órgão julgador, classe e sigilo (prefere o registro do 2º grau) */
export function capaMudou(a?: Doc[], b?: Doc[]): Capa[] {
  const A = (a || []).find((d) => d.grau === "G2") || (a || [])[0], B = (b || []).find((d) => d.grau === "G2") || (b || [])[0];
  const out: Capa[] = [];
  if (!A || !B) return out;
  if (A.orgao && B.orgao && A.orgao !== B.orgao) out.push({ k: "orgao", t: "Órgão julgador", de: A.orgao, para: B.orgao });
  if (A.classe && B.classe && A.classe !== B.classe) out.push({ k: "classe", t: "Classe", de: A.classe, para: B.classe });
  if ((A.sig || 0) !== (B.sig || 0)) out.push({ k: "sigilo", t: "Nível de sigilo", de: String(A.sig || 0), para: String(B.sig || 0) });
  return out;
}

/* comparação de uma leitura com a anterior — mesma lógica do painel da Central */
export function comparar(old: Proc | undefined, g: Doc[], ini: number): { rec: Proc; estado: "prim" | "atual" | "igual"; novos: number; cad: boolean } {
  const rec: Proc = { g, at: ini, nf: false, last: maxMov(g), chg: null, novos: [], seen: true };
  if (!old || !old.g || old.nf) return { rec, estado: "prim", novos: 0, cad: false };
  const lo = maxMov(old.g);
  let novos: Mov[] = g.flatMap((d) => d.mv.filter((m) => m.t > lo).map((m) => ({ ...m, grau: d.grau })));
  if (!novos.length && sumMov(g) > sumMov(old.g)) novos = g.map((d) => d.mv[0] && { ...d.mv[0], grau: d.grau }).filter(Boolean).slice(0, 1) as Mov[];
  const cad = !novos.length && maxUpd(g) > maxUpd(old.g), capa = capaMudou(old.g, g);
  if (novos.length || cad || capa.length) {
    Object.assign(rec, { chg: ini, novos: novos.sort((a, b) => b.t - a.t).slice(0, MAX_MOV), cad, capa, seen: false });
    return { rec, estado: "atual", novos: novos.length, cad };
  }
  Object.assign(rec, { chg: old.chg || null, novos: old.novos || [], cad: old.cad, capa: old.capa, seen: old.seen !== false });
  return { rec, estado: "igual", novos: 0, cad: false };
}
export function naoLocalizado(old: Proc | undefined, ini: number): { rec: Proc; sumiu: boolean } {
  return { rec: { ...(old || { chg: null, novos: [], seen: true }), nf: true, at: ini } as Proc, sumiu: !!(old && old.g && !old.nf) };
}
export function novaExecucao(motivo: string, origem: string, escopo: string, consultados: number, autor = ""): Run {
  return { ini: Date.now(), fim: null, motivo, origem, escopo, ...(autor ? { autor } : {}), consultados, encontrados: 0, naoLoc: 0, prim: 0,
    atual: [], sumidos: [], cad: 0, novosMov: 0, erros: 0, erro: null, base: 0 };
}

/* ───────── TPU — códigos conferidos no SGT/DPJ do CNJ em 28/10/2026 ───────── */
export const TPU = {
  conclusao: [51], peticao: [85], documento: [581],
  redistribuicao: [36], remessa: [123, 978, 980, 982], recebimento: [115, 132, 160, 977, 979, 981],
  decurso: [1051], publicacao: [92], expedicao: [60],
  suspensao: [25, 265, 11975, 12098, 12099, 12100], levantSusp: [12066],
  pautaInc: [12104, 12105], adiado: [12203], vista: [12204], retirado: [12205, 12309],
  provimento: [237], naoProv: [239], naoConhec: [235], edAcolhe: [198, 871], edRejeita: [200],
  homolTrans: [466], homolDesist: [944, 12467], retratacao: [12258],
  transito: [848], baixa: [22], arquivamento: [861, 246],
} as const;
const L = (...xs: ReadonlyArray<readonly number[]>) => xs.flat() as number[];
const KNOWN = new Set<number>(L(...Object.values(TPU)));
const PET = L(TPU.peticao, TPU.documento);
const JULG = L(TPU.provimento, TPU.naoProv, TPU.naoConhec, TPU.edAcolhe, TPU.edRejeita, TPU.homolTrans, TPU.homolDesist);
const SEC = L(TPU.remessa, TPU.recebimento, TPU.expedicao, TPU.publicacao, TPU.decurso, TPU.documento);
const PAUTA_MUD = L(TPU.adiado, TPU.vista, TPU.retirado);
const SAIDA = L(TPU.transito, TPU.baixa, TPU.arquivamento);
export const txtMov = (m: Mov) => nrm(`${m.n || ""} ${m.cp || ""}`);
export const temCodigo = (m: Mov, codes: readonly number[]) => m.c != null && codes.includes(+m.c);
/* o nome só decide quando o movimento chega sem código ou com código local, fora da TPU nacional */
export const peloNome = (m: Mov, re: RegExp) => (m.c == null || !KNOWN.has(+m.c)) && re.test(nrm(m.n));
const isVP = (m: Mov) => /vice|retrat|1\.?030|1\.?040|superior|stj|stf/.test(txtMov(m));

export type Periodicidade = "imediata" | "diaria" | "semanal" | "off";
export type Publico = "des" | "ass" | "srv" | "sessao";
export type Regra = {
  id: string; g: string; nome: string; sev: 0 | 1 | 2 | 3; tier: Periodicidade; aud: Publico[];
  desc?: string; codes?: number[]; kind?: "capa" | "sumiu" | "tempo"; ctx?: "pauta"; excl?: string; dias?: number; uniq?: string[];
  t?: (m: Mov) => boolean;
};
export const REGRAS: Regra[] = [
  { id: "pautaInterc", g: "Sessão de julgamento", sev: 3, tier: "imediata", aud: ["sessao"], ctx: "pauta", excl: "ciencia|ciente",
    nome: "Petição intercorrente em processo pautado", codes: PET,
    desc: "Juntada de petição ou documento depois da inclusão em pauta e antes da sessão. Como o gabinete não certifica nem dá seguimento, o aviso vai direto ao servidor designado para o processo na sessão.",
    t: (m) => temCodigo(m, PET) || peloNome(m, /peticao|juntada de documento/) },
  { id: "pautaMud", g: "Sessão de julgamento", sev: 3, tier: "imediata", aud: ["sessao", "des"], nome: "Adiamento, retirada de pauta ou pedido de vista",
    codes: PAUTA_MUD, t: (m) => temCodigo(m, PAUTA_MUD) || peloNome(m, /adiad|retirad|pedido de vista/) },
  { id: "pautaInc", g: "Sessão de julgamento", sev: 1, tier: "diaria", aud: ["sessao"], nome: "Inclusão em pauta",
    codes: L(TPU.pautaInc), t: (m) => temCodigo(m, TPU.pautaInc) || peloNome(m, /inclusao em pauta/) },
  { id: "redistrib", g: "Competência e capa", sev: 3, tier: "imediata", aud: ["des", "ass"], nome: "Redistribuição",
    codes: L(TPU.redistribuicao), t: (m) => temCodigo(m, TPU.redistribuicao) || peloNome(m, /redistribu/) },
  { id: "capa", g: "Competência e capa", sev: 3, tier: "imediata", aud: ["des", "ass"], kind: "capa", nome: "Mudança de órgão julgador, classe ou sigilo",
    desc: "Comparação da capa do processo entre duas leituras do DataJud." },
  { id: "sumiu", g: "Competência e capa", sev: 2, tier: "diaria", aud: ["ass"], kind: "sumiu", nome: "Processo deixou de constar na base pública",
    desc: "Costuma indicar sigilo superveniente, retificação do número ou baixa do índice." },
  { id: "levSusp", g: "Sobrestamento", sev: 3, tier: "imediata", aud: ["ass", "des"], nome: "Levantamento da suspensão",
    codes: L(TPU.levantSusp), t: (m) => temCodigo(m, TPU.levantSusp) || peloNome(m, /levantamento da suspensao|dessobrest/) },
  { id: "susp", g: "Sobrestamento", sev: 2, tier: "diaria", aud: ["ass"], nome: "Suspensão ou sobrestamento (repercussão geral, repetitivo, IRDR)",
    codes: L(TPU.suspensao), t: (m) => temCodigo(m, TPU.suspensao) || peloNome(m, /suspens|sobrest/) },
  { id: "retornoVP", g: "Retornos ao gabinete", sev: 3, tier: "imediata", aud: ["ass", "des"], nome: "Retorno da Vice-Presidência ou juízo de retratação",
    codes: L(TPU.retratacao, TPU.recebimento),
    desc: "Retratação lançada, ou recebimento cujo complemento indique a Vice-Presidência, os tribunais superiores ou os arts. 1.030 e 1.040 do CPC.",
    t: (m) => temCodigo(m, TPU.retratacao) || peloNome(m, /retratacao/) || ((temCodigo(m, TPU.recebimento) || peloNome(m, /recebiment/)) && isVP(m)) },
  { id: "petUrg", g: "Petições", sev: 3, tier: "imediata", aud: ["ass", "des"], nome: "Petição com pedido urgente, desistência ou acordo", codes: PET,
    desc: "Pelo nome ou complemento: urgência, tutela, liminar, desistência, renúncia, acordo, transação.",
    t: (m) => (temCodigo(m, PET) || peloNome(m, /peticao/)) && /urgen|tutela|liminar|desist|renunc|acordo|transac/.test(txtMov(m)) },
  { id: "petRec", g: "Petições", sev: 2, tier: "diaria", aud: ["ass"], nome: "Embargos de declaração ou agravo interno", codes: PET,
    t: (m) => (temCodigo(m, PET) || peloNome(m, /peticao|embargos|agravo/)) && /embargos de declarac|agravo interno|agravo regimental/.test(txtMov(m)) },
  { id: "peticao", g: "Petições", sev: 1, tier: "diaria", aud: ["ass"], uniq: ["petUrg", "petRec"], nome: "Demais petições juntadas",
    codes: L(TPU.peticao), t: (m) => temCodigo(m, TPU.peticao) || peloNome(m, /peticao/) },
  { id: "conclusao", g: "Gabinete", sev: 1, tier: "diaria", aud: ["ass"], nome: "Conclusão ao relator",
    codes: L(TPU.conclusao), t: (m) => temCodigo(m, TPU.conclusao) || peloNome(m, /^conclus/) },
  { id: "parado", g: "Gabinete", sev: 2, tier: "semanal", aud: ["ass", "des"], kind: "tempo", dias: 60, nome: "Concluso sem movimento há muito tempo",
    codes: L(TPU.conclusao), desc: "Apurado a cada resumo semanal: a última movimentação no DataJud é a conclusão e já passou o prazo indicado." },
  { id: "julgado", g: "Resultado", sev: 1, tier: "semanal", aud: ["des"], nome: "Resultado de julgamento lançado",
    codes: JULG, t: (m) => temCodigo(m, JULG) || peloNome(m, /provimento|conhecimento|acolhimento de embargos|homologac/) },
  { id: "saida", g: "Rotina da Secretaria", sev: 1, tier: "off", aud: ["des"], nome: "Trânsito em julgado, baixa e arquivamento", codes: SAIDA,
    desc: "Atos certificados pela Secretaria; servem apenas para conferir a saída do acervo.",
    t: (m) => temCodigo(m, SAIDA) || peloNome(m, /transito em julgado|baixa definitiva|arquivament/) },
  { id: "secretaria", g: "Rotina da Secretaria", sev: 0, tier: "off", aud: [], nome: "Certidões, remessas, recebimentos, expedições, publicações e decursos", codes: SEC,
    desc: "O gabinete não certifica nem dá seguimento a estes atos: a Secretaria cuida deles. Ficam fora dos avisos, salvo se forem ligados aqui.",
    t: (m) => (temCodigo(m, SEC) && !isVP(m)) || peloNome(m, /certid|ato ordinatorio|remessa|recebiment|expedic|publicac|decurso|decorrid/) },
];
export const REGRA = Object.fromEntries(REGRAS.map((R) => [R.id, R])) as Record<string, Regra>;
export const SEV_TXT: Record<string, string> = { 3: "PRIORIDADE ALTA", 2: "ATENÇÃO", 1: "PARA CONHECIMENTO", 0: "ROTINA", ja: "JÁ AVISADOS DE IMEDIATO NO PERÍODO" };
export const regrasPublicas = () => REGRAS.map(({ t, ...r }) => r);

/* ───────── configuração (compartilhada pelo gabinete) ───────── */
export type RegraCfg = { tier?: Periodicidade; aud?: Publico[]; excl?: string; dias?: number };
export type Papel = "des" | "ass" | "srv";
export type DestinoExtra = { id: string; nome: string; email: string; papel: Papel; filtro: string; cc: boolean; on: boolean };
export type AjusteEquipe = { papel?: Papel; filtro?: string; cc?: boolean; on?: boolean };
export type NotifConfig = {
  r: Record<string, RegraCfg>; extras: DestinoExtra[]; ajustes: Record<string, AjusteEquipe>;
  hora: string; uteis: boolean; semDia: number; semHora: string; envioAuto: boolean; vazio: boolean;
  auto: number; janela: string;
};
export const CONFIG_PADRAO: NotifConfig = { r: {}, extras: [], ajustes: {}, hora: "18:00", uteis: true, semDia: 5, semHora: "17:00",
  envioAuto: true, vazio: false, auto: 60, janela: "00-24" };
const HHMM = /^([01]\d|2[0-3]):[0-5]\d$/;
const EMAIL = /^[^@\s<>]+@[^@\s<>]+\.[^@\s<>]+$/;
const PAPEIS = new Set(["des", "ass", "srv"]);
const TIERS = new Set(["imediata", "diaria", "semanal", "off"]);
const AUDS = new Set(["des", "ass", "srv", "sessao"]);
export function cfgRegra(R: Regra, c: NotifConfig) {
  const o = c.r[R.id] || {};
  return { tier: (o.tier || R.tier) as Periodicidade, aud: (Array.isArray(o.aud) ? o.aud : R.aud) as Publico[], excl: o.excl != null ? o.excl : (R.excl || ""), dias: +(o.dias || 0) || R.dias || 0 };
}
export function regexSegura(s: string): RegExp | null { try { return s ? new RegExp(s, "i") : null; } catch { return null; } }

export function validarConfig(raw: unknown): { ok: true; dados: NotifConfig } | { ok: false; error: string } {
  if (!isRecord(raw)) return { ok: false, error: "A configuração deve ser um objeto." };
  const out: NotifConfig = { ...CONFIG_PADRAO, r: {}, extras: [], ajustes: {} };
  const r = isRecord(raw.r) ? raw.r : {};
  for (const [id, v] of Object.entries(r)) {
    if (!REGRA[id] || !isRecord(v)) continue;
    const c: RegraCfg = {};
    if (v.tier != null) { if (!TIERS.has(v.tier)) return { ok: false, error: `Periodicidade inválida na regra ${id}.` }; c.tier = v.tier; }
    if (v.aud != null) { if (!Array.isArray(v.aud) || v.aud.some((a: unknown) => !AUDS.has(String(a)))) return { ok: false, error: `Destinatários inválidos na regra ${id}.` }; c.aud = [...new Set(v.aud as Publico[])]; }
    if (v.excl != null) { const s = String(v.excl).slice(0, 200); if (s && !regexSegura(s)) return { ok: false, error: `Expressão inválida na regra ${id}.` }; c.excl = s; }
    if (v.dias != null) { const d = +v.dias; if (!Number.isFinite(d) || d < 1 || d > 3650) return { ok: false, error: "Prazo em dias inválido." }; c.dias = d; }
    out.r[id] = c;
  }
  const extras = Array.isArray(raw.extras) ? raw.extras : [];
  if (extras.length > 60) return { ok: false, error: "No máximo 60 destinatários avulsos." };
  for (const x of extras) {
    if (!isRecord(x)) continue;
    const email = String(x.email || "").trim().toLowerCase();
    if (email && !EMAIL.test(email)) return { ok: false, error: `E-mail inválido: ${email}` };
    out.extras.push({ id: String(x.id || "").slice(0, 40) || "x" + Math.random().toString(36).slice(2, 9), nome: String(x.nome || "").trim().slice(0, 120), email,
      papel: PAPEIS.has(x.papel) ? x.papel : "ass", filtro: String(x.filtro || "").slice(0, 300), cc: !!x.cc, on: x.on !== false });
  }
  const aj = isRecord(raw.ajustes) ? raw.ajustes : {};
  for (const [k, v] of Object.entries(aj).slice(0, 200)) {
    if (!isRecord(v)) continue;
    const a: AjusteEquipe = {};
    if (v.papel != null && PAPEIS.has(v.papel)) a.papel = v.papel;
    if (v.filtro != null) a.filtro = String(v.filtro).slice(0, 300);
    if (v.cc != null) a.cc = !!v.cc;
    if (v.on != null) a.on = !!v.on;
    out.ajustes[String(k).slice(0, 80)] = a;
  }
  if (raw.hora != null) { if (!HHMM.test(String(raw.hora))) return { ok: false, error: "Horário do resumo diário inválido." }; out.hora = String(raw.hora); }
  if (raw.semHora != null) { if (!HHMM.test(String(raw.semHora))) return { ok: false, error: "Horário do resumo semanal inválido." }; out.semHora = String(raw.semHora); }
  if (raw.semDia != null) { const d = +raw.semDia; if (!Number.isInteger(d) || d < 0 || d > 6) return { ok: false, error: "Dia do resumo semanal inválido." }; out.semDia = d; }
  if (raw.auto != null) {
    const a = +raw.auto;
    if (!Number.isFinite(a) || a < 0 || a > 1440 || (a > 0 && a < 15)) return { ok: false, error: "Intervalo da sincronização automática inválido." };
    out.auto = 60;
  }
  if (raw.janela != null) {
    const m = String(raw.janela).match(/^(\d{1,2})-(\d{1,2})$/);
    if (!m || +m[1] > 23 || +m[2] > 24 || +m[1] >= +m[2]) return { ok: false, error: "Janela de horário inválida (ex.: 07-20)." };
    out.janela = "00-24";
  }
  for (const k of ["uteis", "envioAuto", "vazio"] as const) if (raw[k] != null) out[k] = !!raw[k];
  return { ok: true, dados: out };
}

/* ───────── destinatários: equipe da pauta + avulsos (ex.: o Desembargador) ───────── */
export type Destinatario = DestinoExtra & { origem: "equipe" | "extra"; servidor?: string };
export const chaveNome = (s: unknown) => nrm(s).replace(/\s+/g, " ");
export function equipeDaPauta(state: unknown): Array<{ chave: string; nome: string; email: string; assessoria: boolean; ativo: boolean; aliases: string[] }> {
  const team = isRecord(state) && isRecord(state.team) ? state.team : {};
  const out: Array<{ chave: string; nome: string; email: string; assessoria: boolean; ativo: boolean; aliases: string[] }> = [];
  const seen = new Set<string>();
  for (const m of Array.isArray(team.members) ? team.members : []) {
    if (!isRecord(m)) continue;
    const nome = String(m.name || "").trim(), chave = chaveNome(nome);
    if (!chave || seen.has(chave)) continue;
    seen.add(chave);
    const email = String(m.email || "").trim().toLowerCase();
    out.push({ chave, nome, email: EMAIL.test(email) ? email : "", assessoria: m.assessoria === true || /^(cj|cm|assessor)/i.test(String(m.hierarchy || m.hierarquia || m.role || "")),
      ativo: m.archived !== true && m.inactive !== true, aliases: (Array.isArray(m.aliases) ? m.aliases : []).map(chaveNome).filter(Boolean) });
  }
  return out;
}
export function destinatariosEfetivos(state: unknown, c: NotifConfig): Destinatario[] {
  const eq: Destinatario[] = equipeDaPauta(state).map((m) => {
    const id = "eq:" + m.chave, a = c.ajustes[id] || {};
    return { id, nome: m.nome, email: m.email, papel: a.papel || (m.assessoria ? "ass" : "srv"), filtro: a.filtro || "", cc: !!a.cc,
      on: a.on != null ? a.on : m.ativo, origem: "equipe", servidor: m.chave };
  });
  return [...c.extras.map((x) => ({ ...x, origem: "extra" as const })), ...eq];
}
const servidorCasa = (d: Destinatario, nome: string) => !!d.servidor && d.servidor === chaveNome(nome);

/* ───────── pauta: sessões futuras em aberto e o servidor designado em cada uma ───────── */
export type PautaInfo = { sessao: string; data: string; servidor: string };
function isoDe(v: unknown): string {
  const s = String(v ?? "").trim(), a = /^(\d{4}-\d{2}-\d{2})/.exec(s);
  if (a) return a[1];
  const b = /^(\d{1,2})[/. -](\d{1,2})[/. -](\d{4})/.exec(s);
  return b ? `${b[3]}-${b[2].padStart(2, "0")}-${b[1].padStart(2, "0")}` : "";
}
export function indicePauta(state: unknown, hojeISO: string): Map<string, PautaInfo[]> {
  const st = isRecord(state) ? state : {}, det = isRecord(st.sessionDetails) ? st.sessionDetails : {};
  const out = new Map<string, PautaInfo[]>();
  const dataDe = (label: string) => { const d = isRecord(det[label]) ? det[label] : {}; return isRecord(d.archive) && d.archive.saved === true ? "" : isoDe(d.date) || isoDe(label); };
  for (const row of Array.isArray(st.rows) ? st.rows : []) {
    if (!isRecord(row)) continue;
    const n = digitos(row.Processo);
    if (n.length !== 20) continue;
    const L: PautaInfo[] = [];
    const entries = Array.isArray(row._pautaEntries) ? row._pautaEntries : [];
    for (const e of entries) {
      if (!isRecord(e) || e.closed === true) continue;
      const sessao = String(e.session || "").trim(), data = sessao && dataDe(sessao);
      if (!data || data < hojeISO) continue;
      const w = isRecord(e.work) ? e.work : {};
      L.push({ sessao, data, servidor: String(w.SERVIDOR || row.SERVIDOR || "").trim() });
    }
    const dest = String(row["Sessão Destino"] || "").trim();
    if (dest && !L.some((x) => x.sessao === dest)) { const data = dataDe(dest); if (data && data >= hojeISO) L.push({ sessao: dest, data, servidor: String(row.SERVIDOR || "").trim() }); }
    if (L.length) out.set(n, L.sort((a, b) => (a.data < b.data ? -1 : 1)));
  }
  return out;
}

/* ───────── avaliação: eventos a partir de uma sincronização ───────── */
export type ProcCtx = { processo?: string; assunto?: string; classe?: string; secao?: string; etiquetas?: string[]; tarefa?: string; ativo?: boolean };
export type Evento = {
  id: string; n: string; p: string; cl: string; r: string; sev: number; tier: Periodicidade; det: number;
  mv: Mov | null; info: string; sess: { sessao: string; data: string; servidor: string; fonte: string } | null; to: string[];
};
const hay = (o?: ProcCtx) => o ? nrm([o.assunto, o.classe, o.secao, ...(o.etiquetas || []), o.tarefa].filter(Boolean).join(" | ")) : "";
function finais(tok: string) {
  const out = new Set<number>();
  tok.replace(/^final\s*:/i, "").split(",").forEach((p) => { const m = p.trim().match(/^(\d)\s*(?:-\s*(\d))?$/); if (m) for (let i = +m[1]; i <= +(m[2] ?? m[1]); i++) out.add(i); });
  return out;
}
export function cabe(d: Pick<Destinatario, "filtro">, o: ProcCtx | undefined, n: string): boolean {
  const toks = String(d.filtro || "").split(";").map((s) => s.trim()).filter(Boolean);
  if (!toks.length) return true;
  const fin = toks.filter((t) => /^final\s*:/i.test(t)), tx = toks.filter((t) => !/^final\s*:/i.test(t)), dig = +n[6], h = hay(o);
  return (!fin.length || fin.some((t) => finais(t).has(dig))) && (!tx.length || tx.some((t) => h.includes(nrm(t))));
}
export function rotear(aud: Publico[], o: ProcCtx | undefined, n: string, D: Destinatario[], servidorSessao?: string): string[] {
  const A = D.filter((d) => d.on !== false), out = new Set<string>();
  const assessoria = () => { let X = A.filter((d) => d.papel === "ass" && d.filtro.trim() && cabe(d, o, n)); if (!X.length) X = A.filter((d) => d.papel === "ass" && !d.filtro.trim()); return X; };
  if (aud.includes("des")) A.filter((d) => d.papel === "des").forEach((d) => out.add(d.id));
  if (aud.includes("ass")) assessoria().forEach((d) => out.add(d.id));
  if (aud.includes("srv")) A.filter((d) => d.papel === "srv" && cabe(d, o, n)).forEach((d) => out.add(d.id));
  if (aud.includes("sessao")) {
    const s = servidorSessao ? A.filter((d) => servidorCasa(d, servidorSessao)) : [];
    (s.length ? s : assessoria()).forEach((d) => out.add(d.id));
  }
  A.filter((d) => d.cc).forEach((d) => out.add(d.id));
  return [...out];
}
function pautaDataJud(r: Proc): { on: boolean; t: number | null } | null {
  const mv = (r.g || []).flatMap((d) => d.mv).sort((a, b) => b.t - a.t);
  for (const m of mv) {
    if (temCodigo(m, TPU.pautaInc) || peloNome(m, /inclusao em pauta/)) return { on: true, t: m.t };
    if (temCodigo(m, TPU.adiado) || peloNome(m, /adiad/)) return { on: true, t: null };
    if (temCodigo(m, L(TPU.retirado, JULG)) || peloNome(m, /retirad|provimento|conhecimento|julgad/)) return { on: false, t: m.t };
  }
  return null;
}
const brData = (iso: string) => iso ? iso.split("-").reverse().join("/") : "—";
export type Contexto = {
  procs: Map<string, Proc>; ctx: Map<string, ProcCtx>; pauta: Map<string, PautaInfo[]>; destinatarios: Destinatario[];
  config: NotifConfig; agora: number; fimDoDia: (iso: string) => number; fmt: (t: number) => string;
};
export function mkEvento(R: Regra, n: string, o: ProcCtx | undefined, m: Mov | null, k: string, info: string, C: Contexto,
  sess: Evento["sess"] = null): Evento {
  const c = cfgRegra(R, C.config);
  return { id: [n, R.id, m ? `${m.c ?? ""}@${m.t}` : k].join("|"), n, p: o?.processo || cnjFmt(n), cl: o?.classe || "", r: R.id, sev: R.sev, tier: c.tier,
    det: C.agora, mv: m ? { n: m.n, c: m.c, cp: m.cp, t: m.t, ...(m.grau ? { grau: m.grau } : {}) } : null, info, sess,
    to: rotear(c.aud, o, n, C.destinatarios, sess?.servidor) };
}
export function avaliar(run: Run, C: Contexto): Evento[] {
  const out: Evento[] = [], ids = new Set<string>(), on = (R: Regra) => cfgRegra(R, C.config).tier !== "off";
  const add = (e: Evento) => { if (!ids.has(e.id)) { ids.add(e.id); out.push(e); } };
  for (const n of run.sumidos) if (on(REGRA.sumiu)) add(mkEvento(REGRA.sumiu, n, C.ctx.get(n), null, "sumiu@" + run.ini, `não localizado na leitura de ${C.fmt(run.ini)}, embora constasse na anterior`, C));
  for (const n of run.atual) {
    const r = C.procs.get(n); if (!r || r.chg !== run.ini) continue;
    const o = C.ctx.get(n);
    for (const c of r.capa || []) if (on(REGRA.capa)) add(mkEvento(REGRA.capa, n, o, null, `capa:${c.k}@${run.ini}`, `${c.t}: ${c.de || "—"} → ${c.para || "—"}`, C));
    for (const m of r.novos || []) {
      const fired = new Set<string>();
      for (const R of REGRAS) {
        if (!R.t || !on(R) || !R.t(m)) continue;
        if (R.uniq && R.uniq.some((x) => fired.has(x))) continue;
        const cf = cfgRegra(R, C.config), ex = regexSegura(cf.excl);
        if (ex && ex.test(txtMov(m))) continue;
        let sess: Evento["sess"] = null, info = "";
        if (R.ctx === "pauta" || cf.aud.includes("sessao")) {
          const P = (C.pauta.get(n) || []).filter((x) => R.ctx !== "pauta" || m.t <= C.fimDoDia(x.data));
          const dj = pautaDataJud(r);
          if (R.ctx === "pauta") {
            if (!P.length && !(dj && dj.on)) continue;           // não está pautado
            if (dj && dj.on && dj.t && m.t < dj.t) continue;      // juntada anterior à inclusão em pauta
          }
          const x = P[0];
          if (x) sess = { sessao: x.sessao, data: x.data, servidor: x.servidor, fonte: "pauta do gabinete" };
          else if (dj && dj.on) sess = { sessao: "", data: "", servidor: "", fonte: "inclusão em pauta no DataJud" };
          info = sess ? (sess.data ? `sessão de ${brData(sess.data)}${sess.sessao && sess.sessao !== brData(sess.data) ? ` (${sess.sessao})` : ""}` : "pautado, sem sessão identificada no gabinete")
            + (sess.servidor ? ` · servidor designado: ${sess.servidor}` : " · sem servidor designado") : "";
        }
        fired.add(R.id);
        add(mkEvento(R, n, o, m, "", info, C, sess));
      }
    }
  }
  return out;
}
/* semanal: concluso há mais de N dias sem movimento (só processos ativos) */
export function parados(C: Contexto): Evento[] {
  const R = REGRA.parado, c = cfgRegra(R, C.config);
  if (c.tier === "off") return [];
  const out: Evento[] = [];
  for (const [n, r] of C.procs) {
    const o = C.ctx.get(n);
    if (!r.g || r.nf || (o && o.ativo === false)) continue;
    const b = ultimoMov(r.g);
    if (!b || !(temCodigo(b, TPU.conclusao) || peloNome(b, /^conclus/))) continue;
    const dd = Math.floor((C.agora - b.t) / 864e5);
    if (dd < (c.dias || 60)) continue;
    out.push(mkEvento(R, n, o, null, `parado@${b.t}#${Math.floor((dd - (c.dias || 60)) / 30)}`, `concluso desde ${C.fmt(b.t).slice(0, 10)} — ${dd} dias sem movimento no DataJud`, C));
  }
  return out;
}

/* ───────── texto do e-mail ───────── */
const esc = (s: unknown) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] as string);
export type Envelope = { tipo: "imediata" | "diaria" | "semanal"; de: number; ate: number; semana?: { imediatos: number; diarios: number } };
export function compor(env: Envelope, d: Destinatario | null, E: Evento[], fmt: (t: number) => string, agora = Date.now()) {
  const tit = { imediata: "Aviso imediato", diaria: "Resumo diário", semanal: "Resumo semanal" }[env.tipo];
  const ord = [...E].sort((a, b) => b.sev - a.sev || ((b.mv?.t) || b.det) - ((a.mv?.t) || a.det));
  const ja = env.tipo === "diaria" ? ord.filter((e) => e.tier === "imediata") : [], F = ja.length ? ord.filter((e) => e.tier !== "imediata") : ord;
  const assunto = `[GabCMT · DataJud] ${tit} de ${fmt(agora).slice(0, 10)} — ${E.length} ${E.length === 1 ? "item" : "itens"}${d ? " — " + d.nome : ""}`;
  const saud = !d ? "Atenção: estes itens não encontraram destinatário nas regras atuais." : d.papel === "des" ? "Excelentíssimo Senhor Desembargador Federal," : `Prezado(a) ${String(d.nome).trim().split(/\s+/)[0] || ""},`;
  const intro = env.tipo === "imediata" ? "Segue aviso de movimentação que, pela regra configurada no gabinete, pede atenção imediata."
    : env.tipo === "diaria" && E.length && !F.length ? `Além dos ${E.length} aviso(s) imediato(s) já enviados, não houve movimentação nova na base nacional do CNJ (DataJud) entre ${fmt(env.de)} e ${fmt(env.ate)}. Segue a relação, para registro.`
    : E.length ? `Segue o resumo das movimentações captadas na base nacional do CNJ (DataJud) entre ${fmt(env.de)} e ${fmt(env.ate)}.`
    : `Não houve movimentação relevante na base nacional do CNJ (DataJud) entre ${fmt(env.de)} e ${fmt(env.ate)}.`;
  const semana = env.semana ? `Na semana, chegaram a você ${env.semana.imediatos} aviso(s) imediato(s) e ${env.semana.diarios} item(ns) dos resumos diários.` : "";
  const linha = (e: Evento) => {
    const R = REGRA[e.r], mv = e.mv ? `${e.mv.n}${e.mv.cp ? " (" + e.mv.cp + ")" : ""} · ${fmt(e.mv.t)}${e.mv.c != null ? " · TPU " + e.mv.c : ""}` : "";
    return { a: `${e.p}${e.cl ? " · " + e.cl : ""} — ${R ? R.nome : e.r}`, b: [mv, e.info].filter(Boolean).join(" · ") };
  };
  const grp: Array<[string, Evento[]]> = (["3", "2", "1", "0"] as const).map((s) => [s, F.filter((e) => String(e.sev) === s)] as [string, Evento[]]).filter(([, X]) => X.length);
  if (ja.length) grp.push(["ja", ja]);
  const rod = `Gerado pelo GabCMT em ${fmt(agora)}. Fonte: API pública do DataJud (CNJ), que não alcança processos sigilosos e costuma refletir o PJe com alguns dias de atraso. Confira no PJe antes de agir.`;
  const texto = [saud, "", intro, semana ? "\n" + semana : null,
    ...grp.flatMap(([s, X]) => ["", `▌ ${SEV_TXT[s]} (${X.length})`, ...X.flatMap((e) => { const l = linha(e); return ["• " + l.a, l.b ? "  " + l.b : null]; })]),
    "", "—", rod].filter((x) => x != null).join("\n");
  const cor = (s: string) => s === "3" ? "#8a1c2b" : s === "2" ? "#9a6b00" : s === "ja" ? "#777" : "#2f5d3a";
  const html = `<div style="font-family:Segoe UI,Arial,sans-serif;font-size:14px;color:#222"><p>${esc(saud)}</p><p>${esc(intro)}</p>${semana ? `<p>${esc(semana)}</p>` : ""}${grp.map(([s, X]) =>
    `<h3 style="font-size:13px;letter-spacing:.06em;color:${cor(s)};margin:16px 0 6px">${SEV_TXT[s]} (${X.length})</h3><ul style="margin:0;padding-left:18px">${X.map((e) => { const l = linha(e);
      return `<li style="margin:0 0 6px"><b>${esc(l.a)}</b>${l.b ? `<br><span style="color:#555">${esc(l.b)}</span>` : ""}</li>`; }).join("")}</ul>`).join("")}<hr style="border:0;border-top:1px solid #ddd;margin:16px 0 8px"><p style="font-size:12px;color:#777">${esc(rod)}</p></div>`;
  return { assunto, texto, html };
}

/* ───────── fuso e agenda ───────── */
export const FUSO_PADRAO = "America/Campo_Grande";
export function partes(t: number, tz: string) {
  const p = Object.fromEntries(new Intl.DateTimeFormat("en-US", { timeZone: tz, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", weekday: "short" })
    .formatToParts(new Date(t)).map((x) => [x.type, x.value]));
  return { y: +p.year, m: +p.month, d: +p.day, h: +p.hour % 24, mi: +p.minute, s: +p.second, wd: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].indexOf(p.weekday) };
}
export function instante(y: number, m: number, d: number, h: number, mi: number, tz: string): number {
  let t = Date.UTC(y, m - 1, d, h, mi);
  for (let i = 0; i < 2; i++) { const p = partes(t, tz); t -= Date.UTC(p.y, p.m - 1, p.d, p.h, p.mi) - Date.UTC(y, m - 1, d, h, mi); }
  return t;
}
export const isoNoFuso = (t: number, tz: string) => { const p = partes(t, tz); return `${p.y}-${String(p.m).padStart(2, "0")}-${String(p.d).padStart(2, "0")}`; };
export const fimDoDia = (iso: string, tz: string) => { const [y, m, d] = iso.split("-").map(Number); return instante(y, m, d, 23, 59, tz) + 59_999; };
export function formatador(tz: string) {
  const f = new Intl.DateTimeFormat("pt-BR", { timeZone: tz, day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
  return (t: number) => f.format(new Date(t)).replace(",", "");
}
/* horário-alvo mais recente já vencido (diário: opcionalmente só dias úteis; semanal: no dia da semana) */
export function ultimoAlvo(agora: number, hhmm: string, tz: string, o: { dia?: number; uteis?: boolean } = {}): number {
  const [h, mi] = hhmm.split(":").map(Number), p = partes(agora, tz);
  for (let k = 0; k < 15; k++) {
    const base = Date.UTC(p.y, p.m - 1, p.d - k), dt = new Date(base), wd = dt.getUTCDay();
    const t = instante(dt.getUTCFullYear(), dt.getUTCMonth() + 1, dt.getUTCDate(), h, mi, tz);
    if (t > agora) continue;
    if (o.dia != null ? wd !== o.dia : o.uteis && (wd === 0 || wd === 6)) continue;
    return t;
  }
  return agora - 7 * 864e5;
}
export function proximoAlvo(agora: number, hhmm: string, tz: string, o: { dia?: number; uteis?: boolean } = {}): number {
  const [h, mi] = hhmm.split(":").map(Number), p = partes(agora, tz);
  for (let k = 0; k < 15; k++) {
    const dt = new Date(Date.UTC(p.y, p.m - 1, p.d + k)), wd = dt.getUTCDay();
    const t = instante(dt.getUTCFullYear(), dt.getUTCMonth() + 1, dt.getUTCDate(), h, mi, tz);
    if (t <= agora) continue;
    if (o.dia != null ? wd !== o.dia : o.uteis && (wd === 0 || wd === 6)) continue;
    return t;
  }
  return agora + 7 * 864e5;
}
export function dentroDaJanela(agora: number, janela: string, tz: string): boolean {
  const m = janela.match(/^(\d{1,2})-(\d{1,2})$/); if (!m) return true;
  const h = partes(agora, tz).h;
  return h >= +m[1] && h < +m[2];
}

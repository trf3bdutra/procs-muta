/**
 * Compatibility boundary for the editable legacy document. Settings get their
 * own document adapter, view host and stylesheet scope; the shared application
 * remains mounted. No copy of the application is loaded into an iframe.
 */
const SETTINGS_SCRIPTS = new Set([
  "session-hub-script", "cmt-cfgio-feature", "cmt-v194-config",
  "cmt-v226-config-pagina-js", "cmt-v234-controle-global-js",
  "cmt-v239-opcao-c-js", "cmt-v243-sessoes-js", "cmt-v244-redesign-js",
  "cmt-v245-sem-subabas-js", "cmt-v248-referencias-js", "cmt-v246-nav-js",
  "cmt-v250-equipe", "cmt-v251-acervo", "cmt-v252-cg", "cmt-v253-cg-regras",
  "cmt-v247-cfg-acompanhamento",
]);

const SETTINGS_STYLES = /^(?:cfg-|session-hub-styles$|cmt-workspace-settings$|cmt-v(?:80-cfgio|194-config|200-config|201-config|217-config|226-config|234-controle-global|239-opcao-c|241-config|242-config|243-sessoes|244-redesign|245-sem-subabas|248-referencias|250-equipe|251-acervo|252-cg|253-cg-regras|272-cfg-chamados))/;
const ASSESSORIA_PAGE_STYLES = new Set([
  "alt-shell-style-ass", "alt-always-ass", "cmt-v40-style-ass", "cmt-adv-style-ass",
  "cmt-sidebar-and-icon-dialog-nav-ass", "cmt-v67-team-map-style-ass", "cmt-v68-style-ass",
  "cmt-v73-style-ass", "cmt-v72-cmt-style-ass", "cmtx-v37-groups-style-ass",
  "cmt-v247-paleta-a-ass", "cmt-cm-page-polish-ass", "ass-sol-style",
]);
const aliases: Record<string, string> = {
  "app-content": "cfg-app-content", "app-title": "cfg-app-title",
  "app-subtitle": "cfg-app-subtitle", "app-modal": "cfg-app-modal",
};
function localSelectors(value: string) {
  return value.replace(/\.(app-main|app-header|header-actions|app-eyebrow)\b/g, (_, name) => ({
    "app-main": ".cmt-settings-main", "app-header": ".cmt-settings-header",
    "header-actions": ".cmt-settings-actions", "app-eyebrow": ".cmt-settings-eyebrow",
  }[name as string] ?? name));
}

function splitSelectors(value: string) {
  const parts: string[] = [];
  let depth = 0, quote = "", start = 0;
  for (let i = 0; i < value.length; i++) {
    const c = value[i];
    if (quote) { if (c === quote && value[i - 1] !== "\\") quote = ""; continue; }
    if (c === '"' || c === "'") { quote = c; continue; }
    if (c === "(" || c === "[") depth++;
    if (c === ")" || c === "]") depth--;
    if (c === "," && !depth) { parts.push(value.slice(start, i)); start = i + 1; }
  }
  parts.push(value.slice(start));
  return parts;
}

export function scopeSettingsSelector(selector: string) {
  let rest = localSelectors(selector.trim()).replace(/#(app-content|app-title|app-subtitle|app-modal)\b/g, (_, id) => `#${aliases[id]}`);
  let qualifiers = "";
  // Merge html/body compounds into ONE local root, not two impossible ancestors.
  while (/^(html|body|:root)(?=[.#[:\s>]|$)/.test(rest)) {
    rest = rest.replace(/^(html|body|:root)/, "");
    let end = 0, depth = 0;
    for (; end < rest.length; end++) {
      const c = rest[end];
      if (c === "(" || c === "[") depth++;
      if (c === ")" || c === "]") depth--;
      if (!depth && /\s|>/.test(c)) break;
    }
    qualifiers += rest.slice(0, end);
    rest = rest.slice(end).trimStart();
    if (rest.startsWith(">")) break;
  }
  return `:where(#cmt-settings-dialog${qualifiers}${rest ? " " + rest : ""})`;
}

/** Small balanced CSS walker; strings, comments and grouped rules remain intact. */
export function scopeSettingsCss(css: string): string {
  let output = "", cursor = 0;
  while (cursor < css.length) {
    let open = -1, quote = "", comment = false;
    for (let i = cursor; i < css.length; i++) {
      if (comment) { if (css[i - 1] === "*" && css[i] === "/") comment = false; continue; }
      if (quote) { if (css[i] === quote && css[i - 1] !== "\\") quote = ""; continue; }
      if (css[i] === "/" && css[i + 1] === "*") { comment = true; i++; continue; }
      if (css[i] === "'" || css[i] === '"') { quote = css[i]; continue; }
      if (css[i] === "{") { open = i; break; }
    }
    if (open < 0) { output += css.slice(cursor); break; }
    let depth = 1, end = open + 1; quote = ""; comment = false;
    for (; end < css.length && depth; end++) {
      const c = css[end];
      if (comment) { if (css[end - 1] === "*" && c === "/") comment = false; continue; }
      if (quote) { if (c === quote && css[end - 1] !== "\\") quote = ""; continue; }
      if (c === "/" && css[end + 1] === "*") { comment = true; end++; continue; }
      if (c === "'" || c === '"') { quote = c; continue; }
      if (c === "{") depth++;
      if (c === "}") depth--;
    }
    const header = css.slice(cursor, open);
    const clean = header.replace(/\/\*[\s\S]*?\*\//g, "").trim();
    const body = css.slice(open + 1, end - 1);
    if (clean.startsWith("@")) {
      output += header + "{" + (/^@(media|supports|container|layer)\b/.test(clean) ? scopeSettingsCss(body) : body) + "}";
    } else {
      output += splitSelectors(clean).map(scopeSettingsSelector).join(",") + "{" + body + "}";
    }
    cursor = end;
  }
  return output;
}

function method(source: string, name: string, next: string) {
  const expression = new RegExp(`\\n    ${name}\\([^\\n]*\\)\\{[\\s\\S]*?(?=\\n    ${next}\\()`);
  const match = source.match(expression);
  if (!match) throw new Error(`Settings compatibility contract missing: ${name}`);
  return { expression, code: match[0].slice(0, match[0].lastIndexOf("}") + 1).trim() };
}

function prepareSessionBackup(code: string) {
  const marker = "if(window.PautaDates?.enhance)try{window.PautaDates.enhance(content);}catch(e){}";
  if (code.includes("data-session-backup-export")) return code;
  if (!code.includes(marker)) throw new Error("Settings session renderer contract missing: date enhancer");
  const addition = `
      const backupHost=content.querySelector('.psh-selected')||content.querySelector('.psh-main')||content.querySelector('.psh');
      if(backupHost){
        const panel=document.createElement('section');
        panel.className='cfg-session-backup';
        const selected=this.pautaPreferences?.session||this.sessions?.[0]||'';
        const options=(this.sessions||[]).map(session=>'<option value="'+esc(session)+'"'+(session===selected?' selected':'')+'>'+esc(session)+'</option>').join('');
        panel.innerHTML='<div class="cfg-session-backup-copy"><span>ARQUIVO DA SESSÃO</span><h3>Backup de sessão e processos</h3><p>Inclui marcos, ordem da pauta e dados completos dos processos vinculados.</p></div><div class="cfg-session-backup-controls"><label><span>Sessão</span><select data-session-backup-session aria-label="Sessão do backup">'+(options||'<option value="">Nenhuma sessão cadastrada</option>')+'</select></label><label><span>Ao importar</span><select data-session-backup-mode aria-label="Modo de importação"><option value="merge">Mesclar dados</option><option value="replace">Substituir esta sessão</option></select></label><div class="cfg-session-backup-buttons"><button type="button" data-session-backup-export>Baixar JSON</button><button type="button" data-session-backup-import>Importar JSON</button><input type="file" data-session-backup-file accept=".json,application/json" hidden></div></div><p class="cfg-session-backup-status" data-session-backup-status role="status" aria-live="polite"></p>';
        backupHost.insertBefore(panel,backupHost.firstElementChild);
        const pick=panel.querySelector('[data-session-backup-session]');
        const mode=panel.querySelector('[data-session-backup-mode]');
        const file=panel.querySelector('[data-session-backup-file]');
        const status=panel.querySelector('[data-session-backup-status]');
        const clone=value=>value==null?value:JSON.parse(JSON.stringify(value));
        const digits=value=>String(value||'').replace(/[^0-9]/g,'');
        const show=(message,error)=>{if(status){status.textContent=message;status.dataset.kind=error?'error':'ok';}};
        panel.querySelector('[data-session-backup-export]')?.addEventListener('click',()=>{
          const session=String(pick?.value||'');
          if(!session){show('Cadastre ou selecione uma sessão antes de exportar.',true);return;}
          try{
            if(typeof P.sessionRows!=='function')throw new Error('O leitor de processos por sessão não está disponível.');
            const draft=Object.assign(Object.create(Object.getPrototypeOf(this)),this);
            draft.rows=clone(this.rows||[]);draft.sessions=clone(this.sessions||[]);
            draft.sessionDetails=clone(this.sessionDetails||{});draft.pautaPreferences=clone(this.pautaPreferences||{});
            draft.workCalendar=clone(this.workCalendar||{});draft.saveDeb=()=>{};draft.save=()=>{};
            const rows=P.sessionRows(draft,session)||[];
            const processes=rows.map(item=>{
              const row=clone(item.r||{}),entry=clone(item.e||{});
              row._pautaEntries=Array.isArray(row._pautaEntries)?row._pautaEntries.filter(value=>value?.session===session):[entry];
              return {process:String(row.Processo||''),row,entry,work:clone(item.w||row)};
            });
            const order=(draft.pautaPreferences?.jsonSessionLists?.[session]||[]).map(digits).filter(Boolean);
            const backup={format:'gabcmt-session-backup',version:1,exportedAt:new Date().toISOString(),session:{key:session,details:clone(draft.sessionDetails?.[session]||{})},orderedProcesses:order,processes};
            const blob=new Blob([JSON.stringify(backup,null,2)],{type:'application/json'});
            const url=URL.createObjectURL(blob),link=document.createElement('a');
            link.href=url;link.download='GabCMT_sessao_'+(digits(session)||'backup')+'.json';link.click();
            setTimeout(()=>URL.revokeObjectURL(url),3000);
            show('Backup exportado: '+processes.length+' processos e os marcos desta sessão.',false);
          }catch(error){show('Falha ao exportar: '+(error?.message||'erro inesperado'),true);}
        });
        panel.querySelector('[data-session-backup-import]')?.addEventListener('click',()=>file?.click());
        file?.addEventListener('change',async event=>{
          const selectedFile=event.target.files?.[0];if(!selectedFile)return;
          try{
            const backup=JSON.parse(await selectedFile.text());
            if(backup?.format!=='gabcmt-session-backup'||backup?.version!==1||!backup?.session?.key||!Array.isArray(backup.processes))throw new Error('Arquivo inválido. Selecione um backup de sessão do GabCMT.');
            const session=String(backup.session.key).trim(),replace=mode?.value==='replace';
            const incoming=backup.processes.map(item=>{
              const row=clone(item?.row||{}),key=digits(item?.process||row.Processo);
              const entry=clone(item?.entry||(row._pautaEntries||[]).find(value=>value?.session===session));
              if(key.length!==20||!entry)throw new Error('O backup contém processo ou vínculo de sessão inválido.');
              row.Processo=row.Processo||item.process;entry.session=session;
              row._pautaEntries=[entry];
              return {key,row,entry};
            });
            const order=[...new Set((Array.isArray(backup.orderedProcesses)?backup.orderedProcesses:incoming.map(item=>item.key)).map(digits).filter(key=>key.length===20))];
            const warning=replace?'Substituirá os dados dos processos e os marcos desta sessão. Outras sessões e seus vínculos serão preservados.':'Mesclará os processos desta sessão, preservando valores já existentes e sem remover itens atuais.';
            if(!window.confirm('Backup: '+session+'\\n'+incoming.length+' processo(s).\\n\\n'+warning+'\\n\\nContinuar?'))return;
            if(!Array.isArray(this.sessions))this.sessions=[];
            if(!this.sessions.includes(session))this.sessions.push(session);
            this.sessionDetails||={};
            this.pautaPreferences||={};this.pautaPreferences.jsonSessionLists||={};
            P.migrate?.(this);
            if(replace){
              this.rows.forEach(row=>{
                const entries=Array.isArray(row._pautaEntries)?row._pautaEntries:[];
                row._pautaEntries=entries.filter(value=>value?.session!==session);
                if(row['Sessão Destino']===session)row['Sessão Destino']='';
              });
              this.sessionDetails[session]=clone(backup.session.details||{});
            }else{
              const current=this.sessionDetails[session]||{};
              this.sessionDetails[session]={...clone(backup.session.details||{}),...current};
              Object.keys(this.sessionDetails[session]).forEach(key=>{
                if((current[key]===undefined||current[key]==='')&&backup.session.details?.[key]!==undefined)this.sessionDetails[session][key]=clone(backup.session.details[key]);
              });
            }
            incoming.forEach(item=>{
              let current=this.rows.find(row=>digits(row.Processo)===item.key);
              if(!current){this.rows.push(item.row);return;}
              const entries=Array.isArray(current._pautaEntries)?current._pautaEntries:[];
              const other=entries.filter(value=>value?.session!==session),old=entries.find(value=>value?.session===session);
              if(replace){
                Object.keys(current).forEach(key=>{if(key!=='_pautaEntries'&&!Object.prototype.hasOwnProperty.call(item.row,key))delete current[key];});
                Object.assign(current,clone(item.row),{_pautaEntries:[...other,clone(item.entry)]});
              }else{
                Object.entries(item.row).forEach(([key,value])=>{
                  if(key==='_pautaEntries'||value==null||value==='')return;
                  if(current[key]==null||current[key]==='')current[key]=clone(value);
                });
                current._pautaEntries=[...other,{...clone(item.entry),...(old||{})}];
              }
            });
            const prior=Array.isArray(this.pautaPreferences.jsonSessionLists[session])?this.pautaPreferences.jsonSessionLists[session].map(digits):[];
            this.pautaPreferences.jsonSessionLists[session]=replace?order:[...new Set([...prior,...order])];
            this.pautaPreferences.session=session;
            this.syncSessionPlans?.();this.saveDeb?.();
            this.notify?.('Backup da sessão '+session+' importado: '+incoming.length+' processo(s).','ok');
            this.renderSettings?.();
          }catch(error){show('Importação não aplicada: '+(error?.message||'erro inesperado'),true);}
          finally{file.value='';}
        });
      }
`;
  return code.replace(marker, marker + addition);
}

function prepareSessionHubBackup(code: string) {
  const renderAnchor = 'aria-label="Excluir sessão">${ICO.del}</button></div></div>\n      ${m.rascunho?';
  const clickAnchor = "if(action==='export'){try{exportHub(h);}catch(err){h.notify('Falha ao exportar sessões: '+err.message,'err');}return true;}";
  const changeAnchor = `if(el.matches?.('[data-hub-file="sessions"]')){const file=el.files?.[0];el.value='';if(file)void readImport(h,file);return true;}`;
  const readAnchor = `async function readImport(h,file){\n   try{if(file.size>40*1024*1024)throw new Error('O arquivo ultrapassa 40 MB.');const data=validateImport(JSON.parse(await file.text()));`;
  const hasRender = code.includes(renderAnchor), hasClick = code.includes(clickAnchor);
  const hasChange = code.includes(changeAnchor), hasRead = code.includes(readAnchor);
  if (!hasRender || !hasClick || !hasChange || !hasRead) {
    throw new Error(`Settings session hub backup contract missing: render=${hasRender}, click=${hasClick}, change=${hasChange}, read=${hasRead}.`);
  }
  code = code.replace(
    renderAnchor,
    'aria-label="Excluir sessão">${ICO.del}</button></div></div>\n       <div class="psh-session-backup" role="group" aria-label="Backup da sessão selecionada"><span class="psh-session-backup-label"><b>Backup desta sessão</b><small>Marcos e todos os processos vinculados</small></span><button type="button" class="psh-btn" data-hub="backup-export" data-hub-session="${esc(s)}">Exportar JSON</button><button type="button" class="psh-btn" data-hub="backup-import" data-hub-session="${esc(s)}">Importar JSON</button><input class="psh-file-import" type="file" data-hub-file="sessions" data-backup-session="true" accept=".json,application/json" aria-label="Importar backup de uma sessão" hidden></div>\n       ${m.rascunho?',
  );
  code = code.replace(
    clickAnchor,
    "if(action==='backup-export'){try{if(!window.CMTConfigIO?.exportSession)throw new Error('Exportação de sessão indisponível.');window.CMTConfigIO.exportSession(el.dataset.hubSession||current(h));}catch(err){h.notify('Falha ao exportar a sessão: '+err.message,'err');}return true;}\n   if(action==='backup-import'){el.closest('.psh-selected')?.querySelector('[data-backup-session]')?.click();return true;}\n   " + clickAnchor,
  );
  code = code.replace(
    readAnchor,
    "async function readImport(h,file,sessionOnly=false){\n    try{if(file.size>40*1024*1024)throw new Error('O arquivo ultrapassa 40 MB.');const data=validateImport(JSON.parse(await file.text()));if(sessionOnly&&(data.escopo!=='sessão'||data.sessions.length!==1))throw new Error('Selecione um backup JSON de uma única sessão do GabCMT.');",
  );
  code = code.replace(
    changeAnchor,
    `if(el.matches?.('[data-hub-file="sessions"]')){const file=el.files?.[0],sessionOnly=el.dataset.backupSession==='true';el.value='';if(file)void readImport(h,file,sessionOnly);return true;}`,
  );
  return code;
}

function settingsView(methods: string[]) {
  return localSelectors(`(function(document,window){
  'use strict';
  const P=window.PautaControl,T=window.PautaTeam,A=window.PautaAssuntos,CA=window.PautaCalendario;
  const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const br=v=>P.date(v)?P.date(v).split('-').reverse().join('/'):'Não informado';
  window.CMTAppDialogs.registerSettingsView({${methods.join(",\n")}});
})(window.CMTAppDialogs.settingsDocument,window.CMTAppDialogs.settingsWindow);`);
}

export function scopeProviderRenders(source: string) {
  // Native async handlers call their lexical render(h), not always h.renderShell().
  // Re-enter the owning view on EVERY paint, including after awaited imports or
  // after the dialog has closed. Keeping a global scope active across await would
  // incorrectly redirect unrelated background work.
  return source.replace(/function render\((h|host)\)\s*\{/g, (_, host) =>
    `function render(${host}){return window.CMTAppDialogs.forHost(${host},()=>cmtSettingsNativeRender(${host}));}
    function cmtSettingsNativeRender(${host}){`);
}

function prepareApplication(source: string) {
  const render = method(source, "renderConfig", "renderAssessoriaOrderDay");
  const assessoriaOrderDay = method(source, "renderAssessoriaOrderDay", "cfgSubtabs");
  const subtabs = method(source, "cfgSubtabs", "renderSessionsTab");
  const sessions = method(source, "renderSessionsTab", "renderImport");
  const sessionsCode = sessions.code;
  // The underlying page's dock/nav must not be reset by a settings render.
  const renderCode = render.code
    .replace("window.PautaGlobalDock?.owner?.syncDockScope();", "")
    .replace("this.syncMainNavCompact();", "")
    .replace("const mainNav=document.getElementById('pauta-main-nav');if(mainNav)mainNav.hidden=true;", "")
    .replace("if(!['calendario','team','materias'].includes(tab))tab='calendario';",
      "if(!['calendario','team','materias','solicitacoes'].includes(tab))tab='calendario';")
    .replace(
      "const tabs=[['calendario','Sessões e marcos',null],['team','Servidores',(this.team?.members||[]).length],['materias','Assuntos e Procedimentos',null]];",
      "const tabs=[['calendario','Sessões e marcos',null],['team','Servidores',(this.team?.members||[]).length],['materias','Assuntos e Procedimentos',null],['solicitacoes','Solicitações',null]];",
    )
    .replace(
      "else {content.innerHTML='';A.setView(this,cur);A.render(this);document.getElementById('ass-tabs')?.remove();}",
      "else if(tab==='solicitacoes'){content.innerHTML='';}else {content.innerHTML='';A.setView(this,cur);A.render(this);document.getElementById('ass-tabs')?.remove();}",
    );
  let result = source
    .replace(method(source, "openConfigDialog", "closeConfigDialog").expression,
      "\n    openConfigDialog(){return window.CMTAppDialogs.openSettings();}\n")
    .replace(method(source, "closeConfigDialog", "refresh").expression,
      "\n    closeConfigDialog(){return window.CMTAppDialogs.closeSettings();}\n")
    .replace(render.expression, "\n    renderConfig(){return window.CMTAppDialogs.renderSettings();}\n")
    .replace(assessoriaOrderDay.expression, "\n")
    .replace(subtabs.expression, "\n    cfgSubtabs(cur){return window.CMTAppDialogs.settingsSubtabs(cur);}\n")
    .replace(sessions.expression, "\n    renderSessionsTab(){return window.CMTAppDialogs.settingsSessions();}\n");
  // The real App keeps its identity and data. Only events originating in the
  // settings dialog receive its separate view host/state.
  result = result
    .replace("e=>this.click(e)", "e=>(window.CMTAppDialogs.hostForEvent(e)||this).click(e)")
    .replace("e=>this.change(e)", "e=>(window.CMTAppDialogs.hostForEvent(e)||this).change(e)")
    .replace("e=>this.input(e)", "e=>(window.CMTAppDialogs.hostForEvent(e)||this).input(e)")
    .replace(
      "e=>window.PautaSessionHub?.submit(this,e)?true:e.target.dataset.calForm?CA.submit(this,e):e.target.dataset.decForm?D.submit(this,e):e.target.dataset.matterForm?M.submit(this,e):T.submit(this,e)",
      "e=>window.CMTAppDialogs.withEventHost(e,this,h=>window.PautaSessionHub?.submit(h,e)?true:e.target.dataset.calForm?CA.submit(h,e):e.target.dataset.decForm?D.submit(h,e):e.target.dataset.matterForm?M.submit(h,e):T.submit(h,e))",
    );
  return { source: result, view: settingsView([renderCode, assessoriaOrderDay.code, subtabs.code, sessionsCode]) };
}

function prepareRouter(source: string) {
  return source
    .replace("var cfgAberta = function () { return !!(D.body && D.body.classList.contains('cfg-modal-open')); };",
      "var cfgAberta = function () { return window.CMTAppDialogs.settingsOpen(); };")
    .replace("if (window.CMTParadigmas && window.CMTParadigmas.aberto && window.CMTParadigmas.aberto()) return { page: 'ementario', arg: '' };", "")
    .replace("var antes = atual().page; if (igual(atual(), r, true))",
      `if(r.page==='configuracoes'){window.CMTAppDialogs.openSettings();if(r.arg)window.CMTCfgNav.ir(r.arg);return true;}
    var antes = atual().page; if (igual(atual(), r, true))`)
    .replace("if (!opt.semHistorico) escreve(r, true);",
      "if (!opt.semHistorico && r.page!=='configuracoes') escreve(r, true);")
    .replace(/^\s*var SLUG = \{ diretrizes: 'protocolo', repertorio: 'repositorio' \};\r?\n/m, "   var SLUG = {};\n")
    .replace(/^\s*ementario: \{ titulo: 'Ementário',[^\n]*\r?\n/m, "")
    .replace(/^\s*diretrizes: \{ titulo: 'Protocolo',[^\n]*\r?\n/m, "")
    .replace(/^\s*repertorio: \{ titulo: 'Repositório',[^\n]*\r?\n/m, "")
    .replace(/, 'diretrizes-e-fluxos': 'diretrizes', protocolo: 'diretrizes', conformidade: 'diretrizes', repositorio: 'repertorio'/, "")
    .replace(/, jurisprudencia: 'ementario', precedentes: 'ementario'/, "")
    .replace(/^\s*var refAberta = function \(nome\) \{[^\n]*\r?\n/m, "")
    .replace(/^\s*if \(refAberta\('diretrizes'\)\) return \{ page: 'diretrizes',[^\n]*\r?\n/m, "")
    .replace(/^\s*if \(refAberta\('repertorio'\)\) return \{ page: 'repertorio',[^\n]*\r?\n/m, "")
    .replace(/^\s*if \(refAberta\('diretrizes'\)[^\n]*\r?\n/gm, "")
    .replace(/^\s*if \(refAberta\('repertorio'\)[^\n]*\r?\n/gm, "")
    .replace(/^\s*if \(window\.CMTParadigmas && window\.CMTParadigmas\.aberto[^\n]*\r?\n/m, "")
    .replace(/^\s*\} else if \(r\.page === 'ementario'\) \{[\s\S]*?^\s*\}\r?\n(?=\s*pend =)/m, "\n      }\n")
    .replace(/: r\.page === 'ementario' \? '\/ementario'\s*: r\.page === 'diretrizes' \? '\/protocolo'\s*: r\.page === 'repertorio' \? '\/repositorio'\s*/g, "")
    .replace(/^\s*if \(window\.CMTParadigmas && window\.CMTParadigmas\.aberto[^\n]*\r?\n/gm, "")
    ;
}

function prepareEmentario(source: string) {
  // Standalone Ementário page/dialog retired; embedded Generator and CM views remain available.
  return "/* Ementário standalone retired; embedded views use /api/app/geradores-ementario.js. */";
}

function prepareUrgencyQueue(source: string) {
  const start = source.indexOf("  function renderUrgencyDialog(host = h) {");
  const end = source.indexOf("  function showUndo(label, action, fn) {", start);
  if (start < 0 || end <= start) throw new Error("Urgency dialog compatibility block is missing");

  let result = source.slice(0, start) + `  function openUrgencyQueue(trigger) {
    if (h?._exclusive) return false;
    document.getElementById('pauta-team-calendar')?.close?.();
    try { window.CMTRotas?.ir?.('decisoes'); } catch (_) {}
    const render = () => {
      const app = window.PautaControl || h;
      if (!app?.state) return false;
      app.state.tab = 'urgencias';
      app.renderShell?.();
      const root = document.getElementById('pauta-decisions-root');
      if (!root) return false;
      root.scrollIntoView({ block: 'start' });
      return true;
    };
    if (!render()) {
      let attempts = 0;
      const retry = () => { if (render() || ++attempts >= 30) return; setTimeout(retry, 100); };
      setTimeout(retry, 0);
    }
    trigger?.setAttribute?.('aria-expanded', 'false');
    return true;
  }
  window.PautaUrgenciasQueue = { open: openUrgencyQueue };
  document.addEventListener('click', event => {
    const target = event.target instanceof Element ? event.target : null;
    if (!target?.matches('[data-pending-overlay]')) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    document.getElementById('app-modal')?.replaceChildren();
    h?.renderShell?.();
  }, true);

` + source.slice(end);

  result = result
    .replace("  let urgencyDialogOpen = false;\n  let urgencyDialogTrigger = null;\n", "")
    .replace(
      /if\s*\(urgencyDialogOpen\)\s*\{\s*urgencyDialogOpen = false;\s*urgencyDialogTrigger\?\.setAttribute\('aria-expanded', 'false'\);\s*urgencyDialogTrigger = null;\s*\}/,
      "",
    )
    .replaceAll("window.PautaUrgenciasDialog", "window.PautaUrgenciasQueue")
    .replaceAll("data-open-urgency-dialog", "data-open-urgency-queue");

  if (/renderUrgencyDialog|openUrgencyDialog|closeUrgencyDialog|PautaUrgenciasDialog|urgencyDialogOpen|urgencyDialogTrigger/.test(result)) {
    throw new Error("Urgency dialog code remains in the prepared module");
  }
  return result;
}

export function prepareSinglePautaExpansion(source: string) {
  const toggle = "      expandedListItems.add(key);\n      paint();";
  const occurrences = source.split(toggle).length - 1;
  if (occurrences !== 1) {
    throw new Error("Compact Pauta process expansion handler was not found exactly once.");
  }
  return source.replace(
    toggle,
    "      expandedListItems.clear();\n      expandedListItems.add(key);\n      paint();",
  );
}

export function preparePautaQuickSearch(source: string) {
  const toolbarAnchor = `    const footer = document.querySelector('.gd-right');
    if (footer && !footer.querySelector('.pauta-quick-jump')) {
      const jump = document.createElement('div');
      jump.className = 'pauta-quick-jump';
      jump.setAttribute('role', 'search');
      jump.innerHTML = \`
        <button type="button" class="pauta-quick-mode" data-pauta-jump-mode aria-pressed="false" title="Alternar a busca entre o número do item e o número do processo">Item</button>
        <input id="pauta-quick-item" type="text" inputmode="numeric" autocomplete="off" placeholder="Nº" aria-label="Número do item da pauta">
        <button type="button" data-pauta-jump>Ir</button>
        <button type="button" class="pauta-quick-top" data-pauta-top title="Ir ao topo da página" aria-label="Ir ao topo da página"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5M6 11l6-6 6 6"/><path d="M5 3h14"/></svg></button>\`;
      footer.appendChild(jump);
      try { applyQuickMode(); } catch { /* aplicado no primeiro foco */ }
    }`;
  const clickHandler = "    if (target.closest('[data-pauta-jump]')) {\n      jumpToItem();\n      return;\n    }\n";
  const focusHandler = "  document.addEventListener('focusin', (event) => {\n    if (event.target instanceof HTMLInputElement && event.target.id === 'pauta-quick-item') refreshQuickItemOptions();\n  });";
  const modeReset = "    const input = document.getElementById('pauta-quick-item');\n    if (input) input.value = '';\n    applyQuickMode();";
  for (const [anchor, label] of [
    [toolbarAnchor, "quick-search toolbar"],
    [clickHandler, "quick-search click handler"],
    [focusHandler, "quick-search focus handler"],
    [modeReset, "quick-search mode reset"],
  ] as const) {
    if (source.split(anchor).length - 1 !== 1) {
      throw new Error(`Pauta quick-search contract missing or duplicated: ${label}.`);
    }
  }

  const toolbar = `    let jump = window.__pautaQuickJumpElement || document.querySelector('.pauta-quick-jump');
    if (!jump) {
      jump = document.createElement('div');
      jump.className = 'pauta-quick-jump';
      jump.setAttribute('role', 'search');
      jump.innerHTML = \`
        <button type="button" class="pauta-quick-mode" data-pauta-jump-mode aria-pressed="false" title="Alternar a busca entre o número do item e o número do processo">Item</button>
        <input id="pauta-quick-item" type="text" inputmode="numeric" autocomplete="off" placeholder="Nº" aria-label="Número do item da pauta">
        <button type="button" class="pauta-quick-top" data-pauta-top title="Ir ao topo da página" aria-label="Ir ao topo da página"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5M6 11l6-6 6 6"/><path d="M5 3h14"/></svg></button>\`;
    }
    window.__pautaQuickJumpElement = jump;
    jump.querySelector('[data-pauta-jump]')?.remove();
    const attachQuickJump = () => {
      const searchBar = app?.querySelector('.pc-filter-card .pq-search-main');
      if (!searchBar) return;
      if (jump.parentElement !== searchBar) searchBar.appendChild(jump);
      const jumpInput = jump.querySelector('#pauta-quick-item');
      const jumpState = window.__pautaQuickJumpState || (window.__pautaQuickJumpState = { value: '' });
      if (jumpInput && jumpInput !== document.activeElement && !jumpInput.value && jumpState.value) {
        jumpInput.value = jumpState.value;
      }
      try { applyQuickMode(); } catch { /* aplicado no primeiro foco */ }
    };
    attachQuickJump();
    if (app && window.__pautaQuickSearchObserverRoot !== app) {
      window.__pautaQuickSearchObserver?.disconnect?.();
      const quickSearchObserver = new MutationObserver((records) => {
        const searchBarAdded = records.some((record) => [...record.addedNodes].some((node) =>
          node.nodeType === 1 && (node.matches?.('.pq-search-main') || node.querySelector?.('.pq-search-main'))));
        if (searchBarAdded) queueMicrotask(attachQuickJump);
      });
      quickSearchObserver.observe(app, { childList: true, subtree: true });
      window.__pautaQuickSearchObserver = quickSearchObserver;
      window.__pautaQuickSearchObserverRoot = app;
    }
    if (!document.getElementById('cmt-pauta-search-layout-style')) {
      const layoutStyle = document.createElement('style');
      layoutStyle.id = 'cmt-pauta-search-layout-style';
      const scope = 'html body' + ':not(#quick-search-layout)'.repeat(18) + ' #controle-pauta-root .pc-filter-card';
      layoutStyle.textContent = \`
        \${scope}>.pc-heading.cmt-fbh{padding-left:12px!important;flex-wrap:wrap!important;gap:6px!important}
        \${scope}>.pc-heading.cmt-fbh>.cmt-fbp{margin-right:0!important;flex:1 1 320px!important;min-width:240px!important}
        \${scope}>.cmt-fb2{position:relative!important;inset:auto!important;height:auto!important;min-height:32px!important;grid-column:1/-1!important;grid-row:auto!important;width:100%!important;margin:0!important;padding:4px 12px!important;pointer-events:auto!important}
        \${scope}>.cmt-fb2>.fb-crit{max-width:none!important;overflow:visible!important;white-space:normal!important;flex-wrap:wrap!important}
        #controle-pauta-root .pc-filter-card .pq-filter-workspace{display:flex!important;flex-direction:column!important}
        #controle-pauta-root .pc-filter-card .pq-filter-workspace>.pq-search-main{order:0!important;flex-wrap:wrap!important}
        #controle-pauta-root .pc-filter-card .pq-filter-workspace>.pc-active-filters{order:1!important;margin:0!important;padding:2px 0!important}
        #controle-pauta-root .pc-filter-card .pq-filter-workspace>.pauta-quick-filter-area{order:2!important}
        #controle-pauta-root .pc-filter-card .pq-filter-workspace>.pc-facets,
        #controle-pauta-root .pc-filter-card .pq-filter-workspace>.pq-advanced-panel{order:3!important}
        #controle-pauta-root .pc-filter-card .pq-search-main>.pauta-quick-jump{margin-left:0!important;flex:0 0 auto!important;justify-content:flex-end;min-width:0;max-width:100%;padding:3px 4px 3px 7px;border:1px solid #d8e2ea;border-radius:10px;background:#f6f9fb;color:#50667a}
        #controle-pauta-root .pc-filter-card .pq-search-main>.pauta-quick-jump .pauta-quick-mode,
        #controle-pauta-root .pc-filter-card .pq-search-main>.pauta-quick-jump .pauta-quick-top{border:1px solid #d8e2ea!important;border-radius:7px!important;background:#fff!important;color:#50667a!important}
        #controle-pauta-root .pc-filter-card .pq-search-main>.pauta-quick-jump input{height:27px!important;border:1px solid #d8e2ea!important;border-radius:7px!important;background:#fff!important;color:#263f52!important}
        #controle-pauta-root .pc-filter-card .pq-search-main>.pauta-quick-jump input::placeholder{color:#8293a0!important}
        @media(max-width:900px){#controle-pauta-root .pc-filter-card .pq-search-main>.pauta-quick-jump{flex:0 1 auto!important}}
        @media(max-width:600px){#controle-pauta-root .pc-filter-card .pq-search-main>.pauta-quick-jump{flex:1 1 100%!important}}
      \`;
      document.head.appendChild(layoutStyle);
    }`;

  return source
    .replace(toolbarAnchor, toolbar)
    .replace(clickHandler, "")
    .replace(modeReset, "    const input = document.getElementById('pauta-quick-item');\n    if (input) { input.value = ''; const state = window.__pautaQuickJumpState; if (state) state.value = ''; }\n    applyQuickMode();")
    .replace(
      focusHandler,
      `${focusHandler}
  let quickJumpTimer = 0;
  document.addEventListener('input', (event) => {
    const input = event.target;
    if (!(input instanceof HTMLInputElement) || input.id !== 'pauta-quick-item') return;
    const value = input.value;
    const state = window.__pautaQuickJumpState || (window.__pautaQuickJumpState = { value: '' });
    state.value = value;
    window.clearTimeout(quickJumpTimer);
    const digits = value.replace(/\\D/g, '');
    if (!digits) return;
    const context = quickItemContext();
    if (!context?.session) return;
    if (quickMode() === 'processo') {
      if (digits.length < 4) return;
      const candidates = context.rows.filter((row) =>
        String(row.r?.Processo || '').replace(/\\D/g, '').includes(digits));
      const hasExact = candidates.some((row) =>
        String(row.r?.Processo || '').replace(/\\D/g, '') === digits);
      if (!hasExact && candidates.length !== 1) return;
    } else {
      const wanted = quickItemKey(digits);
      if (!wanted || !context.rows.some((row) => quickItemKey(quickItemOf(row)) === wanted)) return;
    }
    quickJumpTimer = window.setTimeout(() => {
      if (document.getElementById('pauta-quick-item') !== input || input.value !== value) return;
      jumpToItem();
    }, 260);
  }, true);`,
    );
}

export function prepareDialogDocument(html: string): string {
  if (!html.includes("class App") || html.includes('id="cmt-app-dialog-runtime"')) return html;
  let view = "";
  html = html.replace(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi, (whole, attributes: string, source: string) => {
    if (/\bsrc=/.test(attributes)) return whole;
    const id = attributes.match(/\bid=["']([^"']+)["']/)?.[1] ?? "";
    if (id === "ass-adv-feature") return "";
    if (/\btype=["']application\/json/i.test(attributes)) {
      if (id !== "cmt-mod-enhancements" && !/PautaUrgenciasDialog|data-open-urgency-dialog/.test(source)) return whole;
      const payload: unknown = JSON.parse(source);
      if (typeof payload !== "string") return whole;
      const prepared = id === "cmt-mod-enhancements"
        ? preparePautaQuickSearch(prepareSinglePautaExpansion(prepareUrgencyQueue(payload)))
        : payload;
      const routed = prepared
        .replaceAll("window.PautaUrgenciasDialog", "window.PautaUrgenciasQueue")
        .replaceAll("data-open-urgency-dialog", "data-open-urgency-queue");
      return `<script${attributes}>${JSON.stringify(routed).replace(/</g, "\\u003c")}</script>`;
    }
    let code = source;
    code = code
      .replaceAll("window.PautaUrgenciasDialog", "window.PautaUrgenciasQueue")
      .replaceAll("data-open-urgency-dialog", "data-open-urgency-queue");
    if (id === "cmt-v267-urgencias") {
      code = code.replace(
        "function todas(){var d=window.PautaUrgenciasQueue;if(d&&typeof d.open==='function'){d.open();return;}var b=D.querySelector('[data-open-urgency-queue]');if(b)b.click();}",
        "function todas(){if(window.PautaUrgenciasQueue?.open){window.PautaUrgenciasQueue.open();return;}var b=D.querySelector('[data-main-tab=\"urgencias\"]');if(b)b.click();else irDecisoes();}",
      );
    }
    if (id === "session-hub-script") code = prepareSessionHubBackup(code);
    if (code.includes("class App")) {
      const prepared = prepareApplication(code);
      code = prepared.source; view = prepared.view;
    }
    if (id === "cmt-v238-app-shell") code = prepareRouter(code);
    if (id === "cmt-v266-paradigmas") code = prepareEmentario(code);
    if (id === "cmt-v226-config-pagina-js") {
      code = code.replace("D.body.appendChild(r);", "D.querySelector('.app-main').appendChild(r);");
    }
    if (id === "cmt-v172-rodape-js") {
      // Remove the obsolete summary at its creator, not by hiding the footer.
      code = code.replace(/function strip\(\) \{[\s\S]*?(?=  function paint\(\))/,
        "function strip() { return null; }\n");
    }
    if (id === "cmt-v269-gerador") {
      // The positioned Mesa surface used to survive the generator's close.
      // Its display/layout rules could then reveal fragments in Monocráticas.
      code = code.replace("var g = raiz(); g.hidden = true; R.classList.remove('cmt-ger-on');",
        "var g = raiz(); g.hidden = true; g.classList.remove('pa-mesa-generator-surface'); R.classList.remove('cmt-ger-on','pa-mesa-generator-on');");
    }
    if (id === "cmt-center-panels-controls") {
      const focusLookup = `D.querySelector('#pauta-global-dock>.gd-foot[data-page-footer="pauta"] .pauta-quick-jump')`;
      if (!code.includes(focusLookup)) throw new Error("Pauta quick-search focus lookup contract missing.");
      code = code.replace(focusLookup, `D.querySelector('#controle-pauta-root .pauta-quick-jump')`);
    }
    if (id === "cmt-v40-feature") {
      code = code.replace(
        "if(go.closest('#ass-adv')&&window.CMTAssessoria){window.CMTAssessoria.goTo(Number(go.dataset.cmtGo),go.dataset.cmtSession||'');return;}",
        "",
      );
    }
    if (id === "cmt-v247-troca") {
      code = code.replace(
        ",#ass-adv .cmt2-top button:first-child,#ass-adv [data-adv=\"close\"],#ass-adv .cmt-adv-back",
        "",
      );
    }
    if (id === "cmt-padrao-feature" || id === "cmt-notif-ref-feature") {
      code = code.replace("try{if(window.CMTAssessoria?.isOpen?.())window.CMTAssessoria.close();}catch(_){}", "");
    }
    if (id === "cmt-v247-cfg-acompanhamento") {
      code = code.replace("Solicitações agora fica no painel esquerdo da Mesa da Assessoria (/ass).", "Solicitações fica nas Configurações Globais.");
    }
    if (id === "cmt-v247-solicitacoes") {
      code = code.replace(
        "window.CMTSolicitacoes={dockSlot:dockSlot,undockSlot:undockSlot,abrir:abrir,fechar:fechar,alterna:function(){st.aberto?fechar():abrir();},aberto:function(){return st.aberto;}};",
        "$&window.CMTAppDialogs?.syncSolicitations?.();",
      );
      code = code.replace("painel esquerdo da Mesa da Assessoria (/ass): o painel entra no espaço reservado (#ass-sol-slot) e acompanha cada redesenho da Mesa",
        "Painel de Solicitações acoplado ao diálogo de Configurações Globais");
    }
    if (id === "cmt-v247-comunicacao-canais") {
      source = source.replace("function aberta(){", "function aberta(){if(window.CMTAppDialogs?.settingsOpen?.())return true;");
      return `<script${attributes}>(function(document,window){${source}\n})(window.CMTAppDialogs.communicationDocument,window.CMTAppDialogs.applicationWindow);</script>`;
    }
    if (SETTINGS_SCRIPTS.has(id)) {
      code = `(function(document,window){${localSelectors(code)}\n})(window.CMTAppDialogs.settingsDocument,window.CMTAppDialogs.settingsWindow);`;
    } else if (code.includes("class App") || /window\.Pauta(?:Team|Assuntos|Calendario)\s*=/.test(code)) {
      code = `(function(document){${scopeProviderRenders(code)}\n})(window.CMTAppDialogs.applicationDocument);`;
    }
    return `<script${attributes}>${code}</script>` +
      (source.includes("class App") ? `<script id="cmt-settings-view-controller">${view}</script>` : "");
  });
  html = html.replaceAll("data-open-urgency-dialog", "data-open-urgency-queue");
  html = html.replace(/^\s*\{ id: '(?:ementario|diretrizes|repertorio)', label: '(?:Ementário|Protocolo|Repositório)'[^\n]*\},\r?\n/gm, "");
  html = html.replace(/^\s*\{ sec: 'APOIO' \},\r?\n/gm, "");
  html = html.replace(/<script\b(?=[^>]*\bid=["']cmt-ref-(?:mapa|paragrafos|vade|regimento|diretrizes|protocolo)-src["'])[^>]*>[\s\S]*?<\/script>/gi, "");
  html = html.replace(/<script\b(?=[^>]*\bid=["']cmt-referenciais["'])[^>]*>[\s\S]*?<\/script>/i, "");
  html = html.replace(/<button\b(?=[^>]*\bdata-open-urgency-queue\b)[^>]*>/gi, (button) =>
    button
      .replace(/\saria-haspopup=["'][^"']*["']/gi, "")
      .replace(/\saria-controls=["'][^"']*["']/gi, "")
      .replace(/\saria-expanded=["'][^"']*["']/gi, ""),
  );
  html = html.replace(/<style\b([^>]*)>([\s\S]*?)<\/style>/gi, (whole, attributes: string, css: string) => {
    const id = attributes.match(/\bid=["']([^"']+)["']/)?.[1] ?? "";
    if (ASSESSORIA_PAGE_STYLES.has(id) || id === "cmt-referenciais-css") return "";
    return SETTINGS_STYLES.test(id) ? `<style${attributes}>${scopeSettingsCss(css)}</style>` : whole;
  });
  html = html.replace(/<head(?=[\s>])[^>]*>/i, head => `${head}<script id="cmt-retired-sessions-route">if(['/session','/session/','/sessions','/sessions/'].includes(location.pathname))history.replaceState(history.state,'','/pauta'+location.search+location.hash);</script><script id="cmt-app-dialog-runtime" src="/api/app/dialogs/runtime.js"></script><link rel="stylesheet" href="/api/app/pauta-side-panel.css"><script src="/api/app/pauta-side-panel.js"></script><script id="cmt-geradores-ementario-runtime" src="/api/app/geradores-ementario.js"></script>`);
  // O documento contém "</body>" dentro de strings de scripts: só o último fecha a página de fato.
  const bodyEnd = html.lastIndexOf('</body>');
  const link = '<link rel="stylesheet" href="/api/app/dialogs/frame.css">';
  return bodyEnd < 0 ? html + link : html.slice(0, bodyEnd) + link + html.slice(bodyEnd);
}

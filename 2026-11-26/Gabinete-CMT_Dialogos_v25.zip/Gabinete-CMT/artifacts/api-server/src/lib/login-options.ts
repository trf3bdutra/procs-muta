export const normalizeLoginServer = (value: unknown) =>
  String(value ?? "").trim().replace(/\s+/g, " ").toLocaleUpperCase("pt-BR");

export function loginServersFromLinkedAccounts(
  linked: Array<{
    server: string | null;
    role: string;
    status: string;
    passwordSecretKey: string;
  }>,
) {
  const servers = new Map<string, string>();
  for (const account of linked) {
    const server = normalizeLoginServer(account.server);
    const expectedSecretKey = account.role === "equipe" || (server === "BRUNO" && account.role === "editor")
      ? "TEAM_LOGIN_PASSWORD"
      : null;
    const legacyBrunoDedicatedCredential = server === "BRUNO" &&
      (account.role === "equipe" || account.role === "editor") &&
      account.passwordSecretKey === "BDUTRA_LOGIN_PASSWORD";
    const eligible = !!expectedSecretKey &&
      (expectedSecretKey === account.passwordSecretKey || legacyBrunoDedicatedCredential);
    if (!server || !eligible || account.status !== "active") continue;
    if (!servers.has(server)) servers.set(server, server);
  }
  return [...servers.values()].sort((a, b) => a.localeCompare(b, "pt-BR"));
}

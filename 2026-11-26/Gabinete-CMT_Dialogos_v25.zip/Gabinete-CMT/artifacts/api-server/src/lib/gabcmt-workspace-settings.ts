import { twilioBrowserScript } from "./gabcmt-twilio-browser";

/** Delivery-boundary fixes; do not rewrite the user's editable GabCMT file. */
export function prepareWorkspaceSettings(html: string): string {
  if (!html.includes("cmt-cfgr-caixa") || html.includes('id="cmt-workspace-settings"')) return html;
  if (html.includes('data-cr-seg="canais"')) {
    // Newer GabCMT already has the channel-number form: extend it, do not duplicate it.
    html = html.replace(
      '<div id="cmt-cfgr-canais"></div></div></div>\'',
      '<div id="cmt-cfgr-canais"></div></div><div class="cr-c" id="cmt-cfgr-twilio"></div></div>\'',
    ).replace(
      "} else if (st.seg === 'canais') {\n      canais();",
      "} else if (st.seg === 'canais') {\n      canais(); if (window.CMTTwilio) window.CMTTwilio.mount(r.querySelector('#cmt-cfgr-twilio'));",
    ).replace(/'<div class="cr-rgp" data-cr-rgp="notif"[^'\n]*<\/section>'/, "'</section>'");
  } else {
  html = html.replace(
    '<button type="button" data-cr-seg="avisos">Avisos do painel</button></div>',
    '<button type="button" data-cr-seg="avisos">Avisos do painel</button><button type="button" data-cr-seg="twilio">SMS · WhatsApp</button><button type="button" data-cr-seg="notif">Regras de notificação</button></div>',
  );
  const panes = "'<div data-cr-sp=\"twilio\" hidden><div class=\"cr-c\" id=\"cmt-cfgr-twilio\"></div></div><div data-cr-sp=\"notif\" hidden><div class=\"cr-c\" id=\"cmt-cfgr-notif\"></div></div>' +";
  html = html.replace(
    "'<div data-cr-sp=\"avisos\" hidden><div class=\"cr-c\"><div id=\"cmt-cfgr-avisos\"></div></div></div>' +",
    "'<div data-cr-sp=\"avisos\" hidden><div class=\"cr-c\"><div id=\"cmt-cfgr-avisos\"></div></div></div>' +\n          " + panes,
  ).replace(
    "['etq', 'Etiquetas'], ['notif', 'Notificação']",
    "['etq', 'Etiquetas']",
  ).replace(
    "'<div class=\"cr-rgp\" data-cr-rgp=\"notif\" hidden><div class=\"cr-c\" id=\"cmt-cfgr-notif\"></div></div></section>'",
    "'</section>'",
  ).replace(
    "if (sv.seg === 'avisos') st.seg = 'avisos';",
    "if (['avisos','twilio','notif'].indexOf(sv.seg) >= 0) st.seg = sv.seg;",
  ).replace(
    "if (/^(prod|etq|notif)$/.test(sv.rg || '')) st.rg = sv.rg;",
    "if (/^(prod|etq)$/.test(sv.rg || '')) st.rg = sv.rg; if (sv.rg === 'notif') { st.tab = 'com'; st.seg = 'notif'; }",
  ).replace(
    "} else {\n      var av = r.querySelector('#cmt-cfgr-avisos');",
    "} else if (st.seg === 'notif') {\n      var np = r.querySelector('#cmt-cfgr-notif'); if (np && !np.contains(D.activeElement)) setH(np, window.CMTCfg2Painel.html('notif'));\n    } else if (st.seg === 'twilio') {\n      if (window.CMTTwilio) window.CMTTwilio.mount(r.querySelector('#cmt-cfgr-twilio'));\n    } else {\n      var av = r.querySelector('#cmt-cfgr-avisos');",
  ).replace(
    "Produtividade, etiquetas, correção e notificação: valem para todo o gabinete",
    "Produtividade, etiquetas e correção: valem para todo o gabinete",
  ).replace(
    "else put('cmt-cfgr-notif', function () { return P2.html('notif'); });",
    "else { st.tab = 'com'; st.seg = 'notif'; guarda(); pinta(); }",
  );
  }
  if (html.includes('id="cmt-workspace-settings"')) return html;
  const end = html.toLowerCase().lastIndexOf("</body>");
  const injection = '<style id="cmt-workspace-settings">#cfg-subtabs{display:none!important}body:not(.cfg-modal-open) #cfg2-painel{display:none!important}#cmt-cfgr .cr-seg{flex-wrap:wrap}#cmt-cfgr-twilio form{display:grid;gap:8px}#cmt-cfgr-twilio input,#cmt-cfgr-twilio textarea,#cmt-cfgr-twilio select{width:100%;box-sizing:border-box}#cmt-cfgr-twilio article{padding:10px 0;border-top:1px solid #d8e2e6}#cmt-cfgr-twilio p{white-space:pre-wrap;overflow-wrap:anywhere}#cmt-cfgr-twilio [hidden]{display:none!important}</style><script>' + twilioBrowserScript + '</script>';
  return end < 0 ? html : html.slice(0, end) + injection + html.slice(end);
}

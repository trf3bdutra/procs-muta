import { createHash } from "node:crypto";

/*
 * Os dados embutidos saem do documento que o navegador recebe e passam a ser
 * servidos à parte, com etag e cache imutável. O gabcmt.html continua sendo a
 * fonte oficial: os blocos são extraídos dele a cada versão do arquivo.
 *
 * Dois modos, conforme a leitura de cada bloco no app:
 *
 * - "fonte": o bloco é lido por getElementById(...).textContent em algum ponto
 *   posterior do documento. O bloco é trocado por um script externo clássico,
 *   que bloqueia a análise do documento e recria o nó no mesmo lugar antes de
 *   qualquer código seguinte rodar. A ordem de execução não muda.
 *
 * - "blob": base64 de um gzip lido dentro de função assíncrona. Aqui o bloco
 *   sai inteiro do documento e o app busca os bytes do gzip pela rede, sem o
 *   acréscimo de um terço que o base64 impõe.
 */
type DataBlock = {
  id: string;
  mode: "fonte" | "blob";
};

export type GabcmtDataAsset = {
  content: string | Buffer;
  contentType: "application/javascript" | "application/octet-stream";
  etag: string;
};

export type GabcmtDataDocument = {
  html: string;
  assets: Record<string, GabcmtDataAsset>;
};

export const GABCMT_DATA_BLOCKS: readonly DataBlock[] = [
  { id: "pauta-resources", mode: "fonte" },
  { id: "cmt-mod-enhancements", mode: "fonte" },
  { id: "pauta-initial", mode: "fonte" },
  { id: "cmt-padrao-muta", mode: "fonte" },
  { id: "cmt-manual-diretrizes", mode: "fonte" },
  { id: "cmtx-login-src", mode: "fonte" },
  { id: "cmt-mod-decision-import", mode: "fonte" },
  { id: "cmt-mod-pending-migration", mode: "fonte" },
  { id: "cmt-v251-acervo-src", mode: "blob" },
  { id: "cmt-v268-central-src", mode: "blob" },
];

function replaceEmbeddedSourceOnce(source: string, before: string, after: string, label: string) {
  const first = source.indexOf(before);
  if (first < 0 || source.indexOf(before, first + before.length) >= 0) {
    throw new Error(`Não foi possível aplicar a correção de Pendências (${label}).`);
  }
  return `${source.slice(0, first)}${after}${source.slice(first + before.length)}`;
}

function replaceEmbeddedSourceIfMissing(source: string, before: string, after: string, label: string) {
  if (source.includes(after)) return source;
  return replaceEmbeddedSourceOnce(source, before, after, label);
}

function patchPendingSource(id: string, payload: string) {
  if (!["cmt-mod-enhancements", "cmt-mod-pending-migration"].includes(id)) return payload;
  let parsed: unknown;
  try {
    parsed = JSON.parse(payload);
  } catch {
    throw new Error(`O módulo legado ${id} não contém uma string JSON válida.`);
  }
  if (typeof parsed !== "string") throw new Error(`O módulo legado ${id} precisa ser uma string.`);
  let source = parsed;

  if (id === "cmt-mod-pending-migration") {
    source = replaceEmbeddedSourceIfMissing(
      source,
      "        process: text(issue.process || issue.processNumber || issue.processo, 120),\n        item: text(issue.item || issue.processItem, 80),",
      "        process: text(issue.process || issue.processNumber || issue.processo, 120),\n        session: text(issue.session || issue.sessionId || '', 40),\n        item: text(issue.item || issue.processItem, 80),",
      "preservar sessão ao carregar",
    );
    return JSON.stringify(source);
  }

  const rootSelector = "  const rootEl = () => document.querySelector('#cmt-footer-pending:not([hidden]) [data-pnd-root],#pauta-global-dock #cmt-center-panels[data-active=\"pend\"] [data-pending-panel] [data-pnd-root],#app-modal [data-pnd-root]');";
  const footerRootSelector = "  const rootEl = () => document.querySelector('#cmt-footer-pending:not([hidden]) [data-pnd-root]');";
  const modalRootSelector = "  const rootEl = () => document.querySelector('#app-modal [data-pnd-root]');";
  if (!source.includes(rootSelector)) {
    source = source.includes(footerRootSelector)
      ? replaceEmbeddedSourceOnce(source, footerRootSelector, rootSelector, "usar o quadro montado no rodapé")
      : replaceEmbeddedSourceOnce(source, modalRootSelector, rootSelector, "usar o quadro montado no rodapé");
  }

  const replacements: Array<[string, string, string]> = [
    [
      "  function drawerHTML(issue) {",
      `  function sessionKey(value) {
    return typeof value === 'string' ? value : String(value && (value.s || value.id || value.session || value.date) || '');
  }
  function sessionLabel(value) {
    const raw = String(value || '');
    const match = raw.match(/^(\\d{4})-(\\d{2})-(\\d{2})/);
    return match ? \`\${match[3]}/\${match[2]}/\${match[1]}\` : raw;
  }
  function sessionForProcess(value) {
    const digits = String(value || '').replace(/\\D/g, '');
    if (digits.length !== 20) return '';
    const sessions = [...new Set((h.sessions || []).map(sessionKey).filter(Boolean))];
    const preferred = [window.CMTSessoes?.currentSession?.(), window.PautaControl?.page?.session, h.pautaPreferences?.session]
      .map(sessionKey).filter((session) => sessions.includes(session));
    const ordered = [...new Set([...preferred, ...sessions])];
    for (const session of ordered) {
      let rows = [];
      try { rows = window.PautaControl?.sessionRows?.(h, session) || []; } catch (_) {}
      if (rows.some((item) => String(item?.w?.Processo || item?.r?.Processo || item?.Processo || item?.process || '').replace(/\\D/g, '') === digits)) {
        return session;
      }
    }
    return '';
  }
  function sessionTag(value) {
    return value ? \`<span class="pnb-chip pnb-session" title="Associada à sessão">\${esc(sessionLabel(value))}</span>\` : '';
  }
  function drawerHTML(issue) {`,
      "associação automática de processo à sessão",
    ],
    [
      "    const age = ageOf(issue);\n    const chosen = Object.keys(issue.assignees || {}).filter((id) => issue.assignees[id]);",
      "    const age = ageOf(issue);\n    const sessionKeys = [...new Set([...(h.sessions || []).map(sessionKey), sessionKey(issue.session)].filter(Boolean))];\n    const selectedSession = String(issue.session || sessionForProcess(issue.process) || '');\n    const sessionOptions = sessionKeys.map((session) => `<option value=\"${esc(session)}\" ${session === selectedSession ? 'selected' : ''}>${esc(sessionLabel(session))}</option>`).join('');\n    const chosen = Object.keys(issue.assignees || {}).filter((id) => issue.assignees[id]);",
      "montar opções da sessão no editor",
    ],
    [
      "\${tag}\${flag}<span class=\"sp\"></span>",
      "\${tag}\${sessionTag(issue.session)}\${flag}<span class=\"sp\"></span>",
      "mostrar sessão no cartão",
    ],
    [
      "          <label><span class=\"pnb-lbl\">\${stage === 'waiting' ? 'Aguardando até' : 'Prazo'}</span><input type=\"date\" name=\"dueDate\" value=\"\${esc(issue.dueDate || '')}\"></label>\n        </div>\n        \${stage === 'waiting' ?",
      "          <label><span class=\"pnb-lbl\">\${stage === 'waiting' ? 'Aguardando até' : 'Prazo'}</span><input type=\"date\" name=\"dueDate\" value=\"\${esc(issue.dueDate || '')}\"></label>\n        </div>\n        <label><span class=\"pnb-lbl\">Sessão associada</span><select name=\"session\" aria-label=\"Sessão associada\"><option value=\"\">Sem sessão</option>\${sessionOptions}</select></label>\n        \${stage === 'waiting' ?",
      "campo de sessão no editor",
    ],
    [
      "const dueDate = /^\\d{4}-\\d{2}-\\d{2}$/.test(String(data.get('dueDate') || '')) ? String(data.get('dueDate')) : '';\n    const waitingFor",
      "const dueDate = /^\\d{4}-\\d{2}-\\d{2}$/.test(String(data.get('dueDate') || '')) ? String(data.get('dueDate')) : '';\n    const session = text(data.get('session'), 40) || sessionForProcess(digits);\n    const waitingFor",
      "salvar sessão da pendência",
    ],
    [
      "    if ((issue.dueDate || '') !== dueDate) changes.push('prazo');\n    if ((issue.waitingFor || '') !== waitingFor)",
      "    if ((issue.dueDate || '') !== dueDate) changes.push('prazo');\n    if ((issue.session || '') !== session) changes.push('sessão');\n    if ((issue.waitingFor || '') !== waitingFor)",
      "registrar alteração de sessão",
    ],
    [
      "Object.assign(issue, { title, description, process: digits, dueDate, waitingFor });",
      "Object.assign(issue, { title, description, process: digits, session, dueDate, waitingFor });",
      "persistir sessão da pendência",
    ],
    [
      "      if (!migration.matchesBoardFilter(issue, board.filter, {",
      "      if (board.filter === 'session' && !issue.session) return false;\n      if (!migration.matchesBoardFilter(issue, board.filter, {",
      "filtrar pendências por sessão",
    ],
    [
      "return migration.matchesIssueSearch(issue, board.q, recipientMembers(issue).map((member) => member.name));",
      "return migration.matchesIssueSearch(issue, board.q, [...recipientMembers(issue).map((member) => member.name), sessionLabel(issue.session)]);",
      "buscar pela sessão",
    ],
    [
      "const pills = [['all', 'Todas'], ['mine', 'Minhas', mineCount], ['assess', 'Assessoria'], ['proc', 'Com processo'], ['late', 'Atrasadas', late]];",
      "const pills = [['all', 'Todas'], ['mine', 'Minhas', mineCount], ['assess', 'Assessoria'], ['proc', 'Com processo'], ['session', 'Com sessão', getIssues().filter((issue) => !!issue.session).length], ['late', 'Atrasadas', late]];",
      "recorte de pendências com sessão",
    ],
    [
      "case 'new': stop(); board.view = 'board'; selectedId = ''; paint(); root()?.querySelector('[data-pnd-quick] input')?.focus(); break;",
      "case 'new': { stop(); board.view = 'board'; board.filter = 'all'; board.q = ''; board.menu = ''; board.confirm = ''; selectedId = ''; paint(); const quick = root()?.querySelector('[data-pnd-quick] input'); quick?.scrollIntoView({ block: 'nearest' }); quick?.focus(); break; }",
      "abrir e focar Nova pendência",
    ],
    [
      "status: 'open', stage: 'new', process: proc, dueDate: '', waitingFor: '',",
      "status: 'open', stage: 'new', process: proc, session: sessionForProcess(proc), dueDate: '', waitingFor: '',",
      "associar dúvidas à sessão do processo",
    ],
  ];

  for (const [before, after, label] of replacements) {
    source = replaceEmbeddedSourceIfMissing(source, before, after, label);
  }
  if (!source.includes("cmt-pending-layout-fix")) source += `
;(() => {
  if (document.getElementById('cmt-pending-layout-fix')) return;
  const style = document.createElement('style');
  style.id = 'cmt-pending-layout-fix';
  style.textContent = \`
    #app-modal#app-modal .pndb,
    #pauta-global-dock#pauta-global-dock #cmt-center-panels#cmt-center-panels [data-pending-panel] .pndb,
    #cmt-footer-pending#cmt-footer-pending [data-pending-panel] .pndb{
      position:relative!important;display:flex!important;flex:1 1 auto!important;flex-direction:column!important;
      width:100%!important;height:100%!important;min-width:0!important;min-height:0!important;overflow:hidden!important;box-sizing:border-box!important
    }
    #app-modal#app-modal [data-pending-panel],
    #pauta-global-dock#pauta-global-dock #cmt-center-panels#cmt-center-panels [data-pending-panel],
    #cmt-footer-pending#cmt-footer-pending [data-pending-panel]{
      position:relative!important;display:flex!important;flex:1 1 auto!important;flex-direction:column!important;
      width:100%!important;height:100%!important;min-width:0!important;min-height:0!important;overflow:hidden!important;box-sizing:border-box!important
    }
    #app-modal#app-modal .pndb .pnb-scrim,
    #pauta-global-dock#pauta-global-dock #cmt-center-panels#cmt-center-panels [data-pending-panel] .pnb-scrim,
    #cmt-footer-pending#cmt-footer-pending [data-pending-panel] .pnb-scrim{position:absolute!important;inset:0!important;z-index:99!important}
    #app-modal#app-modal .pndb .pnb-drawer,
    #pauta-global-dock#pauta-global-dock #cmt-center-panels#cmt-center-panels[data-active="pend"] [data-pending-panel] .pnb-drawer,
    #cmt-footer-pending#cmt-footer-pending [data-pending-panel] .pnb-drawer{
      position:absolute!important;top:8px!important;right:8px!important;bottom:8px!important;left:auto!important;
      width:min(560px,calc(100% - 16px))!important;max-width:calc(100% - 16px)!important;height:auto!important;min-height:0!important;
      display:flex!important;flex-direction:column!important;overflow:hidden!important;box-sizing:border-box!important;z-index:100!important;border-radius:10px!important;
      animation:none!important;transform:none!important
    }
    #app-modal#app-modal .pndb :is(.pnb-dh,.pnb-df),
    #pauta-global-dock#pauta-global-dock #cmt-center-panels#cmt-center-panels [data-pending-panel] .pndb :is(.pnb-dh,.pnb-df),
    #cmt-footer-pending#cmt-footer-pending [data-pending-panel] .pndb :is(.pnb-dh,.pnb-df){flex:0 0 auto!important;min-width:0!important;box-sizing:border-box!important}
    #app-modal#app-modal .pndb .pnb-db,
    #pauta-global-dock#pauta-global-dock #cmt-center-panels#cmt-center-panels [data-pending-panel] .pndb .pnb-db,
    #cmt-footer-pending#cmt-footer-pending [data-pending-panel] .pndb .pnb-db{
      flex:1 1 auto!important;min-width:0!important;min-height:0!important;overflow:auto!important;display:grid!important;align-content:start!important;gap:12px!important;box-sizing:border-box!important
    }
    #app-modal#app-modal .pndb .pnb-grid2,
    #pauta-global-dock#pauta-global-dock #cmt-center-panels#cmt-center-panels [data-pending-panel] .pndb .pnb-grid2,
    #cmt-footer-pending#cmt-footer-pending [data-pending-panel] .pndb .pnb-grid2{display:grid!important;grid-template-columns:minmax(0,1fr) minmax(0,1fr)!important;gap:10px!important}
    #app-modal#app-modal .pndb .pnb-db :is(label,input,select,textarea),
    #pauta-global-dock#pauta-global-dock #cmt-center-panels#cmt-center-panels [data-pending-panel] .pndb .pnb-db :is(label,input,select,textarea),
    #cmt-footer-pending#cmt-footer-pending [data-pending-panel] .pndb .pnb-db :is(label,input,select,textarea){min-width:0!important;max-width:100%!important;box-sizing:border-box!important}
    #app-modal#app-modal .pndb .pnb-df{display:grid!important;grid-template-columns:minmax(0,1.2fr) minmax(150px,.8fr)!important;gap:9px!important;align-items:end!important}
    #app-modal#app-modal .pndb .pnb-df .row{grid-column:1/-1!important;display:flex!important;flex-wrap:wrap!important;align-items:center!important;gap:6px!important}
    @media(max-width:760px){
      #app-modal#app-modal .pndb .pnb-drawer,
      #pauta-global-dock#pauta-global-dock #cmt-center-panels#cmt-center-panels [data-pending-panel] .pnb-drawer,
      #cmt-footer-pending#cmt-footer-pending [data-pending-panel] .pnb-drawer{left:8px!important;width:calc(100% - 16px)!important;max-width:calc(100% - 16px)!important}
      #app-modal#app-modal .pndb .pnb-grid2,
      #pauta-global-dock#pauta-global-dock #cmt-center-panels#cmt-center-panels [data-pending-panel] .pndb .pnb-grid2,
      #cmt-footer-pending#cmt-footer-pending [data-pending-panel] .pndb .pnb-grid2{grid-template-columns:minmax(0,1fr)!important}
      #app-modal#app-modal .pndb .pnb-stages{grid-template-columns:repeat(2,minmax(0,1fr))!important}
      #app-modal#app-modal .pndb .pnb-df{grid-template-columns:minmax(0,1fr)!important}
    }
  \`;
  (document.head || document.documentElement).appendChild(style);
})();`;
  return JSON.stringify(source);
}

export function gabcmtDataAssetKey(block: DataBlock) {
  return block.mode === "blob" ? `${block.id}.gz` : `${block.id}.js`;
}

type ScriptElement = { attributes: string; payload: string; start: number; end: number };

/*
 * A varredura percorre os elementos <script> em sequência, como o analisador do
 * navegador faz: o conteúdo de um script é consumido junto com ele, de modo que
 * um trecho de código que cite "<script id=…>" dentro de um texto não é
 * confundido com o bloco de dados de mesmo nome.
 */
function scanScripts(html: string): Map<string, ScriptElement> {
  const expression = /<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi;
  const found = new Map<string, ScriptElement>();
  let match: RegExpExecArray | null;
  while ((match = expression.exec(html))) {
    const attributes = match[1] || "";
    const id = (attributes.match(/\sid\s*=\s*["']([^"']+)["']/) || [])[1];
    if (!id || found.has(id)) continue;
    found.set(id, {
      attributes,
      payload: match[2] || "",
      start: match.index,
      end: match.index + match[0].length,
    });
  }
  return found;
}

function extractBlock(scripts: Map<string, ScriptElement>, block: DataBlock) {
  const element = scripts.get(block.id);
  if (!element) return null;

  const { attributes } = element;
  const payload = patchPendingSource(block.id, element.payload || "");
  const type = (attributes.match(/\btype\s*=\s*["']([^"']+)["']/) || [])[1] || "application/json";
  const key = gabcmtDataAssetKey(block);

  if (block.mode === "blob") {
    const content = Buffer.from(payload.trim(), "base64");
    return {
      key,
      asset: {
        content,
        contentType: "application/octet-stream" as const,
        etag: createHash("sha256").update(content).digest("hex"),
      },
      /* o app busca estes bytes pela rede; nada resta no documento */
      replacement: "",
      start: element.start,
      end: element.end,
    };
  }

  const content = [
    `/* ${block.id}: recria o bloco de dados no mesmo ponto do documento */`,
    "(function(){",
    "var d=document,c=d.currentScript;if(!c||!c.parentNode)return;",
    "var s=d.createElement('script');",
    `s.type=${JSON.stringify(type)};s.id=${JSON.stringify(block.id)};`,
    `s.textContent=${JSON.stringify(payload)};`,
    "c.parentNode.insertBefore(s,c);",
    "})();",
  ].join("\n");

  return {
    key,
    asset: {
      content,
      contentType: "application/javascript" as const,
      etag: createHash("sha256").update(content).digest("hex"),
    },
    replacement: "",
    start: element.start,
    end: element.end,
    source: { key, id: block.id },
  };
}

export function prepareGabcmtDataDocument(html: string): GabcmtDataDocument {
  const scripts = scanScripts(html);
  const matches = GABCMT_DATA_BLOCKS.flatMap((block) => {
    const found = extractBlock(scripts, block);
    return found ? [found] : [];
  }).sort((a, b) => a.start - b.start);

  const assets: Record<string, GabcmtDataAsset> = {};
  const output: string[] = [];
  let cursor = 0;

  for (const found of matches) {
    if (found.start < cursor) throw new Error("Os blocos de dados do GabCMT se sobrepõem.");
    assets[found.key] = found.asset;
    const replacement = found.source
      ? `<script id="${found.source.id}-fonte" src="/api/app/gabcmt-dados/${found.source.key}?v=${found.asset.etag}"></script>`
      : found.replacement;
    output.push(html.slice(cursor, found.start), replacement);
    cursor = found.end;
  }
  output.push(html.slice(cursor));

  return { html: output.join(""), assets };
}

export function isGabcmtDataAsset(value: string) {
  return GABCMT_DATA_BLOCKS.some((block) => value === gabcmtDataAssetKey(block));
}

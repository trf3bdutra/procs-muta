import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";

const lifetimeMs = 20 * 60 * 1000;
export function createUrgencyImageToken(now = Date.now(), secret = process.env.SESSION_SECRET || "") {
  if (!secret) throw new Error("A proteção temporária da imagem não está configurada.");
  const expires = now + lifetimeMs;
  const nonce = randomBytes(24).toString("base64url");
  const value = `${expires}.${nonce}`;
  const signature = createHmac("sha256", secret).update(`urgency-image:${value}`).digest("base64url");
  return `${value}.${signature}`;
}

export function isUrgencyImageTokenValid(token: string, now = Date.now(), secret = process.env.SESSION_SECRET || "") {
  if (!secret || token.length > 180) return false;
  const match = token.match(/^(\d{13})\.([A-Za-z0-9_-]{32})\.([A-Za-z0-9_-]{43})$/);
  if (!match) return false;
  const expires = Number(match[1]);
  if (!Number.isSafeInteger(expires) || expires < now || expires > now + lifetimeMs) return false;
  const expected = createHmac("sha256", secret).update(`urgency-image:${match[1]}.${match[2]}`).digest();
  let supplied: Buffer;
  try { supplied = Buffer.from(match[3], "base64url"); } catch { return false; }
  return supplied.length === expected.length && timingSafeEqual(supplied, expected);
}

export type CarlosMutaMessage = {
  id: string;
  subject: string;
  text: string;
  preview: string;
  receivedAt: string;
};

type LinkPolicyMessage = CarlosMutaMessage & {
  source?: unknown;
  status?: unknown;
  outcome?: unknown;
};

type SessionEntry = Record<string, unknown> & {
  session?: unknown;
  item?: unknown;
  closed?: unknown;
};

export type CarlosMutaLinkResult =
  | { kind: "ignore" }
  | { kind: "review"; processNumber: string; reason: string }
  | {
      kind: "linked";
      row: Record<string, unknown>;
      processNumber: string;
      formattedProcessNumber: string;
      session: string;
      item: string;
    };

const normalize = (value: unknown): string =>
  String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("pt-BR")
    .replace(/[ \t]+/g, " ")
    .trim();

const digits = (value: unknown): string => String(value ?? "").replace(/\D/g, "");

const CNJ_PATTERN =
  /\b\d{7}\s*-?\s*\d{2}\s*\.?\s*\d{4}\s*\.?\s*\d\s*\.?\s*\d{2}\s*\.?\s*\d{4}\b/g;

function extractProcessNumbers(text: string): string[] {
  return [
    ...new Set(
      [...text.matchAll(CNJ_PATTERN)]
        .map((match) => digits(match[0]))
        .filter((processNumber) => processNumber.length === 20),
    ),
  ];
}

function extractSessionDate(text: string): string {
  const normalized = normalize(text);
  const match =
    /(?:sessao(?:\s+de\s+julgamento)?|data\s+da\s+sessao)[^\d]{0,35}(\d{2}\/\d{2}\/\d{4})/i.exec(
      normalized,
    );
  return match?.[1] ?? "";
}

function rowSessions(row: Record<string, unknown>): string[] {
  const entries = Array.isArray(row._pautaEntries)
    ? (row._pautaEntries as SessionEntry[])
    : [];
  const sessions = entries
    .map((entry) => String(entry?.session ?? "").trim())
    .filter(Boolean);
  const destination = String(row["Sessão Destino"] ?? "").trim();
  if (destination) sessions.push(destination);
  return [...new Set(sessions)];
}

/* Indicação de gabinete: "Gab. A", "Gabinete A", "GAB-A", "Gabinete 'A'", seguida de fim de frase, parêntese,
   barra ou "da Turma"/"do Des." (evita "gabinete a ser..."). */
const GAB = String.raw`\bgab(?:inete)?\.?\s*[-–]?\s*["'“‘]?\s*`;
const GAB_FIM = String.raw`["'”’]?(?=\s*(?:$|[\n,.;:)/\-–]|\(|da\s+turma|do\s+des|e\s+))`;
const GAB_A = new RegExp(`${GAB}a${GAB_FIM}`, "im");
/* para excluir basta "Gab. B"/"Gab. C" como palavra própria (exclusão é o lado seguro) */
const GAB_OUTRO = new RegExp(`${GAB}[bc](?![a-z])`, "im");

/** Por que a mensagem é do Gabinete A (relatoria do Des. Fed. Carlos Muta); "" quando não é. */
export function carlosMutaEvidence(message: Pick<CarlosMutaMessage, "subject" | "text" | "preview">): string {
  /* abreviações com ponto ("Des. Fed.", "Exmo.") não podem cortar a busca do cargo antes do nome */
  const content = normalize(
    `${message.subject ?? ""}\n${message.text ?? ""}\n${message.preview ?? ""}`,
  ).replace(/\b(des|fed|exmo|exma|dr|dra|sr|sra)\./g, "$1");
  const name = String.raw`carlos(?:\s+[a-z]+){0,4}\s+muta`;
  const role = String.raw`(?:\b(?:relator(?:a|ia)?(?:\s*\(a\))?|desembargador(?:\s+federal)?)\b|\bdes\.?)`;
  const roleBefore = new RegExp(String.raw`${role}[^\n.]{0,100}\b${name}\b`, "i");
  const roleAfter = new RegExp(String.raw`\b${name}\b[^\n.]{0,100}${role}`, "i");
  if (roleBefore.test(content) || roleAfter.test(content)) return "relatoria do Des. Fed. Carlos Muta";
  /* Gabinete A só conta se a mensagem não indicar também outro gabinete (B ou C) da Turma. */
  if (GAB_A.test(content) && !GAB_OUTRO.test(content)) return "indicação de Gabinete A";
  return "";
}

export function isCarlosMutaRelatoria(message: Pick<CarlosMutaMessage, "subject" | "text" | "preview">): boolean {
  return carlosMutaEvidence(message) !== "";
}

export function manualLinkRejection(
  message: LinkPolicyMessage | null | undefined,
  manual: boolean,
): string | null {
  if (!message) return "A mensagem não está mais na caixa do app. Atualize a lista.";
  if (message.source !== "agentmail" && message.source !== "twilio") {
    return "Esta mensagem não pode ser vinculada por este fluxo.";
  }
  const status = String(message.status ?? "");
  if (!["nova", "pendente", "registrada"].includes(status)) {
    return `A mensagem está com situação “${status || "desconhecida"}” e não pode ser aplicada. Atualize a lista e confira se ela foi descartada ou está sendo tratada em outro navegador.`;
  }
  const outcome =
    message.outcome && typeof message.outcome === "object"
      ? (message.outcome as Record<string, unknown>)
      : {};
  if (!manual && status === "registrada" && outcome.autoCarlosMuta === true) {
    return "A mensagem já foi registrada automaticamente. Use a aplicação manual para confirmar ou corrigir o card.";
  }
  if (!manual && !isCarlosMutaRelatoria(message)) {
    return "A mensagem não foi identificada como solicitação do Gabinete A; selecione o card manualmente para confirmar o vínculo.";
  }
  return null;
}

export function resolveCarlosMutaMessage(
  message: CarlosMutaMessage,
  pautaState: Record<string, unknown>,
  manualSelection?: { processNumber: string; session: string },
): CarlosMutaLinkResult {
  /* A triagem automática exige evidência de relatoria; no vínculo manual, a
     seleção explícita do servidor/processo/sessão substitui essa inferência. */
  if (!manualSelection && !isCarlosMutaRelatoria(message)) return { kind: "ignore" };

  const content = `${message.subject ?? ""}\n${message.text ?? ""}\n${message.preview ?? ""}`;
  const selectedProcess = digits(manualSelection?.processNumber);
  const processNumbers = manualSelection
    ? selectedProcess.length === 20
      ? [selectedProcess]
      : []
    : extractProcessNumbers(content);
  if (processNumbers.length !== 1) {
    return {
      kind: "review",
      processNumber: processNumbers[0] ?? "",
      reason:
        processNumbers.length === 0
          ? "Não foi encontrado um número CNJ único no assunto ou no corpo do e-mail."
          : "O e-mail contém mais de um número CNJ; o vínculo automático foi suspenso para evitar associação incorreta.",
    };
  }

  const processNumber = processNumbers[0];
  const rows = Array.isArray(pautaState.rows)
    ? (pautaState.rows as Record<string, unknown>[])
    : [];
  let candidates = rows.filter((row) => digits(row?.Processo) === processNumber);
  if (!candidates.length) {
    return {
      kind: "review",
      processNumber,
      reason: "O processo identificado não está cadastrado na pauta compartilhada.",
    };
  }

  const requestedSession = manualSelection?.session || extractSessionDate(content);
  if (requestedSession && candidates.length > 1) {
    candidates = candidates.filter((row) => rowSessions(row).includes(requestedSession));
  }

  if (candidates.length !== 1) {
    return {
      kind: "review",
      processNumber,
      reason: requestedSession
        ? "Há mais de um card para o processo e a sessão informada não identifica um único card."
        : "Há mais de um card desse processo em sessões diferentes; o vínculo automático foi suspenso.",
    };
  }

  const row = candidates[0];
  const sessions = rowSessions(row);
  if (requestedSession && sessions.length && !sessions.includes(requestedSession)) {
    return {
      kind: "review",
      processNumber,
      reason: "A sessão indicada no e-mail não corresponde à sessão do card encontrado.",
    };
  }

  const session =
    requestedSession && sessions.includes(requestedSession)
      ? requestedSession
      : sessions.length === 1
        ? sessions[0]
        : String(row["Sessão Destino"] ?? "").trim();
  const entries = Array.isArray(row._pautaEntries)
    ? (row._pautaEntries as SessionEntry[])
    : [];
  const sessionEntry = entries.find((entry) => String(entry?.session ?? "").trim() === session);
  const item = String(
    sessionEntry?.item ?? row["Item (Pauta de Julgamento)"] ?? "",
  ).trim();
  const formattedProcessNumber = `${processNumber.slice(0, 7)}-${processNumber.slice(7, 9)}.${processNumber.slice(9, 13)}.${processNumber.slice(13, 14)}.${processNumber.slice(14, 16)}.${processNumber.slice(16)}`;

  return {
    kind: "linked",
    row,
    processNumber,
    formattedProcessNumber,
    session,
    item,
  };
}

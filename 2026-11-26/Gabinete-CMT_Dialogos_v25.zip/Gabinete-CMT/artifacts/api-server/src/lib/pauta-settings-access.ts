import { isAdministrativeRole, type AppSession } from "./app-auth";

const canonical = (value: unknown) => String(value ?? "")
  .normalize("NFD")
  .replace(/[\u0300-\u036f]/g, "")
  .trim()
  .replace(/\s+/g, " ")
  .toLocaleUpperCase("pt-BR");

const isRecord = (value: unknown): value is Record<string, unknown> =>
  !!value && typeof value === "object" && !Array.isArray(value);

/** Mirrors the Assessoria/CM rule used by the Configurações Globais navigation. */
export function canAccessPautaSettings(
  session: Pick<AppSession, "role" | "name" | "server"> | null,
  state: unknown,
): boolean {
  if (!session) return false;
  if (isAdministrativeRole(session.role)) return true;
  if (!isRecord(state) || !isRecord(state.team) || !Array.isArray(state.team.members)) return false;

  const identities = new Set([session.server, session.name].map(canonical).filter(Boolean));
  if (!identities.size) return false;

  const member = state.team.members.find((candidate) => {
    if (!isRecord(candidate)) return false;
    return [candidate.id, candidate.name, ...(Array.isArray(candidate.aliases) ? candidate.aliases : [])]
      .some((identity) => identities.has(canonical(identity)));
  });
  if (!isRecord(member) || member.archived === true) return false;

  const hierarchy = String(member.hierarchy ?? "").trim();
  const isDesembargador = canonical(member.name) === "CM" || /^(cm|desembargador)\b/i.test(hierarchy);
  if (isDesembargador) return true;
  if (typeof member.assessoria === "boolean") return member.assessoria;
  return /^(cj|assessoria)/i.test(hierarchy);
}

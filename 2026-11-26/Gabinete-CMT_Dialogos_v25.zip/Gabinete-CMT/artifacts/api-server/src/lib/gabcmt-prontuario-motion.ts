const SCRIPT_ID = "alt-shell-script";
const STYLE_ID = "cmt-prontuario-motion-v1";
const MARKER = "/* cmt-prontuario-motion-v1 */";

function replaceOnce(source: string, before: string, after: string, label: string): string {
  const count = source.split(before).length - 1;
  if (count !== 1) throw new Error(`Prontuário motion: expected one ${label}, found ${count}.`);
  return source.replace(before, after);
}

export function prepareProntuarioMotionDocument(html: string): string {
  if (html.includes(`id="${STYLE_ID}"`) || html.includes(`id='${STYLE_ID}'`)) return html;

  let found = false;
  const prepared = html.replace(
    new RegExp(`(<script\\b[^>]*\\bid=["']${SCRIPT_ID}["'][^>]*>)([\\s\\S]*?)(<\\/script>)`, "i"),
    (_match, open: string, original: string, close: string) => {
      found = true;
      if (original.includes(MARKER)) return open + original + close;
      let script = original;

      script = replaceOnce(
        script,
        "let on = false, gid = '', focusedProcess = '', el = null, last = '', pass = false, selectedGroup = null, paintKey = '', paintGroup = null;",
        "let on = false, gid = '', focusedProcess = '', el = null, last = '', pass = false, selectedGroup = null, paintKey = '', paintGroup = null, paintRevision = 0;",
        "Prontuário revision",
      );
      script = replaceOnce(
        script,
        "try{key=JSON.stringify([rowForGroup(current),window.CMTManualSave?.isPending?.(index),window.CMTManualSave?.isBusy?.(),localStorage.getItem('cmt.prontuario.modo.v1'),pageKind()]);}catch(_){}",
        "try{key=JSON.stringify([Number(current?.dataset.preRow),window.CMTManualSave?.isPending?.(index),window.CMTManualSave?.isBusy?.(),localStorage.getItem('cmt.prontuario.modo.v1'),pageKind(),paintRevision]);}catch(_){}",
        "lightweight panel cache key",
      );
      script = replaceOnce(
        script,
        "const later = (keep) => { clearTimeout(lt); lt = setTimeout(() => paint(!keep), 160); };",
        "const later = (keep) => { clearTimeout(lt); lt = setTimeout(() => {paintRevision++;paint(!keep);}, 160); };",
        "edit revision",
      );
      script = replaceOnce(
        script,
        "doc.addEventListener('pauta:updated', scheduleGeoPaint);",
        "doc.addEventListener('pauta:updated',()=>{paintRevision++;scheduleGeoPaint();});",
        "shared update revision",
      );
      script = replaceOnce(
        script,
        "function paint(force) {",
        "function paint(force, deferHeavy = false) {",
        "deferred first paint",
      );
      script = replaceOnce(
        script,
        "const a = doc.activeElement; if (!force && p.contains(a) && (/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)||a.isContentEditable) && a.type !== 'checkbox') return;\n         const h = html(g)+dadosGerador(g);",
        "const a = doc.activeElement; if (!force && p.contains(a) && (/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)||a.isContentEditable) && a.type !== 'checkbox') return;\n         if(!force&&paintGroup===g&&paintKey===key&&p.firstChild)return;\n         if(deferHeavy){if(p.__qpLoading)return;p.__qpLoading=true;p.innerHTML='<header class=\"qp-h\"><div class=\"qp-process-control\"><strong>Carregando processo…</strong></div></header><div class=\"qp-loading\" role=\"status\" aria-busy=\"true\">Carregando Prontuário…</div>';const targetKey=keyOf(g),targetProcess=digits(processOfGroup(g));const renderDeferred=()=>{if(!p.__qpLoading)return;p.__qpLoading=false;const active=cur();if(on&&p.isConnected&&active&&keyOf(active)===targetKey&&digits(processOfGroup(active))===targetProcess)paint(true);};if(typeof requestIdleCallback==='function')requestIdleCallback(renderDeferred,{timeout:120});else setTimeout(renderDeferred,0);return;}\n         const h = html(g)+dadosGerador(g);",
        "cached process render",
      );
      script = replaceOnce(
        script,
        "paint(changed); try{doc.dispatchEvent(new CustomEvent('cmt:prontuario-process-selected'",
        "paint(changed,true); try{doc.dispatchEvent(new CustomEvent('cmt:prontuario-process-selected'",
        "deferred process selection",
      );
      script = replaceOnce(
        script,
        "if(changed||moved)paint(false);",
        "if(changed||moved)paint(false,on);",
        "deferred opening render",
      );
      script = replaceOnce(
        script,
        "if (on && (changed || moved)) requestAnimationFrame(geo);",
        "/* paint() already measures the panel when its layout is dirty. */",
        "duplicate geometry measurement",
      );
      script = script.replace(
        "/* ── Prontuário da Mesa: a seleção da lista define o processo deste painel e da ficha do Gerador. ── */",
        `${MARKER}\n      /* ── Prontuário da Mesa: a seleção da lista define o processo deste painel e da ficha do Gerador. ── */`,
      );
      return open + script + close;
    },
  );
  if (!found) throw new Error(`Prontuário motion: missing script ${SCRIPT_ID}.`);

  const style = `<style id="${STYLE_ID}">
#alt-qp:not([hidden]){animation:cmt-qp-enter 140ms cubic-bezier(.2,.75,.25,1) both}
.qp-loading{display:grid;min-height:90px;place-items:center;color:#607680;font:600 12px/1.5 Figtree,system-ui,sans-serif}
@keyframes cmt-qp-enter{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:translateX(0)}}
@media(prefers-reduced-motion:reduce){#alt-qp:not([hidden]){animation:none!important}}
</style>`;
  const bodyClose = prepared.lastIndexOf("</body>");
  if (bodyClose < 0) throw new Error("Prontuário motion: document body closing tag is missing.");
  return prepared.slice(0, bodyClose) + style + prepared.slice(bodyClose);
}

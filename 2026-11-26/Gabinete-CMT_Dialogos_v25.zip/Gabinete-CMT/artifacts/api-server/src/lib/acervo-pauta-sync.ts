import { applyAcervoToTriagem, collectTriagemAcervoPatches } from "./acervo-triagem-sync";
type JsonRecord = Record<string, unknown>;

export const ACERVO_PAUTA_FIELDS = [
  "classe_judicial", "Classe", "assunto_judicial", "Assunto", "Partes", "Gabinete",
  "polo_ativo", "polo_passivo", "advogado_pa", "advogado_pp", "data_distribuição",
  "Data_Distribuição", "tarefa_atual", "data_entrada_tarefa", "prioridade", "etiquetas",
  "ultimo_movimento", "Última_Movimentação", "Data_Última_Movimentação", "valor_causa",
  "dpu", "mpf", "Seção de Origem",
] as const;

export type AcervoPautaField = (typeof ACERVO_PAUTA_FIELDS)[number];

export type AcervoPautaRecord = {
  processo: unknown;
  linha: JsonRecord;
  pauta?: JsonRecord;
  pautasPorFicha?: JsonRecord;
};

export type AcervoPautaPatch = {
  processo: string;
  escopo: string;
  setFields: JsonRecord;
  removeFields: string[];
};

const isRecord = (value: unknown): value is JsonRecord =>
  !!value && typeof value === "object" && !Array.isArray(value);

const digits = (value: unknown) => String(value ?? "").replace(/\D/g, "");
const same = (left: unknown, right: unknown) => JSON.stringify(left) === JSON.stringify(right);
const isEmpty = (value: unknown) =>
  value == null || value === "" ||
  (Array.isArray(value) && value.length === 0) ||
  (isRecord(value) && Object.keys(value).length === 0);
const copy = <T>(value: T): T =>
  value == null ? value : JSON.parse(JSON.stringify(value)) as T;

/** Usa a mesma identidade de ficha por sessão que a mesclagem da Pauta. */
export function pautaFichaScopeKey(row: JsonRecord): string {
  const sessions = new Set<string>();
  if (Array.isArray(row._pautaEntries)) {
    for (const entry of row._pautaEntries) {
      if (isRecord(entry) && typeof entry.session === "string" && entry.session) {
        sessions.add(entry.session);
      }
    }
  }
  if (typeof row["Sessão Destino"] === "string" && row["Sessão Destino"]) {
    sessions.add(row["Sessão Destino"] as string);
  }
  return JSON.stringify([...sessions].sort());
}

function legacyOverridesFor(
  record: AcervoPautaRecord,
  candidate: JsonRecord,
  processCount: number,
): JsonRecord {
  const scoped = record.pautasPorFicha;
  const scope = pautaFichaScopeKey(candidate);
  if (scoped && Object.hasOwn(scoped, scope) && isRecord(scoped[scope])) {
    return scoped[scope] as JsonRecord;
  }
  // Dados legados sem escopo são seguros somente quando há uma única ficha.
  return processCount === 1 && isRecord(record.pauta) ? record.pauta : {};
}

/** Reaplica dados do Acervo sem sobrescrever uma edição manual não rastreada. */
export function applyAcervoToPautaState(
  state: JsonRecord,
  records: AcervoPautaRecord[],
): { state: JsonRecord; changed: boolean } {
  const triagem = applyAcervoToTriagem(state, records);
  state = triagem.state;
  if (!Array.isArray(state.rows) || !records.length) return triagem;

  const byProcess = new Map<string, AcervoPautaRecord>();
  for (const record of records) {
    const key = digits(record.processo);
    if (key.length === 20) byProcess.set(key, record);
  }
  if (!byProcess.size) return { state, changed: false };

  const processCounts = new Map<string, number>();
  for (const candidate of state.rows as unknown[]) {
    if (!isRecord(candidate)) continue;
    const key = digits(candidate.Processo);
    if (key.length === 20) processCounts.set(key, (processCounts.get(key) ?? 0) + 1);
  }

  let changed = triagem.changed;
  const rows = (state.rows as unknown[]).map((candidate) => {
    if (!isRecord(candidate)) return candidate;
    const process = digits(candidate.Processo);
    const record = byProcess.get(process);
    if (!record) return candidate;

    const row = { ...candidate };
    const managed = { ...(isRecord(candidate._acervoManaged) ? candidate._acervoManaged : {}) };
    const overrides = legacyOverridesFor(record, candidate, processCounts.get(process) ?? 0);
    let rowChanged = false;

    for (const field of ACERVO_PAUTA_FIELDS) {
      const value = record.linha[field];
      if (isEmpty(value)) continue;
      const stillAcervoManaged =
        Object.hasOwn(managed, field) && same(row[field], managed[field]);
      if (isEmpty(row[field]) || stillAcervoManaged || same(row[field], value)) {
        if (!same(row[field], value)) {
          row[field] = copy(value);
          rowChanged = true;
        }
        if (!same(managed[field], value)) {
          managed[field] = copy(value);
          rowChanged = true;
        }
      }

      if (Object.hasOwn(overrides, field) && !same(row[field], overrides[field])) {
        row[field] = copy(overrides[field]);
        rowChanged = true;
      }
    }

    if (rowChanged) {
      if (Object.keys(managed).length) row._acervoManaged = managed;
      else delete row._acervoManaged;
      changed = true;
      return row;
    }
    return candidate;
  });

  return changed ? { state: { ...state, rows }, changed: true } : { state, changed: false };
}

/** Identifica edições da ficha que devem voltar ao bloco operacional do Acervo. */
export function collectPautaAcervoPatches(
  beforeState: JsonRecord,
  nextState: JsonRecord,
): { state: JsonRecord; patches: AcervoPautaPatch[] } {
  const triagemPatches = collectTriagemAcervoPatches(beforeState, nextState);
  if (!Array.isArray(nextState.rows)) return { state: nextState, patches: triagemPatches };

  const previousByIdentity = new Map<string, JsonRecord>();
  for (const candidate of Array.isArray(beforeState.rows) ? beforeState.rows : []) {
    if (!isRecord(candidate)) continue;
    const process = digits(candidate.Processo);
    if (process.length === 20) {
      previousByIdentity.set(JSON.stringify([process, pautaFichaScopeKey(candidate)]), candidate);
    }
  }

  const patches = new Map<string, AcervoPautaPatch>();
  let stateChanged = false;
  const rows = (nextState.rows as unknown[]).map((candidate) => {
    if (!isRecord(candidate)) return candidate;
    const process = digits(candidate.Processo);
    if (process.length !== 20) return candidate;
    const escopo = pautaFichaScopeKey(candidate);
    const previous = previousByIdentity.get(JSON.stringify([process, escopo]));
    if (!previous) return candidate;
    const row = { ...candidate };
    const managedNext = { ...(isRecord(candidate._acervoManaged) ? candidate._acervoManaged : {}) };
    const managedPrevious = isRecord(previous?._acervoManaged) ? previous._acervoManaged : {};
    let rowChanged = false;
    const patchKey = JSON.stringify([process, escopo]);
    let patch = patches.get(patchKey);

    for (const field of ACERVO_PAUTA_FIELDS) {
      if (same(previous?.[field], candidate[field])) continue;

      const isCurrentAcervoValue =
        Object.hasOwn(managedNext, field) && same(managedNext[field], candidate[field]);
      patch ??= { processo: process, escopo, setFields: {}, removeFields: [] };
      if (Object.hasOwn(managedPrevious, field) && same(candidate[field], managedPrevious[field])) {
        patch.removeFields.push(field);
        if (!same(managedNext[field], managedPrevious[field])) {
          managedNext[field] = copy(managedPrevious[field]);
          rowChanged = true;
        }
      } else if (isCurrentAcervoValue) {
        continue;
      } else {
        patch.setFields[field] = copy(Object.hasOwn(candidate, field) ? candidate[field] : "");
      }
      patches.set(patchKey, patch);
    }

    if (rowChanged) {
      if (Object.keys(managedNext).length) row._acervoManaged = managedNext;
      else delete row._acervoManaged;
      stateChanged = true;
      return row;
    }
    return candidate;
  });

  return {
    state: stateChanged ? { ...nextState, rows } : nextState,
    patches: [...patches.values(), ...triagemPatches],
  };
}

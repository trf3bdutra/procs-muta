import type { Request } from "express";

export type AppRole = "equipe" | "editor" | "administracao";

export function isAdministrativeRole(role: AppRole | string | null | undefined): boolean {
  return role === "administracao" || role === "editor";
}

export type AppSession = {
  userId?: string;
  sessionId?: string;
  role: AppRole;
  name: string;
  server?: string;
  issuedAt: number;
  expiresAt: number;
};

export function canDeleteProcessCards(role: AppRole | null | undefined): boolean {
  return isAdministrativeRole(role);
}

export function canAccessGlobalSettings(role: AppRole | null | undefined): boolean {
  return isAdministrativeRole(role);
}

export const TEAM_SERVER_NAMES = [
  "ALEXANDER",
  "BRUNO",
  "SAFFIOTI",
  "VANILDA",
  "GIOVANA",
  "DALETE",
  "JOSÉ",
  "RODRIGO",
  "DEBORA",
  "RENATO",
  "VICTOR",
  "ESTELA",
  "MARIA EDUARDA",
  "WELLINGTON",
] as const;

// Only approved local authentication + database membership middleware can populate this.
const approvedSessions = new WeakMap<object, AppSession>();
export function setAppSession(req: object, session: AppSession): void {
  approvedSessions.set(req, session);
}
export function getAppSession(req: Pick<Request, "headers">): AppSession | null {
  return approvedSessions.get(req) ?? null;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

export function removesProcessCards(previous: unknown, next: unknown): boolean {
  if (!isRecord(previous) || !isRecord(next)) return false;
  const collections: Array<[unknown, unknown]> = [
    [previous.rows, next.rows],
  ];
  const beforeDecisions = isRecord(previous.decisoes) ? previous.decisoes : {};
  const afterDecisions = isRecord(next.decisoes) ? next.decisoes : {};
  collections.push(
    [beforeDecisions.monocraticas, afterDecisions.monocraticas],
    [beforeDecisions.liminares, afterDecisions.liminares],
  );
  return collections.some(([before, after]) => {
    const beforeCards = Array.isArray(before) ? before : [];
    const afterCards = Array.isArray(after) ? after : [];
    return afterCards.length < beforeCards.length;
  });
}

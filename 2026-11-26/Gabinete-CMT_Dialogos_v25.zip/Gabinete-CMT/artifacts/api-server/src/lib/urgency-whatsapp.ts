/** Explicit, one-shot forwarding. Never call this from automatic urgency synchronization. */
export const CM_URGENCY_WHATSAPP = "+5511999001336";
const TEST_URGENCY_WHATSAPP = "+556699313888";
export function urgencyWhatsappDestination(environment: { NODE_ENV?: string; REPLIT_DEPLOYMENT?: string } = process.env) {
  const test = environment.NODE_ENV === "development" && environment.REPLIT_DEPLOYMENT !== "1";
  return test
    ? { number: TEST_URGENCY_WHATSAPP, display: "+55 66 9931-3888", test: true }
    : { number: CM_URGENCY_WHATSAPP, display: "+55 11 99900-1336", test: false };
}
export const URGENCY_MESSAGE_LIMIT = 1500;
export function urgencyWhatsappTemplateSid() {
  const sid = String(process.env.TWILIO_WHATSAPP_CONTENT_SID || "").trim();
  return /^HX[0-9a-f]{32}$/i.test(sid) ? sid : "";
}
type Card = Record<string, unknown>;
const text = (v: unknown) => String(v ?? "").trim();

export function linkedUrgency(state: Card, monoId: string): Card {
  const decisions = (state.decisoes ?? {}) as Card;
  const monos = Array.isArray(decisions.monocraticas) ? decisions.monocraticas as Card[] : [];
  const urgencies = Array.isArray(decisions.liminares) ? decisions.liminares as Card[] : [];
  const mono = monos.find((m) => m.id === monoId);
  const urgency = mono && urgencies.find((u) => u.id === mono.linkedLimId || u.linkedMonoId === mono.id);
  if (!urgency) throw new Error("O pedido de urgência vinculado não foi encontrado. Salve o card antes de encaminhar.");
  return urgency;
}

export function urgencyMessage(urgency: Card, state: Card): string {
  const members = ((state.team as Card)?.members ?? []) as Card[];
  const responsible = members.find((m) => m.id === urgency.responsavel);
  const lines = [
    "*Gabinete CMT · Pedido de urgência*",
    ["Processo", urgency.processo], ["Classe", urgency.classe],
    ["Partes", urgency.partes], ["Medida", urgency.medida],
    ["Prioridade", urgency.urgencia], ["Pedido", urgency.pedido],
    ["Assunto", urgency.assunto], ["Tema", urgency.tema],
    ["Especificidades", urgency.especificidades],
    ["Conclusão", urgency.conclusao], ["Prazo", urgency.prazo],
    ["Responsável", responsible?.name || urgency.responsavel],
    ["Situação", urgency.status], ["Resultado", urgency.resultado],
    ["Observações", urgency.observacoes],
  ];
  return lines.map((line) => typeof line === "string" ? line :
    text(line[1]) ? `${line[0]}: ${text(line[1])}` : "").filter(Boolean).join("\n");
}

export function forwardingText(mode: string, custom: string | undefined, urgency: Card, state: Card) {
  const body = mode === "custom" ? text(custom) : urgencyMessage(urgency, state);
  if (!body) throw new Error("Escreva a mensagem personalizada.");
  if (body.length > URGENCY_MESSAGE_LIMIT) throw new Error(`A mensagem excede ${URGENCY_MESSAGE_LIMIT} caracteres. Use a opção personalizada para resumir o conteúdo.`);
  return body;
}

/** Divide at paragraph boundaries without adding, removing, or rewriting any characters. */
export function splitWhatsappText(body: string, maxChars = 950): string[] {
  if (!body) throw new Error("A mensagem não pode estar vazia.");
  if (!Number.isInteger(maxChars) || maxChars < 2) throw new Error("Limite de mensagem inválido.");
  const parts: string[] = [];
  let rest = body;
  while (rest.length > maxChars) {
    const floor = Math.floor(maxChars * 0.55);
    let cut = rest.lastIndexOf("\n\n", maxChars - 2);
    let separator = 2;
    if (cut < floor) { cut = rest.lastIndexOf("\n", maxChars - 1); separator = 1; }
    if (cut < floor) { cut = maxChars; separator = 0; }
    if (separator === 0 && /[\uD800-\uDBFF]/.test(rest[cut - 1]) && /[\uDC00-\uDFFF]/.test(rest[cut])) cut--;
    parts.push(rest.slice(0, cut + separator));
    rest = rest.slice(cut + separator);
  }
  if (rest) parts.push(rest);
  if (parts.some((part) => part.length > maxChars) || parts.join("") !== body) {
    throw new Error("Não foi possível dividir a mensagem sem alterar o texto.");
  }
  return parts;
}

/** Claim persisted before contacting Twilio; uncertain attempts are never retried automatically. */
export async function forwardOnce(
  key: string,
  payload: Card,
  io: {
    claim: (key: string, payload: Card) => Promise<boolean>;
    read: (key: string) => Promise<Card>;
    finish: (key: string, payload: Card) => Promise<void>;
    send: () => Promise<{ sid: string; status: string }>;
  },
): Promise<Card> {
  if (!await io.claim(key, payload)) {
    const previous = await io.read(key);
    if (previous.status === "accepted") return previous;
    throw new Error("Esta abertura do card já iniciou um encaminhamento. Confira o resultado antes de reabrir e solicitar outro.");
  }
  let result: { sid: string; status: string };
  try {
    result = await io.send();
  } catch (error) {
    await io.finish(key, { ...payload, status: "unconfirmed", error: (error as Error).message });
    throw error;
  }
  const accepted = { ...payload, status: "accepted", providerId: result.sid, providerStatus: result.status, acceptedAt: new Date().toISOString() };
  await io.finish(key, accepted);
  return accepted;
}

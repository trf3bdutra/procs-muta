/** Reuse the native per-page footer for Campo do Servidor. */
export function prepareServerFooterDocument(html: string): string {
  const replacements: Array<[string, string]> = [
    ["if(R.classList.contains('cmt-srv-on'))return '';", "if(R.classList.contains('cmt-srv-on'))return 'servidor';"],
    ["const current=this.host.state.tab==='monocraticas'?'decisoes':'pauta';", "const current=document.documentElement.classList.contains('cmt-srv-on')?'servidor':this.host.state.tab==='monocraticas'?'decisoes':'pauta';"],
    ["triagem:'Rodapé do Controle de Triagem'}", "triagem:'Rodapé do Controle de Triagem',servidor:'Rodapé do Campo do Servidor'}"],
    ["const pages=[current,...['pauta','decisoes','triagem'].filter", "const pages=[current,...['pauta','decisoes','triagem','servidor'].filter"],
    ["const footer = activePage && activePage !== 'servidor'", "const footer = activePage"],
  ];
  let result = html;
  for (const [from, to] of replacements) {
    if (!result.includes(from) && result.includes(to)) continue;
    if (result.split(from).length !== 2) throw new Error("Campo do Servidor footer contract changed: " + from);
    result = result.replace(from, to);
  }
  // Retire only old server-specific positioning/hiding of the shared dock.
  // Leave unrelated profile styles and all other pages untouched.
  result = result.replace(/(<style\b[^>]*>)([\s\S]*?)(<\/style>)/gi, (_, open, css, close) =>
    open + (open.includes('id="cmt-server-standard-footer-css"') ? css : css.replace(/([^{}]+)\{([^{}]*)\}/g, (rule: string, selectors: string, declarations: string) => {
      if (!selectors.includes("#pauta-global-dock") || !/cmt-srv-on|data-cmt-frame-page="servidor"/.test(selectors)) return rule;
      const retained = selectors.split(/,(?![^(]*\))/).filter((selector: string) =>
        !(selector.includes("#pauta-global-dock") && /cmt-srv-on|data-cmt-frame-page="servidor"/.test(selector)));
      return retained.length ? retained.join(",") + "{" + declarations + "}" : "";
    })) + close,
  );
  if (!result.includes('id="cmt-server-standard-footer-css"')) {
    const style = `<style id="cmt-server-standard-footer-css">
html.cmt-srv-on body #pauta-global-dock#pauta-global-dock#pauta-global-dock#pauta-global-dock{left:var(--cmt-frame-left,var(--alt-w,78px))!important;right:var(--cmt-frame-right,58px)!important;bottom:0!important;width:auto!important}
</style>`;
    const end = result.lastIndexOf("</body>");
    result = end < 0 ? result + style : result.slice(0, end) + style + result.slice(end);
  }
  return result;
}

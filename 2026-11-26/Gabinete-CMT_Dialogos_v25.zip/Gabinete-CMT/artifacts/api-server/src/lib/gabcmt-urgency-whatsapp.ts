/** Keep integration hooks outside the user-editable legacy document. */
export function prepareUrgencyWhatsappDocument(html: string): string {
  const formAnchor = "block+'<fieldset><legend>Decisão</legend>');};";
  const saveAnchor = "if(form.dataset.decInline){if(form.dataset.decInline==='new')";
  if (!html.includes(formAnchor) || !html.includes(saveAnchor)) {
    throw new Error("Urgency forwarding: linked monocratic form contract changed.");
  }
  const prepared = html
    .replace(formAnchor, "block.replace('</fieldset>',(window.CMTUrgencyWhatsApp?.controls(lim,x)||'')+'</fieldset>')+'<fieldset><legend>Decisão</legend>');};")
    .replace(saveAnchor, "if(kind==='mono'&&window.CMTUrgencyWhatsApp?.handleSave(h,form,saved)){render(h);return true;}"+saveAnchor);
  // Earlier body closings belong to print templates inside executable scripts.
  const bodyEnd = prepared.toLowerCase().lastIndexOf("</body>");
  if (bodyEnd < 0) throw new Error("Urgency forwarding: document body closing tag missing.");
  return prepared.slice(0, bodyEnd) +
    '<script src="/api/app/urgency-whatsapp.js"></script>' + prepared.slice(bodyEnd);
}

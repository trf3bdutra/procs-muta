import { randomUUID } from "node:crypto";
import { and, eq, sql } from "drizzle-orm";
import {
  db, pautaSnapshotsTable as snapshots, accountMembershipsTable as accounts,
  localCredentialsTable as credentials, accountAuditTable as audit,
} from "@workspace/db";

// Explicit owner request. Audit marker prevents recreating a later-removed account.
const STAFF = { userId: "sahassan", name: "SALAH", email: "sahassan@trf3.jus.br" } as const;
const ACTION = "owner:provision-assessoria-salah";

export async function provisionOwnerApprovedStaff(environment: "development" | "production") {
  return db.transaction(async tx => {
    await tx.execute(sql`select pg_advisory_xact_lock(7210467)`);
    const [done] = await tx.select({ id: audit.id }).from(audit).where(and(
      eq(audit.environment, environment), eq(audit.targetId, STAFF.userId), eq(audit.action, ACTION),
    )).limit(1);
    if (done) return { applied: false };

    if (!process.env.TEAM_LOGIN_PASSWORD || process.env.TEAM_LOGIN_PASSWORD.length < 6) {
      throw new Error("Configure a senha da Equipe nos Secrets antes de provisionar a Assessoria.");
    }
    const [snapshot] = await tx.select().from(snapshots).where(eq(snapshots.id, "main")).for("update");
    if (!snapshot || !snapshot.state.team || typeof snapshot.state.team !== "object") {
      throw new Error("O cadastro da equipe precisa existir; nenhuma pauta será criada ou substituída.");
    }
    const team = snapshot.state.team as Record<string, unknown>;
    if (!Array.isArray(team.members)) throw new Error("O cadastro de servidores não possui formato válido.");
    const members = team.members as Array<Record<string, unknown>>;
    const matches = members.filter(m => String(m.name || "").trim().toUpperCase() === STAFF.name ||
      String(m.email || "").trim().toLowerCase() === STAFF.email);
    if (matches.length > 1) throw new Error("Há servidores conflitantes; nenhum cadastro foi alterado.");
    const member = matches[0];
    if (member && (String(member.name || "").trim().toUpperCase() !== STAFF.name ||
      (String(member.email || "").trim() && String(member.email).trim().toLowerCase() !== STAFF.email))) {
      throw new Error("O servidor existente possui outro vínculo; nenhum cadastro foi alterado.");
    }

    const collisions = await tx.select().from(accounts).where(sql`
      ${accounts.userId} = ${STAFF.userId} OR (
        ${accounts.environment} = ${environment} AND (
          lower(trim(${accounts.email})) = ${STAFF.email} OR upper(trim(${accounts.server})) = ${STAFF.name}
        )
      )`);
    if (collisions.length > 1) throw new Error("Há contas conflitantes; nenhum acesso foi alterado.");
    const account = collisions[0];
    if (account && (account.environment !== environment || account.email.trim().toLowerCase() !== STAFF.email ||
      account.server?.trim().toUpperCase() !== STAFF.name || account.status !== "active" ||
      account.role !== "equipe" || account.adminAccess)) {
      throw new Error("A conta existente exige conferência; nenhum acesso foi alterado.");
    }
    const userId = account?.userId || STAFF.userId;
    const [credential] = await tx.select().from(credentials).where(eq(credentials.userId, userId));
    if (credential && (credential.environment !== environment || credential.passwordSecretKey !== "TEAM_LOGIN_PASSWORD")) {
      throw new Error("A credencial existente exige conferência; nenhuma senha foi alterada.");
    }

    const nextMember = member
      ? { ...member, name: STAFF.name, email: STAFF.email, assessoria: true }
      : { id: `srv_${randomUUID()}`, name: STAFF.name, email: STAFF.email, assessoria: true,
          hierarchy: "Assessoria", aliases: [], functions: [], daily: [], logs: [],
          absences: [], absenceRequests: [], baseStatus: "disponivel" };
    if (!member || JSON.stringify(member) !== JSON.stringify(nextMember)) {
      const nextMembers = member ? members.map(m => m === member ? nextMember : m) : [...members, nextMember];
      await tx.update(snapshots).set({
        state: { ...snapshot.state, team: { ...team, members: nextMembers } },
        revision: snapshot.revision + 1, updatedAt: new Date(),
      }).where(eq(snapshots.id, "main"));
    }
    if (!account) await tx.insert(accounts).values({
      userId, environment, email: STAFF.email, name: STAFF.name, status: "active",
      role: "equipe", server: STAFF.name, adminAccess: false,
    });
    if (!credential) await tx.insert(credentials).values({
      userId, environment, passwordSecretKey: "TEAM_LOGIN_PASSWORD",
    });
    await tx.insert(audit).values({
      id: randomUUID(), environment, actorId: "workspace-owner", targetId: STAFF.userId, action: ACTION,
    });
    return { applied: true };
  });
}

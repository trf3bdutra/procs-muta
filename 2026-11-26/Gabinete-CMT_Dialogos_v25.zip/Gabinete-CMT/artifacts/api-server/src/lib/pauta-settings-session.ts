import { createHmac, timingSafeEqual } from "node:crypto";

export const SETTINGS_SESSION_COOKIE = "cmt_settings_access";

export function createSettingsSessionToken(
  secret: string,
  sessionId: string,
  sessionExpiresAt: number,
  nowMs = Date.now(),
): string {
  const expiresAt = Math.floor(sessionExpiresAt);
  if (!secret || !sessionId || !Number.isSafeInteger(expiresAt) || expiresAt <= Math.floor(nowMs / 1000)) {
    throw new Error("A sessão autenticada é necessária para liberar as Configurações.");
  }
  const signature = createHmac("sha256", secret)
    .update(`cmt-global-settings:v2:${sessionId}:${expiresAt}`)
    .digest("base64url");
  return `${expiresAt}.${signature}`;
}

export function verifySettingsSessionToken(
  secret: string,
  token: string,
  sessionId: string,
  sessionExpiresAt: number,
  nowMs = Date.now(),
): boolean {
  if (!secret || !token || !sessionId || !Number.isSafeInteger(Math.floor(sessionExpiresAt))) return false;
  const separator = token.indexOf(".");
  if (separator < 1) return false;

  const expiresAt = token.slice(0, separator);
  const signature = token.slice(separator + 1);
  if (!/^\d{10,12}$/.test(expiresAt) || !signature) return false;

  const expiry = Number(expiresAt);
  const nowSeconds = Math.floor(nowMs / 1000);
  if (
    !Number.isSafeInteger(expiry) ||
    expiry <= nowSeconds ||
    expiry > Math.floor(sessionExpiresAt)
  ) {
    return false;
  }

  const expected = createHmac("sha256", secret)
    .update(`cmt-global-settings:v2:${sessionId}:${expiresAt}`)
    .digest();
  const received = Buffer.from(signature, "base64url");
  return received.length === expected.length && timingSafeEqual(received, expected);
}

export function readCookie(
  header: string | undefined,
  name = SETTINGS_SESSION_COOKIE,
): string | null {
  if (!header) return null;
  for (const part of header.split(";")) {
    const index = part.indexOf("=");
    if (index < 0) continue;
    if (part.slice(0, index).trim() === name) {
      return part.slice(index + 1).trim() || null;
    }
  }
  return null;
}

const SIDEBAR_MARKER = "/* cmt-left-day-width-observer */";
const SHELL_MARKER = "/* cmt-shell-event-refresh */";
const SETTINGS_MARKER = "/* cmt-settings-event-refresh */";

function replaceOnce(source: string, before: string, after: string, label: string): string {
  const count = source.split(before).length - 1;
  if (count !== 1) throw new Error(`GabCMT responsiveness: expected one ${label}, found ${count}.`);
  return source.replace(before, after);
}

function replacePatternOnce(source: string, pattern: RegExp, after: string, label: string): string {
  const matches = source.match(pattern);
  if (!matches || matches.length !== 1) {
    throw new Error(`GabCMT responsiveness: expected one ${label}, found ${matches?.length ?? 0}.`);
  }
  return source.replace(pattern, after);
}

function transformScript(html: string, id: string, transform: (source: string) => string): string {
  const expression = new RegExp(
    `(<script\\b[^>]*\\bid=["']${id}["'][^>]*>)([\\s\\S]*?)(<\\/script>)`,
    "i",
  );
  let found = false;
  const output = html.replace(expression, (_match, open: string, source: string, close: string) => {
    found = true;
    return open + transform(source) + close;
  });
  if (!found) throw new Error(`GabCMT responsiveness: missing script ${id}.`);
  return output;
}

function updateShellScript(source: string): string {
  if (source.includes(SHELL_MARKER)) return source;
  source = replaceOnce(
      source,
      "new MutationObserver(modalState).observe(doc.body, { childList: true });",
      "new MutationObserver(() => { watchSync(); modalState(); retitle(); }).observe(doc.body, { childList: true });",
      "body child reconciliation",
    );
  source = replaceOnce(
      source,
      "if (dock) { let odT = 0; new MutationObserver(() => { clearTimeout(odT); odT = setTimeout(() => { if (!$('#pauta-global-dock .alt-dock-team')) paintDockTeam(); }, 30); }).observe(dock, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'hidden', 'aria-expanded'] }); }",
      "if (dock) { let odT = 0; new MutationObserver(() => { clearTimeout(odT); odT = setTimeout(() => { if (!$('#pauta-global-dock .alt-dock-team')) paintDockTeam(); paintTools(); modalState(); }, 30); }).observe(dock, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'hidden', 'aria-expanded'] }); }",
      "dock update observer",
    );
  source = replaceOnce(
      source,
      "addEventListener('pauta:updated', () => { rpDataVersion = currentRpDataVersion(); RP.refreshProductivity(); });",
      "addEventListener('pauta:updated', () => { rpDataVersion = currentRpDataVersion(); RP.refreshProductivity(); paintDockTeam(); paintTools(); const pn = $('.gd-panel.gd-p-prod'); if (pn && !pn.querySelector(':scope > .alt-od-team')) paintOD(); });",
      "shared data refresh",
    );
  source = replaceOnce(
      source,
      "setInterval(() => { const version = currentRpDataVersion(); if (version !== rpDataVersion) { rpDataVersion = version; RP.refreshProductivity(); } const pn = $('.gd-panel.gd-p-prod'); if (pn && !pn.querySelector(':scope > .alt-od-team')) paintOD(); paintTools(); stripCalendarEntryPoints(); if (doc.hidden) return; watchSync(); modalState(); titleMonoActions(); retitle(); }, 700);",
      `${SHELL_MARKER}
    let shellSyncFrame = 0;
    const syncShell = () => {
      shellSyncFrame = 0;
      const version = currentRpDataVersion();
      if (version !== rpDataVersion) { rpDataVersion = version; RP.refreshProductivity(); }
      const pn = $('.gd-panel.gd-p-prod');
      if (pn && !pn.querySelector(':scope > .alt-od-team')) paintOD();
      paintTools(); stripCalendarEntryPoints();
      if (doc.hidden) return;
      watchSync(); modalState(); titleMonoActions(); retitle();
    };
    const scheduleShellSync = () => {
      if (shellSyncFrame || doc.hidden) return;
      shellSyncFrame = requestAnimationFrame(syncShell);
    };
    addEventListener('pauta:updated', scheduleShellSync);
    doc.addEventListener('visibilitychange', scheduleShellSync);
    addEventListener('focus', scheduleShellSync);
    scheduleShellSync();`,
      "700ms whole-shell polling",
    );
  return source;
}

function updateSidebarScript(source: string): string {
  if (source.includes(SIDEBAR_MARKER)) return source;
  return replaceOnce(
    source,
    "paintDay(); placeGear(); stdPanels(); dropGdOrg();",
    `paintDay();
    ${SIDEBAR_MARKER}
    const daySide = doc.getElementById('alt-side');
    if (daySide && typeof ResizeObserver === 'function') {
      let dayWidthFrame = 0, lastDayNarrow = null;
      const syncDayWidth = () => {
        if (dayWidthFrame) return;
        dayWidthFrame = requestAnimationFrame(() => {
          dayWidthFrame = 0;
          const narrow = daySide.getBoundingClientRect().width < 180;
          if (narrow === lastDayNarrow) return;
          lastDayNarrow = narrow;
          const day = daySide.querySelector(':scope > .cx-lday:not(.cx-lfoot)');
          const team = daySide.querySelector(':scope > .cx-lfoot');
          day?.classList.toggle('is-narrow', narrow);
          team?.classList.toggle('is-narrow', narrow);
        });
      };
      const dayWidthObserver = new ResizeObserver(syncDayWidth);
      dayWidthObserver.observe(daySide);
      addEventListener('resize', syncDayWidth, { passive: true });
      syncDayWidth();
    }
    placeGear(); stdPanels(); dropGdOrg();`,
    "sidebar width reconciliation",
  );
}

function transformSettingsScript(source: string): string {
  if (source.includes(SETTINGS_MARKER)) return source;

  source = replacePatternOnce(
    source,
    /setInterval\(function\(\)\{var bar=D\.getElementById\('cmtCG-bar'\);[\s\S]*?\},1500\);/,
    `function updateBarLabels(){var bar=D.getElementById('cmtCG-bar');if(!bar)return;bar.querySelectorAll('.tbb').forEach(function(b){var t=(b.textContent||'').trim()||b.getAttribute('title')||'';if(t&&!b.title)b.title=t;if(t&&!b.getAttribute('aria-label'))b.setAttribute('aria-label',t);});var u=bar.querySelector('.upd'),a=bar.querySelector('[data-g="atualizar"]');if(u&&a){var tt='Recalcular agora · '+u.textContent.trim();if(a.title!==tt)a.title=tt;}}updateBarLabels();`,
    "settings toolbar interval",
  );
  source = replaceOnce(source, "setInterval(poe,1000);poe();", "poe();", "backup-button interval");
  source = replaceOnce(source, "poe2();setInterval(poe2,2000);", "poe2();", "close-button interval");
  source = replacePatternOnce(
    source,
    /var ultima='';setInterval\(function\(\)\{if\(aberta\(\)\)return;try\{var a=window\.CMTRotas&&window\.CMTRotas\.atual\(\);if\(a&&a\.pagina\)ultima=a\.pagina;\}catch\(_\)\{\}\},500\);/,
    "var ultima='';",
    "route polling",
  );
  const legacyDialogStateInterval =
    /setInterval\(function\(\)\{var m=D\.querySelector\('main\.app-main\.cfg2-on'\);if\(!m\)return;var on=aberta\(\);if\(on\)\{if\(m\.getAttribute\('role'\)!=='dialog'\)\{m\.setAttribute\('role','dialog'\);m\.setAttribute\('aria-modal','true'\);m\.setAttribute\('aria-label','Configurações globais'\);\}\}else if\(m\.getAttribute\('role'\)==='dialog'\)\{m\.removeAttribute\('role'\);m\.removeAttribute\('aria-modal'\);m\.removeAttribute\('aria-label'\);\}\s*D\.documentElement\.classList\.toggle\('pa-cfg-dlg',on\);\},300\);/;
  // Earlier document preparation can already remove this obsolete polling loop.
  if (legacyDialogStateInterval.test(source)) {
    source = replacePatternOnce(source, legacyDialogStateInterval, "", "dialog state interval");
  }
  source = replacePatternOnce(
    source,
    /setInterval\(function\(\)\{var li=D\.querySelector\('#alt-side li\.cmt-cfg-nav'\),ln=D\.querySelector\('#alt-side \.v2-side-line'\);[\s\S]*?\},700\);/,
    `var cfgPosFrame=0,cfgSideObserver=null,cfgNavObserver=null;
  function positionCfg(){var li=D.querySelector('#alt-side li.cmt-cfg-nav'),ln=D.querySelector('#alt-side .v2-side-line'),side=D.getElementById('alt-side'),root=D.documentElement;if(!li||!ln||!side||!ln.getClientRects().length){root.classList.remove('pa-cfg-topo');return;}
    var z=parseFloat(getComputedStyle(root).zoom)||1,sr=side.getBoundingClientRect(),lr=ln.getBoundingClientRect(),prim=[].slice.call(D.querySelectorAll('#alt-side ul.as-nav>li')).filter(function(x){return x!==li&&x.getClientRects().length;})[0];
    var fim=prim?prim.getBoundingClientRect().top:lr.bottom+60,h=li.getBoundingClientRect().height||32,top=lr.bottom+Math.max(4,(fim-lr.bottom-h)/2);
    root.classList.add('pa-cfg-topo');[['--pa-cfg-t',top],['--pa-cfg-l',sr.left],['--pa-cfg-w',sr.width]].forEach(function(v){var value=Math.round(v[1]/z)+'px';if(root.style.getPropertyValue(v[0])!==value)root.style.setProperty(v[0],value);});}
  function scheduleCfgPosition(){if(cfgPosFrame)return;cfgPosFrame=requestAnimationFrame(function(){cfgPosFrame=0;positionCfg();});}
  function observeCfgPosition(){var side=D.getElementById('alt-side'),nav=side&&side.querySelector('ul.as-nav');if(side&&window.ResizeObserver&&!cfgSideObserver){cfgSideObserver=new ResizeObserver(scheduleCfgPosition);cfgSideObserver.observe(side);var line=side.querySelector('.v2-side-line');if(line)cfgSideObserver.observe(line);}if(nav&&window.MutationObserver&&!cfgNavObserver){cfgNavObserver=new MutationObserver(scheduleCfgPosition);cfgNavObserver.observe(nav,{childList:true,subtree:true,attributes:true,attributeFilter:['class','hidden']});}}
  addEventListener('resize',scheduleCfgPosition,{passive:true});observeCfgPosition();scheduleCfgPosition();`,
    "700ms settings-button geometry interval",
  );
  source = replaceOnce(
    source,
    "x.addEventListener('click',fecha);",
    `x.addEventListener('click',fecha);
    ${SETTINGS_MARKER}
    var cfgWasOpen=false,cfgRailObserver=null,cfgToolbarObserver=null;
    function observeSettings(){var rail=D.querySelector('#cx-rrail nav.rr-foot');if(rail&&!cfgRailObserver){cfgRailObserver=new MutationObserver(poe);cfgRailObserver.observe(rail,{childList:true,subtree:true});}observeCfgPosition();}
    function watchToolbar(){var bar=D.getElementById('cmtCG-bar');if(!bar)return;updateBarLabels();if(!cfgToolbarObserver){cfgToolbarObserver=new MutationObserver(updateBarLabels);cfgToolbarObserver.observe(bar,{childList:true,subtree:true,characterData:true});}}
    function syncSettings(){var on=aberta(),m=D.querySelector('main.app-main.cfg2-on');
      if(on&&!cfgWasOpen){try{var current=window.CMTRotas&&window.CMTRotas.atual();if(current&&current.pagina)ultima=current.pagina;else ultima=D.documentElement.getAttribute('data-v2-page')||'pauta';}catch(_){ultima=D.documentElement.getAttribute('data-v2-page')||'pauta';}poe();observeSettings();watchToolbar();scheduleCfgPosition();requestAnimationFrame(function(){syncSettings();});setTimeout(watchToolbar,100);setTimeout(watchToolbar,420);}
      if(on&&m){if(m.getAttribute('role')!=='dialog'){m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-label','Configurações globais');}}
      else if(m&&m.getAttribute('role')==='dialog'){m.removeAttribute('role');m.removeAttribute('aria-modal');m.removeAttribute('aria-label');}
      D.documentElement.classList.toggle('pa-cfg-dlg',on);
      if(!on&&cfgWasOpen){cfgRailObserver&&cfgRailObserver.disconnect();cfgRailObserver=null;cfgToolbarObserver&&cfgToolbarObserver.disconnect();cfgToolbarObserver=null;}
      cfgWasOpen=on;
    }
    var cfgStateObserver=new MutationObserver(syncSettings);cfgStateObserver.observe(D.body,{attributes:true,attributeFilter:['class']});syncSettings();
    D.addEventListener('click',function(e){if(aberta()&&e.target.closest&&e.target.closest('#cfg-tabs,#cfg2-painel')){setTimeout(watchToolbar,0);setTimeout(watchToolbar,120);}},true);
    addEventListener('pauta:updated',function(){if(aberta())updateBarLabels();});`,
    "settings lifecycle wiring",
  );
  return source;
}

function transformRulesScript(source: string): string {
  if (source.includes("/* cmt-rules-event-refresh */")) return source;
  source = replaceOnce(
    source,
    "setInterval(function () { agenda(); }, 1200);",
    "/* cmt-rules-event-refresh */ addEventListener('pauta:updated', agenda); addEventListener('cmt:notification-preferences-changed', agenda);",
    "rules panel interval",
  );
  return source;
}

export function prepareGabcmtUiResponsivenessDocument(html: string): string {
  return transformScript(
    transformScript(
      transformScript(
        transformScript(html, "alt-shell-script", updateShellScript),
        "cmtx-v37-rrail-script",
        updateSidebarScript,
      ),
      "cmt-v247-cfg-acompanhamento",
      transformSettingsScript,
    ),
    "cmt-v253-cg-regras",
    transformRulesScript,
  );
}

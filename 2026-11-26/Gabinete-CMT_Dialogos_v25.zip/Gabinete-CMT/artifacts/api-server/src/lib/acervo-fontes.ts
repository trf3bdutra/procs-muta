/** Importação unificada de planilhas para o acervo (padrão 1.0) — regras puras, sem banco de dados.
 *
 * Fontes reconhecidas pelo conteúdo (nunca pelo nome do arquivo): célula A1 ("Filtros aplicados") e
 * cabeçalho na linha 3 nos relatórios do BI; cabeçalho na linha 1 na relação do PJe.
 *   pje · tramitacao · julgamentos · sentencas1g · metas · listagem · indicadores
 * Regras: datas dd/mm/aaaa nunca são lidas como mês/dia; "####" conta como vazio; valor vazio nunca
 * sobrescreve; o perdedor de uma divergência entre fontes fica em `divergencias`; importar nunca apaga.
 */

export type Celula = string | number | boolean | null | undefined;
export type Matriz = Celula[][];
export type FonteId = "pje" | "tramitacao" | "julgamentos" | "sentencas1g" | "metas" | "listagem" | "indicadores";
export type Importado = Record<string, unknown>;
export type AcervoAtual = { processo: string; importado: Importado; situacao: string; historicoSituacao: Array<Record<string, unknown>> };

export const FONTES: Record<FonteId, { rotulo: string; familia: "pje" | "bi"; completa: boolean }> = {
  pje: { rotulo: "Relação do PJe", familia: "pje", completa: false },
  tramitacao: { rotulo: "BI · Tramitação Total", familia: "bi", completa: true },
  julgamentos: { rotulo: "BI · Julgamentos", familia: "bi", completa: false },
  sentencas1g: { rotulo: "BI · Sentenças de 1º grau", familia: "bi", completa: false },
  metas: { rotulo: "BI · Metas", familia: "bi", completa: true },
  listagem: { rotulo: "BI · Listagem 3.xx", familia: "bi", completa: true },
  indicadores: { rotulo: "Indicadores", familia: "bi", completa: false },
};
export const FONTE_IDS = Object.keys(FONTES) as FonteId[];
export const MAX_LINHAS = 60000;

/* ───────── utilitários ───────── */
export const norm = (v: unknown) => String(v ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]/g, "");
const txt = (v: unknown) => (v == null ? "" : String(v)).replace(/\s+/g, " ").trim();
export function vazio(v: unknown): boolean {
  const t = txt(v);
  return !t || /^#+$/.test(t) || t === "-" || t === "—" || /^(null|undefined|nan)$/i.test(t);
}
const limpo = (v: unknown) => (vazio(v) ? "" : txt(v));
export function cnj(v: unknown): string {
  const d = String(v ?? "").replace(/\D/g, "");
  if (d.length !== 20) return "";
  return `${d.slice(0, 7)}-${d.slice(7, 9)}.${d.slice(9, 13)}.${d.slice(13, 14)}.${d.slice(14, 16)}.${d.slice(16)}`;
}
const pad = (n: number) => String(n).padStart(2, "0");
/** AAAA-MM-DD. Número = data serial do Excel; texto dd/mm/aaaa nunca é lido como mês/dia. */
export function data(v: unknown): string {
  if (v == null || v === "") return "";
  if (typeof v === "number" && Number.isFinite(v)) {
    if (v < 20000 || v > 80000) return "";
    const ms = Math.round((v - 25569) * 86400000);
    const d = new Date(ms);
    return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
  }
  const t = txt(v);
  let m = t.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return valida(+m[1], +m[2], +m[3]);
  m = t.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2}|\d{4})\b/);
  if (m) { const y = m[3].length === 2 ? 2000 + +m[3] : +m[3]; return valida(y, +m[2], +m[1]); }
  m = t.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})\b/);
  if (m) return valida(+m[3], +m[2], +m[1]);
  if (/^\d{5}(\.\d+)?$/.test(t)) return data(Number(t));
  return "";
}
function valida(y: number, mo: number, d: number): string {
  if (y < 1900 || y > 2200 || mo < 1 || mo > 12 || d < 1 || d > 31) return "";
  const dt = new Date(Date.UTC(y, mo - 1, d));
  if (dt.getUTCMonth() !== mo - 1) return "";
  return `${y}-${pad(mo)}-${pad(d)}`;
}
const simNao = (v: unknown) => { const t = norm(v); if (!t) return ""; if (/^(s|sim|true|1|x|y|yes)$/.test(t)) return "sim"; if (/^(n|nao|false|0|no)$/.test(t)) return "não"; return limpo(v); };
const ultimaDataDoTexto = (t: string) => { const all = [...t.matchAll(/(\d{1,2})\/(\d{1,2})\/(\d{4})/g)]; return all.length ? data(all[all.length - 1][0]) : ""; };

/* ───────── reconhecimento ───────── */
export type Leitura = { fonte: FonteId | null; motivo: string; filtros: string; cabecalhoLinha: number; cabecalho: string[]; linhas: Celula[][] };

export function reconhecer(matriz: Matriz): Leitura {
  const rows = (Array.isArray(matriz) ? matriz : []).filter((r) => Array.isArray(r));
  const a1 = txt(rows[0]?.[0]);
  const filtros = /filtros?\s+aplicad/i.test(a1) ? a1 : "";
  let h = -1;
  if (filtros && rows[2]) h = 2;
  if (h < 0) for (let i = 0; i < Math.min(rows.length, 8); i++) {
    const n = rows[i].map(norm);
    if (n.some((c) => /^(processo|numeroprocesso|numerodoprocesso|nprocesso)$/.test(c)) || (n.includes("questao") && n.includes("valor"))) { h = i; break; }
  }
  if (h < 0) h = filtros ? 2 : 0;
  const cab = (rows[h] || []).map((c) => txt(c));
  const H = new Set(cab.map(norm));
  const linhas = rows.slice(h + 1).filter((r) => r.some((c) => !vazio(c)));
  const tem = (...k: string[]) => k.every((x) => H.has(x));
  const temAlgum = (...k: string[]) => k.some((x) => H.has(x));
  const f = norm(filtros);
  const temProcesso = temAlgum("processo", "numeroprocesso", "numerodoprocesso");
  const base = { filtros, cabecalhoLinha: h + 1, cabecalho: cab, linhas };
  if (temAlgum("datasobrestamento") && temAlgum("sinpendente1julgamento", "pendente1julgamento") || (f.includes("tramitacaototal") && temProcesso))
    return { ...base, fonte: "tramitacao", motivo: "colunas Data_Sobrestamento e Sin_Pendente_1Julgamento" };
  if (tem("questao") && temAlgum("descricaodaquestao", "descricaoquestao") && temAlgum("orgaojulgador") && temProcesso)
    return { ...base, fonte: "listagem", motivo: "colunas Questão, Descrição da questão e Órgão Julgador" };
  if ((temAlgum("numerodoprocesso", "processo") && temAlgum("deshierarquiagrupo")) || (temAlgum("faixadameta", "faixa") && temAlgum("datadereferencia")))
    return { ...base, fonte: "metas", motivo: temAlgum("deshierarquiagrupo") ? "colunas Número do Processo e DES_HIERARQUIA_GRUPO" : "colunas Faixa da Meta e Data de Referência" };
  if (temAlgum("dataevento") && temProcesso) {
    const si = cab.findIndex((c) => norm(c) === "sistema"), mi = cab.findIndex((c) => norm(c) === "magistrado");
    const pj1 = si >= 0 ? linhas.filter((r) => /pje1g/i.test(norm(r[si])) && (mi < 0 || !vazio(r[mi]))).length : 0;
    if (si >= 0 && pj1 > 0 && pj1 >= linhas.length / 2) return { ...base, fonte: "sentencas1g", motivo: "Sistema = PJe1G com Magistrado preenchido" };
    if (temAlgum("codevento") || f.includes("acordao") || f.includes("julgamento")) return { ...base, fonte: "julgamentos", motivo: "colunas Data_Evento e Cod_Evento" };
  }
  if (temAlgum("numerodoprocesso", "numeroprocesso", "processo") && (temAlgum("tagsprocessolist", "nometarefa", "tarefaatual") || tem("classejudicial", "poloativo")))
    return { ...base, fonte: "pje", motivo: temAlgum("tagsprocessolist") ? "relação Triagem de gabinete do PJe" : "relação Acervo detalhado do PJe" };
  if (!temProcesso && (temAlgum("questao", "evento", "indicador") || filtros) && linhas.length)
    return { ...base, fonte: "indicadores", motivo: "planilha agregada, sem coluna de processo" };
  return { ...base, fonte: null, motivo: "formato não reconhecido" };
}

/* ───────── leitura das linhas → campos do padrão 1.0 ───────── */
type Campos = Importado & { processo: string };
type ModoCampo = "set" | "fill";
export type LinhaLida = { processo: string; campos: Record<string, unknown>; modo: Record<string, ModoCampo>; julgamento?: Record<string, unknown>; meta?: Record<string, unknown>; marcador?: string };

function getter(cab: string[]) {
  const idx = new Map<string, number>(); cab.forEach((c, i) => { const n = norm(c); if (n && !idx.has(n)) idx.set(n, i); });
  return (row: Celula[], ...nomes: string[]) => { for (const n of nomes) { const i = idx.get(n); if (i != null && !vazio(row[i])) return row[i]; } return undefined; };
}
const FILL = <T extends string>(...k: T[]) => Object.fromEntries(k.map((x) => [x, "fill" as ModoCampo]));

export function metaDoBi(v: unknown): { meta: string; confirmar: boolean } | null {
  const raw = String(v ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  const t = norm(v); if (!t) return null;
  const n = raw.match(/meta\s*0?(\d{1,2})(?!\d)/); if (!n) return null;
  const k = +n[1];
  if (k === 2) return /15anos/.test(t) ? { meta: "2b", confirmar: true } : { meta: "2a", confirmar: false };
  if (k === 6) return { meta: "6", confirmar: false };
  if (k === 7) return /indigen/.test(t) ? { meta: "7a", confirmar: false } : /quilomb/.test(t) ? { meta: "7b", confirmar: true } : /racis/.test(t) ? { meta: "7c", confirmar: true } : { meta: "7", confirmar: true };
  if (k === 4) return { meta: /4b|improb/.test(t) ? "4b" : "4a", confirmar: true };
  if (k === 10) return { meta: "10", confirmar: true };
  return { meta: String(k), confirmar: true };
}
const MARCADORES: Array<[RegExp, string]> = [
  [/^3\.01B$/, "sobrestado"], [/^3\.10[AE]$/, "sobrestado"], [/^3\.01C$/, "concluso"], [/^3\.05B$/, "ms-coletivo"], [/^3\.05E$/, "acp"],
  [/^3\.05G$/, "preferencia-legal"], [/^3\.11D$/, "ed-pendente"], [/^3\.18B$/, "julgado-12m"], [/^3\.18C$/, "baixado"],
];
export function marcadorDaQuestao(questao: unknown, descricao: unknown): string {
  const q = txt(questao), d = txt(descricao);
  let m = q.match(/(\d\.\d{2})\s*[-–.]?\s*([A-H])\b/i);
  const cod = m ? `${m[1]}${m[2].toUpperCase()}` : (() => { const n = q.match(/(\d\.\d{2})/); const l = d.match(/^\s*([A-H])\b/i) || q.match(/\b([A-H])\s*$/i); return n && l ? `${n[1]}${l[1].toUpperCase()}` : ""; })();
  if (!cod) return "";
  return MARCADORES.find(([re]) => re.test(cod))?.[1] || "";
}
const secaoDe = (v: unknown) => { const m = txt(v).match(/([1-4])\s*[ªaº°o]?\s*se[cç][aã]o/i); return m ? `${m[1]}ª Seção` : ""; };
const tipoJulgamento = (v: unknown) => { const t = norm(v); return /acordao/.test(t) ? "acórdão" : /terminativ/.test(t) ? "decisão terminativa" : /acordo/.test(t) ? "acordo homologado" : /senten/.test(t) ? "sentença" : limpo(v); };

export function lerLinhas(fonte: FonteId, l: Leitura): { linhas: LinhaLida[]; rejeitadas: number; referencia: string; indicadores?: Record<string, unknown> } {
  const g = getter(l.cabecalho);
  let referencia = "";
  const out: LinhaLida[] = []; let rejeitadas = 0;
  if (fonte === "indicadores") {
    const tabela = l.linhas.map((r) => Object.fromEntries(l.cabecalho.map((c, i) => [c || `col${i + 1}`, typeof r[i] === "number" ? r[i] : limpo(r[i])])));
    const H = new Set(l.cabecalho.map(norm));
    const tipo = H.has("questao") ? "questoes" : (H.has("evento") || H.has("indicador")) ? "eventos" : [...H].some((x) => x.includes("tempo")) ? "tempoMedio" : "outros";
    referencia = ultimaDataDoTexto(l.filtros);
    return { linhas: [], rejeitadas: 0, referencia, indicadores: { [tipo]: { filtros: l.filtros, cabecalho: l.cabecalho, linhas: tabela } } };
  }
  for (const r of l.linhas) {
    const processo = cnj(g(r, "processo", "numeroprocesso", "numerodoprocesso", "nprocesso"));
    if (!processo) { rejeitadas++; continue; }
    const c: Record<string, unknown> = {}; let modo: Record<string, ModoCampo> = {};
    const put = (k: string, v: unknown) => { if (v === undefined || v === null || v === "") return; if (typeof v === "string" && vazio(v)) return; c[k] = v; };
    const linha: LinhaLida = { processo, campos: c, modo };
    if (fonte === "tramitacao") {
      referencia ||= data(g(r, "datarelatorio"));
      put("dataDistribuicao", data(g(r, "distribuicao", "datadistribuicao")));
      const ds = data(g(r, "datasobrestamento")), ms = limpo(g(r, "motivosobrestamento"));
      if (ds || ms) put("sobrestamento", { data: ds, motivo: ms });
      put("pendentePrimeiroJulgamento", simNao(g(r, "sinpendente1julgamento", "pendente1julgamento")));
      put("conclusao", simNao(g(r, "conclusao")));
      put("dataConclusao", data(g(r, "dataconclusao")));
      put("classeCodigo", limpo(g(r, "codclasse", "codigoclasse")));
      put("classe", limpo(g(r, "classe")));
      put("assuntoCodigo", limpo(g(r, "codassuntoprincipal", "codigoassuntoprincipal")));
      put("assunto", limpo(g(r, "assuntoprincipal", "assunto")));
      put("assuntos", limpo(g(r, "assuntosprocesso", "assuntosdoprocesso")));
      put("nivelSigilo", limpo(g(r, "nivelsigilo")) || (simNao(g(r, "sigilo")) === "sim" ? "sigiloso" : ""));
      put("poloAtivo", limpo(g(r, "poloativo")));
      put("poloPassivo", limpo(g(r, "polopassivo")));
      put("valorCausa", limpo(g(r, "valorcausa", "valordacausa")));
      put("dataUltimaMovimentacao", data(g(r, "dataultimamovimentacao")));
      put("ultimaMovimentacao", limpo(g(r, "ultimamovimentacao")));
    } else if (fonte === "julgamentos") {
      const dj = data(g(r, "dataevento"));
      if (dj) linha.julgamento = { data: dj, tipo: tipoJulgamento(g(r, "indicador")), codEvento: limpo(g(r, "codevento")), resultado: limpo(g(r, "evento")), relator: limpo(g(r, "magistrado")) };
      put("dataDistribuicao", data(g(r, "distribuicao", "datadistribuicao")));
      put("classe", limpo(g(r, "classe"))); put("assunto", limpo(g(r, "assunto", "assuntoprincipal")));
      put("poloAtivo", limpo(g(r, "poloativo"))); put("poloPassivo", limpo(g(r, "polopassivo")));
      put("valorCausa", limpo(g(r, "valorcausa", "valordacausa"))); put("nivelSigilo", limpo(g(r, "nivelsigilo")));
      modo = FILL("dataDistribuicao", "classe", "assunto", "poloAtivo", "poloPassivo", "valorCausa", "nivelSigilo");
    } else if (fonte === "sentencas1g") {
      if (!/pje1g/i.test(norm(g(r, "sistema")))) { rejeitadas++; continue; }
      const pg = { juizo: limpo(g(r, "unidade")), juiz: limpo(g(r, "magistrado")), subsecao: limpo(g(r, "subsecao")), dataSentenca: data(g(r, "dataevento")), resultado: limpo(g(r, "evento")) };
      put("primeiroGrau", Object.fromEntries(Object.entries(pg).filter(([, v]) => v)));
      modo = FILL("primeiroGrau");
    } else if (fonte === "metas") {
      const ref = data(g(r, "datadereferencia")); if (ref) referencia ||= ref;
      const mt = metaDoBi(g(r, "deshierarquiagrupo", "faixadameta", "faixa"));
      if (mt) linha.meta = { meta: mt.meta, faixa: limpo(g(r, "deshierarquiagrupo", "faixadameta", "faixa")), confirmar: mt.confirmar };
      put("classe", limpo(g(r, "classe"))); put("assunto", limpo(g(r, "assunto")));
      put("dataDistribuicao", data(g(r, "datadedistribuicao", "datadistribuicao"))); put("ultimaMovimentacao", limpo(g(r, "ultimamovimentacao")));
      modo = FILL("classe", "assunto", "dataDistribuicao", "ultimaMovimentacao");
    } else if (fonte === "listagem") {
      put("secaoJulgadora", secaoDe(g(r, "orgaojulgador")));
      put("fase", limpo(g(r, "fase"))); put("dataFase", data(g(r, "datadafase", "datafase")));
      put("classeOrigem", limpo(g(r, "classedeorigem", "classeorigem")));
      put("dataDistribuicao", data(g(r, "datadedistribuicao", "datadistribuicao"))); put("dataConclusao", data(g(r, "datadaconclusao", "dataconclusao")));
      put("classe", limpo(g(r, "classe"))); put("assunto", limpo(g(r, "assunto")));
      put("ultimaMovimentacao", limpo(g(r, "ultimamovimentacao"))); put("dataUltimaMovimentacao", data(g(r, "datadaultimamovimentacao", "dataultimamovimentacao")));
      const mk = marcadorDaQuestao(g(r, "questao"), g(r, "descricaodaquestao", "descricaoquestao")); if (mk) linha.marcador = mk;
      modo = FILL("dataDistribuicao", "dataConclusao", "classe", "assunto", "ultimaMovimentacao", "dataUltimaMovimentacao");
    } else if (fonte === "pje") {
      put("tarefaAtual", limpo(g(r, "tarefaatual", "nometarefa")));
      put("dataEntradaTarefa", data(g(r, "dataentradatarefa", "datachegada")));
      const et = limpo(g(r, "etiquetas", "tagsprocessolist", "etiquetasatuais"));
      if (et) put("etiquetas", et);
      put("poloAtivo", limpo(g(r, "poloativo"))); put("poloPassivo", limpo(g(r, "polopassivo")));
      put("advogadoPoloAtivo", limpo(g(r, "advogadopa", "advogadopoloativo"))); put("advogadoPoloPassivo", limpo(g(r, "advogadopp", "advogadopolopassivo")));
      put("dpu", simNao(g(r, "dpu"))); put("mpf", simNao(g(r, "mpf"))); put("prioridade", simNao(g(r, "prioridade")));
      put("dataUltimaDistribuicao", data(g(r, "datadistribuicao")));
      put("dataDistribuicao1g", data(g(r, "dtdistribuicao1g")));
      put("classe", limpo(g(r, "classejudicial", "classe"))); put("assunto", limpo(g(r, "assuntojudicial", "assuntoprincipal")));
      put("valorCausa", limpo(g(r, "valorcausa")));
      const um = limpo(g(r, "descricaoultimomovimento", "ultimomovimento"));
      if (um && !data(um)) put("ultimaMovimentacao", um);
      put("dataUltimaMovimentacao", data(g(r, "ultimomovimento")) || data(g(r, "dataultimomovimento")));
      if (simNao(g(r, "sigiloso")) === "sim") put("nivelSigilo", "sigiloso");
      modo = FILL("classe", "assunto", "valorCausa", "nivelSigilo");
    }
    linha.modo = modo;
    out.push(linha);
  }
  referencia ||= ultimaDataDoTexto(l.filtros);
  return { linhas: out, rejeitadas, referencia };
}

/* ───────── mescla com prioridade entre fontes ───────── */
const DONO_PJE = new Set(["tarefaAtual", "dataEntradaTarefa", "etiquetas", "poloAtivo", "poloPassivo", "advogadoPoloAtivo", "advogadoPoloPassivo"]);
const DONO_BI = new Set(["classeCodigo", "assuntoCodigo", "conclusao", "dataConclusao", "sobrestamento", "secaoJulgadora", "dataDistribuicao"]);
const ORIGEM_DATAJUD = "DataJud";

function prioridadeDoCampo(campo: string, fonte: string): number {
  const familia = FONTES[fonte as FonteId]?.familia;
  if (!familia) return -1;
  if (DONO_PJE.has(campo)) return familia === "pje" ? 3 : 2;
  if (DONO_BI.has(campo)) return familia === "bi" ? 3 : 2;
  return familia === "pje" ? 3 : 2;
}

function mesmaOrigem(left: unknown, right: unknown): boolean {
  return JSON.stringify(left ?? null) === JSON.stringify(right ?? null);
}

/** Complementa o registro com DataJud, preservando fontes prioritárias e registrando divergências. */
export function aplicarDataJudAoImportado(
  atual: Importado,
  campos: Record<string, unknown>,
  agora: string,
): { importado: Importado; changed: boolean } {
  const imp = JSON.parse(JSON.stringify(atual || {})) as Importado;
  const origens = (imp.origens && typeof imp.origens === "object" ? imp.origens : {}) as Record<string, { fonte?: string; em?: string; referencia?: string }>;
  const divergencias = Array.isArray(imp.divergencias) ? [...imp.divergencias as Divergencia[]] : [];
  let changed = false;
  const dNova = data(campos.dataUltimaMovimentacao);
  const dAtual = data(imp.dataUltimaMovimentacao);
  const temMovimentoAtual = !vazioValor(imp.ultimaMovimentacao) || !vazioValor(imp.dataUltimaMovimentacao);
  const movimentoMaisNovo = !!dNova && !!dAtual && dNova > dAtual;
  const completaMovimentoNaMesmaData =
    vazioValor(imp.ultimaMovimentacao) && !!dNova && !!dAtual && dNova === dAtual;
  const referencia = dNova || agora.slice(0, 10);

  const registrarDivergencia = (campo: string, valor: unknown, mantido: unknown) => {
    const existe = divergencias.some((item) =>
      item.campo === campo && item.fonte === ORIGEM_DATAJUD &&
      mesmaOrigem(item.valor, valor) && mesmaOrigem(item.mantido, mantido)
    );
    if (!existe) {
      divergencias.push({ campo, valor, fonte: ORIGEM_DATAJUD, em: referencia, mantido });
      changed = true;
    }
  };
  const gravar = (campo: string, valor: unknown) => {
    imp[campo] = JSON.parse(JSON.stringify(valor));
    origens[campo] = { fonte: ORIGEM_DATAJUD, em: agora, referencia };
    changed = true;
  };

  const entradaDataJud = campos.datajud as Record<string, unknown> | undefined;
  const docsAnteriores = Array.isArray((imp.datajud as Record<string, unknown> | undefined)?.documentos)
    ? (imp.datajud as Record<string, unknown>).documentos as Array<Record<string, unknown>>
    : [];
  const docsNovos = Array.isArray(entradaDataJud?.documentos)
    ? entradaDataJud.documentos as Array<Record<string, unknown>>
    : [];
  const timestamp = (value: unknown) => {
    const text = String(value ?? "").trim();
    const compact = text.match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/);
    if (compact) return Date.UTC(+compact[1], +compact[2] - 1, +compact[3], +compact[4], +compact[5], +compact[6]);
    const parsed = Date.parse(text);
    return Number.isFinite(parsed) ? parsed : 0;
  };
  const anteriorPorId = new Map(docsAnteriores.map((doc, index) => [String(doc.id || doc.grau || index), doc]));
  const respostaInteiraAntiga = docsNovos.length > 0 && docsNovos.every((doc, index) => {
    const anterior = anteriorPorId.get(String(doc.id || doc.grau || index));
    const dataAnterior = timestamp(anterior?.dataCarga || anterior?.dataHoraUltimaAtualizacao);
    const dataNova = timestamp(doc.dataCarga || doc.dataHoraUltimaAtualizacao);
    return !!anterior && !!dataAnterior && !!dataNova && dataNova < dataAnterior;
  });
  if (docsNovos.length) {
    const documentos = new Map<string, Record<string, unknown>>();
    for (const doc of docsAnteriores) documentos.set(String(doc.id || doc.grau || documentos.size), doc);
    for (const doc of docsNovos) {
      const chave = String(doc.id || doc.grau || documentos.size);
      const anterior = documentos.get(chave);
      const dataAnterior = timestamp(anterior?.dataCarga || anterior?.dataHoraUltimaAtualizacao);
      const dataNova = timestamp(doc.dataCarga || doc.dataHoraUltimaAtualizacao);
      if (anterior && dataAnterior && dataNova && dataNova < dataAnterior) continue;
      documentos.set(chave, doc);
    }
    const lista = [...documentos.values()];
    const porData = (a: unknown, b: unknown) => {
      return timestamp(b) - timestamp(a);
    };
    const movimentosUnicos = new Map<string, Record<string, unknown>>();
    const movimentosEntrada: Array<Record<string, unknown>> = [];
    for (const doc of lista) {
      const doDocumento = Array.isArray(doc.movimentos) ? doc.movimentos as Array<Record<string, unknown>> : [];
      for (const mov of doDocumento) movimentosEntrada.push({ ...mov, grau: String(doc.grau || "") });
    }
    for (const mov of movimentosEntrada) {
      const chave = [mov.dataHora, mov.codigo, mov.nome, mov.grau].map(String).join("|");
      if (!movimentosUnicos.has(chave)) movimentosUnicos.set(chave, mov);
    }
    const movimentos = [...movimentosUnicos.values()].sort((a, b) => porData(a.dataHora, b.dataHora)).slice(0, 20);
    const docMaisRecente = [...lista].sort((a, b) =>
      porData(a.dataCarga || a.dataHoraUltimaAtualizacao, b.dataCarga || b.dataHoraUltimaAtualizacao)
    )[0];
    const blocoDataJud = {
      documentos: lista,
      movimentos,
      ultimaMovimentacao: movimentos[0] || null,
      orgaoJulgador: docMaisRecente?.orgaoJulgador || null,
      nivelSigilo: docMaisRecente?.nivelSigilo ?? null,
      dataHoraUltimaAtualizacao: docMaisRecente?.dataHoraUltimaAtualizacao || null,
      dataCarga: docMaisRecente?.dataCarga || null,
    };
    if (!mesmaOrigem(imp.datajud, blocoDataJud)) {
      imp.datajud = blocoDataJud;
      changed = true;
    }
  }

  for (const [campo, valor] of Object.entries(campos)) {
    if (campo === "datajud") continue;
    if (respostaInteiraAntiga) continue;
    if (vazioValor(valor)) continue;
    const atualCampo = imp[campo];
    if (vazioValor(atualCampo)) {
      const campoDeMovimento = campo === "ultimaMovimentacao" || campo === "dataUltimaMovimentacao";
      const podeCompletarMovimento = !temMovimentoAtual || movimentoMaisNovo ||
        (campo === "ultimaMovimentacao" && completaMovimentoNaMesmaData);
      if (!campoDeMovimento || podeCompletarMovimento) gravar(campo, valor);
      else registrarDivergencia(campo, valor, atualCampo ?? "");
      continue;
    }
    if (mesmaOrigem(atualCampo, valor)) continue;

    if (campo === "ultimaMovimentacao" || campo === "dataUltimaMovimentacao") {
      if (movimentoMaisNovo) gravar(campo, valor);
      else registrarDivergencia(campo, valor, atualCampo);
      continue;
    }
    if (origens[campo]?.fonte === ORIGEM_DATAJUD) {
      gravar(campo, valor);
      continue;
    }
    registrarDivergencia(campo, valor, atualCampo);
  }

  const fontes = new Set(Array.isArray(imp.fontes) ? imp.fontes as string[] : []);
  if (!fontes.has(ORIGEM_DATAJUD)) {
    fontes.add(ORIGEM_DATAJUD);
    imp.fontes = [...fontes];
    changed = true;
  }
  if (Object.keys(origens).length && !mesmaOrigem(imp.origens, origens)) {
    imp.origens = origens;
    changed = true;
  }
  if (divergencias.length) {
    const limitadas = divergencias.slice(-30);
    if (!mesmaOrigem(imp.divergencias, limitadas)) {
      imp.divergencias = limitadas;
      changed = true;
    }
  }
  if (changed) {
    imp.atualizadoEm = agora;
    imp.dataJudAtualizadoEm = agora;
  }
  return { importado: imp, changed };
}

/** onde cada campo aparece no app — a prévia separa as mudanças por destino */
export const DESTINOS: Record<string, string[]> = {
  dataDistribuicao: ["pauta", "metas", "decisoes", "triagem"], dataUltimaDistribuicao: ["ficha"], dataDistribuicao1g: ["ficha"],
  sobrestamento: ["metas", "triagem", "pauta"], pendentePrimeiroJulgamento: ["pauta"], conclusao: ["decisoes", "triagem"], dataConclusao: ["decisoes", "triagem"],
  classe: ["pauta", "triagem", "metas", "decisoes"], classeCodigo: ["pauta"], assunto: ["pauta", "triagem", "metas", "decisoes", "materias"], assuntoCodigo: ["materias"], assuntos: ["materias"],
  nivelSigilo: ["triagem"], poloAtivo: ["pauta", "triagem", "metas", "decisoes"], poloPassivo: ["pauta", "triagem", "metas", "decisoes"], advogadoPoloAtivo: ["ficha"], advogadoPoloPassivo: ["ficha"],
  valorCausa: ["ficha"], dataUltimaMovimentacao: ["pauta", "decisoes", "triagem"], ultimaMovimentacao: ["pauta", "decisoes", "triagem"],
  julgamentos: ["pauta", "metas", "decisoes"], primeiroGrau: ["ficha", "triagem", "pauta"], metas: ["metas", "pauta", "triagem"], secaoJulgadora: ["pauta", "triagem", "materias"],
  marcadores: ["pauta", "triagem", "metas"], fase: ["ficha"], dataFase: ["ficha"], classeOrigem: ["triagem"], tarefaAtual: ["pauta", "triagem", "decisoes"], dataEntradaTarefa: ["pauta", "triagem", "decisoes"],
  etiquetas: ["pauta", "triagem"], dpu: ["pauta", "triagem"], mpf: ["pauta", "triagem"], prioridade: ["triagem", "pauta"],
};
export const DESTINO_ROTULO: Record<string, string> = { pauta: "Pauta", triagem: "Triagem", metas: "Metas", decisoes: "Decisões", materias: "Matérias", ficha: "Ficha do processo" };

const igual = (a: unknown, b: unknown) => (typeof a === "object" || typeof b === "object") ? JSON.stringify(a ?? null) === JSON.stringify(b ?? null) : norm(a) === norm(b);
const vazioValor = (v: unknown) => v == null || (typeof v === "string" ? vazio(v) : typeof v === "object" ? !Object.values(v as object).some((x) => !vazio(x)) : false);

export type Mudanca = { campo: string; de: unknown; para: unknown };
export type Divergencia = { campo: string; valor: unknown; fonte: string; em: string; mantido: unknown };
export type ResultadoProcesso = { processo: string; novo: boolean; mudancas: Mudanca[]; divergencias: Divergencia[]; situacaoDe: string; situacaoPara: string; depois: AcervoAtual };

function situacaoDe(imp: Importado): string {
  const mk = Array.isArray(imp.marcadores) ? imp.marcadores as string[] : [];
  if (mk.includes("baixado")) return "baixado";
  const sob = imp.sobrestamento as { data?: string } | undefined;
  if ((sob && sob.data) || mk.includes("sobrestado")) return "sobrestado";
  const js = Array.isArray(imp.julgamentos) ? imp.julgamentos as Array<{ data?: string; tipo?: string }> : [];
  const ref = String(imp.dataUltimaDistribuicao || imp.dataDistribuicao || "");
  if (js.some((j) => j.data && (!ref || j.data >= ref) && j.tipo !== "sentença")) return "julgado";
  return "em tramitação";
}

export function mesclar(atual: AcervoAtual | null, lidas: LinhaLida[], fonte: FonteId, referencia: string, agora: string): ResultadoProcesso {
  const processo = (atual?.processo || lidas[0].processo);
  const imp: Importado = JSON.parse(JSON.stringify(atual?.importado || { versao: "1.0", id: `acv-${processo.replace(/\D/g, "")}`, processo }));
  imp.versao ||= "1.0"; imp.processo = processo; imp.id ||= `acv-${processo.replace(/\D/g, "")}`;
  const origens = (imp.origens && typeof imp.origens === "object" ? imp.origens : {}) as Record<string, { fonte: string; em: string; referencia?: string }>;
  const divs: Divergencia[] = [], mud: Mudanca[] = [];
  const fam = FONTES[fonte].familia, rot = FONTES[fonte].rotulo;
  const marca = (campo: string) => { origens[campo] = { fonte, em: agora, ...(referencia ? { referencia } : {}) }; };
  for (const l of lidas) {
    const dataMovimentacaoAnterior = data(imp.dataUltimaMovimentacao);
    const temMovimentacaoAnterior = !vazioValor(imp.ultimaMovimentacao) || !vazioValor(imp.dataUltimaMovimentacao);
    const movimentoMaisNovo = !!data(l.campos.dataUltimaMovimentacao) &&
      !!dataMovimentacaoAnterior && data(l.campos.dataUltimaMovimentacao) > dataMovimentacaoAnterior;
    const completaMovimentoNaMesmaData =
      vazioValor(imp.ultimaMovimentacao) &&
      !!data(l.campos.dataUltimaMovimentacao) &&
      !!dataMovimentacaoAnterior &&
      data(l.campos.dataUltimaMovimentacao) === dataMovimentacaoAnterior;
    for (const [campo, valor] of Object.entries(l.campos)) {
      if (vazioValor(valor)) continue;
      const cur = imp[campo];
      if (vazioValor(cur)) {
        const campoDeMovimento = campo === "ultimaMovimentacao" || campo === "dataUltimaMovimentacao";
        const podeCompletarMovimento = !temMovimentacaoAnterior || movimentoMaisNovo ||
          (campo === "ultimaMovimentacao" && completaMovimentoNaMesmaData);
        if (!campoDeMovimento || podeCompletarMovimento) {
          mud.push({ campo, de: cur ?? "", para: valor });
          imp[campo] = valor;
          marca(campo);
        }
        continue;
      }
      if (igual(cur, valor)) continue;
      const origemAtual = String(origens[campo]?.fonte || "");
      const perde = (manter: boolean) => {
        if (manter) {
          divs.push({ campo, valor, fonte: rot, em: referencia || agora.slice(0, 10), mantido: cur });
        } else {
          divs.push({ campo, valor: cur, fonte: FONTES[origemAtual as FonteId]?.rotulo || origemAtual || "anterior",
            em: origens[campo]?.referencia || origens[campo]?.em?.slice(0, 10) || "", mantido: valor });
          mud.push({ campo, de: cur, para: valor });
          imp[campo] = valor;
          marca(campo);
        }
      };
      if (campo === "ultimaMovimentacao" || campo === "dataUltimaMovimentacao") {
        if (movimentoMaisNovo) {
          perde(false);
        } else {
          perde(true);
        }
        continue;
      }
      const fonteAtualConhecida = origemAtual === ORIGEM_DATAJUD || !!FONTES[origemAtual as FonteId];
      const prioridadeAtual = fonteAtualConhecida ? prioridadeDoCampo(campo, origemAtual) : 4;
      const prioridadeNova = prioridadeDoCampo(campo, fonte);
      if (prioridadeNova < prioridadeAtual ||
          (l.modo[campo] === "fill" && prioridadeNova < 3)) {
        perde(true);
        continue;
      }
      if (prioridadeNova > prioridadeAtual) {
        perde(false);
        continue;
      }
      mud.push({ campo, de: cur, para: valor }); imp[campo] = valor; marca(campo);
    }
    if (l.julgamento) {
      const js = Array.isArray(imp.julgamentos) ? [...imp.julgamentos as Array<Record<string, unknown>>] : [];
      const k = `${l.julgamento.data}|${l.julgamento.codEvento || l.julgamento.resultado}`;
      if (!js.some((j) => `${j.data}|${j.codEvento || j.resultado}` === k)) { js.push(l.julgamento); js.sort((a, b) => String(a.data).localeCompare(String(b.data))); mud.push({ campo: "julgamentos", de: imp.julgamentos ?? [], para: js }); imp.julgamentos = js; marca("julgamentos"); }
    }
  }
  if (fonte === "metas") {
    const novas: Array<Record<string, unknown>> = lidas.filter((l) => l.meta).map((l) => ({ ...(l.meta as Record<string, unknown>), referencia }));
    const antes = Array.isArray(imp.metas) ? imp.metas as Array<Record<string, unknown>> : [];
    const fora = antes.filter((m) => !novas.some((n) => n.meta === m.meta));
    const prox: Array<Record<string, unknown>> = [...novas.filter((n, i, a) => a.findIndex((x) => x.meta === n.meta) === i), ...fora.map((m) => ({ ...m, ausenteDesde: m.ausenteDesde || referencia }))];
    if (!igual(antes.map((m) => m.meta).sort(), prox.map((m) => m.meta).sort()) || novas.length) { if (!igual(antes, prox)) mud.push({ campo: "metas", de: antes, para: prox }); imp.metas = prox; marca("metas"); }
  }
  if (fonte === "listagem") {
    const mk = [...new Set(lidas.map((l) => l.marcador).filter(Boolean) as string[])].sort();
    const antes = Array.isArray(imp.marcadores) ? imp.marcadores as string[] : [];
    if (!igual([...antes].sort(), mk)) { mud.push({ campo: "marcadores", de: antes, para: mk }); imp.marcadores = mk; marca("marcadores"); }
  }
  const fontes = new Set(Array.isArray(imp.fontes) ? imp.fontes as string[] : []); fontes.add(rot); imp.fontes = [...fontes];
  const nc = (imp.naoConsta && typeof imp.naoConsta === "object" ? imp.naoConsta : {}) as Record<string, string>;
  if (nc[fonte]) { delete nc[fonte]; imp.naoConsta = nc; }
  if (divs.length) imp.divergencias = [...(Array.isArray(imp.divergencias) ? imp.divergencias as Divergencia[] : []), ...divs].slice(-30);
  imp.origens = origens;
  if (mud.length) imp.atualizadoEm = agora;
  const sitDe = atual?.situacao || "", sitPara = situacaoDe(imp);
  const hist = [...(atual?.historicoSituacao || [])];
  if (sitPara !== sitDe) hist.push({ situacao: sitPara, de: sitDe || null, em: referencia || agora.slice(0, 10), fonte: rot, registradoEm: agora });
  return { processo, novo: !atual, mudancas: mud, divergencias: divs, situacaoDe: sitDe, situacaoPara: sitPara, depois: { processo, importado: imp, situacao: sitPara, historicoSituacao: hist.slice(-50) } };
}

/** Um processo ausente de um relatório completo fica com "não consta em fonte X desde a data Y" (nunca é apagado). */
export function marcarAusente(atual: AcervoAtual, fonte: FonteId, referencia: string): AcervoAtual | null {
  const nc = { ...((atual.importado.naoConsta as Record<string, string>) || {}) };
  if (nc[fonte]) return null;
  nc[fonte] = referencia;
  return { ...atual, importado: { ...atual.importado, naoConsta: nc } };
}

/* ───────── prévia ───────── */
export type Previa = {
  fonte: FonteId; rotulo: string; motivo: string; arquivo: string; referencia: string; filtros: string; cabecalhoLinha: number;
  linhas: number; rejeitadas: number; processos: number; novos: number; atualizados: number; iguais: number; divergencias: number; ausentes: number;
  situacoes: Record<string, number>; porDestino: Record<string, { rotulo: string; processos: number }>; metasRevisar: number;
  amostra: Array<{ processo: string; novo: boolean; mudancas: Mudanca[]; divergencias: Divergencia[]; situacao?: string }>;
  indicadores?: Record<string, unknown>; assinatura: string;
};
export type Calculo = { previa: Previa; gravar: AcervoAtual[]; indicadores?: Record<string, unknown> };

export function calcular(matriz: Matriz, arquivo: string, atuais: Map<string, AcervoAtual>, agora: string, forcarFonte?: FonteId | null): Calculo | { erro: string; leitura: Pick<Leitura, "fonte" | "motivo" | "cabecalho" | "filtros"> } {
  const l = reconhecer(matriz);
  const fonte = forcarFonte && FONTES[forcarFonte] ? forcarFonte : l.fonte;
  if (!fonte) return { erro: "Formato não reconhecido: confira se a planilha é a relação do PJe ou um dos relatórios do BI.", leitura: { fonte: l.fonte, motivo: l.motivo, cabecalho: l.cabecalho.slice(0, 40), filtros: l.filtros } };
  const lido = lerLinhas(fonte, l);
  const referencia = lido.referencia || agora.slice(0, 10);
  const grupos = new Map<string, LinhaLida[]>();
  for (const x of lido.linhas) { const a = grupos.get(x.processo); if (a) a.push(x); else grupos.set(x.processo, [x]); }
  const gravar: AcervoAtual[] = []; const amostra: Previa["amostra"] = [];
  const porDestino: Record<string, Set<string>> = {}; const situacoes: Record<string, number> = {};
  let novos = 0, atualizados = 0, iguais = 0, divergencias = 0, ausentes = 0, metasRevisar = 0;
  for (const [proc, ls] of grupos) {
    const r = mesclar(atuais.get(proc) || null, ls, fonte, referencia, agora);
    if (r.novo) novos++; else if (r.mudancas.length || r.situacaoDe !== r.situacaoPara) atualizados++; else iguais++;
    divergencias += r.divergencias.length;
    if (ls.some((x) => (x.meta as { confirmar?: boolean } | undefined)?.confirmar)) metasRevisar++;
    if (r.situacaoDe !== r.situacaoPara && r.situacaoDe) situacoes[r.situacaoPara] = (situacoes[r.situacaoPara] || 0) + 1;
    for (const m of r.mudancas) for (const d of DESTINOS[m.campo] || ["ficha"]) (porDestino[d] ||= new Set()).add(proc);
    if (r.novo || r.mudancas.length || r.divergencias.length || r.situacaoDe !== r.situacaoPara || ls.length) gravar.push(r.depois);
    if ((r.novo || r.mudancas.length || r.divergencias.length) && amostra.length < 60) amostra.push({ processo: proc, novo: r.novo, mudancas: r.mudancas.slice(0, 12), divergencias: r.divergencias.slice(0, 6), ...(r.situacaoDe !== r.situacaoPara ? { situacao: `${r.situacaoDe || "—"} → ${r.situacaoPara}` } : {}) });
  }
  if (FONTES[fonte].completa && grupos.size) {
    for (const [proc, a] of atuais) {
      if (grupos.has(proc) || a.situacao === "baixado") continue;
      if (fonte === "metas" && !(Array.isArray(a.importado.metas) && (a.importado.metas as unknown[]).length)) continue;
      const m = marcarAusente(a, fonte, referencia); if (m) { gravar.push(m); ausentes++; }
    }
  }
  const assinatura = `${fonte}|${referencia}|${lido.linhas.length}|${grupos.size}|${novos}|${atualizados}|${divergencias}`;
  const previa: Previa = {
    fonte, rotulo: FONTES[fonte].rotulo, motivo: forcarFonte && forcarFonte !== l.fonte ? `escolhida manualmente (${l.motivo})` : l.motivo, arquivo, referencia, filtros: l.filtros, cabecalhoLinha: l.cabecalhoLinha,
    linhas: l.linhas.length, rejeitadas: lido.rejeitadas, processos: grupos.size, novos, atualizados, iguais, divergencias, ausentes, situacoes, metasRevisar,
    porDestino: Object.fromEntries(Object.entries(porDestino).map(([k, v]) => [k, { rotulo: DESTINO_ROTULO[k] || k, processos: v.size }])),
    amostra, ...(lido.indicadores ? { indicadores: { tipos: Object.keys(lido.indicadores), linhas: l.linhas.length } } : {}), assinatura,
  };
  return { previa, gravar, ...(lido.indicadores ? { indicadores: lido.indicadores } : {}) };
}

/** Mensagem de commit legível para a atualização de banco/acervo.json. */
export function mensagemCommit(p: Pick<Previa, "rotulo" | "referencia" | "novos" | "atualizados" | "situacoes">): string {
  const ref = p.referencia ? ` ${p.referencia.slice(8, 10)}/${p.referencia.slice(5, 7)}` : "";
  const partes = [`${p.novos} novo${p.novos === 1 ? "" : "s"}`, `${p.atualizados} atualizado${p.atualizados === 1 ? "" : "s"}`];
  if (p.situacoes.baixado) partes.push(`${p.situacoes.baixado} baixado${p.situacoes.baixado === 1 ? "" : "s"}`);
  if (p.situacoes.julgado) partes.push(`${p.situacoes.julgado} julgado${p.situacoes.julgado === 1 ? "" : "s"}`);
  return `Fontes · ${p.rotulo.replace(/^BI · /, "BI ")}${ref} · ${partes.join(", ")}`;
}

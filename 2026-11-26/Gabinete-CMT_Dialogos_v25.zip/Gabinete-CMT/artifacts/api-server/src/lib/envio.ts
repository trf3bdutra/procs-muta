/**
 * Envio de mensagens do gabinete: e-mail pelo AgentMail e SMS/WhatsApp pela Twilio.
 *
 * Chaves só no servidor:
 *   e-mail   caixa gabinete-cmt@agentmail.to e AGENTMAIL_MAIL_KEY (somente no servidor)
 *   Twilio   TWILIO_ACCOUNT_SID e TWILIO_AUTH_TOKEN — ou uma API key
 *            (TWILIO_API_KEY_SID "SK…" + TWILIO_API_KEY / TWILIO_API_KEY_SECRET);
 *            os números de origem vêm da configuração da Comunicação (ou de TWILIO_SMS_FROM / TWILIO_WHATSAPP_FROM)
 */

export type Canal = "email" | "sms" | "whatsapp";
export type Destinatario = { nome?: string; email?: string; tel?: string };
export type ResultadoEnvio = { canal: Canal; para: string; ok: boolean; erro?: string };

const env = (k: string) => process.env[k]?.trim() || "";

/** Chave exclusiva da caixa de comunicação; nunca reutilizar a chave de solicitações. */
export const chaveEmail = () => env("AGENTMAIL_MAIL_KEY");
export const caixaEmail = () => "gabinete-cmt@agentmail.to";

/** Credencial da Twilio: API key (SID começando por "SK" + segredo) ou, senão, Account SID + Auth Token. */
export function credencialTwilio(): { conta: string; usuario: string; senha: string } | null {
  const conta = env("TWILIO_ACCOUNT_SID");
  if (!conta) return null;
  const kSid = env("TWILIO_API_KEY_SID");
  const kSec = env("TWILIO_API_KEY_SECRET") || env("TWILIO_API_KEY");
  if (/^SK[0-9a-f]{32}$/i.test(kSid) && kSec) return { conta, usuario: kSid, senha: kSec };
  const token = env("TWILIO_AUTH_TOKEN");
  return token ? { conta, usuario: conta, senha: token } : null;
}

const origemPadrao = (o: { smsNumber?: string; whatsappNumber?: string }) => ({
  smsNumber: o.smsNumber || env("TWILIO_SMS_FROM"),
  whatsappNumber: o.whatsappNumber || env("TWILIO_WHATSAPP_FROM"),
});

export function canaisDisponiveis(origem: { smsNumber?: string; whatsappNumber?: string; ativo?: boolean }): Record<Canal, boolean> {
  const twilio = Boolean(credencialTwilio());
  const o = origemPadrao(origem);
  return {
    email: Boolean(chaveEmail()),
    sms: twilio && Boolean(o.smsNumber),
    whatsapp: twilio && Boolean(o.whatsappNumber),
  };
}

export const emailValido = (v: string) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v);
/** Telefone no formato da Twilio (E.164). Números brasileiros sem DDI ganham +55. */
export function telefoneE164(v: string): string {
  const d = String(v || "").replace(/\D/g, "");
  if (!d) return "";
  if (String(v).trim().startsWith("+")) return `+${d}`;
  return d.length >= 10 && d.length <= 11 ? `+55${d}` : `+${d}`;
}

export async function enviarEmail(para: string[], assunto: string, texto: string, idempotencyKey?: string): Promise<void> {
  const inbox = caixaEmail();
  const key = chaveEmail();
  if (!key) throw new Error("Envio de e-mail não configurado no servidor (AGENTMAIL_MAIL_KEY).");
  const headers: Record<string, string> = { "Content-Type": "application/json", Authorization: `Bearer ${key}` };
  if (idempotencyKey) headers["Idempotency-Key"] = idempotencyKey;
  const r = await fetch(`https://api.agentmail.to/v0/inboxes/${encodeURIComponent(inbox)}/messages/send`, {
    method: "POST",
    signal: AbortSignal.timeout(20e3),
    headers,
    body: JSON.stringify({ to: para, subject: assunto.slice(0, 250), text: texto, labels: ["gabcmt-comunicacao"] }),
  });
  if (!r.ok) throw new Error(`AgentMail recusou o envio (HTTP ${r.status}).`);
}

export type TwilioTemplate = { contentSid: string; variables?: Record<string, string> };

/** ContentSid replaces Body; never combine a template with a free-form message. */
export function twilioMessageForm(
  canal: "sms" | "whatsapp", de: string, para: string, texto: string, template?: TwilioTemplate,
  mediaUrls: string[] = [],
): URLSearchParams {
  const prefix = canal === "whatsapp" ? "whatsapp:" : "";
  const corpo = new URLSearchParams({
    From: prefix + telefoneE164(de.replace(/^whatsapp:/i, "")),
    To: prefix + telefoneE164(para.replace(/^whatsapp:/i, "")),
  });
  if (template) {
    if (mediaUrls.length) throw new Error("Um modelo e anexos de mídia não podem ser combinados neste envio.");
    if (canal !== "whatsapp" || !/^HX[0-9a-f]{32}$/i.test(template.contentSid)) throw new Error("Modelo WhatsApp inválido.");
    const entries = Object.entries(template.variables || {});
    if (entries.length > 100 || entries.some(([key, value]) => !/^[1-9]\d*$/.test(key) || typeof value !== "string" || !value.trim() || value.length > 1500)) {
      throw new Error("Variáveis do modelo inválidas. Use chaves numéricas e valores de texto preenchidos.");
    }
    corpo.set("ContentSid", template.contentSid);
    if (entries.length) corpo.set("ContentVariables", JSON.stringify(template.variables));
  } else {
    if (!texto.trim()) throw new Error("A mensagem não pode estar vazia.");
    if (texto.length > 1600 || (mediaUrls.length && canal === "whatsapp" && texto.length > 1024)) {
      throw new Error(mediaUrls.length ? "A legenda da imagem excede 1.024 caracteres." : "A mensagem excede 1.600 caracteres.");
    }
    corpo.set("Body", texto);
  }
  if (mediaUrls.length > 10) throw new Error("O envio aceita até 10 anexos.");
  for (const raw of mediaUrls) {
    let parsed: URL;
    try { parsed = new URL(raw); } catch { throw new Error("A URL da mídia é inválida."); }
    if (parsed.protocol !== "https:") throw new Error("A mídia do WhatsApp precisa estar em uma URL HTTPS.");
    corpo.append("MediaUrl", raw);
  }
  return corpo;
}

export async function enviarTwilio(
  canal: "sms" | "whatsapp", de: string, para: string, texto: string,
  template?: TwilioTemplate, mediaUrls: string[] = [],
): Promise<{ sid: string; status: string }> {
  const cred = credencialTwilio();
  if (!cred) throw new Error("Twilio não configurada no servidor (TWILIO_ACCOUNT_SID e TWILIO_AUTH_TOKEN).");
  de = de || env(canal === "whatsapp" ? "TWILIO_WHATSAPP_FROM" : "TWILIO_SMS_FROM");
  if (!de) throw new Error(`Número de ${canal === "whatsapp" ? "WhatsApp" : "SMS"} do gabinete não informado na Comunicação.`);
  const corpo = twilioMessageForm(canal, de, para, texto, template, mediaUrls);
  const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(cred.conta)}/Messages.json`, {
    method: "POST",
    signal: AbortSignal.timeout(20e3),
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Authorization: `Basic ${Buffer.from(`${cred.usuario}:${cred.senha}`).toString("base64")}`,
    },
    body: corpo.toString(),
  });
  if (!r.ok) {
    const j = (await r.json().catch(() => ({}))) as { code?: number };
    const explanations: Record<number, string> = {
      63016: "Fora da janela de conversa do WhatsApp. Escolha um modelo aprovado pela Meta, em vez de texto livre.",
      63015: "O destinatário precisa aderir ao Sandbox do WhatsApp desta conta Twilio antes do teste.",
      63007: "O número de origem não está habilitado como remetente WhatsApp nesta conta.",
      21608: "A conta Twilio de teste só pode enviar para destinatários verificados.",
      21656: "As variáveis não correspondem ao modelo Twilio selecionado.",
      21654: "Confira o ContentSid e a aprovação do modelo para WhatsApp.",
    };
    // Never echo provider messages that may contain message contents or contact details.
    const detail = j.code && explanations[j.code] ? explanations[j.code] : "Confira o remetente, as credenciais e a configuração do modelo na Twilio.";
    throw new Error(`Twilio recusou o envio (HTTP ${r.status}${j.code ? `, código ${j.code}` : ""}). ${detail}`);
  }
  const message = await r.json() as { sid?: string; status?: string };
  if (!message.sid || ["failed", "undelivered", "canceled"].includes(message.status || "")) {
    throw new Error("A Twilio não confirmou a aceitação da mensagem.");
  }
  return { sid: message.sid, status: message.status || "accepted" };
}

/** Avisa cada destinatário por cada canal pedido; quem não tem o contato daquele canal é pulado e informado. */
export async function avisar(
  canais: Canal[],
  destinatarios: Destinatario[],
  titulo: string,
  texto: string,
  origem: { smsNumber?: string; whatsappNumber?: string },
): Promise<ResultadoEnvio[]> {
  const out: ResultadoEnvio[] = [];
  const corpoCurto = `${titulo}\n${texto}`.trim();
  if (canais.includes("email")) {
    const emails = [...new Set(destinatarios.map((d) => String(d.email || "").trim()).filter(emailValido))];
    for (const e of emails) {
      try { await enviarEmail([e], titulo, texto); out.push({ canal: "email", para: e, ok: true }); }
      catch (err) { out.push({ canal: "email", para: e, ok: false, erro: (err as Error).message }); }
    }
  }
  for (const canal of ["sms", "whatsapp"] as const) {
    if (!canais.includes(canal)) continue;
    const tels = [...new Set(destinatarios.map((d) => telefoneE164(String(d.tel || ""))).filter((t) => t.length >= 12))];
    for (const t of tels) {
      try {
        await enviarTwilio(canal, canal === "whatsapp" ? origem.whatsappNumber || "" : origem.smsNumber || "", t, corpoCurto);
        out.push({ canal, para: t, ok: true });
      } catch (err) { out.push({ canal, para: t, ok: false, erro: (err as Error).message }); }
    }
  }
  return out;
}

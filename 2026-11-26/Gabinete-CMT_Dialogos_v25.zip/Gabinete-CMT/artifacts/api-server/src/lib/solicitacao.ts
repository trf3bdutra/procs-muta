/**
 * Leitura da solicitação contida numa mensagem (e-mail, SMS ou WhatsApp).
 *
 * Baseado no leitor do AppRegional TRgMS (server/agentmail.ts › parseEmailRequest): primeiro os campos do
 * formulário padronizado ("Tipo de solicitação:", "Número do processo:", "Advogado:", ...), depois a leitura
 * livre do assunto e do corpo. Aqui o resultado é só informativo: quem decide aplicar ao card é a equipe
 * ou o vínculo automático por CNJ único (agentmail-carlos-muta.ts).
 */

export type TipoSolicitacao =
  | "sustentacao_oral"
  | "preferencia"
  | "retirada_pauta"
  | "adiamento"
  | "memoriais"
  | "juntada"
  | "desistencia_acordo"
  | "urgencia"
  | "outro";

export type Solicitacao = {
  tipo: TipoSolicitacao;
  rotulo: string;
  modalidade: "presencial" | "videoconferencia" | null;
  motivoPreferencia: string | null;
  processos: string[];
  advogado: string | null;
  oab: string | null;
  solicitante: string | null;
  parte: string | null;
  email: string | null;
  telefones: string | null;
  dataSessao: string | null;
  orgaoJulgador: string | null;
  relator: string | null;
};

export const ROTULOS: Record<TipoSolicitacao, string> = {
  sustentacao_oral: "Sustentação oral",
  preferencia: "Preferência",
  retirada_pauta: "Retirada de pauta",
  adiamento: "Adiamento",
  memoriais: "Memoriais / despacho",
  juntada: "Juntada de documento",
  desistencia_acordo: "Desistência ou acordo",
  urgencia: "Urgência",
  outro: "Outra solicitação",
};

const MOTIVOS: [RegExp, string][] = [
  [/idos[oa]/i, "pessoa idosa"],
  [/defici[eê]ncia|\bpcd\b/i, "pessoa com deficiência"],
  [/r[eé]u\s*pres[oa]/i, "réu preso"],
  [/grave\s*enfermidade|doen[cç]a\s*grave/i, "doença grave"],
  [/crian[cç]a|adolescente/i, "criança ou adolescente"],
  [/aliment/i, "alimentos"],
  [/habeas\s*corpus/i, "habeas corpus"],
  [/mandado\s*de\s*seguran[cç]a/i, "mandado de segurança"],
];

const CNJ = /\b\d{7}\s*-?\s*\d{2}\s*\.?\s*\d{4}\s*\.?\s*\d\s*\.?\s*\d{2}\s*\.?\s*\d{4}\b/g;
const digitos = (v: string) => v.replace(/\D/g, "");
export const formataCnj = (d: string) =>
  d.length === 20 ? `${d.slice(0, 7)}-${d.slice(7, 9)}.${d.slice(9, 13)}.${d.slice(13, 14)}.${d.slice(14, 16)}.${d.slice(16)}` : d;

/** Campo "Rótulo: valor" (ou "Rótulo valor") numa linha do corpo, como no formulário padronizado. */
function campo(corpo: string, rotulo: string): string | null {
  for (const sep of [String.raw`\s*:\s*`, String.raw`\s+`]) {
    const m = corpo.match(new RegExp(`^\\s*${rotulo}${sep}(.+)$`, "im"));
    if (m) {
      const v = m[1].replace(/\s+TRMS[_\-\w.]*$/i, "").replace(/\s*\(preencher\)\s*$/i, "").trim();
      if (v) return v.slice(0, 300);
    }
  }
  return null;
}

function tipoDe(texto: string): TipoSolicitacao {
  const t = texto.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  if (/sustentacao\s*oral/.test(t)) return "sustentacao_oral";
  if (/preferencia/.test(t)) return "preferencia";
  if (/retirad[ao]\s+(?:do\s+processo\s+)?d[ae]\s+pauta|exclusao\s+d[ae]\s+pauta/.test(t)) return "retirada_pauta";
  if (/adiamento|adiar\s+o\s+julgamento/.test(t)) return "adiamento";
  if (/memoriais|despachar\s+com|audiencia\s+com\s+o\s+(?:relator|desembargador)/.test(t)) return "memoriais";
  if (/juntada|junta(?:r|da)\s+de\s+documento/.test(t)) return "juntada";
  if (/desistencia|acordo|composicao\s+amigavel/.test(t)) return "desistencia_acordo";
  if (/urgen(?:te|cia)|liminar|tutela\s+de\s+urgencia/.test(t)) return "urgencia";
  return "outro";
}

/** Órgão julgador citado no texto quando não vem no campo próprio (ex.: “3ª Turma”, “Turma Regional de MS”). */
function orgaoNoTexto(texto: string): string | null {
  const m = texto.match(/\b(\d{1,2}\s*[ªaº]\s*Turma(?:\s+Recursal)?|Turma\s+Regional(?:\s+de\s+[A-Z]{2})?|[OÓ]rg[aã]o\s+Especial|\d{1,2}\s*[ªaº]\s*Se[cç][aã]o|Plen[aá]rio)\b/i);
  return m ? m[1].replace(/\s+/g, " ").replace(/^(\d+)\s*[aº]\s*/i, "$1ª ").trim() : null;
}

export function lerSolicitacao(assunto: string, corpo: string): Solicitacao {
  const tudo = `${assunto ?? ""}\n${corpo ?? ""}`;
  const tipoCampo = campo(corpo, "Tipo de solicita[cç][aã]o") || campo(corpo, "TIPO");
  const tipo = tipoDe(tipoCampo || tudo);

  const processoCampo = campo(corpo, "N[uú]mero do [Pp]rocesso") || campo(corpo, "PROCESSO");
  const processos = [
    ...new Set([...(processoCampo ? processoCampo.match(CNJ) ?? [] : []), ...(tudo.match(CNJ) ?? [])]
      .map(digitos).filter((d) => d.length === 20)),
  ];

  let oab = campo(corpo, "OAB");
  if (!oab) oab = tudo.match(/\(OAB\s+([^)]+)\)/i)?.[1]?.trim() ?? null;
  let advogado =
    campo(corpo, "Advogado(?:\\(a\\))? que realizar[aá] a Sustenta[cç][aã]o Oral") ||
    campo(corpo, "Advogad[oa](?:\\(a\\))?") ||
    campo(corpo, "ADVOGADO");
  if (advogado) {
    advogado = advogado.replace(/\s*\(OAB\s+[^)]+\)/i, "").trim();
    const nua = advogado.match(/\s*\(([A-Z]{2}\d+[A-Z]?)\)/);
    if (nua) { oab = oab || nua[1]; advogado = advogado.replace(nua[0], "").trim(); }
  }

  const video = /videoconfer[eê]ncia|v[ií]deo\s*confer|telepresencial|virtual/i.test(tudo);
  const modalidade = tipo === "sustentacao_oral" ? (video ? "videoconferencia" : "presencial") : null;

  let motivoPreferencia: string | null = null;
  if (tipo === "preferencia") {
    const motivo = campo(corpo, "Motivo") || tudo;
    motivoPreferencia = MOTIVOS.find(([re]) => re.test(motivo))?.[1] ?? (campo(corpo, "Motivo") || null);
  }

  let parte = campo(corpo, "Parte representada") || campo(corpo, "PARTE REPRESENTADA");
  if (!parte) {
    const polo = campo(corpo, "Polo") || "";
    if (/AUTOR|APELANTE|RECORRENTE|IMPETRANTE|AGRAVANTE/i.test(polo)) parte = "polo ativo";
    else if (/R[EÉ]U|APELAD|RECORRID|AGRAVAD/i.test(polo)) parte = "polo passivo";
    else if (/MPF|MINIST[EÉ]RIO/i.test(polo)) parte = "MPF";
    else if (polo) parte = polo;
  }

  let email = campo(corpo, "E-?mail(?: do advogado)?");
  email = email?.match(/[\w.+-]+@[\w.-]+\.\w+/)?.[0] ?? null;
  const telefones =
    campo(corpo, "Telefones? de [Cc]ontato") ||
    [campo(corpo, "Telefone"), campo(corpo, "Celular")].filter(Boolean).join("; ") ||
    null;

  const dataRaw = campo(corpo, "Data da sess[aã]o") ||
    tudo.match(/sess[aã]o(?:\s+de\s+julgamento)?[^\d\n]{0,30}(\d{1,2}[/.-]\d{1,2}[/.-]\d{4})/i)?.[1] || null;
  let dataSessao: string | null = null;
  const dm = dataRaw?.match(/(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})/);
  if (dm) dataSessao = `${dm[1].padStart(2, "0")}/${dm[2].padStart(2, "0")}/${dm[3]}`;

  return {
    tipo,
    rotulo: ROTULOS[tipo],
    modalidade,
    motivoPreferencia,
    processos,
    advogado: advogado || null,
    oab: oab || null,
    solicitante: campo(corpo, "Solicitante") || campo(corpo, "Requerente"),
    parte: parte || null,
    email,
    telefones,
    dataSessao,
    orgaoJulgador: campo(corpo, "[OÓ]rg[aã]o [Jj]ulgador") || orgaoNoTexto(`${assunto}\n${corpo}`),
    relator: campo(corpo, "Relator(?:\\(a\\))?"),
  };
}

/** Uma linha legível para o alerta do card: tipo, modalidade ou motivo, quem pede e como falar com ele. */
export function resumoSolicitacao(s: Solicitacao): string {
  const partes = [
    s.modalidade === "videoconferencia" ? "por videoconferência" : s.modalidade === "presencial" ? "presencial" : "",
    s.motivoPreferencia ? `motivo: ${s.motivoPreferencia}` : "",
    s.advogado ? `${s.advogado}${s.oab ? ` (OAB ${s.oab})` : ""}` : s.solicitante || "",
    s.parte ? `parte: ${s.parte}` : "",
    s.email || "",
    s.telefones || "",
  ].filter(Boolean);
  return partes.join(" · ").replace(/\|/g, "/").slice(0, 400);
}

/** Cor do alerta no card, na convenção "cor | título | descrição" das Alertas da pauta
 *  (o card só reconhece cinza, amarelo, laranja e vermelho). */
export function corSolicitacao(tipo: TipoSolicitacao): "cinza" | "amarelo" | "laranja" | "vermelho" {
  if (tipo === "retirada_pauta" || tipo === "adiamento" || tipo === "desistencia_acordo") return "vermelho";
  if (tipo === "preferencia" || tipo === "urgencia") return "laranja";
  if (tipo === "sustentacao_oral") return "amarelo";
  return "cinza";
}

/** Linha de alerta do card para a solicitação aplicada. Sustentação oral usa os alertas próprios do card
 *  (“Sustentação oral presencial” ou “virtual”), com advogado e OAB na síntese; preferência entra em laranja. */
export function linhaAlertaSolicitacao(s: Solicitacao, canal: string, descricao: string): string {
  const limpa = (v: string) => v.replace(/[|\n]/g, " ").replace(/\s+/g, " ").trim();
  const adv = s.advogado ? `${s.advogado}${s.oab ? ` · OAB ${s.oab}` : ""}` : s.solicitante || "";
  const quem = [s.solicitante && s.solicitante !== s.advogado ? s.solicitante : "", s.parte].filter(Boolean).join(" — ");
  const desc = limpa([quem, `${canal} · Gab. A`, descricao].filter(Boolean).join(" · ")).slice(0, 600);
  if (s.tipo === "sustentacao_oral") {
    const nome = s.modalidade === "videoconferencia" ? "Sustentação oral virtual" : "Sustentação oral presencial";
    return `${nome} | ${limpa(adv)} | ${desc}`;
  }
  if (s.tipo === "preferencia") {
    return `laranja | ${limpa(`Preferência${s.motivoPreferencia ? ` · ${s.motivoPreferencia}` : ""}${adv ? ` · ${adv}` : ""}`)} | ${desc}`;
  }
  return `${corSolicitacao(s.tipo)} | ${limpa(`${s.rotulo} · ${canal} · Gab. A`)} | ${limpa(descricao)}`;
}

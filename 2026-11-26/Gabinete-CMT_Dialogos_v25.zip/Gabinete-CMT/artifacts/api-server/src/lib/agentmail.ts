import { createHmac, timingSafeEqual } from "node:crypto";

export const MESSAGE_STATUSES = [
  "nova",
  "registrando",
  "registrada",
  "pendente",
  "descartada",
] as const;

export type MessageStatus = (typeof MESSAGE_STATUSES)[number];
export type InboxAttachment = {
  filename: string;
  contentType: string;
  size: number;
};

export type InboxMessage = {
  id: string;
  source: "agentmail" | "manual" | "twilio";
  /** Canal de origem; ausente nas mensagens antigas (= e-mail). */
  channel?: "email" | "sms" | "whatsapp";
  inboxId: string;
  threadId: string;
  from: string;
  to: string[];
  subject: string;
  text: string;
  preview: string;
  receivedAt: string;
  attachments: InboxAttachment[];
  status: MessageStatus;
  outcome?: Record<string, unknown>;
  updatedAt: string;
  updatedBy?: string;
};

export type InboxState = {
  version: 1;
  messages: InboxMessage[];
  /** IDs excluídos localmente, para não reaparecerem em tentativas de webhook. */
  deletedMessageIds?: string[];
  lastEventAt?: string;
  lastSyncAt?: string;
};

export const MAX_TEXT = 20_000;
export const EMAIL_RETENTION_CUTOFF = "2026-08-01T04:00:00.000Z";

const str = (value: unknown): string =>
  typeof value === "string" ? value.trim() : value == null ? "" : String(value).trim();

const list = (value: unknown): string[] =>
  Array.isArray(value)
    ? value.map(str).filter(Boolean)
    : str(value)
      ? [str(value)]
      : [];

export function htmlToText(html: string): string {
  return str(html)
    .replace(/<(script|style)[\s\S]*?<\/\1>/gi, " ")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(p|div|tr|li|h[1-6])>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/[ \t]+/g, " ")
    .replace(/\s*\n\s*/g, "\n")
    .trim();
}

export function verifySvixSignature(
  secret: string,
  headers: { id?: string; timestamp?: string; signature?: string },
  rawBody: string | Buffer,
  nowSeconds = Math.floor(Date.now() / 1000),
  toleranceSeconds = 300,
): boolean {
  const id = str(headers.id);
  const timestamp = str(headers.timestamp);
  const signatures = str(headers.signature);
  if (!secret || !id || !timestamp || !signatures) return false;

  const signedAt = Number(timestamp);
  if (
    !Number.isSafeInteger(signedAt) ||
    Math.abs(nowSeconds - signedAt) > toleranceSeconds
  ) {
    return false;
  }

  const encodedKey = secret.startsWith("whsec_") ? secret.slice(6) : secret;
  const key = Buffer.from(encodedKey, "base64");
  if (!key.length) return false;

  const body = typeof rawBody === "string" ? rawBody : rawBody.toString("utf8");
  const expected = createHmac("sha256", key)
    .update(`${id}.${timestamp}.${body}`)
    .digest();

  return signatures.split(/\s+/).some((part) => {
    const [version, value] = part.split(",");
    if (version !== "v1" || !value) return false;
    const received = Buffer.from(value, "base64");
    return received.length === expected.length && timingSafeEqual(received, expected);
  });
}

export function normalizeAgentMailMessage(
  raw: Record<string, unknown>,
  nowIso = new Date().toISOString(),
): InboxMessage | null {
  const id = str(raw.message_id ?? raw.id);
  if (!id) return null;

  const html = str(raw.html ?? raw.extracted_html);
  let text = str(raw.text ?? raw.extracted_text);
  if (!text && html) text = htmlToText(html);

  const attachments = (Array.isArray(raw.attachments) ? raw.attachments : [])
    .filter(
      (attachment): attachment is Record<string, unknown> =>
        Boolean(attachment) && typeof attachment === "object",
    )
    .map((attachment) => ({
      filename: str(attachment.filename).slice(0, 500),
      contentType: str(attachment.content_type ?? attachment.contentType).slice(0, 200),
      size: Math.max(0, Number(attachment.size) || 0),
    }));

  return {
    id,
    source: "agentmail",
    inboxId: str(raw.inbox_id),
    threadId: str(raw.thread_id),
    from: list(raw.from_ ?? raw.from)[0] || "",
    to: list(raw.to),
    subject: str(raw.subject).slice(0, 500),
    text: text.slice(0, MAX_TEXT),
    preview: (str(raw.preview) || text).slice(0, 280),
    receivedAt: str(raw.timestamp ?? raw.created_at) || nowIso,
    attachments,
    status: "nova",
    updatedAt: nowIso,
  };
}

export function manualMessage(
  body: Record<string, unknown>,
  nowIso = new Date().toISOString(),
): InboxMessage | null {
  const text = str(body.text).slice(0, MAX_TEXT);
  if (!text) return null;

  return {
    id: `manual-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
    source: "manual",
    inboxId: "",
    threadId: "",
    from: str(body.from).slice(0, 300),
    to: [],
    subject: str(body.subject).slice(0, 500),
    text,
    preview: text.slice(0, 280),
    receivedAt: nowIso,
    attachments: [],
    status: "nova",
    updatedAt: nowIso,
    updatedBy: str(body.by).slice(0, 80) || undefined,
  };
}

export function emptyInbox(): InboxState {
  return { version: 1, messages: [], deletedMessageIds: [] };
}

export function coerceInbox(value: unknown): InboxState {
  const object =
    value && typeof value === "object"
      ? (value as Record<string, unknown>)
      : {};
  const messages = Array.isArray(object.messages)
    ? (object.messages as InboxMessage[]).filter(
        (message) => message && typeof message.id === "string",
      )
    : [];

  return {
    version: 1,
    messages,
    deletedMessageIds: Array.isArray(object.deletedMessageIds)
      ? [...new Set(object.deletedMessageIds.map(str).filter(Boolean))]
      : [],
    lastEventAt: str(object.lastEventAt) || undefined,
    lastSyncAt: str(object.lastSyncAt) || undefined,
  };
}

/** Remove mensagens somente da caixa local do app; não apaga a cópia no AgentMail. */
export function removeInboxMessages(
  state: InboxState,
  ids: string[],
): { deletedIds: string[]; notFoundIds: string[] } {
  const requested = [...new Set(ids)];
  const present = new Set(
    state.messages
      .filter((message) => requested.includes(message.id))
      .map((message) => message.id),
  );
  const deletedIds = requested.filter((id) => present.has(id));
  state.messages = state.messages.filter((message) => !present.has(message.id));
  state.deletedMessageIds = [
    ...new Set([...(state.deletedMessageIds ?? []), ...deletedIds]),
  ];
  return {
    deletedIds,
    notFoundIds: requested.filter((id) => !present.has(id)),
  };
}

export function agentMailRetentionSummary(state: InboxState) {
  const cutoff = Date.parse(EMAIL_RETENTION_CUTOFF);
  const emails = state.messages.filter((message) => message.source === "agentmail");
  let beforeCutoff = 0;
  let fromCutoff = 0;
  let undated = 0;
  for (const message of emails) {
    const receivedAt = Date.parse(message.receivedAt);
    if (!Number.isFinite(receivedAt)) undated += 1;
    else if (receivedAt < cutoff) beforeCutoff += 1;
    else fromCutoff += 1;
  }
  return { total: emails.length, beforeCutoff, fromCutoff, undated };
}

export function removeAgentMailBeforeAugust2026(state: InboxState) {
  const cutoff = Date.parse(EMAIL_RETENTION_CUTOFF);
  const ids = state.messages
    .filter((message) =>
      message.source === "agentmail" &&
      Number.isFinite(Date.parse(message.receivedAt)) &&
      Date.parse(message.receivedAt) < cutoff,
    )
    .map((message) => message.id);
  const result = removeInboxMessages(state, ids);
  return { deleted: result.deletedIds.length, ...agentMailRetentionSummary(state) };
}

/** Uma importação explicitamente selecionada pode restaurar uma mensagem excluída. */
export function allowInboxMessages(state: InboxState, ids: string[]): void {
  const allowed = new Set(ids);
  state.deletedMessageIds = (state.deletedMessageIds ?? []).filter(
    (id) => !allowed.has(id),
  );
}

export function upsertMessage(
  state: InboxState,
  message: InboxMessage,
  sort = true,
): boolean {
  if (state.deletedMessageIds?.includes(message.id)) return false;
  if (state.messages.some((item) => item.id === message.id)) return false;
  state.messages.unshift(message);
  if (sort) sortInboxMessages(state);
  return true;
}

export function sortInboxMessages(state: InboxState): void {
  state.messages.sort((a, b) => b.receivedAt.localeCompare(a.receivedAt));
}

/** Hydrates a webhook stub from the API without overwriting triage changes. */
export function mergeAgentMailMessage(
  state: InboxState,
  incoming: InboxMessage,
  sortNewMessage = true,
): "inserted" | "updated" | "unchanged" {
  if (state.deletedMessageIds?.includes(incoming.id)) return "unchanged";
  const existing = state.messages.find((item) => item.id === incoming.id);
  if (!existing) {
    upsertMessage(state, incoming, sortNewMessage);
    return "inserted";
  }

  let changed = false;
  const copyIfPresent = <K extends "inboxId" | "threadId" | "from" | "subject" | "preview">(
    key: K,
    value: InboxMessage[K],
  ) => {
    if (value && existing[key] !== value) {
      existing[key] = value;
      changed = true;
    }
  };

  copyIfPresent("inboxId", incoming.inboxId);
  copyIfPresent("threadId", incoming.threadId);
  copyIfPresent("from", incoming.from);
  copyIfPresent("subject", incoming.subject);
  copyIfPresent("preview", incoming.preview);

  if (incoming.to.length && JSON.stringify(existing.to) !== JSON.stringify(incoming.to)) {
    existing.to = incoming.to;
    changed = true;
  }
  if (incoming.text && existing.text !== incoming.text) {
    existing.text = incoming.text;
    changed = true;
  }
  if (
    incoming.attachments.length &&
    JSON.stringify(existing.attachments) !== JSON.stringify(incoming.attachments)
  ) {
    existing.attachments = incoming.attachments;
    changed = true;
  }

  if (changed) existing.updatedAt = incoming.updatedAt;
  return changed ? "updated" : "unchanged";
}

export function patchMessage(
  state: InboxState,
  id: string,
  changes: { status?: string; outcome?: Record<string, unknown>; by?: string },
  ifStatus?: string,
  nowIso = new Date().toISOString(),
):
  | { ok: true; message: InboxMessage }
  | { ok: false; code: 404 | 409 | 400; message?: InboxMessage } {
  const message = state.messages.find((item) => item.id === id);
  if (!message) return { ok: false, code: 404 };
  if (ifStatus && message.status !== ifStatus) {
    return { ok: false, code: 409, message };
  }

  if (changes.status !== undefined) {
    if (!(MESSAGE_STATUSES as readonly string[]).includes(changes.status)) {
      return { ok: false, code: 400 };
    }
    message.status = changes.status as MessageStatus;
  }
  if (changes.outcome && typeof changes.outcome === "object") {
    message.outcome = changes.outcome;
  }
  message.updatedAt = nowIso;
  if (changes.by) message.updatedBy = str(changes.by).slice(0, 80);
  return { ok: true, message };
}

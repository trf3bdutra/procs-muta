import { cnj, norm, reconhecer, type Matriz } from "./acervo-fontes";

const isRecord = (value: unknown): value is Record<string, unknown> =>
  !!value && typeof value === "object" && !Array.isArray(value);

const processHeaders = new Set(["processo", "numeroprocesso", "numerodoprocesso", "nprocesso"]);
const taskHeaders = new Set(["tarefaatual", "nometarefa", "tarefaprocessolist", "tagsprocessolist"]);

export function rawPjeLinesByProcess(matriz: Matriz): Map<string, Record<string, unknown>[]> {
  const reading = reconhecer(matriz);
  if (reading.fonte !== "pje") return new Map();
  const processIndex = reading.cabecalho.findIndex((header) => processHeaders.has(norm(header)));
  if (processIndex < 0) return new Map();

  const output = new Map<string, Record<string, unknown>[]>();
  for (const row of reading.linhas) {
    const processo = cnj(row[processIndex]);
    if (!processo) continue;
    const raw: Record<string, unknown> = {};
    reading.cabecalho.forEach((header, index) => {
      const key = String(header ?? "").trim();
      if (key) raw[key] = row[index] ?? "";
    });
    raw.processo = processo;
    const lines = output.get(processo);
    if (lines) lines.push(raw);
    else output.set(processo, [raw]);
  }
  return output;
}

export function isDetailedPjeReport(matriz: Matriz): boolean {
  const reading = reconhecer(matriz);
  if (reading.fonte !== "pje") return false;
  const headers = new Set(reading.cabecalho.map(norm));
  return headers.has("classejudicial") &&
    [...headers].some((header) => header === "poloativo" || header === "parteativa") &&
    [...headers].some((header) => header === "polopassivo" || header === "partepassiva");
}

export function mergePjeRawRows(
  previous: unknown,
  incoming: Record<string, unknown>[],
  replaceComplete: boolean,
): Record<string, unknown>[] {
  const oldRows = Array.isArray(previous) ? previous.filter(isRecord) : [];
  if (replaceComplete || oldRows.length === 0) return incoming;

  const taskValue = (row: Record<string, unknown>) => {
    const key = Object.keys(row).find((name) => taskHeaders.has(norm(name)));
    return key ? String(row[key] ?? "").trim() : "";
  };
  const taskOccurrences = (rows: Record<string, unknown>[]) => {
    const counts = new Map<string, number>();
    return rows.map((row) => {
      const task = norm(taskValue(row));
      const index = counts.get(task) ?? 0;
      counts.set(task, index + 1);
      return { row, key: `${task || "row"}#${index}` };
    });
  };

  const merged = taskOccurrences(oldRows);
  const positions = new Map(merged.map((entry, index) => [entry.key, index]));
  for (const entry of taskOccurrences(incoming)) {
    const index = positions.get(entry.key);
    if (index === undefined) {
      positions.set(entry.key, merged.length);
      merged.push(entry);
      continue;
    }
    const combined = { ...merged[index].row };
    for (const [key, value] of Object.entries(entry.row)) {
      if (value !== null && value !== undefined && String(value).trim() !== "") combined[key] = value;
    }
    merged[index] = { row: combined, key: entry.key };
  }
  return merged.map((entry) => entry.row);
}

export function completeAcervoLines(
  process: string,
  imported: unknown,
  fallback: Record<string, unknown>,
): Record<string, unknown>[] {
  const raw = isRecord(imported) && Array.isArray(imported.linhas)
    ? imported.linhas.filter(isRecord)
    : [];
  if (raw.length) {
    return raw.map((line) => ({ ...line, processo: process }));
  }
  const line: Record<string, unknown> = { ...fallback, processo: process };
  delete line["linhas"];
  return [line];
}

export function isAcervoProcessActive(status: unknown): boolean {
  const normalized = norm(status);
  return !["baixado", "arquivado", "remetido"].some((inactive) => normalized.includes(inactive));
}

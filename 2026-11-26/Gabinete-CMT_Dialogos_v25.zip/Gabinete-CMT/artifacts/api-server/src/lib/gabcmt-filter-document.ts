/**
 * Dedicated Filter document. It shares authenticated data/runtime services with
 * Gabinete, but owns its entry, navigation and Triagem/Sessões workspace.
 */
export function prepareFilterDocument(html: string): string {
  const styles = `<style id="cmt-filter-document-style">
html[data-cmt-workspace="filter"] #alt-side .as-nav{display:none!important}
html[data-cmt-workspace="filter"] #pauta-global-dock>.gd-foot:not([data-page-footer="triagem"]){display:none!important}
html[data-cmt-workspace="filter"] #cx-rrail{position:fixed!important;top:0!important;right:0!important;bottom:0!important;height:100vh!important;height:100dvh!important;border-radius:0!important}
html[data-cmt-workspace="filter"] #cx-rrail>.rr-foot{bottom:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important}
html[data-cmt-workspace="filter"] #pauta-global-dock>.gd-foot::after{display:none!important;content:none!important;background:none!important}
#cmt-filter-back{display:flex;align-items:center;justify-content:center;gap:6px;margin:12px 6px;padding:10px 6px;border:1px solid rgba(255,255,255,.25);border-radius:10px;color:inherit;text-decoration:none;font:700 11px/1.2 Figtree,system-ui,sans-serif}
#cmt-filter-back:focus-visible{outline:2px solid #e9c46f;outline-offset:3px}
</style>`;
  const assets = `<link rel="stylesheet" href="/api/app/pauta-side-panel.css"><script src="/api/app/pauta-side-panel.js"></script>`;
  const controller = `<script id="cmt-filter-document-controller">
(()=>{'use strict';let attempts=0;
function mount(){const side=document.getElementById('alt-side');if(!side){if(++attempts<60)setTimeout(mount,100);return;}
if(!document.getElementById('cmt-filter-back')){const back=document.createElement('a');back.id='cmt-filter-back';back.href='/gabinete';back.target='_top';back.textContent='← Gabinete';back.setAttribute('aria-label','Voltar ao Gabinete');const top=side.querySelector('.as-top');if(top)top.after(back);else side.prepend(back);}
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})();
</script>`;
  const document = html
    .replace(/<html\b/i, '<html data-cmt-workspace="filter"')
    .replace(/<title>[\s\S]*?<\/title>/i, "<title>Triagem — GabCMT</title>")
    .replace(/<\/head>/i, `${styles}${assets}</head>`);
  const end = document.toLowerCase().lastIndexOf("</body>");
  if (end < 0) throw new Error("O documento Filter não possui fechamento de body.");
  return document.slice(0, end) + controller + document.slice(end);
}

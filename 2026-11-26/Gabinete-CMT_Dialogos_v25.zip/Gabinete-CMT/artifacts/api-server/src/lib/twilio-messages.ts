import type { InboxMessage } from "./agentmail";
import { createHmac, timingSafeEqual } from "node:crypto";

export function verifyTwilioSignature(url: string, parameters: Record<string, unknown>, signature: string, token: string): boolean {
  if (!url || !signature || !token || Object.values(parameters).some((v) => typeof v !== "string")) return false;
  const payload = url + Object.keys(parameters).sort().map((key) => key + parameters[key]).join("");
  const expected = Buffer.from(createHmac("sha1", token).update(payload).digest("base64"));
  const actual = Buffer.from(signature);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export class TwilioFailure extends Error {
  status: number;
  code?: number;
  constructor(status: number, code?: number) {
    super(code === 63016
      ? "WhatsApp fora da janela de atendimento: é necessário um modelo aprovado pelo Twilio."
      : code === 21608
        ? "A conta Twilio de teste exige um destinatário verificado."
        : `Twilio recusou a operação (HTTP ${status}${code ? `, código ${code}` : ""}).`);
    this.status = status;
    this.code = code;
  }
}

export function twilioAccountPath(): string {
  const account = process.env.TWILIO_ACCOUNT_SID?.trim();
  if (!account || !/^AC[a-f\d]{32}$/i.test(account) || !process.env.TWILIO_AUTH_TOKEN?.trim()) {
    throw new Error("Configure TWILIO_ACCOUNT_SID e TWILIO_AUTH_TOKEN nos Secrets do servidor.");
  }
  return `/2010-04-01/Accounts/${account}`;
}

export async function twilioRequest(path: string, body?: URLSearchParams): Promise<Record<string, any>> {
  const prefix = twilioAccountPath();
  // Only this account's message resource is permitted, never a caller-supplied URL.
  if (!path.startsWith(prefix + "/Messages") || path.includes("..")) throw new Error("Recurso Twilio inválido.");
  const response = await fetch("https://api.twilio.com" + path, {
    method: body ? "POST" : "GET",
    headers: {
      Authorization: "Basic " + Buffer.from(`${process.env.TWILIO_ACCOUNT_SID?.trim()}:${process.env.TWILIO_AUTH_TOKEN?.trim()}`).toString("base64"),
      ...(body ? { "Content-Type": "application/x-www-form-urlencoded" } : {}),
    },
    body: body?.toString(),
    signal: AbortSignal.timeout(20_000),
  });
  const data = await response.json() as Record<string, any>;
  if (!response.ok) throw new TwilioFailure(response.status, Number(data.code) || undefined);
  return data;
}

export function twilioSendForm(input: { channel: "sms" | "whatsapp"; from: string; to: string; text: string }) {
  if (!/^\+[1-9]\d{7,14}$/.test(input.from) || !/^\+[1-9]\d{7,14}$/.test(input.to)) throw new Error("Use números internacionais, por exemplo +5567999999999.");
  const text = input.text.trim();
  if (!text || text.length > 1600) throw new Error("Preencha uma mensagem de até 1.600 caracteres.");
  const prefix = input.channel === "whatsapp" ? "whatsapp:" : "";
  return new URLSearchParams({ From: prefix + input.from, To: prefix + input.to, Body: text });
}

export function twilioNextPageToken(uri: unknown): string | null {
  if (typeof uri !== "string" || !uri) return null;
  const url = new URL(uri, "https://api.twilio.com");
  if (url.origin !== "https://api.twilio.com" || url.pathname !== twilioAccountPath() + "/Messages.json") return null;
  return url.searchParams.get("PageToken");
}

export function normalizeTwilioMessage(raw: Record<string, any>): InboxMessage {
  if (!/^(SM|MM)[a-f\d]{32}$/i.test(String(raw.sid))) throw new Error("Identificador Twilio inválido.");
  const now = new Date().toISOString();
  const date = new Date(raw.date_sent || raw.date_created || now);
  const from = String(raw.from ?? "").slice(0, 200);
  const to = String(raw.to ?? "").slice(0, 200);
  const text = String(raw.body ?? "").slice(0, 20_000);
  return {
    id: `twilio:${raw.sid}`, source: "twilio", inboxId: String(raw.account_sid ?? ""),
    threadId: "", from, to: [to], subject: `${from.startsWith("whatsapp:") || to.startsWith("whatsapp:") ? "WhatsApp" : "SMS"} · ${from}`,
    text, preview: text.slice(0, 300), receivedAt: Number.isNaN(date.getTime()) ? now : date.toISOString(),
    attachments: [], status: "nova", updatedAt: now,
  };
}

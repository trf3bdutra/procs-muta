export const AGENTMAIL_COMUNICACAO_INBOX = "gabinete-cmt@agentmail.to";

const AGENTMAIL_API_ORIGIN = "https://api.agentmail.to";

export class AgentMailCommunicationError extends Error {
  constructor(message: string, readonly status: number) {
    super(message);
    this.name = "AgentMailCommunicationError";
  }
}

/** Reads the separate communication inbox. The requests inbox key is never used here. */
export async function agentMailCommunicationRequest(
  path: string,
  options: RequestInit = {},
): Promise<Response> {
  const apiKey = process.env.AGENTMAIL_MAIL_KEY?.trim();
  if (!apiKey) {
    throw new AgentMailCommunicationError("A chave da caixa de comunicação não está configurada.", 503);
  }
  const headers = new Headers(options.headers);
  headers.set("Authorization", `Bearer ${apiKey}`);
  const response = await fetch(new URL(path, AGENTMAIL_API_ORIGIN), {
    ...options,
    headers,
    signal: options.signal ?? AbortSignal.timeout(20_000),
  });
  if (!response.ok) {
    throw new AgentMailCommunicationError(`AgentMail respondeu HTTP ${response.status}.`, response.status);
  }
  return response;
}

export function agentMailCommunicationListPath(query: string, pageToken: string): string {
  const search = query.trim();
  const params = new URLSearchParams({ limit: "50" });
  if (pageToken) params.set("page_token", pageToken);
  if (search) params.set("q", search);
  const inbox = `/v0/inboxes/${encodeURIComponent(AGENTMAIL_COMUNICACAO_INBOX)}/messages`;
  return `${inbox}${search ? "/search" : ""}?${params.toString()}`;
}

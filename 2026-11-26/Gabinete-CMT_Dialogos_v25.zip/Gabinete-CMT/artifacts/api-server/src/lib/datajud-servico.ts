/* DataJud no servidor: consulta ao CNJ com limite de ritmo, linha de base compartilhada no PostgreSQL,
   sincronização em lote (manual, agendada ou por gatilho externo), eventos pelas regras da TPU,
   resumos diário e semanal e entrega por AgentMail ou webhook. As tabelas nascem em tempo de execução. */
import { pool } from "@workspace/db";
import { logger } from "./logger";
import * as D from "./datajud";
import { isAcervoProcessActive } from "./central-data";
import { etiquetasDe, padronizarImportado } from "./acervo-normalizacao";
import { atualizarAcervoComDataJud, garantirTabelas as garantirAcervo } from "../routes/acervo-importado";
import { aoVivo, publicar } from "./datajud-ao-vivo";

const env = (k: string) => String(process.env[k] ?? "").trim();
export const BASE = (env("DATAJUD_BASE") || "https://api-publica.datajud.cnj.jus.br/").replace(/\/?$/, "/");
export const ALIAS = env("DATAJUD_ALIAS") || "api_publica_trf3";
export const FUSO = env("DATAJUD_FUSO") || D.FUSO_PADRAO;
const CHAVE = (env("DATAJUD_API_KEY") || D.DATAJUD_PUBLIC_KEY).replace(/^APIKey\s+/i, "");
const RPM = Math.max(10, Math.min(120, +env("DATAJUD_RPM") || 90));
const LOTE = 100;
export const fmt = D.formatador(FUSO);

export class DataJudErro extends Error { constructor(msg: string, public status = 500) { super(msg); } }

/* ───────── tabelas ───────── */
let pronto: Promise<void> | null = null;
export function garantirTabelasDataJud(): Promise<void> {
  pronto ??= pool.query(`
    CREATE TABLE IF NOT EXISTS datajud_processo (processo text PRIMARY KEY, dados jsonb NOT NULL, atualizado_em timestamptz NOT NULL DEFAULT now());
    CREATE TABLE IF NOT EXISTS datajud_execucao (id serial PRIMARY KEY, inicio timestamptz NOT NULL, fim timestamptz, dados jsonb NOT NULL);
    CREATE INDEX IF NOT EXISTS datajud_execucao_inicio_idx ON datajud_execucao (inicio DESC);
    CREATE TABLE IF NOT EXISTS datajud_evento (id text PRIMARY KEY, processo text NOT NULL, regra text NOT NULL, periodicidade text NOT NULL,
      detectado_em timestamptz NOT NULL DEFAULT now(), dados jsonb NOT NULL);
    CREATE INDEX IF NOT EXISTS datajud_evento_detectado_idx ON datajud_evento (detectado_em DESC);
    CREATE TABLE IF NOT EXISTS datajud_envio (id serial PRIMARY KEY, tipo text NOT NULL, destinatario text NOT NULL DEFAULT '', nome text NOT NULL DEFAULT '',
      email text NOT NULL DEFAULT '', assunto text NOT NULL, texto text NOT NULL, html text NOT NULL DEFAULT '', eventos jsonb NOT NULL DEFAULT '[]'::jsonb,
      de timestamptz, ate timestamptz, criado_em timestamptz NOT NULL DEFAULT now(), enviado_em timestamptz, via text, erro text, registrado_em timestamptz);
    CREATE INDEX IF NOT EXISTS datajud_envio_criado_idx ON datajud_envio (criado_em DESC);
    CREATE TABLE IF NOT EXISTS datajud_config (id text PRIMARY KEY, dados jsonb NOT NULL DEFAULT '{}'::jsonb, versao integer NOT NULL DEFAULT 0,
      atualizado_em timestamptz NOT NULL DEFAULT now(), atualizado_por text NOT NULL DEFAULT '');
  `).then(() => undefined).catch((e) => { pronto = null; throw e; });
  return pronto;
}

/* ───────── configuração e marcas da agenda ───────── */
export async function lerConfig(): Promise<{ dados: D.NotifConfig; versao: number }> {
  await garantirTabelasDataJud();
  const { rows } = await pool.query("SELECT dados, versao FROM datajud_config WHERE id = 'notificacoes'");
  const v = rows[0] ? D.validarConfig(rows[0].dados) : null;
  return { dados: v && v.ok ? v.dados : { ...D.CONFIG_PADRAO }, versao: Number(rows[0]?.versao ?? 0) };
}
export async function gravarConfig(raw: unknown, versao: number | null, autor: string) {
  const v = D.validarConfig(raw);
  if (!v.ok) throw new DataJudErro(v.error, 400);
  await garantirTabelasDataJud();
  const c = await pool.connect();
  try {
    await c.query("BEGIN");
    const { rows } = await c.query("SELECT versao FROM datajud_config WHERE id = 'notificacoes' FOR UPDATE");
    const atual = Number(rows[0]?.versao ?? 0);
    if (versao != null && versao !== atual) { await c.query("ROLLBACK"); throw new DataJudErro("Outra pessoa alterou a configuração agora há pouco; recarregue e refaça a alteração.", 409); }
    await c.query(`INSERT INTO datajud_config (id, dados, versao, atualizado_em, atualizado_por) VALUES ('notificacoes', $1::jsonb, $2, now(), $3)
      ON CONFLICT (id) DO UPDATE SET dados = EXCLUDED.dados, versao = EXCLUDED.versao, atualizado_em = now(), atualizado_por = EXCLUDED.atualizado_por`,
      [JSON.stringify(v.dados), atual + 1, autor]);
    await c.query("COMMIT");
    return { dados: v.dados, versao: atual + 1 };
  } catch (e) { await c.query("ROLLBACK").catch(() => {}); throw e; } finally { c.release(); }
}
type Marcas = { diaria?: number; semanal?: number };
async function lerMarcas(): Promise<Marcas> {
  await garantirTabelasDataJud();
  const { rows } = await pool.query("SELECT dados FROM datajud_config WHERE id = 'marcas'");
  return (rows[0]?.dados as Marcas) || {};
}
async function gravarMarca(k: keyof Marcas, t: number) {
  await pool.query(`INSERT INTO datajud_config (id, dados) VALUES ('marcas', $1::jsonb)
    ON CONFLICT (id) DO UPDATE SET dados = datajud_config.dados || EXCLUDED.dados, atualizado_em = now()`, [JSON.stringify({ [k]: t })]);
}
/* trava entre instâncias: só uma roda a sincronização ou o resumo de cada vez */
async function comTrava<T>(nome: string, fn: () => Promise<T>): Promise<T | null> {
  const c = await pool.connect();
  try {
    const { rows } = await c.query("SELECT pg_try_advisory_lock(hashtext($1)) AS ok", [nome]);
    if (!rows[0]?.ok) return null;
    try { return await fn(); } finally { await c.query("SELECT pg_advisory_unlock(hashtext($1))", [nome]).catch(() => {}); }
  } finally { c.release(); }
}

/* ───────── consulta ao CNJ ───────── */
const marcasRitmo: number[] = [];
async function vez() {
  for (;;) {
    const agora = Date.now();
    while (marcasRitmo.length && agora - marcasRitmo[0] > 60e3) marcasRitmo.shift();
    if (marcasRitmo.length < RPM) { marcasRitmo.push(agora); return; }
    await new Promise((r) => setTimeout(r, 60e3 - (agora - marcasRitmo[0]) + 25));
  }
}
export const reqUltimoMinuto = () => marcasRitmo.filter((t) => Date.now() - t < 60e3).length;
export async function consultarCNJ(nums: string[], alias = ALIAS, chave = "", desde: number | null = null): Promise<any[]> {
  if (!/^api_publica_[a-z0-9_-]{2,30}$/.test(alias)) throw new DataJudErro("Índice do tribunal inválido.", 400);
  const body = JSON.stringify(D.corpoConsulta(nums, desde));
  for (let k = 0; ; k++) {
    await vez();
    let r: Response;
    try {
      r = await fetch(BASE + alias + "/_search", { method: "POST", signal: AbortSignal.timeout(30e3),
        headers: { "Content-Type": "application/json", Authorization: "APIKey " + (chave || CHAVE) }, body });
    } catch (e) {
      const mensagem = e instanceof Error ? e.message : String(e);
      const nome = e instanceof Error ? e.name : "";
      const timeout = nome === "TimeoutError" || /timed?\s*out|timeout|aborted due to timeout/i.test(mensagem);
      const partes = timeout ? D.dividirLoteDataJud(nums) : null;
      if (partes) {
        logger.warn({ alias, quantidade: nums.length, sublotes: partes.map((p) => p.length) },
          "datajud: consulta excedeu o tempo; subdividindo lote");
        const primeiro = await consultarCNJ(partes[0], alias, chave, desde);
        const segundo = await consultarCNJ(partes[1], alias, chave, desde);
        return [...primeiro, ...segundo];
      }
      if (k < 3) { await new Promise((ok) => setTimeout(ok, 1500 * 2 ** k)); continue; }
      throw new DataJudErro("DataJud indisponível: " + mensagem, 502);
    }
    if ((r.status === 429 || r.status >= 500) && k < 4) { await new Promise((ok) => setTimeout(ok, 2000 * 2 ** k)); continue; }
    if (!r.ok) throw new DataJudErro(`DataJud respondeu HTTP ${r.status}${r.status === 401 || r.status === 403 ? " — confira a chave vigente na Wiki do DataJud (DATAJUD_API_KEY)" : ""}.`, r.status === 429 ? 429 : 502);
    const text = await r.text();
    if (text.length > 30_000_000) throw new DataJudErro("Resposta do DataJud acima do limite seguro.", 502);
    const d = JSON.parse(text);
    return (Array.isArray(d?.hits?.hits) ? d.hits.hits : []).map((h: any) => h?._source).filter(Boolean);
  }
}
/* cache curto para a rota de consulta avulsa (a sincronização sempre lê fresco) */
const cache = new Map<string, { t: number; docs: any[] }>();
const TTL = (Number(env("DATAJUD_CACHE_MIN") || 10)) * 60e3;
export async function consultaAvulsa(numeros: unknown, alias = ALIAS, chave = "") {
  const nums = [...new Set((Array.isArray(numeros) ? numeros : []).map(D.digitos))].filter((n) => n.length === 20);
  if (!nums.length) throw new DataJudErro('Informe "numeros" com 20 dígitos.', 400);
  if (nums.length > 500) throw new DataJudErro("No máximo 500 números por chamada.", 413);
  const agora = Date.now(), hits: any[] = [], falta: string[] = [];
  let hit = 0;
  for (const n of nums) { const c = cache.get(alias + ":" + n); if (c && agora - c.t < TTL) { hit++; hits.push(...c.docs); } else falta.push(n); }
  for (let i = 0; i < falta.length; i += LOTE) {
    const part = falta.slice(i, i + LOTE), docs = await consultarCNJ(part, alias, chave), by: Record<string, any[]> = {};
    for (const d of docs) (by[D.digitos(d.numeroProcesso)] ||= []).push(d);
    for (const n of part) cache.set(alias + ":" + n, { t: Date.now(), docs: by[n] || [] });
    hits.push(...docs.filter((d) => part.includes(D.digitos(d.numeroProcesso))));
  }
  if (cache.size > 50_000) for (const [k, v] of cache) if (agora - v.t > TTL) cache.delete(k);
  let acervo: { novos: number; alterados: number } | undefined;
  let acervoErro = "";
  if (alias === ALIAS && hits.length) {
    try { acervo = await atualizarAcervoComDataJud(hits); }
    catch (e) {
      acervoErro = e instanceof Error ? e.message : String(e);
      logger.warn({ err: acervoErro }, "datajud: acervo local não atualizado");
    }
  }
  return {
    ok: true, alias, consultadoEm: new Date().toISOString(), hits, cache: { hit, miss: falta.length },
    ...(acervo ? { acervo } : {}),
    ...(acervoErro ? { acervoErro } : {}),
  };
}

/* ───────── leitura do acervo e da pauta ───────── */
async function pautaEstado(): Promise<unknown> {
  const { rows } = await pool.query("SELECT state FROM pauta_snapshots WHERE id = 'main'").catch(() => ({ rows: [] as any[] }));
  return rows[0]?.state ?? null;
}
async function escopoPadrao(state: unknown): Promise<string[]> {
  await garantirAcervo();
  const { rows } = await pool.query("SELECT processo, situacao FROM acervo");
  const set = new Set<string>(rows.filter((r) => isAcervoProcessActive(r.situacao)).map((r) => D.digitos(r.processo)).filter((n) => n.length === 20));
  for (const n of D.indicePauta(state, D.isoNoFuso(Date.now(), FUSO)).keys()) set.add(n);
  return [...set];
}
async function contextos(nums: string[]): Promise<Map<string, D.ProcCtx>> {
  const out = new Map<string, D.ProcCtx>();
  if (!nums.length) return out;
  await garantirAcervo();
  const fmtd = nums.map(D.cnjFmt);
  const { rows } = await pool.query("SELECT processo, importado, situacao FROM acervo WHERE processo = ANY($1::text[])", [fmtd]);
  for (const r of rows) {
    const imp = padronizarImportado({ ...(r.importado || {}), processo: r.processo });
    out.set(D.digitos(r.processo), { processo: r.processo, classe: String(imp.classe || ""), assunto: String(imp.assunto || ""),
      secao: String(imp.secao || imp.secaoCompetente || ""), etiquetas: etiquetasDe(imp), tarefa: String(imp.tarefaAtual || ""), ativo: isAcervoProcessActive(r.situacao) });
  }
  return out;
}
async function lerProcs(nums?: string[]): Promise<Map<string, D.Proc>> {
  await garantirTabelasDataJud();
  const { rows } = nums ? await pool.query("SELECT processo, dados FROM datajud_processo WHERE processo = ANY($1::text[])", [nums])
    : await pool.query("SELECT processo, dados FROM datajud_processo");
  return new Map(rows.map((r) => [r.processo as string, r.dados as D.Proc]));
}
async function gravarProcs(recs: Array<[string, D.Proc]>) {
  for (let i = 0; i < recs.length; i += 500) {
    const part = recs.slice(i, i + 500).map(([processo, dados]) => ({ processo, dados }));
    await pool.query(`INSERT INTO datajud_processo (processo, dados, atualizado_em) SELECT x.processo, x.dados, now()
      FROM jsonb_to_recordset($1::jsonb) AS x(processo text, dados jsonb)
      ON CONFLICT (processo) DO UPDATE SET dados = EXCLUDED.dados, atualizado_em = now()`, [JSON.stringify(part)]);
  }
}
async function contextoAvaliacao(procs: Map<string, D.Proc>, nums: string[]): Promise<D.Contexto> {
  const [state, cfg, ctx] = await Promise.all([pautaEstado(), lerConfig(), contextos(nums)]);
  const agora = Date.now();
  return { procs, ctx, pauta: D.indicePauta(state, D.isoNoFuso(agora, FUSO)), destinatarios: D.destinatariosEfetivos(state, cfg.dados),
    config: cfg.dados, agora, fimDoDia: (iso) => D.fimDoDia(iso, FUSO), fmt };
}
export async function destinatarios() { const [s, c] = await Promise.all([pautaEstado(), lerConfig()]); return D.destinatariosEfetivos(s, c.dados); }
export async function pautados() {
  const state = await pautaEstado(), idx = D.indicePauta(state, D.isoNoFuso(Date.now(), FUSO));
  const D2 = D.destinatariosEfetivos(state, (await lerConfig()).dados);
  return [...idx].flatMap(([n, L]) => L.map((x) => {
    const d = D2.find((y) => y.servidor && y.servidor === D.chaveNome(x.servidor));
    return { processo: D.cnjFmt(n), sessao: x.sessao, data: x.data, servidor: x.servidor, destinatario: d ? d.id : "", email: d ? d.email : "" };
  })).sort((a, b) => (a.data < b.data ? -1 : a.data > b.data ? 1 : a.processo < b.processo ? -1 : 1));
}

/* ───────── sincronização ───────── */
export const estado = { rodando: false, parar: false, feitos: 0, total: 0, inicio: 0, motivo: "", autor: "" };
type Pedido = { motivo: string; autor?: string; numeros?: string[]; completa?: boolean };
export async function sincronizar(o: Pedido): Promise<D.Run> {
  if (estado.rodando) throw new DataJudErro("Já há uma sincronização em andamento.", 409);
  estado.rodando = true;
  try {
    await garantirTabelasDataJud();
    const r = await comTrava("cmt-datajud-sync", () => executar(o));
    if (!r) throw new DataJudErro("Outra instância do servidor está sincronizando agora.", 409);
    return r;
  } finally { estado.rodando = false; estado.parar = false; }
}
/* Leitura completa no máximo a cada 20 h (detecta também o que sumiu da base pública); entre elas, leitura leve:
   o CNJ devolve só os documentos recarregados desde a última carga vista, e nada muda no banco para o resto. */
const COMPLETA_MS = 20 * 3600e3, MARGEM_MS = 6 * 3600e3;
async function ultimaCompleta(): Promise<{ ini: number; base: number } | null> {
  const { rows } = await pool.query(`SELECT dados FROM datajud_execucao WHERE coalesce(dados->>'modo', 'completa') = 'completa'
    AND (dados->>'encontrados')::int > 0 ORDER BY inicio DESC LIMIT 1`);
  const r = rows[0]?.dados as D.Run | undefined;
  if (!r) return null;
  const { rows: L } = await pool.query("SELECT max((dados->>'base')::bigint) AS b FROM datajud_execucao WHERE inicio >= to_timestamp($1 / 1000.0)", [r.ini]);
  return { ini: r.ini, base: Number(L[0]?.b || r.base || 0) };
}
async function executar(o: Pedido): Promise<D.Run> {
  const state = await pautaEstado();
  const nums = o.numeros?.length ? [...new Set(o.numeros.map(D.digitos))].filter((n) => n.length === 20).slice(0, 20000) : await escopoPadrao(state);
  const run = D.novaExecucao(o.motivo, "Servidor do GabCMT", o.numeros?.length ? "lista" : "ativos e pautados", nums.length, o.autor || "");
  Object.assign(estado, { feitos: 0, total: nums.length, inicio: run.ini, motivo: o.motivo, autor: o.autor || "" });
  const old = await lerProcs(nums), novo: Array<[string, D.Proc]> = [], procs = new Map(old);
  const uc = o.completa || o.numeros?.length ? null : await ultimaCompleta();
  const leve = !!uc && uc.base > 0 && run.ini - uc.ini < COMPLETA_MS;
  run.modo = leve ? "leve" : "completa"; run.desde = leve ? uc!.base - MARGEM_MS : null;
  /* na leve, quem ainda não tem linha de base é lido por inteiro, num lote à parte */
  const semBase = leve ? nums.filter((n) => !old.get(n)?.g) : [];
  const fila: Array<{ part: string[]; desde: number | null }> = [];
  const comBase = leve ? nums.filter((n) => old.get(n)?.g) : nums;
  for (let i = 0; i < comBase.length; i += LOTE) fila.push({ part: comBase.slice(i, i + LOTE), desde: run.desde ?? null });
  for (let i = 0; i < semBase.length; i += LOTE) fila.push({ part: semBase.slice(i, i + LOTE), desde: null });
  for (let q = 0; q < fila.length && !estado.parar; q++) {
    const { part, desde } = fila[q];
    let docs: any[];
    try { docs = await consultarCNJ(part, ALIAS, "", desde); }
    catch (e) { run.erros += part.length; run.erro = e instanceof Error ? e.message : String(e); if (e instanceof DataJudErro && [400, 401, 403].includes(e.status)) break; continue; }
    const by: Record<string, D.Doc[]> = {};
    for (const raw of docs) { const x = D.normalizarDoc(raw); if (x) (by[x.num] ||= []).push(x.doc); }
    for (const n of part) {
      const g = by[n], prev = old.get(n);
      if (!g) {
        if (desde) continue;                                     // leve: não voltou = não mudou
        run.naoLoc++; const x = D.naoLocalizado(prev, run.ini);
        if (x.sumiu) run.sumidos.push(n);
        if (!prev || !prev.nf || x.sumiu) novo.push([n, x.rec]);
        procs.set(n, x.rec); continue;
      }
      run.encontrados++;
      for (const d of g) run.base = Math.max(run.base, d.upd || 0, d.ts || 0);
      const c = D.comparar(prev, g, run.ini);
      if (c.estado === "prim") run.prim++;
      if (c.estado === "atual") { run.atual.push(n); run.novosMov += c.novos; if (c.cad) run.cad++; }
      if (c.estado !== "igual" || JSON.stringify(prev?.g) !== JSON.stringify(c.rec.g)) novo.push([n, c.rec]);   // só grava o que mudou
      procs.set(n, c.rec);
    }
    if (docs.length) await atualizarAcervoComDataJud(docs.slice(0, 1000)).catch((e) => logger.warn({ err: e?.message }, "datajud: acervo local não atualizado neste lote"));
    estado.feitos = Math.min(nums.length, estado.feitos + part.length);
  }
  await gravarProcs(novo);
  run.fim = Date.now(); run.interrompido = estado.parar || undefined;
  const C = await contextoAvaliacao(procs, [...new Set([...run.atual, ...run.sumidos])]);
  const ev = D.avaliar(run, C), novos = await gravarEventos(ev);
  run.eventos = novos.length;
  await pool.query("INSERT INTO datajud_execucao (inicio, fim, dados) VALUES (to_timestamp($1 / 1000.0), to_timestamp($2 / 1000.0), $3::jsonb)",
    [run.ini, run.fim, JSON.stringify(run)]);
  await pool.query("DELETE FROM datajud_execucao WHERE id NOT IN (SELECT id FROM datajud_execucao ORDER BY inicio DESC LIMIT 200)");
  const im = novos.filter((e) => e.tier === "imediata");
  /* aviso ao vivo para as Centrais abertas: resumo pequeno; cada navegador busca só os processos alterados */
  const por: Record<string, number> = {};
  for (const e of im) for (const rid of e.to) por[rid] = (por[rid] || 0) + 1;
  if (run.atual.length || run.sumidos.length || run.prim || novos.length) {
    const top = run.atual.slice(0, 6).map((n) => { const r = procs.get(n), m = r?.novos?.[0]; return { p: C.ctx.get(n)?.processo || D.cnjFmt(n), m: m ? m.n : r?.capa?.[0]?.t || "atualização cadastral" }; });
    await publicar({ tipo: "sync", ini: run.ini, fim: run.fim, modo: run.modo, primeiras: run.prim, atualizados: run.atual.length, sumidos: run.sumidos.length, eventos: novos.length, imediatos: im.length, por, top });
  }
  if (im.length) {
    const ids = await envelopes("imediata", im, run.ini, run.fim, C);
    if (C.config.envioAuto && canal()) await enviarPendentes(ids);
  }
  logger.info({ motivo: o.motivo, modo: run.modo, consultados: run.consultados, atualizados: run.atual.length, gravados: novo.length, eventos: novos.length, erro: run.erro }, "datajud: sincronização concluída");
  return run;
}
async function gravarEventos(ev: D.Evento[]): Promise<D.Evento[]> {
  if (!ev.length) return [];
  const rows = ev.map((e) => ({ id: e.id, processo: e.n, regra: e.r, periodicidade: e.tier, dados: e }));
  const { rows: ins } = await pool.query(`INSERT INTO datajud_evento (id, processo, regra, periodicidade, detectado_em, dados)
    SELECT x.id, x.processo, x.regra, x.periodicidade, now(), x.dados FROM jsonb_to_recordset($1::jsonb) AS x(id text, processo text, regra text, periodicidade text, dados jsonb)
    ON CONFLICT (id) DO NOTHING RETURNING id`, [JSON.stringify(rows)]);
  const ok = new Set(ins.map((r) => r.id));
  return ev.filter((e) => ok.has(e.id));
}

/* ───────── envelopes, resumos e entrega ───────── */
async function envelopes(tipo: D.Envelope["tipo"], E: D.Evento[], de: number, ate: number, C: D.Contexto, todos = false): Promise<number[]> {
  const by = new Map<string, D.Evento[]>();
  for (const e of E) for (const rid of e.to.length ? e.to : [""]) { if (!by.has(rid)) by.set(rid, []); by.get(rid)!.push(e); }
  if (todos) for (const d of C.destinatarios) if (d.on !== false && d.email && !by.has(d.id)) by.set(d.id, []);
  const ids: number[] = [];
  for (const [rid, X] of by) {
    const d = C.destinatarios.find((y) => y.id === rid) || null;
    let semana: D.Envelope["semana"];
    if (tipo === "semanal" && d) {
      const { rows } = await pool.query(`SELECT periodicidade, count(*)::int AS n FROM datajud_evento WHERE detectado_em > to_timestamp($1 / 1000.0)
        AND detectado_em <= to_timestamp($2 / 1000.0) AND dados->'to' ? $3 GROUP BY periodicidade`, [de, ate, rid]);
      const n = (k: string) => Number(rows.find((r) => r.periodicidade === k)?.n || 0);
      semana = { imediatos: n("imediata"), diarios: n("diaria") };
    }
    const c = D.compor({ tipo, de, ate, semana }, d, X, fmt);
    const { rows } = await pool.query(`INSERT INTO datajud_envio (tipo, destinatario, nome, email, assunto, texto, html, eventos, de, ate)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb, to_timestamp($9 / 1000.0), to_timestamp($10 / 1000.0)) RETURNING id`,
      [tipo, rid, d ? d.nome : "", d ? d.email : "", c.assunto, c.texto, c.html, JSON.stringify(X.map((e) => e.id)), de, ate]);
    ids.push(rows[0].id);
  }
  await pool.query("DELETE FROM datajud_envio WHERE id NOT IN (SELECT id FROM datajud_envio ORDER BY criado_em DESC LIMIT 2000)");
  return ids;
}
export async function resumo(tipo: "diaria" | "semanal", manual = false, alvo?: number): Promise<{ envelopes: number; itens: number } | null> {
  await garantirTabelasDataJud();
  return comTrava("cmt-datajud-resumo", async () => {
    const agora = Date.now(), marcas = await lerMarcas(), desde = marcas[tipo] || agora - (tipo === "semanal" ? 7 : 1) * 864e5;
    if (alvo && (marcas[tipo] || 0) >= alvo) return null;                 // outra instância já gerou
    const procs = tipo === "semanal" ? await lerProcs() : new Map<string, D.Proc>();
    const C = await contextoAvaliacao(procs, tipo === "semanal" ? [...procs.keys()] : []);
    if (tipo === "semanal") await gravarEventos(D.parados(C));
    const { rows } = await pool.query(`SELECT dados FROM datajud_evento WHERE detectado_em > to_timestamp($1 / 1000.0) AND detectado_em <= now()
      AND periodicidade = ANY($2::text[]) ORDER BY detectado_em`, [desde, tipo === "semanal" ? ["semanal"] : ["diaria", "imediata"]]);
    const E = rows.map((r) => r.dados as D.Evento);
    const ids = await envelopes(tipo, E, desde, agora, C, C.config.vazio);
    await gravarMarca(tipo, agora);
    if (C.config.envioAuto && canal()) await enviarPendentes(ids);
    logger.info({ tipo, manual, envelopes: ids.length, itens: E.length }, "datajud: resumo gerado");
    return { envelopes: ids.length, itens: E.length };
  });
}
export function canal(): "agentmail" | "webhook" | null {
  if (env("DATAJUD_AGENTMAIL_INBOX") && (env("DATAJUD_AGENTMAIL_KEY") || env("AGENTMAIL_ENTRADA_KEY"))) return "agentmail";
  if (env("NOTIFY_WEBHOOK")) return "webhook";
  return null;
}
export type Mensagem = { para: Array<{ nome: string; email: string }>; assunto: string; texto: string; html?: string; tipo?: string; eventos?: unknown[] };
export async function entregar(m: Mensagem): Promise<string> {
  const via = canal();
  if (!via) throw new DataJudErro("Nenhum canal de envio configurado (DATAJUD_AGENTMAIL_INBOX ou NOTIFY_WEBHOOK).", 503);
  if (via === "agentmail") {
    const inbox = env("DATAJUD_AGENTMAIL_INBOX"), key = env("DATAJUD_AGENTMAIL_KEY") || env("AGENTMAIL_ENTRADA_KEY");
    const r = await fetch(`https://api.agentmail.to/v0/inboxes/${encodeURIComponent(inbox)}/messages/send`, { method: "POST", signal: AbortSignal.timeout(20e3),
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({ to: m.para.map((p) => p.email), subject: m.assunto, text: m.texto, ...(m.html ? { html: m.html } : {}), labels: ["gabcmt-datajud"] }) });
    if (!r.ok) throw new DataJudErro(`AgentMail recusou o envio (HTTP ${r.status}).`, 502);
    return "AgentMail";
  }
  const token = env("NOTIFY_TOKEN");
  const r = await fetch(env("NOTIFY_WEBHOOK"), { method: "POST", signal: AbortSignal.timeout(20e3),
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify({ em: new Date().toISOString(), origem: "GabCMT · DataJud", ...m }) });
  if (!r.ok) throw new DataJudErro(`O webhook respondeu HTTP ${r.status}.`, 502);
  return "webhook";
}
export async function enviarPendentes(ids?: number[]) {
  await garantirTabelasDataJud();
  const { rows } = ids ? await pool.query("SELECT * FROM datajud_envio WHERE id = ANY($1::int[]) AND enviado_em IS NULL", [ids])
    : await pool.query("SELECT * FROM datajud_envio WHERE enviado_em IS NULL AND email <> '' ORDER BY criado_em LIMIT 200");
  let ok = 0, falhas = 0, ultimo = "";
  for (const e of rows) {
    if (!e.email) continue;
    try {
      const via = await entregar({ para: [{ nome: e.nome, email: e.email }], assunto: e.assunto, texto: e.texto, html: e.html, tipo: e.tipo });
      await pool.query("UPDATE datajud_envio SET enviado_em = now(), via = $2, erro = NULL WHERE id = $1", [e.id, via]); ok++;
    } catch (err) {
      ultimo = err instanceof Error ? err.message : String(err); falhas++;
      await pool.query("UPDATE datajud_envio SET erro = $2 WHERE id = $1", [e.id, ultimo.slice(0, 300)]);
    }
  }
  return { enviados: ok, falhas, erro: ultimo || null };
}

/* ───────── leitura para a Central ───────── */
/* desde (ms): só os processos gravados depois desse instante — é o que a Central baixa a cada aviso ao vivo */
export async function estadoParaCentral(desde?: number) {
  await garantirTabelasDataJud();
  const [procs, runs] = await Promise.all([
    desde ? pool.query("SELECT processo, dados FROM datajud_processo WHERE atualizado_em > to_timestamp($1 / 1000.0)", [desde]).then((r) => new Map(r.rows.map((x) => [x.processo as string, x.dados as D.Proc])))
      : lerProcs(),
    pool.query("SELECT dados FROM datajud_execucao ORDER BY inicio DESC LIMIT 40")]);
  const R = runs.rows.map((r) => r.dados as D.Run);
  return { at: R[0]?.fim || null, runs: R, proc: Object.fromEntries(procs), ...(desde ? { parcial: true, desde } : {}), servidorEm: Date.now() };
}
export async function marcarVisto(nums: string[], visto: boolean) {
  await garantirTabelasDataJud();
  const L = [...new Set(nums.map(D.digitos))].filter((n) => n.length === 20).slice(0, 20000);
  if (!L.length) return 0;
  const r = await pool.query("UPDATE datajud_processo SET dados = jsonb_set(dados, '{seen}', $2::jsonb) WHERE processo = ANY($1::text[])", [L, JSON.stringify(!!visto)]);
  return r.rowCount || 0;
}
export async function status() {
  await garantirTabelasDataJud();
  const [{ rows }, cfg, marcas] = await Promise.all([pool.query("SELECT dados FROM datajud_execucao ORDER BY inicio DESC LIMIT 1"), lerConfig(), lerMarcas()]);
  const ult = rows[0]?.dados as D.Run | undefined, agora = Date.now(), c = cfg.dados;
  let proxima: number | null = null;
  if (c.auto > 0) { proxima = Math.max(agora, (ult?.ini || 0) + c.auto * 60e3); for (let k = 0; k < 48 && !D.dentroDaJanela(proxima, c.janela, FUSO); k++) proxima += 30 * 60e3; }
  return { rodando: estado.rodando, prog: estado.rodando ? { done: estado.feitos, tot: estado.total, motivo: estado.motivo, autor: estado.autor } : null,
    ultima: ult || null, proxima, auto: c.auto, janela: c.janela, fuso: FUSO, alias: ALIAS, canal: canal(), agenda: agendaLigada(),
    reqUltimoMinuto: reqUltimoMinuto(), rpm: RPM, aoVivo: aoVivo(),
    resumos: { diaria: { ultima: marcas.diaria || null, proxima: D.proximoAlvo(agora, c.hora, FUSO, { uteis: c.uteis }) },
      semanal: { ultima: marcas.semanal || null, proxima: D.proximoAlvo(agora, c.semHora, FUSO, { dia: c.semDia }) } } };
}
export async function painelNotificacoes() {
  await garantirTabelasDataJud();
  const [cfg, dest, ev, envs, st] = await Promise.all([lerConfig(), destinatarios(),
    pool.query("SELECT dados FROM datajud_evento ORDER BY detectado_em DESC LIMIT 400"),
    pool.query(`SELECT id, tipo, destinatario, nome, email, assunto, texto, eventos, extract(epoch from criado_em) * 1000 AS at,
      extract(epoch from de) * 1000 AS de, extract(epoch from ate) * 1000 AS ate, extract(epoch from enviado_em) * 1000 AS sent, via, erro
      FROM datajud_envio ORDER BY criado_em DESC LIMIT 150`), status()]);
  const extra = new Map<string, D.Evento>();
  const have = new Set(ev.rows.map((r) => (r.dados as D.Evento).id));
  const faltam = [...new Set(envs.rows.flatMap((e) => e.eventos as string[]))].filter((id) => !have.has(id));
  if (faltam.length) { const { rows } = await pool.query("SELECT dados FROM datajud_evento WHERE id = ANY($1::text[])", [faltam]); for (const r of rows) extra.set(r.dados.id, r.dados); }
  return { config: cfg.dados, versao: cfg.versao, destinatarios: dest, regras: D.regrasPublicas(), tpu: D.TPU,
    eventos: [...ev.rows.map((r) => r.dados), ...extra.values()],
    envios: envs.rows.map((e) => ({ id: String(e.id), tier: e.tipo, rid: e.destinatario, nome: e.nome, email: e.email, assunto: e.assunto, texto: e.texto,
      ev: e.eventos, at: Number(e.at), de: Number(e.de), ate: Number(e.ate), sent: e.sent ? Number(e.sent) : null, via: e.via, erro: e.erro })),
    status: st };
}
export async function marcarEnviado(id: number, autor: string) {
  await pool.query("UPDATE datajud_envio SET enviado_em = now(), via = $2 WHERE id = $1 AND enviado_em IS NULL", [id, "marcado manualmente" + (autor ? " · " + autor : "")]);
}
export async function limparEnviados() { await pool.query("DELETE FROM datajud_envio WHERE enviado_em IS NOT NULL"); }

/* ───────── agenda ───────── */
let relogio: NodeJS.Timeout | null = null;
const agendaLigada = () => env("DATAJUD_AGENDA") !== "0";
let ocupado = false;
export async function tick(motivo = "agenda"): Promise<Record<string, unknown>> {
  if (!env("DATABASE_URL")) return { pulado: "sem banco" };
  if (ocupado) return { pulado: "agenda já em execução" };
  ocupado = true;
  try { return await tick0(motivo); } finally { ocupado = false; }
}
async function tick0(motivo: string): Promise<Record<string, unknown>> {
  await garantirTabelasDataJud();
  const { dados: c } = await lerConfig(), agora = Date.now(), out: Record<string, unknown> = {};
  if (c.auto > 0 && !estado.rodando && D.dentroDaJanela(agora, c.janela, FUSO)) {
    const { rows } = await pool.query("SELECT extract(epoch from max(inicio)) * 1000 AS t FROM datajud_execucao");
    const ult = Number(rows[0]?.t || 0);
    if (!ult || agora - ult >= c.auto * 60e3) {
      try { const r = await sincronizar({ motivo: motivo === "cron" ? "agendada (gatilho externo)" : "automática" }); out.sincronizacao = { atualizados: r.atual.length, eventos: r.eventos }; }
      catch (e) { out.sincronizacao = { erro: e instanceof Error ? e.message : String(e) }; }
    }
  }
  const marcas = await lerMarcas();
  for (const [tipo, alvo] of [["diaria", D.ultimoAlvo(agora, c.hora, FUSO, { uteis: c.uteis })], ["semanal", D.ultimoAlvo(agora, c.semHora, FUSO, { dia: c.semDia })]] as const) {
    if (!marcas[tipo]) { await gravarMarca(tipo, alvo); continue; }       // primeira vez: começa a contar daqui
    if (marcas[tipo]! < alvo) out[tipo] = await resumo(tipo, false, alvo);
  }
  return out;
}
export function iniciarAgendaDataJud() {
  if (!agendaLigada() || relogio || !env("DATABASE_URL")) return;
  const rodar = () => { tick().catch((e) => logger.warn({ err: e instanceof Error ? e.message : String(e) }, "datajud: agenda falhou")); };
  setTimeout(rodar, 20_000).unref();
  relogio = setInterval(rodar, 60_000);
  relogio.unref();
  logger.info({ fuso: FUSO, alias: ALIAS }, "datajud: agenda ligada");
}

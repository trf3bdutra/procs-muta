import { createHash } from "node:crypto";

type FeatureBlock = {
  id: string;
  tag: "script" | "style";
  feature: "configuracoes" | "gerador" | "painel-direito" | "rodapes";
};

export type GabcmtFeatureAsset = {
  content: string;
  contentType: "application/javascript" | "text/css";
  etag: string;
  feature: FeatureBlock["feature"];
};

export type GabcmtFeatureDocument = {
  html: string;
  assets: Record<string, GabcmtFeatureAsset>;
};

const OPERATIONAL_CENTER_ASSET = "cmt-operational-center.js";
const OPERATIONAL_CENTER_IDS = {
  style: "cmt-center-panels-style",
  controls: "cmt-center-panels-controls",
} as const;
const OPERATIONAL_CENTER_THEME = `
#alt-side[data-cmt-page="decisoes"]{--cmt-page-rail:#174e45;--cmt-page-edge:#78a89a}
#alt-rside[data-cmt-page="decisoes"] .rr-head,#alt-rside[data-cmt-page="decisoes"] .rr-foot{background:#174e45!important;border-color:#78a89a!important}
#alt-rside[data-cmt-page="decisoes"]{--gd-bg:#174e45;--gd-ac:#28655a}
#cx-rrail#cx-rrail[data-cmt-page="decisoes"]{--cx-rr-bg:#174e45;--cx-rr-ac:#28655a;border-color:#78a89a!important}
#cx-rrail#cx-rrail[data-cmt-page="decisoes"]>.rr-top,#cx-rrail#cx-rrail[data-cmt-page="decisoes"]>.rr-foot{background:#174e45!important;border-color:#78a89a!important}
#cx-rrail#cx-rrail[data-cmt-page="decisoes"] .rr-btn{background:#28655a!important;border-color:#78a89a!important;color:#eff5ee!important}
#cx-rrail#cx-rrail[data-cmt-page="decisoes"] .rr-btn[aria-pressed="true"]{background:#d7c88c!important;color:#19493e!important}
#pauta-global-dock>.gd-foot[data-page-footer="decisoes"]{--gd-bg:#174e45;--gd-ac:#28655a;--gd-line:#457c6d}
:is(#cmt-center-panels,#cmt-center-panels-pauta,#cmt-center-panels-decisoes)[data-center-page="decisoes"]{border-color:#78a89a!important}
:is(#cmt-center-panels,#cmt-center-panels-pauta,#cmt-center-panels-decisoes)[data-center-page="decisoes"] .cmt-center-panel-head{background:#174e45!important;border-color:#457c6d!important;color:#edf5ed!important}
:is(#cmt-center-panels,#cmt-center-panels-pauta,#cmt-center-panels-decisoes)[data-center-page="decisoes"] .cmt-center-panel-tabs [aria-selected="true"]{background:#28655a!important;border-color:#78a89a!important;color:#fff!important}
`;

function extractOperationalCenter(html: string) {
  const style = extractBlock(html, { id: OPERATIONAL_CENTER_IDS.style, tag: "style", feature: "rodapes" });
  const controls = extractBlock(html, { id: OPERATIONAL_CENTER_IDS.controls, tag: "script", feature: "rodapes" });
  if (!style && !controls) return null;
  if (!style || !controls) {
    throw new Error("The operational center must include its style and controls together.");
  }

  const css = `${style.content.replace(
    /#cmt-center-panels/g,
    ":is(#cmt-center-panels,#cmt-center-panels-pauta,#cmt-center-panels-decisoes)",
  )}\n${OPERATIONAL_CENTER_THEME}`;
  const content = [
    "/* cmt-center-panels-style:start */",
    `const cmtCenterPanelsCss=${JSON.stringify(css)};`,
    `(()=>{const s=document.createElement('style');s.id='cmt-center-panels-style';s.textContent=cmtCenterPanelsCss;(document.head||document.documentElement).appendChild(s);})();`,
    "/* cmt-center-panels-controls:start */",
    controls.content,
  ].join("\n");
  const etag = createHash("sha256").update(content).digest("hex");
  const url = `/api/app/gabcmt-feature-modules/${OPERATIONAL_CENTER_ASSET}?v=${etag}`;

  const operations = [
    { start: style.start, end: style.end, replacement: "" },
    {
      start: controls.start,
      end: controls.end,
      replacement: `<script id="cmt-operational-center-module" src="${url}"></script>`,
    },
  ].sort((a, b) => a.start - b.start);
  const output: string[] = [];
  let cursor = 0;
  for (const operation of operations) {
    if (operation.start < cursor) throw new Error("Operational center source blocks overlap.");
    output.push(html.slice(cursor, operation.start), operation.replacement);
    cursor = operation.end;
  }
  output.push(html.slice(cursor));
  return { html: output.join(""), content, etag };
}

/*
 * Os módulos são extraídos do GabCMT vigente no limite de entrega. Assim,
 * edições posteriores do HTML continuam sendo a fonte oficial sem recolocar
 * os blocos dentro do HTML que o navegador recebe.
 *
 * Os blocos permanecem nos pontos originais do documento para preservar a
 * ordem de execução e a cascata de estilos das dependências legadas.
 */
export const GABCMT_FEATURE_BLOCKS: readonly FeatureBlock[] = [
  { id: "cmt-settings-view-controller", tag: "script", feature: "configuracoes" },
  { id: "cfg-modal-v25-style", tag: "style", feature: "configuracoes" },
  { id: "cfg-v59-style", tag: "style", feature: "configuracoes" },
  { id: "cmt-v80-cfgio-style", tag: "style", feature: "configuracoes" },
  { id: "cmt-v272-cfg-chamados", tag: "style", feature: "configuracoes" },
  { id: "cmt-v194-config-css", tag: "style", feature: "configuracoes" },
  { id: "cmt-v217-config-por-cima", tag: "style", feature: "configuracoes" },
  { id: "cmt-v200-config-faixa", tag: "style", feature: "configuracoes" },
  { id: "cmt-v201-config-compacto", tag: "style", feature: "configuracoes" },
  { id: "cmt-v226-config-pagina", tag: "style", feature: "configuracoes" },
  { id: "cmt-v241-config-rodape", tag: "style", feature: "configuracoes" },
  { id: "cmt-v242-config-conteudo", tag: "style", feature: "configuracoes" },
  { id: "cfg-dialog-close-and-contrast", tag: "style", feature: "configuracoes" },
  { id: "cmt-cfgio-feature", tag: "script", feature: "configuracoes" },
  { id: "cmt-v194-config", tag: "script", feature: "configuracoes" },
  { id: "cmt-v226-config-pagina-js", tag: "script", feature: "configuracoes" },
  { id: "cmt-v247-cfg-acompanhamento", tag: "script", feature: "configuracoes" },
  { id: "cmt-v269-css", tag: "style", feature: "gerador" },
  { id: "cmt-v269-gerador", tag: "script", feature: "gerador" },
  { id: "cmtx-v37-ui-style", tag: "style", feature: "painel-direito" },
  { id: "cmtx-v37-rrail-script", tag: "script", feature: "painel-direito" },
  { id: "cmt-v280-page-footers", tag: "script", feature: "rodapes" },
  { id: "cmt-frame-stability-css", tag: "style", feature: "painel-direito" },
];

const escapeRegExp = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

function extractBlock(html: string, block: FeatureBlock) {
  const id = escapeRegExp(block.id);
  const expression = new RegExp(
    `<${block.tag}\\b(?=[^>]*\\bid=["']${id}["'])[^>]*>([\\s\\S]*?)<\\/${block.tag}\\s*>`,
    "i",
  );
  const match = expression.exec(html);
  if (!match) return null;

  const content = match[1];
  const extension = block.tag === "script" ? "js" : "css";
  const key = `${block.id}.${extension}`;
  const etag = createHash("sha256").update(content).digest("hex");
  const url = `/api/app/gabcmt-feature-modules/${key}?v=${etag}`;
  const replacement = block.tag === "script"
    ? `<script id="${block.id}" src="${url}"></script>`
    : `<link id="${block.id}" rel="stylesheet" href="${url}">`;

  return {
    key,
    content,
    etag,
    replacement,
    start: match.index,
    end: match.index + match[0].length,
  };
}

export function prepareGabcmtFeatureDocument(html: string): GabcmtFeatureDocument {
  const operationalCenter = extractOperationalCenter(html);
  const source = operationalCenter?.html ?? html;
  const matches = GABCMT_FEATURE_BLOCKS.flatMap((block) => {
    const found = extractBlock(source, block);
    return found ? [{ block, found }] : [];
  }).sort((a, b) => a.found.start - b.found.start);
  const assets: Record<string, GabcmtFeatureAsset> = operationalCenter ? {
    [OPERATIONAL_CENTER_ASSET]: {
      content: operationalCenter.content,
      contentType: "application/javascript",
      etag: operationalCenter.etag,
      feature: "rodapes",
    },
  } : {};
  const output: string[] = [];
  let cursor = 0;

  for (const { block, found } of matches) {
    if (found.start < cursor) throw new Error("GabCMT feature source blocks overlap.");
    assets[found.key] = {
      content: found.content,
      contentType: block.tag === "script" ? "application/javascript" : "text/css",
      etag: found.etag,
      feature: block.feature,
    };
    output.push(source.slice(cursor, found.start), found.replacement);
    cursor = found.end;
  }
  output.push(source.slice(cursor));

  // Fetch independent assets together, but execute them in their original
  // parser positions. `async`/`defer` would break legacy module dependencies.
  const preload = Object.entries(assets).map(([key, asset]) =>
    `<link rel="preload" as="${asset.contentType === "text/css" ? "style" : "script"}" href="/api/app/gabcmt-feature-modules/${key}?v=${asset.etag}">`,
  ).join("");
  const document = output.join("").replace(/<head\b[^>]*>/i, (head) => head + preload);
  return { html: document, assets };
}

export function isGabcmtFeatureAsset(value: string) {
  if (value === OPERATIONAL_CENTER_ASSET) return true;
  return GABCMT_FEATURE_BLOCKS.some((block) => {
    const extension = block.tag === "script" ? "js" : "css";
    return value === `${block.id}.${extension}`;
  });
}

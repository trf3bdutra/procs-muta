const communicationInboxScript = String.raw`(() => {
  if (window.CMTAgentMailCommunication) return;
  const D = document;
  let root = null, active = false, busy = false, loaded = false;
  let query = '', pageToken = '', messages = [], detail = null, error = '';

  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));
  const date = value => {
    if (!value) return '';
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? String(value) : parsed.toLocaleString('pt-BR', {
      day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit'
    });
  };
  const report = message => {
    error = String(message || 'Não foi possível consultar a caixa.');
    render();
  };

  function style() {
    if (D.getElementById('pa-agentmail-comunicacao-style')) return;
    const s = D.createElement('style');
    s.id = 'pa-agentmail-comunicacao-style';
    s.textContent = "#pa-agentmail-comunicacao{position:fixed;z-index:2147483001;top:var(--pa-dock-top,64px);right:var(--pa-dock-r,0px);bottom:var(--pa-dock-bot,58px);width:var(--pa-dock-w,460px);display:flex;flex-direction:column;min-width:0;overflow:hidden;background:#f4f7f9;color:#183047;font:500 12px/1.45 Figtree,system-ui,sans-serif;border-left:1px solid #dce5ea;box-shadow:-8px 0 22px #102b3a12}" +
      "#pa-agentmail-comunicacao[hidden]{display:none!important}" +
      "#pa-agentmail-comunicacao *{box-sizing:border-box;min-width:0}" +
      "#pa-agentmail-comunicacao .amc-head{padding:11px 12px 9px;background:#fff;border-bottom:1px solid #e2e9ee;flex:0 0 auto}" +
      "#pa-agentmail-comunicacao .amc-top{display:flex;align-items:center;justify-content:space-between;gap:8px}" +
      "#pa-agentmail-comunicacao .amc-title{font-size:13px;font-weight:800;color:#19394e}" +
      "#pa-agentmail-comunicacao .amc-address{display:block;margin-top:2px;color:#66798a;font-size:10.5px;overflow-wrap:anywhere}" +
      "#pa-agentmail-comunicacao button{font:700 11px/1.2 Figtree,system-ui,sans-serif;cursor:pointer;border:1px solid #d7e1e7;border-radius:7px;background:#fff;color:#23465a;padding:7px 9px}" +
      "#pa-agentmail-comunicacao button:hover{background:#edf5f6;border-color:#bad0d7}" +
      "#pa-agentmail-comunicacao .amc-search{display:flex;gap:6px;margin-top:9px}" +
      "#pa-agentmail-comunicacao .amc-search input{flex:1;width:100%;height:33px;border:1px solid #d6e0e6;border-radius:7px;padding:0 9px;background:#fff;color:#183047;font:500 11.5px Figtree,system-ui,sans-serif}" +
      "#pa-agentmail-comunicacao .amc-status{padding:7px 11px;color:#63788a;font-size:10.5px;flex:0 0 auto}" +
      "#pa-agentmail-comunicacao .amc-error{margin:0 9px 7px;padding:9px 10px;background:#fff1ed;border:1px solid #f1c9bd;border-radius:8px;color:#873f2e;font-size:11px}" +
      "#pa-agentmail-comunicacao .amc-list{flex:1;overflow:auto;padding:0 8px 10px;overscroll-behavior:contain}" +
      "#pa-agentmail-comunicacao .amc-item{display:block;width:100%;margin:0 0 6px;text-align:left;border-radius:9px;padding:9px 10px;background:#fff}" +
      "#pa-agentmail-comunicacao .amc-item.is-unread{border-left:3px solid #d8b350}" +
      "#pa-agentmail-comunicacao .amc-item .amc-from{display:block;font-size:10px;color:#63788a;overflow-wrap:anywhere}" +
      "#pa-agentmail-comunicacao .amc-item .amc-subject{display:block;margin:3px 0;font-size:12px;color:#17384d}" +
      "#pa-agentmail-comunicacao .amc-item .amc-preview{display:block;color:#627789;font-size:10.5px;line-height:1.35}" +
      "#pa-agentmail-comunicacao .amc-item .amc-date{display:block;margin-top:5px;color:#8795a0;font-size:9.5px}" +
      "#pa-agentmail-comunicacao .amc-empty{margin:16px 5px;padding:16px 12px;text-align:center;color:#63788a;background:#fff;border:1px dashed #d4dfe5;border-radius:9px}" +
      "#pa-agentmail-comunicacao .amc-more{display:flex;justify-content:center;padding:4px 0 10px}" +
      "#pa-agentmail-comunicacao .amc-detail{flex:1;overflow:auto;padding:10px}" +
      "#pa-agentmail-comunicacao .amc-detail-card{padding:11px;background:#fff;border:1px solid #e0e7ec;border-radius:9px}" +
      "#pa-agentmail-comunicacao .amc-detail h3{margin:8px 0 10px;font-size:14px;line-height:1.35;color:#19394e;overflow-wrap:anywhere}" +
      "#pa-agentmail-comunicacao .amc-meta{display:grid;gap:4px;color:#657a8b;font-size:10px;overflow-wrap:anywhere}" +
      "#pa-agentmail-comunicacao .amc-body{margin:12px 0 0;padding-top:10px;border-top:1px solid #e5ebef;white-space:pre-wrap;overflow-wrap:anywhere;font:500 11.5px/1.55 Figtree,system-ui,sans-serif;color:#243f53}" +
      "@media(max-width:700px){#pa-agentmail-comunicacao{width:100vw;right:0}}";
    (D.head || D.documentElement).appendChild(s);
  }

  function mount() {
    if (root) return;
    style();
    root = D.createElement('aside');
    root.id = 'pa-agentmail-comunicacao';
    root.hidden = true;
    root.setAttribute('aria-label', 'Caixa de entrada do AgentMail gabinete-cmt');
    D.body.appendChild(root);
    root.addEventListener('submit', event => {
      const form = event.target;
      if (!form.matches('[data-amc-search]')) return;
      event.preventDefault();
      query = String(new FormData(form).get('q') || '').trim();
      pageToken = '';
      detail = null;
      messages = [];
      loaded = false;
      void load(true);
    });
    root.addEventListener('click', event => {
      const button = event.target instanceof Element ? event.target.closest('button') : null;
      if (!button || !root.contains(button)) return;
      if (button.hasAttribute('data-amc-refresh')) { void load(true); return; }
      if (button.hasAttribute('data-amc-back')) { detail = null; render(); return; }
      if (button.hasAttribute('data-amc-more')) { void load(false); return; }
      const id = button.getAttribute('data-amc-id');
      if (id) void openMessage(id);
    });
  }

  function render() {
    if (!root) return;
    const oldList = root.querySelector('.amc-list');
    const oldScroll = oldList ? oldList.scrollTop : 0;
    const status = busy ? 'Consultando AgentMail…' : loaded
      ? (messages.length ? messages.length + ' mensagem(ns) nesta página' : 'Nenhuma mensagem encontrada')
      : 'A caixa não foi consultada nesta sessão.';
    const header = '<header class="amc-head"><div class="amc-top"><div><div class="amc-title">Caixa de entrada</div><span class="amc-address">gabinete-cmt@agentmail.to</span></div><button type="button" data-amc-refresh aria-label="Atualizar caixa">Atualizar</button></div>'
      + '<form class="amc-search" data-amc-search><input type="search" name="q" value="' + esc(query) + '" placeholder="Buscar remetente, assunto ou conteúdo" aria-label="Buscar e-mails"><button type="submit">Buscar</button></form></header>';
    if (detail) {
      const attachments = detail.attachments && detail.attachments.length
        ? '<p class="amc-meta">Anexos: ' + detail.attachments.map(x => esc(x.name)).join(', ') + '</p>' : '';
      root.innerHTML = header + (error ? '<div class="amc-error" role="alert">' + esc(error) + '</div>' : '')
        + '<div class="amc-detail"><button type="button" data-amc-back>← Voltar à caixa</button><article class="amc-detail-card"><h3>'
        + esc(detail.subject || '(sem assunto)') + '</h3><div class="amc-meta"><span>De: ' + esc(detail.from) + '</span><span>Para: ' + esc(detail.to) + '</span>'
        + (detail.cc ? '<span>Cc: ' + esc(detail.cc) + '</span>' : '') + '<span>' + esc(date(detail.timestamp)) + '</span></div>'
        + attachments + '<pre class="amc-body">' + esc(detail.text || '(Esta mensagem não contém texto simples.)') + '</pre></article></div>';
      return;
    }
    const rows = messages.map(message => '<button type="button" class="amc-item' + (message.unread ? ' is-unread' : '')
      + '" data-amc-id="' + esc(message.id) + '"><span class="amc-from">' + esc(message.from || 'Remetente não informado')
      + '</span><b class="amc-subject">' + esc(message.subject || '(sem assunto)') + '</b><span class="amc-preview">'
      + esc(message.preview || 'Sem prévia') + '</span><span class="amc-date">' + esc(date(message.timestamp)) + '</span></button>').join('');
    root.innerHTML = header + '<div class="amc-status" aria-live="polite">' + esc(status) + '</div>'
      + (error ? '<div class="amc-error" role="alert">' + esc(error) + '</div>' : '')
      + '<div class="amc-list">' + (rows || (loaded && !busy
        ? '<div class="amc-empty">Não há mensagens nesta caixa ou busca.</div>'
        : '<div class="amc-empty">Abra a caixa ou faça uma busca para consultar mensagens.</div>'))
      + (pageToken ? '<div class="amc-more"><button type="button" data-amc-more>Carregar mais</button></div>' : '')
      + '</div>';
    const newList = root.querySelector('.amc-list');
    if (newList) newList.scrollTop = oldScroll;
  }

  async function load(reset) {
    if (busy) return;
    if (reset) pageToken = '';
    busy = true;
    error = '';
    render();
    try {
      const params = new URLSearchParams();
      if (query) params.set('q', query);
      if (pageToken) params.set('pageToken', pageToken);
      const response = await fetch('/api/pauta/mensagens/email/caixa?' + params.toString(), {
        credentials:'same-origin', cache:'no-store', headers:{Accept:'application/json'}
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || ('HTTP ' + response.status));
      messages = reset ? (data.messages || []) : messages.concat(data.messages || []);
      pageToken = data.nextPageToken || '';
      loaded = true;
    } catch (cause) {
      report(cause && cause.message || 'Não foi possível consultar a caixa.');
    } finally {
      busy = false;
      render();
    }
  }

  async function openMessage(id) {
    if (busy) return;
    busy = true;
    error = '';
    render();
    try {
      const params = new URLSearchParams({messageId:id});
      const response = await fetch('/api/pauta/mensagens/email/caixa/mensagem?' + params.toString(), {
        credentials:'same-origin', cache:'no-store', headers:{Accept:'application/json'}
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || ('HTTP ' + response.status));
      detail = data;
    } catch (cause) {
      report(cause && cause.message || 'Não foi possível abrir esta mensagem.');
    } finally {
      busy = false;
      render();
    }
  }

  function dock(on) {
    if (!on) {
      active = false;
      if (root) root.hidden = true;
      return;
    }
    mount();
    root.hidden = false;
    if (!active) {
      active = true;
      if (!loaded) void load(true);
    }
  }

  setInterval(() => {
    if (active && !busy && !detail) void load(true);
  }, 60_000);
  window.CMTAgentMailCommunication = {dock};
})();`;

export function prepareAgentMailCommunication(html: string): string {
  if (!html.includes("cmt-cfgr-caixa") || html.includes('id="cmt-agentmail-comunicacao"')) return html;
  const closingBody = html.toLowerCase().lastIndexOf("</body>");
  if (closingBody < 0) return html;
  return html.slice(0, closingBody)
    + `<script id="cmt-agentmail-comunicacao">${communicationInboxScript}</script>`
    + html.slice(closingBody);
}

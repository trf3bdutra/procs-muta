import { Router, type IRouter } from "express";
import {
  padraoCatalogChanges,
  PadraoCatalogError,
  searchPadraoPrecedents,
  type PadraoCatalog,
} from "../lib/padrao-catalog";
import { getAppSession } from "./app-auth";
import { atualizarAcervoComDataJud } from "../routes/acervo-importado";

/* Os catálogos ficam indisponíveis até existir uma cópia local.
   DataJud continua consultando a API pública do CNJ, mas seus resultados são salvos no banco local. */
const router: IRouter = Router();

/* chave pública divulgada pelo CNJ na wiki do DataJud; uma chave privada, se configurada, fica só no servidor. */
const DATAJUD_PUBLIC_KEY = "cDZHYzlZa0JadVREZDJCendQbXY6SkJlTzNjLV9TRENyQk1RdnFKZGRQdw==";

async function catalog(): Promise<PadraoCatalog> {
  throw new PadraoCatalogError("unavailable", "Catálogos do Padrão indisponíveis: a conexão externa foi desativada e ainda não há cópia local.");
}

function fail(res: any, error: unknown) {
  const msg = error instanceof Error ? error.message : "Bancos do Padrão indisponíveis.";
  res.status(error instanceof PadraoCatalogError && error.kind === "invalid-response" ? 502 : 503).json({ error: msg });
}

router.use("/shared", (_req, res, next) => { res.set("Cache-Control", "no-store"); next(); });

/* edição livre no próprio navegador; publicação no repositório não é feita por este app */
router.get("/shared/session", (_req, res) => { res.json({ authorized: false, readOnly: true }); });
router.post("/shared/session", (_req, res) => {
  res.status(403).json({ error: "Os bancos do Padrão são somente leitura neste app; as alterações ficam só nesta aba." });
});
router.delete("/shared/session", (_req, res) => { res.json({ authorized: false }); });

router.get("/shared/catalogs", async (req, res): Promise<void> => {
  try {
    const data = await catalog();
    const julgados = ["excluir", "somente", "incluir"].includes(String(req.query.julgados)) ? String(req.query.julgados) : "excluir";
    res.json(padraoCatalogChanges(data, Number(req.query.sinceRevision) || 0, julgados));
  } catch (error) {
    req.log.warn({ err: error instanceof Error ? error.message : String(error) }, "Padrão catalogs unavailable");
    fail(res, error);
  }
});

router.get("/shared/catalogs/mirror-status", (_req, res) => {
  res.status(503).json({ readOnly: true, available: false, reason: "Catálogos sem cópia local." });
});

router.get("/shared/catalogs/precedents/search", async (req, res): Promise<void> => {
  try { res.json(searchPadraoPrecedents(await catalog(), req.query as Record<string, unknown>)); } catch (error) { fail(res, error); }
});

/* ───────── DataJud ───────── */
router.post("/datajud/:tribunal", async (req, res): Promise<void> => {
  const session = getAppSession(req);
  if (!session) { res.status(401).json({ error: "Entre no Gabinete para consultar e sincronizar o DataJud." }); return; }
  const trib = String(req.params.tribunal || "").toLowerCase();
  if (!/^[a-z0-9]{2,12}$/.test(trib)) { res.status(400).json({ error: "Tribunal inválido." }); return; }
  const body = JSON.stringify(req.body ?? {});
  if (body.length > 20_000) { res.status(413).json({ error: "Consulta grande demais." }); return; }
  const key = String(process.env.DATAJUD_API_KEY || DATAJUD_PUBLIC_KEY).trim();
  try {
    const r = await fetch(`https://api-publica.datajud.cnj.jus.br/api_publica_${trib}/_search`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `APIKey ${key}` },
      body,
      signal: AbortSignal.timeout(25_000),
    });
    const text = await r.text();
    if (!r.ok) { res.status(r.status).type("application/json").set("Cache-Control", "no-store").send(text.slice(0, 1_000_000)); return; }
    if (text.length > 8_000_000) { res.status(502).json({ error: "Resposta do DataJud acima do limite seguro." }); return; }
    let data: any;
    try { data = JSON.parse(text); } catch { res.status(502).json({ error: "Resposta inválida do DataJud." }); return; }
    const hits = Array.isArray(data?.hits?.hits) ? data.hits.hits.slice(0, 1000) : [];
    const sincronizacao = await atualizarAcervoComDataJud(hits);
    res
      .status(200)
      .type("application/json")
      .set("Cache-Control", "no-store")
      .set("X-Acervo-Atualizados", String(sincronizacao.alterados + sincronizacao.novos))
      .send(text);
  } catch {
    req.log.error("Falha ao consultar DataJud ou gravar os resultados no banco local do acervo.");
    res.status(502).json({ error: "Não foi possível consultar o DataJud e atualizar o acervo local." });
  }
});

export default router;

type SessionEntry = Record<string, unknown> & {
  session?: unknown;
  closed?: unknown;
};

type PautaState = Record<string, unknown> & {
  sessions?: unknown;
  sessionDetails?: unknown;
  rows?: unknown;
};

export type SessionEmailScope = {
  kind: "session" | "review" | "unrelated";
  sessions: string[];
  processNumbers: string[];
  reason?: string;
};

export type SessionEmailIndex = {
  sessionsByProcess: Map<string, string[]>;
  sessionsByDate: Map<string, string[]>;
};

const digits = (value: unknown): string => String(value ?? "").replace(/\D/g, "");

const normalize = (value: unknown): string =>
  String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("pt-BR");

const MONTHS: Record<string, string> = {
  janeiro: "01",
  fevereiro: "02",
  marco: "03",
  abril: "04",
  maio: "05",
  junho: "06",
  julho: "07",
  agosto: "08",
  setembro: "09",
  outubro: "10",
  novembro: "11",
  dezembro: "12",
};

function record(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
}

function isoDate(value: unknown): string {
  const raw = String(value ?? "").trim();
  const iso = /^(\d{4}-\d{2}-\d{2})/.exec(raw);
  if (iso) return iso[1];
  const normalized = normalize(raw);
  const numeric = /^(\d{1,2})[/. -](\d{1,2})[/. -](\d{4})$/.exec(normalized);
  if (numeric) {
    return `${numeric[3]}-${numeric[2].padStart(2, "0")}-${numeric[1].padStart(2, "0")}`;
  }
  const written = /^(\d{1,2})\s+de\s+([a-z]+)\s+de\s+(\d{4})$/.exec(normalized);
  if (written && MONTHS[written[2]]) {
    return `${written[3]}-${MONTHS[written[2]]}-${written[1].padStart(2, "0")}`;
  }
  return "";
}

function rowSessions(row: Record<string, unknown>): string[] {
  const entries = Array.isArray(row._pautaEntries)
    ? (row._pautaEntries as SessionEntry[])
    : [];
  const sessions = entries
    .filter((entry) => entry?.closed !== true)
    .map((entry) => String(entry?.session ?? "").trim())
    .filter(Boolean);
  const destination = String(row["Sessão Destino"] ?? "").trim();
  if (destination) sessions.push(destination);
  return [...new Set(sessions)];
}

function processNumbers(text: string): string[] {
  const pattern =
    /\b\d{7}\s*-?\s*\d{2}\s*\.?\s*\d{4}\s*\.?\s*\d\s*\.?\s*\d{2}\s*\.?\s*\d{4}\b/g;
  return [
    ...new Set(
      [...text.matchAll(pattern)]
        .map((match) => digits(match[0]))
        .filter((number) => number.length === 20),
    ),
  ];
}

function explicitSessionDates(text: string): string[] {
  const normalized = normalize(text);
  const dates = new Set<string>();
  const patterns = [
    /\b\d{1,2}[/. -]\d{1,2}[/. -]\d{4}\b/g,
    /\b\d{1,2}\s+de\s+(?:janeiro|fevereiro|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s+de\s+\d{4}\b/g,
  ];
  for (const pattern of patterns) {
    for (const match of normalized.matchAll(pattern)) {
      const index = match.index ?? 0;
      const context = normalized.slice(Math.max(0, index - 60), index + match[0].length + 60);
      if (!/\b(sessao|pauta|julgamento)\b/.test(context)) continue;
      const date = isoDate(match[0]);
      if (date) dates.add(date);
    }
  }
  return [...dates];
}

export function buildSessionEmailIndex(
  pautaState: PautaState,
  todayISO: string,
): SessionEmailIndex {
  const details = record(pautaState.sessionDetails);
  const rows = Array.isArray(pautaState.rows)
    ? (pautaState.rows as Record<string, unknown>[])
    : [];
  const labels = new Set<string>(
    Array.isArray(pautaState.sessions)
      ? pautaState.sessions.map((session) => String(session ?? "").trim()).filter(Boolean)
      : [],
  );

  for (const [label, value] of Object.entries(details)) {
    if (label.trim()) labels.add(label.trim());
    void value;
  }
  for (const row of rows) {
    for (const session of rowSessions(record(row))) labels.add(session);
  }

  const sessionsByDate = new Map<string, string[]>();
  const futureSessions = new Set<string>();
  for (const label of labels) {
    const sessionDetails = record(details[label]);
    if (record(sessionDetails.archive).saved === true) continue;
    const date = isoDate(sessionDetails.date) || isoDate(label);
    if (!date || date < todayISO) continue;
    futureSessions.add(label);
    const sameDate = sessionsByDate.get(date) ?? [];
    sameDate.push(label);
    sessionsByDate.set(date, sameDate);
  }

  const processSessionSets = new Map<string, Set<string>>();
  for (const row of rows) {
    const item = record(row);
    const processNumber = digits(item.Processo);
    if (processNumber.length !== 20) continue;
    for (const session of rowSessions(item)) {
      if (!futureSessions.has(session)) continue;
      const sessions = processSessionSets.get(processNumber) ?? new Set<string>();
      sessions.add(session);
      processSessionSets.set(processNumber, sessions);
    }
  }

  return {
    sessionsByProcess: new Map(
      [...processSessionSets].map(([number, sessions]) => [number, [...sessions]]),
    ),
    sessionsByDate,
  };
}

export function classifySessionEmail(
  message: { subject?: unknown; text?: unknown; preview?: unknown },
  index: SessionEmailIndex,
): SessionEmailScope {
  const content = `${message.subject ?? ""}\n${message.text ?? ""}\n${message.preview ?? ""}`;
  const numbers = processNumbers(content);
  const explicitDates = explicitSessionDates(content);
  const matchedProcesses = numbers.filter((number) => index.sessionsByProcess.has(number));
  const processSessions = new Set(
    matchedProcesses.flatMap((number) => index.sessionsByProcess.get(number) ?? []),
  );
  const dateSessions = new Set(
    explicitDates.flatMap((date) => index.sessionsByDate.get(date) ?? []),
  );

  if (processSessions.size && dateSessions.size) {
    const overlap = [...processSessions].filter((session) => dateSessions.has(session));
    if (!overlap.length) {
      return {
        kind: "review",
        sessions: [...new Set([...processSessions, ...dateSessions])],
        processNumbers: numbers,
        reason: "O CNJ e a data explícita apontam para sessões diferentes.",
      };
    }
    return {
      kind: "session",
      sessions: overlap,
      processNumbers: numbers,
    };
  }

  const sessions = processSessions.size ? processSessions : dateSessions;
  if (sessions.size) {
    return {
      kind: "session",
      sessions: [...sessions],
      processNumbers: numbers,
    };
  }

  if (!numbers.length && !explicitDates.length) {
    return {
      kind: "unrelated",
      sessions: [],
      processNumbers: [],
      reason: "Não há CNJ nem data explícita de sessão na mensagem.",
    };
  }

  return {
    kind: "review",
    sessions: [],
    processNumbers: numbers,
    reason: "Não foi encontrado CNJ pautado nem data explícita de sessão atual ou futura.",
  };
}

export function requireSingleActiveSession(
  scope: SessionEmailScope,
  associatedSession: string,
): { ok: true } | { ok: false; reason: string } {
  if (scope.kind !== "session") {
    return {
      ok: false,
      reason: `A mensagem não corresponde a uma sessão ativa: ${scope.reason ?? "o vínculo automático foi suspenso."}`,
    };
  }
  if (
    scope.sessions.length !== 1 ||
    scope.sessions[0] !== associatedSession
  ) {
    return {
      ok: false,
      reason:
        "A mensagem corresponde a mais de uma sessão ativa ou a outra sessão; informe a sessão para evitar associação incorreta.",
    };
  }
  return { ok: true };
}

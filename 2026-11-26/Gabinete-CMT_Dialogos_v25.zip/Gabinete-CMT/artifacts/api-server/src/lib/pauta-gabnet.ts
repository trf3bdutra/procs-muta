export const GABNET_DEFAULT_MAP = [
  "########################",
  "#cccccc#........#mmmmmm#",
  "#cc@ccc#........#mTTTTm#",
  "#cccccc#........#mmmmmm#",
  "###..###.P....P.###..###",
  "#......................#",
  "#.d.d.d.d.d.d.d.d......#",
  "#......................#",
  "#.d.d.d.d.d.d.d.d......#",
  "#......................#",
  "#ss.........P.....kkkkk#",
  "#ss...............kkkkk#",
  "#ss........P......kkKkk#",
  "########################",
] as const;

export const GABNET_ITEMS = {
  cafe: { label: "Café", icon: "☕" },
  livro: { label: "Livro", icon: "📚" },
  planta: { label: "Planta", icon: "🪴" },
  documento: { label: "Documento", icon: "📄" },
  primeiros_passos: { label: "Primeiros passos", icon: "👣" },
  explorador: { label: "Explorador", icon: "🧭" },
  dedicado: { label: "Presença constante", icon: "🏅" },
} as const;

const WALKABLE = new Set([".", "c", "m", "k"]);
const VALID_TILES = /^[.#dT@sPKcmk]+$/;
const DAY_PICKUP_ITEMS = ["cafe", "livro", "planta", "documento"] as const;

export type GabnetDirection = "up" | "down" | "left" | "right" | "stay";
export type GabnetPlayer = {
  x: number;
  y: number;
  lastSeen: number;
  steps: number;
  zones: string[];
  achievements: string[];
};
export type GabnetPickup = {
  id: string;
  item: (typeof DAY_PICKUP_ITEMS)[number];
  x: number;
  y: number;
  claimedBy: string | null;
};
export type GabnetGameState = {
  date: string;
  revision: number;
  players: Record<string, GabnetPlayer>;
  inventories: Record<string, Record<string, number>>;
  pickups: GabnetPickup[];
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

function safeMap(value: unknown): string[] {
  if (
    Array.isArray(value) &&
    value.length >= 5 &&
    value.length <= 40 &&
    value.every(
      (row) =>
        typeof row === "string" &&
        row.length >= 5 &&
        row.length <= 48 &&
        row.length === (value[0] as string)?.length &&
        VALID_TILES.test(row),
    )
  ) {
    return value as string[];
  }
  return [...GABNET_DEFAULT_MAP];
}

function walkableCells(map: string[]): { x: number; y: number }[] {
  const cells: { x: number; y: number }[] = [];
  map.forEach((row, y) => {
    for (let x = 0; x < row.length; x += 1) {
      if (WALKABLE.has(row[x])) cells.push({ x, y });
    }
  });
  return cells;
}

function hash(value: string): number {
  let result = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    result ^= value.charCodeAt(index);
    result = Math.imul(result, 16777619);
  }
  return result >>> 0;
}

function makeDailyPickups(map: string[], date: string): GabnetPickup[] {
  const cells = walkableCells(map).sort((left, right) => {
    const a = hash(`${date}:${left.x}:${left.y}`);
    const b = hash(`${date}:${right.x}:${right.y}`);
    return a - b || left.y - right.y || left.x - right.x;
  });
  const used = new Set<string>();
  return DAY_PICKUP_ITEMS.flatMap((item, index) => {
    const cell = cells.find((candidate) => !used.has(`${candidate.x},${candidate.y}`));
    if (!cell) return [];
    used.add(`${cell.x},${cell.y}`);
    return [{
      id: `${date}-${index + 1}`,
      item,
      ...cell,
      claimedBy: null,
    }];
  });
}

function cleanPlayer(value: unknown): GabnetPlayer | null {
  if (!isRecord(value)) return null;
  const x = Number(value.x);
  const y = Number(value.y);
  if (!Number.isInteger(x) || !Number.isInteger(y)) return null;
  return {
    x,
    y,
    lastSeen: Number.isFinite(Number(value.lastSeen)) ? Number(value.lastSeen) : 0,
    steps: Math.max(0, Math.floor(Number(value.steps) || 0)),
    zones: Array.isArray(value.zones)
      ? value.zones.filter((zone): zone is string => ["c", "m", "k"].includes(String(zone)))
      : [],
    achievements: Array.isArray(value.achievements)
      ? value.achievements.filter((item): item is string => typeof item === "string")
      : [],
  };
}

export function normalizeGabnetGame(
  value: unknown,
  date: string,
  mapValue: unknown,
): GabnetGameState {
  const source = isRecord(value) ? value : {};
  const map = safeMap(mapValue);
  const players: Record<string, GabnetPlayer> = {};
  if (isRecord(source.players)) {
    for (const [id, player] of Object.entries(source.players)) {
      if (!id || id.length > 120) continue;
      const clean = cleanPlayer(player);
      if (clean) players[id] = clean;
    }
  }
  const inventories: Record<string, Record<string, number>> = {};
  if (isRecord(source.inventories)) {
    for (const [id, inventory] of Object.entries(source.inventories)) {
      if (!id || id.length > 120 || !isRecord(inventory)) continue;
      inventories[id] = {};
      for (const [item, quantity] of Object.entries(inventory)) {
        if (item in GABNET_ITEMS && Number.isFinite(Number(quantity)) && Number(quantity) > 0) {
          inventories[id][item] = Math.min(9999, Math.floor(Number(quantity)));
        }
      }
    }
  }
  const currentDayPickups =
    source.date === date && Array.isArray(source.pickups)
      ? source.pickups.flatMap((pickup): GabnetPickup[] => {
          if (!isRecord(pickup)) return [];
          const item = String(pickup.item) as GabnetPickup["item"];
          const x = Number(pickup.x);
          const y = Number(pickup.y);
          if (
            !(item in GABNET_ITEMS) ||
            !DAY_PICKUP_ITEMS.includes(item as (typeof DAY_PICKUP_ITEMS)[number]) ||
            !Number.isInteger(x) ||
            !Number.isInteger(y) ||
            !WALKABLE.has((map[y] || "")[x])
          ) return [];
          return [{
            id: String(pickup.id || ""),
            item: item as GabnetPickup["item"],
            x,
            y,
            claimedBy: typeof pickup.claimedBy === "string" ? pickup.claimedBy : null,
          }];
        })
      : makeDailyPickups(map, date);

  return {
    date,
    revision: Math.max(0, Math.floor(Number(source.revision) || 0)),
    players,
    inventories,
    pickups: currentDayPickups,
  };
}

function spawnPosition(
  game: GabnetGameState,
  memberId: string,
  map: string[],
  now: number,
): { x: number; y: number } {
  const cells = walkableCells(map);
  const occupied = new Set(
    Object.entries(game.players)
      .filter(([id, player]) => id !== memberId && now - player.lastSeen < 90_000)
      .map(([, player]) => `${player.x},${player.y}`),
  );
  if (!cells.length) return { x: 1, y: 1 };
  const offset = hash(memberId) % cells.length;
  for (let index = 0; index < cells.length; index += 1) {
    const candidate = cells[(offset + index) % cells.length];
    if (!occupied.has(`${candidate.x},${candidate.y}`)) return candidate;
  }
  return cells[offset];
}

export function applyGabnetAction(input: {
  game: GabnetGameState;
  map: string[];
  memberId: string;
  direction: GabnetDirection;
  now: number;
}): {
  game: GabnetGameState;
  collected: string[];
  achievements: string[];
} {
  const { game, map, memberId, direction, now } = input;
  const player = game.players[memberId] || {
    ...spawnPosition(game, memberId, map, now),
    lastSeen: now,
    steps: 0,
    zones: [],
    achievements: [],
  };
  const delta = {
    up: [0, -1],
    down: [0, 1],
    left: [-1, 0],
    right: [1, 0],
    stay: [0, 0],
  }[direction];
  const nextX = player.x + delta[0];
  const nextY = player.y + delta[1];
  const occupied = Object.entries(game.players).some(([id, other]) =>
    id !== memberId &&
    now - other.lastSeen < 90_000 &&
    other.x === nextX &&
    other.y === nextY,
  );
  const canMove =
    direction !== "stay" &&
    WALKABLE.has((map[nextY] || "")[nextX]) &&
    !occupied;
  const moved = canMove
    ? { ...player, x: nextX, y: nextY, steps: player.steps + 1 }
    : { ...player };
  moved.lastSeen = now;

  const zone = (map[moved.y] || "")[moved.x];
  if (["c", "m", "k"].includes(zone) && !moved.zones.includes(zone)) {
    moved.zones = [...moved.zones, zone];
  }

  const inventory = game.inventories[memberId] || (game.inventories[memberId] = {});
  const collected: string[] = [];
  const pickup = game.pickups.find(
    (item) => item.x === moved.x && item.y === moved.y && !item.claimedBy,
  );
  if (pickup) {
    pickup.claimedBy = memberId;
    inventory[pickup.item] = (inventory[pickup.item] || 0) + 1;
    collected.push(pickup.item);
  }

  const achievements: string[] = [];
  const reward = (achievement: string, item: string) => {
    if (moved.achievements.includes(achievement)) return;
    moved.achievements = [...moved.achievements, achievement];
    inventory[item] = (inventory[item] || 0) + 1;
    achievements.push(item);
  };
  if (moved.steps >= 10) reward("first-10-steps", "primeiros_passos");
  if (moved.steps >= 30) reward("first-30-steps", "dedicado");
  if (["c", "m", "k"].every((value) => moved.zones.includes(value))) {
    reward("visited-all-zones", "explorador");
  }

  game.players[memberId] = moved;
  return { game, collected, achievements };
}

export function gabnetMemberId(member: { id?: unknown; name?: unknown }): string {
  const id = String(member.id || "").trim();
  if (id) return id.slice(0, 120);
  return String(member.name || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLocaleLowerCase("pt-BR")
    .replace(/\s+/g, "-")
    .slice(0, 120);
}

export function gabnetLocalDate(now = new Date()): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Cuiaba",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(now);
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

export function gabnetMapFromState(state: Record<string, unknown>): string[] {
  const preferences = isRecord(state.pautaPreferences) ? state.pautaPreferences : {};
  const config = isRecord(preferences.gabnet) ? preferences.gabnet : {};
  return safeMap(config.map);
}

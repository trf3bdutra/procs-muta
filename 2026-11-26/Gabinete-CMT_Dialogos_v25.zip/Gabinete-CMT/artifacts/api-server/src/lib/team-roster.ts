import { TEAM_SERVER_NAMES } from "./app-auth";

/* Equipe do app: os servidores cadastrados na pauta compartilhada (team.members, gravada no PostgreSQL),
   com o e-mail institucional obrigatório no cadastro. O e-mail liga o servidor à conta de acesso
   (account_memberships.email) e a parte antes do @ é o endereço da página própria do servidor. */

export type TeamMemberRef = { id: string; name: string; email: string; slug: string };

const EMAIL = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/i;

export const canonicalServer = (value: unknown) =>
  String(value ?? "").trim().replace(/\s+/g, " ").toLocaleUpperCase("pt-BR");

export const normalizeEmail = (value: unknown) => String(value ?? "").trim().toLowerCase();

export const isValidEmail = (value: unknown) => EMAIL.test(normalizeEmail(value));

export const emailSlug = (value: unknown) =>
  normalizeEmail(value).split("@")[0]!.replace(/[^a-z0-9._-]+/g, "");

export const SERVER_PROFILE_RESERVED_SLUGS = new Set([
  "", "sign-in", "gabinete", "cm", "cmt", "padrao", "accounts", "api", "command", "visualizacao-avancada",
]);

export type ServerProfileIdentity = { server: string; email: string; slug: string | null };
export type ServerProfileAccountRow = {
  server: unknown;
  email: unknown;
  role: unknown;
  status: unknown;
};

export function serverProfileIdentitiesFromAccounts(rows: readonly ServerProfileAccountRow[]): ServerProfileIdentity[] {
  const candidates = rows.flatMap((row) => {
    const server = canonicalServer(row.server);
    const email = normalizeEmail(row.email);
    if ((row.role !== "equipe" && row.role !== "editor") || row.status !== "active" || !server || !isValidEmail(email)) return [];
    return [{ server, email, slug: emailSlug(email) }];
  });
  const slugCounts = new Map<string, number>();
  const serverCounts = new Map<string, number>();
  for (const candidate of candidates) {
    if (candidate.slug) slugCounts.set(candidate.slug, (slugCounts.get(candidate.slug) ?? 0) + 1);
    serverCounts.set(candidate.server, (serverCounts.get(candidate.server) ?? 0) + 1);
  }
  return candidates.map(({ server, email, slug }) => ({
    server,
    email,
    slug: slug && !SERVER_PROFILE_RESERVED_SLUGS.has(slug) &&
      slugCounts.get(slug) === 1 && serverCounts.get(server) === 1 ? slug : null,
  }));
}

const isRecord = (value: unknown): value is Record<string, unknown> =>
  !!value && typeof value === "object" && !Array.isArray(value);

export function teamMembersFromState(state: unknown): TeamMemberRef[] {
  if (!isRecord(state) || !isRecord(state.team) || !Array.isArray(state.team.members)) return [];
  const seen = new Set<string>();
  const out: TeamMemberRef[] = [];
  for (const raw of state.team.members) {
    if (!isRecord(raw)) continue;
    const name = canonicalServer(raw.name);
    if (!name || seen.has(name)) continue;
    seen.add(name);
    const email = isValidEmail(raw.email) ? normalizeEmail(raw.email) : "";
    out.push({ id: String(raw.id ?? ""), name, email, slug: email ? emailSlug(email) : "" });
  }
  return out;
}

/* Servidores que podem ser vinculados a uma conta: a lista histórica e todos os cadastrados no app. */
export function rosterFrom(members: readonly TeamMemberRef[]): string[] {
  const names = new Set<string>(TEAM_SERVER_NAMES.map(canonicalServer));
  for (const member of members) names.add(member.name);
  return [...names];
}

/* Servidor cujo e-mail cadastrado é o da conta (comparação sem diferenciar maiúsculas). */
export function serverForEmail(members: readonly TeamMemberRef[], email: unknown): string | null {
  const wanted = normalizeEmail(email);
  if (!wanted) return null;
  return members.find((member) => member.email === wanted)?.name ?? null;
}

import { isDeepStrictEqual } from "node:util";

type Snapshot = Record<string, unknown>;

const ADMIN_ONLY_ROOTS = [
  "sessions",
  "sessionDetails",
  "names",
  "sourceColumns",
  "importLog",
  "workCalendar",
  "assuntos",
] as const;

// These records represent live team work, not settings. All other team-level
// state is treated as configuration unless deliberately classified otherwise.
const TEAM_OPERATIONAL_FIELDS = new Set([
  "diligencias",
  "ordemDia",
  "pendingCompletions",
  "pendingIssues",
  "pendingTickets",
  "triagem",
]);

function record(value: unknown): Snapshot {
  return value && typeof value === "object" && !Array.isArray(value)
    ? value as Snapshot
    : {};
}

export function hasAdminOnlyPautaSettingsChanges(beforeValue: unknown, afterValue: unknown): boolean {
  const before = record(beforeValue);
  const after = record(afterValue);

  if (ADMIN_ONLY_ROOTS.some((key) => !isDeepStrictEqual(before[key], after[key]))) return true;

  const beforeTeam = record(before.team);
  const afterTeam = record(after.team);
  const teamKeys = new Set([...Object.keys(beforeTeam), ...Object.keys(afterTeam)]);
  for (const key of teamKeys) {
    if (TEAM_OPERATIONAL_FIELDS.has(key)) continue;
    if (!isDeepStrictEqual(beforeTeam[key], afterTeam[key])) return true;
  }

  return false;
}

import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import type { Request, Response } from "express";
import type { AppSession } from "./app-auth";

const COOKIE_NAME = "cmt_cm_access";
const LINK_PURPOSE = "gabcmt:cm-access-link:v1";
const COOKIE_MAX_AGE_SECONDS = 10 * 365 * 24 * 60 * 60;
const PERMANENT_EXPIRY_SECONDS = 253_402_300_799;

function validSecret(secret: string): boolean {
  return Buffer.byteLength(secret, "utf8") >= 32;
}

export function getCmAccessSecret(): string {
  const secret = process.env.CM_ACCESS_LINK_SECRET;
  if (!secret || !validSecret(secret)) {
    throw new Error("CM_ACCESS_LINK_SECRET must contain at least 32 bytes.");
  }
  return secret;
}

function mac(secret: string, value: string): string {
  return createHmac("sha256", secret).update(value).digest("base64url");
}

function safeEqual(left: string, right: string): boolean {
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  return a.length === b.length && timingSafeEqual(a, b);
}

export function createCmAccessLinkToken(secret: string): string {
  if (!validSecret(secret)) throw new Error("A chave do link do CM deve ter pelo menos 32 bytes.");
  return mac(secret, LINK_PURPOSE);
}

export function verifyCmAccessLinkToken(token: unknown, secret: string): boolean {
  if (typeof token !== "string" || token.length > 256 || !validSecret(secret)) return false;
  return safeEqual(token, createCmAccessLinkToken(secret));
}

export function createCmSessionToken(secret: string, now = Date.now()): string {
  if (!validSecret(secret)) throw new Error("A chave do link do CM deve ter pelo menos 32 bytes.");
  const issuedAt = Math.floor(now / 1000);
  const payload = Buffer.from(JSON.stringify({
    version: 1,
    issuedAt,
    nonce: randomBytes(16).toString("base64url"),
  })).toString("base64url");
  return `${payload}.${mac(secret, `session:${payload}`)}`;
}

export function readCmSessionToken(token: unknown, secret: string, now = Date.now()): AppSession | null {
  if (typeof token !== "string" || token.length > 1024 || !validSecret(secret)) return null;
  const separator = token.lastIndexOf(".");
  if (separator <= 0) return null;
  const payload = token.slice(0, separator);
  const signature = token.slice(separator + 1);
  if (!safeEqual(signature, mac(secret, `session:${payload}`))) return null;

  try {
    const value = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as {
      version?: unknown;
      issuedAt?: unknown;
      nonce?: unknown;
    };
    const current = Math.floor(now / 1000);
    if (value.version !== 1 || !Number.isInteger(value.issuedAt) ||
      typeof value.nonce !== "string" || !/^[A-Za-z0-9_-]{20,30}$/.test(value.nonce)) return null;
    const issuedAt = value.issuedAt as number;
    if (issuedAt > current + 60) return null;
    return {
      userId: "cm-link",
      sessionId: `cm-link-${value.nonce}`,
      role: "equipe",
      name: "Desembargador",
      server: "CM",
      issuedAt,
      expiresAt: PERMANENT_EXPIRY_SECONDS,
    };
  } catch {
    return null;
  }
}

function readCookie(req: Request, name: string): string | null {
  const raw = req.headers.cookie;
  if (typeof raw !== "string") return null;
  for (const part of raw.split(";")) {
    const separator = part.indexOf("=");
    if (separator < 0 || part.slice(0, separator).trim() !== name) continue;
    try { return decodeURIComponent(part.slice(separator + 1).trim()); }
    catch { return null; }
  }
  return null;
}

function secureCookie(req: Request): boolean {
  return req.secure || String(req.headers["x-forwarded-proto"] || "").split(",")[0].trim().toLowerCase() === "https";
}

export function setCmSessionCookie(req: Request, res: Response, token: string): void {
  const secure = secureCookie(req) ? "; Secure" : "";
  res.append("Set-Cookie", `${COOKIE_NAME}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${COOKIE_MAX_AGE_SECONDS}${secure}`);
}

export function clearCmSessionCookie(req: Request, res: Response): void {
  const secure = secureCookie(req) ? "; Secure" : "";
  res.append("Set-Cookie", `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure}`);
}

export function readCmAccessSession(req: Request): AppSession | null {
  const secret = process.env.CM_ACCESS_LINK_SECRET;
  if (!secret || !validSecret(secret)) return null;
  return readCmSessionToken(readCookie(req, COOKIE_NAME), secret);
}

import { readFileSync, statSync } from "node:fs";
import { prepareAgentMailCommunication } from "./gabcmt-agentmail-comunicacao";
import { prepareAgentMailBrowser } from "./gabcmt-agentmail-browser";
import { prepareWorkspaceSettings } from "./gabcmt-workspace-settings";
import { prepareDialogDocument } from "./gabcmt-dialog-document";
import { preparePendingPanel } from "./gabcmt-pending-panel";
import { prepareStableSessionHeader } from "./gabcmt-session-header";
import { prepareStartupDocument } from "./gabcmt-startup-document";
import { prepareServerLayoutDocument } from "./gabcmt-server-layout";
import { prepareServerFooterDocument } from "./gabcmt-server-footer";
import { prepareProntuarioMotionDocument } from "./gabcmt-prontuario-motion";
import { prepareGabcmtUiResponsivenessDocument } from "./gabcmt-ui-responsiveness";

const forcedSettingsReset = "if (on && !eraAberta) { try { window.CMTCfgNav && window.CMTCfgNav.ir('cg'); } catch (_) {} }";

export function prepareGabcmtDocument(html: string): string {
  const prepared = preparePendingPanel(prepareDialogDocument(prepareAgentMailCommunication(prepareWorkspaceSettings(prepareAgentMailBrowser(html.replace(
    /(<script\b[^>]*\bid=["']cmt-v234-controle-global-js["'][^>]*>)([\s\S]*?)(<\/script>)/gi,
    (_, opening: string, script: string, closing: string) =>
      opening + script.replace(forcedSettingsReset, "") + closing,
  ))))));
  return prepareGabcmtUiResponsivenessDocument(
    prepareProntuarioMotionDocument(
      prepareServerLayoutDocument(
        prepareServerFooterDocument(
          prepareStartupDocument(prepareStableSessionHeader(prepared)),
        ),
      ),
    ),
  );
}

export function createGabcmtDocumentReader(paths: URL[]) {
  let cached: { version: string; html: string } | undefined;
  return () => {
    for (const path of paths) {
      try {
        const stat = statSync(path);
        const version = `${path.href}|${stat.mtimeMs}|${stat.ctimeMs}|${stat.size}`;
        if (cached?.version !== version) {
          cached = { version, html: prepareGabcmtDocument(readFileSync(path, "utf8")) };
        }
        return cached;
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
      }
    }
    throw new Error("Protected GabCMT HTML was not found.");
  };
}

/* Independent modal roots and explicit compatibility adapters for native views. */
(function (W, D) {
  'use strict';
  if (W.CMTAppDialogs) return;
  const aliases = { 'app-content': 'cfg-app-content', 'app-title': 'cfg-app-title', 'app-subtitle': 'cfg-app-subtitle', 'app-modal': 'cfg-app-modal' };
  const handlers = new WeakMap(), hosts = new WeakMap(), sharedHandlers = new WeakMap();
  let settings, view, settingsPendingOpen = false, settingsPageMode = false, settingsUnlockPending = null, context = 0, configState, privateState, returnSettings;
  const selector = value => String(value)
    .replace(/#(app-content|app-title|app-subtitle|app-modal)\b/g, (_, id) => '#' + aliases[id])
    .replace(/\.(app-main|app-header|header-actions|app-eyebrow)\b/g, (_, name) => ({
      'app-main': '.cmt-settings-main', 'app-header': '.cmt-settings-header',
      'header-actions': '.cmt-settings-actions', 'app-eyebrow': '.cmt-settings-eyebrow',
    }[name]));
  const inScope = callback => { context++; try { return callback(); } finally { context--; } };
  const visibleDialog = () => settings?.open ? settings : null;
  function settingsRoot() {
    if (settings) return settings;
    settings = D.createElement('dialog');
    settings.id = 'cmt-settings-dialog'; settings.className = 'cmt-app-dialog';
    settings.setAttribute('aria-labelledby', 'cmt-settings-dialog-title');
    settings.innerHTML = '<header class="cmt-dialog-header"><div><small>GABINETE CMT · ADMINISTRAÇÃO</small><h1 id="cmt-settings-dialog-title">Configurações Globais</h1></div><button type="button" data-cmt-dialog-close="settings" aria-label="Fechar Configurações Globais" title="Fechar">×</button></header><main id="cmt-settings-view" class="cmt-settings-main"><header class="cmt-settings-header"><div class="app-heading"><div class="cmt-settings-eyebrow">GABINETE CMT</div><h1 id="cfg-app-title">Configurações Globais</h1><p id="cfg-app-subtitle">Administração do gabinete</p></div><div class="cmt-settings-actions"><button type="button" class="cfg-back" data-cfg-extra data-app="config-close" aria-label="Fechar Configurações Globais" title="Fechar">×</button></div></header><section id="cfg-app-content"></section></main><div class="cmt-dialog-overlays"><div id="cfg-app-modal"></div></div>';
    settings.addEventListener('cancel', event => { event.preventDefault(); closeSettings(); });
    settings.addEventListener('click', event => {
      if (event.target.closest?.('[data-app="config-close"],[data-cmt-dialog-close="settings"]')) { event.preventDefault(); event.stopPropagation(); closeSettings(); }
    });
    return settings;
  }
  function getSettingsHost() {
    const actual = W.PautaApp;
    if (!actual) return null;
    if (hosts.has(actual)) return hosts.get(actual);
    configState = { ...actual.state, tab: 'calendario' };
    privateState = { _configModalOpen: false, _cfgShownTab: '', _cfgObs: null };
    const wrapped = new Map();
    const proxy = new Proxy(actual, {
      get(target, key) {
        if (key === '__cmtSettingsHost') return true;
        if (key === 'state') return configState;
        if (Object.hasOwn(privateState, key)) {
          const value = privateState[key];
          if (typeof value !== 'function') return value;
          const cached = wrapped.get(key);
          if (cached?.original === value) return cached.fn;
          const fn = function () { const args = arguments; return inScope(() => Reflect.apply(value, proxy, args)); };
          wrapped.set(key, { original: value, fn }); return fn;
        }
        if (key === 'isConfig') return () => !!settings?.open;
        if (key === 'openConfigDialog') return openSettings;
        if (key === 'closeConfigDialog') return closeSettings;
        if (key === 'renderShell' || key === 'renderConfig') return renderSettings;
        if (key === 'cfgSubtabs') return current => inScope(() => view?.cfgSubtabs.call(proxy, current));
        if (key === 'renderSessionsTab') return () => inScope(() => view?.renderSessionsTab.call(proxy));
        if (key === 'syncMainNavCompact') return () => {};
        if (key === 'notify') return (message, type) => {
          const root = settingsRoot();
          let notice = root.querySelector('.cmt-dialog-notice');
          if (!notice) {
            notice = D.createElement('div'); notice.className = 'cmt-dialog-notice';
            root.querySelector('.cmt-settings-header').after(notice);
          }
          notice.setAttribute('role', type === 'error' || type === 'warn' ? 'alert' : 'status');
          notice.dataset.kind = type || 'info'; notice.textContent = message; notice.hidden = false;
        };
        const value = Reflect.get(target, key, target);
        if (typeof value !== 'function') return value;
        const cached = wrapped.get(key);
        if (cached?.original === value) return cached.fn;
        const fn = function () { const args = arguments; return inScope(() => Reflect.apply(value, proxy, args)); };
        wrapped.set(key, { original: value, fn }); return fn;
      },
      set(target, key, value) {
        if (key === 'state') { configState = value; return true; }
        if (Object.hasOwn(privateState, key) || typeof value === 'function' || /^_cfg|^_config/.test(String(key))) {
          privateState[key] = value; return true;
        }
        return Reflect.set(target, key, value, target);
      },
      defineProperty(target, key, descriptor) {
        if ('value' in descriptor && (typeof descriptor.value === 'function' || /^_cfg|^_config/.test(String(key)))) {
          privateState[key] = descriptor.value; return true;
        }
        return Reflect.defineProperty(target, key, descriptor);
      },
    });
    hosts.set(actual, proxy);
    return proxy;
  }
  const shellQuery = /(?:#(?:app-content|app-title|app-subtitle|app-modal|pauta-main-nav)\b|(?:main)?\.app-main|\.app-header|\.header-actions|\.app-eyebrow)/;
  const globalQuery = /#(?:alt-side|cx-rrail|alt-rside|pauta-global-dock)\b/;
  function query(value, all) {
    const root = settingsRoot(), query = selector(value);
    if (query === 'html' || query === 'body' || query === ':root') return all ? [root] : root;
    const found = all ? root.querySelectorAll(query) : root.querySelector(query);
    if (all ? found.length : found) return found;
    if (shellQuery.test(value) || !globalQuery.test(value)) return all ? [] : null;
    return all ? D.querySelectorAll(value) : D.querySelector(value);
  }
  function eventForSettings(event) { return !!(settings?.open && event?.target instanceof W.Node && settings.contains(event.target)); }
  function addListener(type, listener, options) {
    if (!listener) return;
    let byType = handlers.get(listener);
    if (!byType) { byType = new Map(); handlers.set(listener, byType); }
    const capture = typeof options === 'boolean' ? options : !!options?.capture;
    const key = type + ':' + capture;
    let wrapped = byType.get(key);
    if (!wrapped) {
      wrapped = event => {
        if (/^(click|change|input|submit|keydown|mousedown|pointerdown)$/.test(type)) {
          const entry = event.target?.closest?.('#alt-side .as-brand>.cx-gear,.cmt-cfgbtn,[data-app="config-dialog"]');
          const shortcut = type === 'keydown' && event.altKey && event.key === '0';
          if (!eventForSettings(event) && !entry && !shortcut) return;
        }
        return inScope(() => typeof listener === 'function' ? listener.call(D, event) : listener.handleEvent(event));
      };
      byType.set(key, wrapped);
    }
    D.addEventListener(type, wrapped, options);
  }
  function scopeDynamicCss(css) {
    if (!String(css).trim()) return css;
    const sheet = new W.CSSStyleSheet();
    sheet.replaceSync(css);
    function selectors(value) {
      let depth = 0, start = 0, quote = '', result = [];
      for (let i = 0; i < value.length; i++) {
        const c = value[i];
        if (quote) { if (c === quote && value[i - 1] !== '\\') quote = ''; continue; }
        if (c === '"' || c === "'") { quote = c; continue; }
        if (c === '(' || c === '[') depth++;
        if (c === ')' || c === ']') depth--;
        if (c === ',' && !depth) { result.push(value.slice(start, i)); start = i + 1; }
      }
      result.push(value.slice(start));
      return result;
    }
    function local(value) {
      let rest = selector(value.trim()), flags = '';
      while (/^(html|body|:root)(?=[.#[:\s>]|$)/.test(rest)) {
        rest = rest.replace(/^(html|body|:root)/, '');
        let end = 0, depth = 0;
        for (; end < rest.length; end++) {
          if (rest[end] === '(' || rest[end] === '[') depth++;
          if (rest[end] === ')' || rest[end] === ']') depth--;
          if (!depth && /\s|>/.test(rest[end])) break;
        }
        flags += rest.slice(0, end); rest = rest.slice(end).trimStart();
        if (rest.startsWith('>')) break;
      }
      return ':where(#cmt-settings-dialog' + flags + (rest ? ' ' + rest : '') + ')';
    }
    function visit(rules) {
      for (const rule of rules) {
        if (rule.type === 1) rule.selectorText = selectors(rule.selectorText).map(local).join(',');
        else if (rule.type !== 7 && rule.cssRules) visit(rule.cssRules);
      }
    }
    visit(sheet.cssRules);
    return Array.from(sheet.cssRules, rule => rule.cssText).join('\n');
  }
  function createElement(name, options) {
    const node = D.createElement(name, options);
    if (String(name).toLowerCase() === 'style') {
      const property = Object.getOwnPropertyDescriptor(W.Node.prototype, 'textContent');
      Object.defineProperty(node, 'textContent', {
        configurable: true,
        get() { return property.get.call(node); },
        set(value) { property.set.call(node, scopeDynamicCss(String(value))); },
      });
    }
    return node;
  }
  const settingsDocument = new Proxy(D, {
    get(target, key) {
      if (key === 'body' || key === 'documentElement' || key === 'scrollingElement') return settingsRoot();
      if (key === 'title') return settingsRoot().dataset.title || 'Configurações Globais';
      if (key === 'getElementById') return id => {
        const local = settingsRoot().querySelector('[id="' + (aliases[id] || id).replace(/"/g, '\\"') + '"]');
        if (local || aliases[id] || id === 'pauta-main-nav') return local;
        return D.getElementById(id);
      };
      if (key === 'querySelector') return value => query(value, false);
      if (key === 'querySelectorAll') return value => query(value, true);
      if (key === 'createElement') return createElement;
      if (key === 'addEventListener') return addListener;
      if (key === 'removeEventListener') return (type, listener, options) => {
        const capture = typeof options === 'boolean' ? options : !!options?.capture;
        D.removeEventListener(type, handlers.get(listener)?.get(type + ':' + capture) || listener, options);
      };
      const value = Reflect.get(target, key, target);
      return typeof value === 'function' ? value.bind(target) : value;
    },
    set(target, key, value) {
      if (key === 'title') { settingsRoot().dataset.title = value; return true; }
      return Reflect.set(target, key, value, target);
    },
  });
  const applicationDocument = new Proxy(D, {
    get(target, key) {
      if (context) return settingsDocument[key];
      const value = Reflect.get(target, key, target);
      return typeof value === 'function' ? value.bind(target) : value;
    },
    set(target, key, value) {
      if (context) { settingsDocument[key] = value; return true; }
      return Reflect.set(target, key, value, target);
    },
  });
  const settingsWindow = new Proxy(W, {
    get(target, key) {
      if (key === 'document') return settingsDocument;
      if (key === 'PautaApp' || key === '__painelCentralComponent') return getSettingsHost();
      const value = Reflect.get(target, key, target);
      // Constructors must keep their native identity/prototype.
      return typeof value === 'function' && /^[a-z]/.test(String(key)) ? value.bind(target) : value;
    },
    set(target, key, value) { return Reflect.set(target, key, value, target); },
  });
  function attach(dialog) { if (!dialog.isConnected) D.body.appendChild(dialog); }
  // A mesma permissão deve reger a visibilidade da navegação e a abertura real.
  function canOpenSettings() {
    return W.CMT_AUTH_SESSION?.role === 'administracao' || W.CMT_AUTH_SESSION?.role === 'editor';
  }
  function showSettingsPasswordPrompt() {
    return new Promise(resolve => {
      let settled = false;
      const dialog = D.createElement('dialog');
      dialog.className = 'cmt-settings-access';
      dialog.setAttribute('aria-labelledby', 'cmt-settings-access-title');
      dialog.innerHTML = '<form><header><small>ACESSO RESTRITO</small><h2 id="cmt-settings-access-title">Configurações Globais</h2><p>Confirme a senha da Administração para continuar nesta sessão.</p></header><label for="cmt-settings-access-password">Senha da Administração</label><input id="cmt-settings-access-password" name="password" type="password" autocomplete="current-password" required><p class="cmt-settings-access-error" role="alert" hidden></p><footer><button type="button" data-cmt-access-cancel>Cancelar</button><button type="submit" class="is-primary">Continuar</button></footer></form>';
      let style = D.getElementById('cmt-settings-access-style');
      if (!style) {
        style = D.createElement('style');
        style.id = 'cmt-settings-access-style';
        style.textContent = `
          dialog.cmt-settings-access{width:min(420px,calc(100vw - 32px));max-width:none;padding:0;border:1px solid #d7e0e8;border-radius:14px;color:#263747;background:#fff;box-shadow:0 24px 80px rgba(8,25,39,.28);font:500 14px/1.45 Figtree,system-ui,sans-serif}
          dialog.cmt-settings-access::backdrop{background:rgba(12,25,38,.58);backdrop-filter:blur(2px)}
          .cmt-settings-access form{display:grid;gap:10px;padding:24px}
          .cmt-settings-access header small{color:#8b6b32;font-size:10px;font-weight:800;letter-spacing:.16em}
          .cmt-settings-access h2{margin:5px 0;font-size:21px;color:#18394c}
          .cmt-settings-access header p{margin:0 0 8px;color:#687989;font-size:13px}
          .cmt-settings-access label{font-size:12px;font-weight:750;color:#465968}
          .cmt-settings-access input{box-sizing:border-box;width:100%;height:42px;padding:0 12px;border:1px solid #cbd7e0;border-radius:7px;color:#1e2d3a;background:#fff;font:500 15px Figtree,system-ui,sans-serif}
          .cmt-settings-access input:focus{outline:3px solid rgba(33,99,139,.18);border-color:#39799b}
          .cmt-settings-access .cmt-settings-access-error{margin:0;color:#a83232;font-size:12px}
          .cmt-settings-access footer{display:flex;justify-content:flex-end;gap:8px;margin-top:8px}
          .cmt-settings-access footer button{min-height:36px;padding:0 14px;border:1px solid #d3dde5;border-radius:7px;color:#405263;background:#fff;font:700 12px Figtree,system-ui,sans-serif;cursor:pointer}
          .cmt-settings-access footer button.is-primary{border-color:#123f4b;color:#fff;background:#123f4b}
          .cmt-settings-access footer button:disabled{opacity:.6;cursor:wait}
        `;
        D.head.appendChild(style);
      }
      const finish = unlocked => {
        if (settled) return;
        settled = true;
        if (dialog.open) dialog.close();
        dialog.remove();
        resolve(unlocked);
      };
      const form = dialog.querySelector('form');
      const input = dialog.querySelector('input');
      const error = dialog.querySelector('.cmt-settings-access-error');
      const submit = dialog.querySelector('[type="submit"]');
      dialog.querySelector('[data-cmt-access-cancel]').addEventListener('click', () => finish(false));
      dialog.addEventListener('cancel', event => { event.preventDefault(); finish(false); });
      dialog.addEventListener('close', () => finish(false), { once: true });
      form.addEventListener('submit', async event => {
        event.preventDefault();
        const password = input.value;
        input.value = '';
        if (!password) { input.focus(); return; }
        submit.disabled = true;
        error.hidden = true;
        try {
          const response = await W.fetch('/api/pauta/settings/unlock', {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password }),
          });
          const result = await response.json().catch(() => ({}));
          if (!response.ok || result?.ok !== true) {
            error.textContent = result?.error || 'Não foi possível confirmar a senha.';
            error.hidden = false;
            input.focus();
            return;
          }
          finish(true);
        } catch (_) {
          error.textContent = 'Falha de conexão. Tente novamente.';
          error.hidden = false;
          input.focus();
        } finally {
          input.value = '';
          if (dialog.isConnected) submit.disabled = false;
        }
      });
      D.body.appendChild(dialog);
      try {
        dialog.showModal();
        input.focus({ preventScroll: true });
      } catch (_) {
        finish(false);
      }
    });
  }
  function ensureSettingsAccess() {
    if (settingsUnlockPending) return settingsUnlockPending;
    settingsUnlockPending = (async () => {
      try {
        const response = await W.fetch('/api/pauta/settings/access', {
          credentials: 'same-origin',
          cache: 'no-store',
        });
        if (response.status === 401 || response.status === 403) {
          W.PautaApp?.notify?.('Sua sessão não tem autorização para abrir Configurações Globais.', 'warn');
          return false;
        }
        if (!response.ok) throw new Error('Não foi possível validar o acesso.');
        const result = await response.json();
        if (result?.unlocked === true) return true;
        return await showSettingsPasswordPrompt();
      } catch (error) {
        console.error('[Configurações] Falha ao validar a senha da Administração.', error);
        W.PautaApp?.notify?.('Não foi possível validar o acesso às Configurações Globais.', 'warn');
        return false;
      }
    })();
    return settingsUnlockPending.finally(() => { settingsUnlockPending = null; });
  }
  function openSettings(options = {}) {
    // Não deferir a checagem de acesso: chamadas diretas e atalhos também precisam dela.
    if (!canOpenSettings()) {
      W.PautaApp?.notify?.('Somente a Administração pode acessar Configurações Globais.', 'warn');
      return false;
    }
    const nextPageMode = options?.page === true || settingsPageMode;
    return ensureSettingsAccess().then(unlocked => {
      if (!unlocked) return false;
      settingsPageMode = nextPageMode;
      return openSettingsUnlocked();
    });
  }
  function openSettingsUnlocked() {
    if (!settingsPageMode && W.parent !== W) {
      W.parent.postMessage({ type: 'pauta:open-global-settings' }, W.location.origin);
      return true;
    }
    const h = getSettingsHost();
    if (!h) { console.error('[Configurações] O controlador da página ainda não está disponível.'); return false; }
    if (!view) { settingsPendingOpen = true; return true; }
    const root = settingsRoot();
    root.classList.toggle('cmt-settings-page', settingsPageMode);
    if (root.open) {
      // Reabrir promove o diálogo ao topo da camada modal se outro diálogo
      // tiver sido aberto depois; não re-renderiza nem descarta o formulário atual.
      try { root.close(); root.showModal(); }
      catch (error) { console.error('[Configurações] Não foi possível trazer o diálogo para frente.', error); return false; }
      root.querySelector('#cmt-settings-view [data-app="config-close"]')?.focus({ preventScroll: true });
      return true;
    }
    returnSettings = D.activeElement;
    attach(root); privateState._configModalOpen = true;
    root.classList.add('cfg-modal-open', 'cfg-on', 'alt-on');
    root.dataset.v2Page = 'config';
    try { root.showModal(); }
    catch (error) {
      console.error('[Configurações] Não foi possível abrir o diálogo.', error);
      W.PautaApp?.notify?.('Não foi possível abrir Configurações Globais. Feche outro diálogo aberto e tente novamente.', 'warn');
      privateState._configModalOpen = false;
      return false;
    }
    renderSettings();
    root.dataset.rendered = 'true';
    // Local observers run after these classes change. No real html/body flags.
    root.dispatchEvent(new CustomEvent('cmt:settings-open'));
    W.CMTCfgNav?.sync?.(); W.CMTCfgRail?.pinta?.();
    root.querySelector('#cmt-settings-view [data-app="config-close"]')?.focus({ preventScroll: true });
    return true;
  }
  function closeSettings(options = {}) {
    if (settingsPageMode && !options?.fromRoute) {
      if (W.parent !== W) {
        W.parent.postMessage({ type: 'pauta:close-global-settings' }, W.location.origin);
        return;
      }
      W.history.back();
      return;
    }
    if (!settings?.open) {
      if (options?.fromRoute) {
        settingsPendingOpen = false;
        settingsPageMode = false;
      }
      return;
    }
    parkSolicitations();
    const child = settings.querySelector('#cfg-app-modal');
    if (child?.firstElementChild && !options?.fromRoute) {
      child.querySelector('input,textarea,select,button')?.focus({ preventScroll: true });
      return; // Resolve the native form/confirmation before dismissing its owner.
    }
    privateState._configModalOpen = false;
    settings.close();
    settings.classList.remove('cfg-modal-open', 'cfg-on', 'cmt-settings-page');
    settingsPageMode = false;
    if (returnSettings?.isConnected) returnSettings.focus({ preventScroll: true });
  }
  function solicitationsHost() {
    const main = settingsRoot().querySelector('#cmt-settings-view');
    if (!main) return null;
    let host = main.querySelector('#cmt-solicitacoes-host');
    if (!host) {
      host = D.createElement('section');
      host.id = 'cmt-solicitacoes-host';
      host.setAttribute('aria-label', 'Solicitações');
      host.hidden = true;
      main.appendChild(host);
    }
    return host;
  }
  function parkSolicitations() {
    W.CMTSolicitacoes?.undockSlot?.();
    const host = settings?.querySelector('#cmt-solicitacoes-host');
    if (host) host.hidden = true;
  }
  function syncSolicitations() {
    const host = solicitationsHost();
    if (!host) return false;
    const active = !!settings?.open && getSettingsHost()?.state?.tab === 'solicitacoes';
    host.hidden = !active;
    if (active) return W.CMTSolicitacoes?.dockSlot?.(host) === true;
    const panel = host.querySelector('#pa-sol');
    if (panel) {
      panel.hidden = true;
      return false;
    }
    parkSolicitations();
    return false;
  }
  function renderSettings() {
    const h = getSettingsHost();
    if (!h || !settings?.open || !view) return;
    try {
      inScope(() => view.renderConfig.call(h));
      syncSolicitations();
    }
    catch (error) {
      console.error('[Configurações] Falha ao renderizar a tela.', error);
      const content = settingsRoot().querySelector('#cfg-app-content');
      if (content) {
        content.innerHTML = '<section class="pc-card cfg-render-error" role="alert"><h2>Não foi possível carregar as Configurações Globais</h2><p>O diálogo abriu, mas ocorreu uma falha ao montar o conteúdo. Tente novamente.</p><button type="button" class="cfg-btn is-primary" data-app="config-render-retry">Tentar novamente</button></section>';
        content.querySelector('[data-app="config-render-retry"]')?.addEventListener('click', () => renderSettings(), { once: true });
      }
      return false;
    }
    return true;
  }
  // Nunca dois diálogos abertos: o novo substitui o anterior sem descartar o conteúdo montado.
  function dismissSettings() {
    if (!settings?.open) return;
    parkSolicitations();
    privateState._configModalOpen = false;
    settings.close(); settings.classList.remove('cfg-modal-open', 'cfg-on');
  }
  const communicationDocument = new Proxy(D, {
    get(target, key) {
      if (key === 'addEventListener') return (type, listener, options) => {
        if (!listener) return;
        let listeners = sharedHandlers.get(listener);
        if (!listeners) { listeners = new Map(); sharedHandlers.set(listener, listeners); }
        let wrapped = listeners.get(type);
        if (!wrapped) {
          wrapped = event => {
            const invoke = () => typeof listener === 'function' ? listener.call(D, event) : listener.handleEvent(event);
            return eventForSettings(event) ? inScope(invoke) : invoke();
          };
          listeners.set(type, wrapped);
        }
        D.addEventListener(type, wrapped, options);
      };
      if (key === 'removeEventListener') return (type, listener, options) => D.removeEventListener(type, sharedHandlers.get(listener)?.get(type) || listener, options);
      return Reflect.get(applicationDocument, key);
    },
  });
  const applicationWindow = new Proxy(W, {
    get(target, key) {
      if (context) return Reflect.get(settingsWindow, key);
      const value = Reflect.get(target, key, target);
      // Métodos nativos (addEventListener, fetch…) exigem o window real como receptor.
      return typeof value === 'function' && /^[a-z]/.test(String(key)) ? value.bind(target) : value;
    },
  });
  W.CMTAppDialogs = {
    settingsDocument, applicationDocument, settingsWindow, communicationDocument, applicationWindow,
    registerSettingsView(value) {
      view = value;
      if (settingsPendingOpen) {
        settingsPendingOpen = false;
        openSettings({ page: settingsPageMode });
      }
    },
    openSettings, closeSettings, renderSettings, canOpenSettings, syncSolicitations,
    settingsOpen: () => !!settings?.open,
    settingsSubtabs: current => getSettingsHost()?.cfgSubtabs(current),
    settingsSessions: () => getSettingsHost()?.renderSessionsTab(),
    hostForEvent: event => eventForSettings(event) ? getSettingsHost() : null,
    withEventHost(event, fallback, callback) { return eventForSettings(event) ? inScope(() => callback(getSettingsHost())) : callback(fallback); },
    forHost(host, callback) { return host?.__cmtSettingsHost ? inScope(callback) : callback(); },
    active: visibleDialog,
  };
  // Open the independent dialog directly. This avoids relying on delegated
  // handlers that may not exist yet while the legacy page is initializing.
  D.addEventListener?.('click', event => {
    const target = event.target;
    if (!(target instanceof W.Element)) return;
    const trigger = target.closest('#alt-side [data-cmt-cfg-nav],[data-app="config-dialog"],#alt-side .as-brand>.cx-gear');
    if (!trigger || trigger.closest('#cmt-settings-dialog')) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    try { if (D.documentElement?.classList?.contains('cmt-srv-on')) W.CMTServidor?.close?.(); } catch (_) {}
    openSettings();
  }, true);
})(window, document);

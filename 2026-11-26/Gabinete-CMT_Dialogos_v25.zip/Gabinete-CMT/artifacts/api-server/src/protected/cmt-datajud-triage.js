/* Embedded DataJud triage module for the authenticated GabCMT iframe. */
(function (W, D) {
  'use strict';

  var processes = [
    { item: '1', number: '50059724320244036000', subject: '28,86%' },
    { item: '2', number: '50060157720244036000', subject: '28,86%' },
    { item: '3', number: '50046311120264036000', subject: '28,86%' },
    { item: '4', number: '50130542820244036000', subject: '28,86%' },
    { item: '5', number: '50013221620254036000', subject: '28,86%' },
    { item: '6', number: '50075028220244036000', subject: '28,86%' },
    { item: '7', number: '50103533120234036000', subject: '28,86%' },
    { item: '20', number: '50085551120184036000', subject: 'Anuidade conselhos' },
    { item: '21', number: '00023517020174036000', subject: 'Anuidade conselhos' },
    { item: '22', number: '50002796220264030001', subject: 'Contribuições previdenciárias' },
    { item: '28', number: '50090978720224036000', subject: 'Impostos' },
    { item: '34', number: '50013496220264036000', subject: 'PIS' },
    { item: '35', number: '50106921920254036000', subject: 'Processo/recurso administrativo' },
    { item: '36', number: '50106818720254036000', subject: 'Processo/recurso administrativo' },
    { item: '113', number: '50083879620244036000', subject: '28,86%' }
  ];
  var rules = [
    ['R01', 'Interposição'], ['R02', 'Decisão'], ['R03', 'Intimação'],
    ['R04', 'Prazos'], ['R05', 'Preparo'], ['R06', 'Representação'],
    ['R07', 'Saneamento'], ['R08', 'Admissibilidade anterior'],
    ['R09', 'Fato superveniente']
  ];
  var instances = new WeakMap();
  var css = `
    .cmt-dj{--dj-ink:#24353a;--dj-muted:#66777a;--dj-line:#d9e2df;--dj-paper:#f5f7f2;--dj-card:#fffefa;--dj-teal:#176b62;--dj-teal-dark:#10554f;--dj-sand:#e9eee7;--dj-amber:#9a5e16;--dj-red:#9a413b;color:var(--dj-ink);background:var(--dj-paper);font:14px/1.45 "Figtree", "Segoe UI", sans-serif;padding:clamp(16px,2.4vw,32px);min-height:100%;box-sizing:border-box}
    .cmt-dj *{box-sizing:border-box}.cmt-dj button,.cmt-dj input{font:inherit}.cmt-dj button{cursor:pointer}
    .cmt-dj .dj-wrap{max-width:1380px;margin:0 auto}.cmt-dj .dj-eyebrow{font-size:11px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--dj-teal)}
    .cmt-dj .dj-head{display:flex;justify-content:space-between;align-items:flex-start;gap:24px;margin-bottom:22px}
    .cmt-dj h1{font-size:clamp(25px,3vw,36px);line-height:1.08;letter-spacing:-.035em;margin:7px 0 8px;font-weight:750}
    .cmt-dj .dj-subtitle{color:var(--dj-muted);margin:0;max-width:680px}.cmt-dj .dj-tag{border:1px solid #bdd5ce;background:#e9f2ed;color:#205c52;padding:8px 11px;border-radius:3px;font-size:12px;font-weight:700;white-space:nowrap}
    .cmt-dj .dj-notice{display:flex;gap:12px;align-items:flex-start;background:#f2ead8;border-left:4px solid #bb8a38;padding:13px 16px;margin:18px 0 22px;color:#4f493d}
    .cmt-dj .dj-notice strong{display:block;font-size:13px;margin-bottom:2px}.cmt-dj .dj-notice p{margin:0;font-size:12px}
    .cmt-dj .dj-toolbar{display:flex;flex-wrap:wrap;align-items:center;gap:9px;padding:14px;background:#e9eee8;border:1px solid var(--dj-line);margin-bottom:16px}
    .cmt-dj .dj-btn{border:1px solid #aabbb5;background:var(--dj-card);color:var(--dj-ink);padding:9px 13px;border-radius:3px;font-size:12px;font-weight:750;transition:background .15s,transform .15s}
    .cmt-dj .dj-btn:hover:not(:disabled){background:#f4f8f4;transform:translateY(-1px)}.cmt-dj .dj-btn:focus-visible,.cmt-dj input:focus-visible{outline:3px solid #84b9ac;outline-offset:2px}
    .cmt-dj .dj-btn.primary{background:var(--dj-teal);border-color:var(--dj-teal);color:white}.cmt-dj .dj-btn.primary:hover:not(:disabled){background:var(--dj-teal-dark)}
    .cmt-dj .dj-btn:disabled{opacity:.48;cursor:not-allowed}.cmt-dj .dj-btn.subtle{background:transparent}
    .cmt-dj .dj-separator{height:28px;border-left:1px solid #c6d1cb;margin:0 3px}
    .cmt-dj .dj-stopcheck{display:flex;align-items:center;gap:7px;color:#495b5b;font-size:12px;font-weight:650;margin-left:auto}
    .cmt-dj .dj-stopcheck input{width:16px;height:16px;accent-color:var(--dj-teal)}
    .cmt-dj .dj-progress{display:grid;grid-template-columns:auto minmax(100px,1fr) auto;gap:13px;align-items:center;background:var(--dj-card);border:1px solid var(--dj-line);padding:12px 15px;margin-bottom:16px}
    .cmt-dj .dj-progress-label{font-size:12px;font-weight:750;white-space:nowrap}.cmt-dj .dj-track{height:7px;background:#e5ebe6;overflow:hidden}
    .cmt-dj .dj-track span{display:block;height:100%;background:var(--dj-teal);transition:width .2s}.cmt-dj .dj-progress-count{font-size:12px;font-variant-numeric:tabular-nums;color:var(--dj-muted)}
    .cmt-dj .dj-grid{display:grid;grid-template-columns:minmax(300px,.82fr) minmax(0,1.6fr);gap:16px;align-items:start}
    .cmt-dj .dj-panel{background:var(--dj-card);border:1px solid var(--dj-line);min-width:0}
    .cmt-dj .dj-panel-head{padding:15px 17px;border-bottom:1px solid var(--dj-line);display:flex;justify-content:space-between;gap:12px;align-items:center}
    .cmt-dj h2{font-size:14px;letter-spacing:.01em;margin:0;font-weight:800}.cmt-dj .dj-panel-meta{font-size:11px;color:var(--dj-muted)}
    .cmt-dj .dj-processes{max-height:670px;overflow:auto}.cmt-dj .dj-process{border:0;border-bottom:1px solid #e9eeea;padding:12px 15px;display:grid;grid-template-columns:36px minmax(0,1fr) auto;gap:10px;align-items:center;width:100%;text-align:left;background:transparent;color:inherit}
    .cmt-dj .dj-process:last-child{border-bottom:0}.cmt-dj .dj-process.selected{background:#edf5f0;box-shadow:inset 3px 0 var(--dj-teal)}
    .cmt-dj .dj-item{font:700 11px/1 "SFMono-Regular",Consolas,monospace;color:#58706d;background:#edf0e9;padding:7px 4px;text-align:center}
    .cmt-dj .dj-number{font:600 11px/1.3 "SFMono-Regular",Consolas,monospace;letter-spacing:-.02em;overflow-wrap:anywhere}
    .cmt-dj .dj-subject{font-size:11px;color:var(--dj-muted);margin-top:4px}.cmt-dj .dj-state{font-size:10px;white-space:nowrap;font-weight:800;letter-spacing:.015em}
    .cmt-dj .dj-state[data-status="pending"]{color:#7c8580}.cmt-dj .dj-state[data-status="running"]{color:var(--dj-teal)}
    .cmt-dj .dj-state[data-status="found"]{color:#1e6b4a}.cmt-dj .dj-state[data-status="not-found"]{color:#8a671c}.cmt-dj .dj-state[data-status="error"]{color:var(--dj-red)}
    .cmt-dj .dj-detail{min-height:220px;padding:17px}.cmt-dj .dj-detail-empty{padding:22px 4px;color:var(--dj-muted);font-size:13px}
    .cmt-dj .dj-detail-top{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding-bottom:14px;border-bottom:1px solid var(--dj-line)}
    .cmt-dj .dj-detail-top h3{font-size:14px;margin:0 0 5px}.cmt-dj .dj-detail-top p{font:11px "SFMono-Regular",Consolas,monospace;margin:0;color:var(--dj-muted)}
    .cmt-dj .dj-badge{font-size:10px;font-weight:800;padding:5px 8px;border-radius:2px;background:#e4efe8;color:#27634d;white-space:nowrap}
    .cmt-dj .dj-badge.empty{background:#f1eddf;color:#80631f}.cmt-dj .dj-badge.error{background:#f5e8e5;color:#98493f}
    .cmt-dj .dj-findings{margin-top:14px}.cmt-dj .dj-findings h4{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#536965;margin:0 0 9px}
    .cmt-dj .dj-movement{border:1px solid var(--dj-line);padding:12px;margin:9px 0;background:#fff}.cmt-dj .dj-movement-title{font-weight:750;font-size:13px;margin:0 0 9px}
    .cmt-dj .dj-evidence{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px 14px;margin:0}
    .cmt-dj .dj-evidence div{min-width:0}.cmt-dj .dj-evidence dt{font-size:10px;color:var(--dj-muted);text-transform:uppercase;letter-spacing:.06em}
    .cmt-dj .dj-evidence dd{font-size:11px;margin:2px 0 0;overflow-wrap:anywhere}
    .cmt-dj .dj-rule-list{display:flex;flex-wrap:wrap;gap:5px;margin-top:10px}.cmt-dj .dj-rule{font-size:10px;background:#e9f2ed;color:#285f53;padding:4px 7px;border:1px solid #d2e4da}
    .cmt-dj .dj-comps{font-size:11px;color:#52625e;margin:9px 0 0}.cmt-dj .dj-comps strong{color:#344742}
    .cmt-dj .dj-no-movement{font-size:12px;color:var(--dj-muted);padding:12px;border:1px dashed var(--dj-line);margin-top:12px}
    .cmt-dj .dj-footnote{padding:14px 17px;border-top:1px solid var(--dj-line);font-size:11px;color:var(--dj-muted)}
    .cmt-dj .dj-export{display:flex;gap:7px;flex-wrap:wrap}.cmt-dj .dj-alert{width:100%;color:var(--dj-red);font-size:12px;margin:0}
    .cmt-dj .dj-dialog{width:min(920px,calc(100vw - 28px));max-height:82vh;border:1px solid #aebdb6;padding:0;background:#fbfcf8;color:var(--dj-ink);box-shadow:0 18px 60px #1e353329}
    .cmt-dj .dj-dialog::backdrop{background:#1d3438a6}.cmt-dj .dj-dialog-head{display:flex;justify-content:space-between;align-items:center;padding:13px 16px;border-bottom:1px solid var(--dj-line)}
    .cmt-dj .dj-dialog pre{white-space:pre-wrap;overflow:auto;max-height:calc(82vh - 60px);padding:16px;margin:0;font:11px/1.55 "SFMono-Regular",Consolas,monospace}
    .cmt-dj .dj-hidden{display:none!important}
    @media(max-width:900px){.cmt-dj .dj-grid{grid-template-columns:1fr}.cmt-dj .dj-processes{max-height:390px}.cmt-dj .dj-head{flex-direction:column}.cmt-dj .dj-tag{align-self:flex-start}}
    @media(max-width:560px){.cmt-dj{padding:14px}.cmt-dj .dj-toolbar{align-items:stretch}.cmt-dj .dj-toolbar .dj-btn{flex:1 1 calc(50% - 8px)}.cmt-dj .dj-stopcheck{margin:4px 0 0;width:100%}.cmt-dj .dj-separator{display:none}.cmt-dj .dj-progress{grid-template-columns:1fr auto;gap:8px}.cmt-dj .dj-track{grid-column:1/-1;grid-row:2}.cmt-dj .dj-evidence{grid-template-columns:repeat(2,minmax(0,1fr))}.cmt-dj .dj-process{grid-template-columns:32px minmax(0,1fr)}.cmt-dj .dj-state{grid-column:2}.cmt-dj .dj-panel-head{align-items:flex-start;flex-direction:column}}
  `;

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function fmtNumber(number) {
    return String(number).replace(/^(\d{7})(\d{2})(\d{4})(\d)(\d{2})(\d{4})$/, '$1-$2.$3.$4.$5.$6');
  }
  function makeState() {
    return {
      rows: processes.map(function (p) { return Object.assign({}, p, { status: 'pending', response: null, raw: null, error: '' }); }),
      selected: 0, running: false, waiting: false, stopAfterCurrent: false, shouldStop: false, current: -1, lastError: ''
    };
  }
  function countDone(s) {
    return s.rows.filter(function (r) { return r.status === 'found' || r.status === 'not-found' || r.status === 'error'; }).length;
  }
  function styleBlock() { return '<style data-cmt-dj-style>' + css + '</style>'; }
  function statusLabel(status) {
    return ({ pending: 'Pendente', running: 'Consultando', found: 'Encontrado', 'not-found': 'Não localizado', error: 'Erro técnico' })[status] || 'Pendente';
  }
  function renderProcess(r, index, selected) {
    return '<button type="button" class="dj-process' + (selected ? ' selected' : '') + '" data-action="select-process" data-testid="process-row-' + index + '" aria-label="Examinar item ' + esc(r.item) + ', ' + esc(fmtNumber(r.number)) + ', ' + statusLabel(r.status) + '">' +
      '<span class="dj-item" aria-label="Item ' + esc(r.item) + '">' + esc(r.item) + '</span>' +
      '<div><div class="dj-number">' + esc(fmtNumber(r.number)) + '</div><div class="dj-subject">' + esc(r.subject) + '</div></div>' +
      '<span class="dj-state" data-status="' + esc(r.status) + '" data-testid="status-process-' + index + '" role="status">' + statusLabel(r.status) + '</span></button>';
  }
  function renderDetail(s) {
    var r = s.rows[s.selected];
    if (!r || r.status === 'pending') {
      return '<div class="dj-detail-empty" data-testid="detail-empty">Selecione um processo consultado para examinar os movimentos e as evidências retornadas.</div>';
    }
    var badge = r.status === 'found' ? '<span class="dj-badge">Registro correspondente</span>' :
      r.status === 'not-found' ? '<span class="dj-badge empty">Nenhum registro correspondente</span>' :
      '<span class="dj-badge error">Falha técnica</span>';
    var body = '';
    if (r.status === 'error') body = '<div class="dj-no-movement" role="alert" data-testid="detail-error">' + esc(r.error || 'A consulta não foi concluída.') + '</div>';
    else if (!r.response || !r.response.movimentos || !r.response.movimentos.length) {
      body = '<div class="dj-no-movement" data-testid="detail-no-movements">Não foram retornados movimentos para esta consulta. A ausência de dados não permite concluir a situação jurídica do processo.</div>';
    } else {
      body = '<div class="dj-findings"><h4>Movimentos e evidências — ' + r.response.movimentos.length + '</h4>' +
        r.response.movimentos.map(function (m, i) {
          var labels = Array.isArray(m.regras) ? m.regras : [];
          var complements = Array.isArray(m.complementos) ? m.complementos : [];
          return '<article class="dj-movement" data-testid="movement-' + s.selected + '-' + i + '">' +
            '<p class="dj-movement-title">' + esc(m.nome || 'Movimento sem nome') + '</p>' +
            '<dl class="dj-evidence"><div><dt>Data</dt><dd>' + esc(m.data || 'Não informada') + '</dd></div>' +
            '<div><dt>Código</dt><dd>' + esc(m.codigo == null ? 'Não informado' : m.codigo) + '</dd></div>' +
            '<div><dt>Complementos</dt><dd>' + (complements.length ? esc(complements.length + ' registro(s)') : 'Nenhum informado') + '</dd></div></dl>' +
            (labels.length ? '<div class="dj-rule-list" aria-label="Regras identificadas">' + labels.map(function (rule) {
              return '<span class="dj-rule" data-testid="rule-label-' + s.selected + '-' + i + '">' + esc(rule.id || 'Regra') + ' · ' + esc(rule.titulo || 'Sem título') + '</span>';
            }).join('') + '</div>' : '<p class="dj-comps">Nenhum rótulo de regra associado pela consulta.</p>') +
            (complements.length ? '<p class="dj-comps"><strong>Complementos:</strong> ' + esc(complements.map(function (c) {
              if (typeof c === 'string') return c;
              try { return JSON.stringify(c); } catch (_) { return String(c); }
            }).join(' · ')) + '</p>' : '') +
            '</article>';
        }).join('') + '</div>';
    }
    return '<div class="dj-detail" data-testid="selected-process-detail"><div class="dj-detail-top"><div><h3>Item ' + esc(r.item) + ' · ' + esc(r.subject) + '</h3><p>' + esc(fmtNumber(r.number)) + '</p></div>' +
      '<div class="dj-export">' + badge + '<button class="dj-btn subtle" type="button" data-action="raw" data-testid="button-open-raw" aria-label="Abrir JSON bruto retornado">Ver JSON bruto</button></div></div>' +
      body + '</div>';
  }
  function render(root) {
    if (!root) return;
    var s = instances.get(root);
    if (!s) { s = makeState(); instances.set(root, s); }
    var done = countDone(s), pct = Math.round(done / s.rows.length * 100);
    root.innerHTML = styleBlock() + '<main class="cmt-dj"><div class="dj-wrap">' +
      '<header class="dj-head"><div><div class="dj-eyebrow">GabCMT · Apoio à triagem</div><h1>Movimentos DataJud</h1>' +
      '<p class="dj-subtitle">Consulta sequencial de 15 processos selecionados do TRF3. Examine os registros e os sinais que merecem conferência.</p></div>' +
      '<div class="dj-tag">TRF3 · consulta pública</div></header>' +
      '<aside class="dj-notice" data-testid="notice-human-review"><div aria-hidden="true">!</div><div><strong>Sinal de movimento não é conclusão jurídica</strong>' +
      '<p>Os rótulos são evidências para revisão humana. Não determinam regularidade, prazo, preparo, admissibilidade ou qualquer resultado processual.</p></div></aside>' +
      '<section class="dj-toolbar" aria-label="Ações de consulta e exportação">' +
       '<button type="button" class="dj-btn primary" data-action="test" data-testid="button-query-selected" ' + (s.running ? 'disabled' : '') + '>Consultar processo selecionado</button>' +
      '<button type="button" class="dj-btn primary" data-action="all" data-testid="button-query-all" ' + (s.running ? 'disabled' : '') + '>Consultar os 15 em sequência</button>' +
      '<button type="button" class="dj-btn" data-action="stop" data-testid="button-stop-after-current" ' + (!s.running ? 'disabled' : '') + '>Parar após a consulta atual</button>' +
      '<label class="dj-stopcheck"><input type="checkbox" data-action="stop-toggle" data-testid="input-stop-after-current" aria-label="Parar o lote após a consulta em andamento" ' + (s.stopAfterCurrent ? 'checked' : '') + ' ' + (s.running ? 'disabled' : '') + '> Parar após a consulta atual</label>' +
      '<span class="dj-separator" aria-hidden="true"></span><div class="dj-export" aria-label="Exportar resultados">' +
      '<button type="button" class="dj-btn" data-action="export-json" data-testid="button-export-json" ' + (done ? '' : 'disabled') + '>Exportar JSON</button>' +
      '<button type="button" class="dj-btn" data-action="export-summary" data-testid="button-export-summary-csv" ' + (done ? '' : 'disabled') + '>Resumo CSV</button>' +
      '<button type="button" class="dj-btn" data-action="export-movements" data-testid="button-export-movements-csv" ' + (done ? '' : 'disabled') + '>Movimentos CSV</button></div>' +
      (s.lastError ? '<p class="dj-alert" role="alert" data-testid="status-global-error">' + esc(s.lastError) + '</p>' : '') + '</section>' +
      '<section class="dj-progress" aria-label="Progresso das consultas" data-testid="progress-region">' +
       '<span class="dj-progress-label" data-testid="status-progress">' + (s.running ? s.waiting ? 'Próxima consulta em 1,5 s' : 'Consultando item ' + esc(s.rows[s.current] ? s.rows[s.current].item : '') : 'Consultas concluídas') + '</span>' +
      '<div class="dj-track" role="progressbar" aria-label="Progresso da triagem" aria-valuemin="0" aria-valuemax="15" aria-valuenow="' + done + '"><span style="width:' + pct + '%"></span></div>' +
      '<span class="dj-progress-count" data-testid="text-progress-count">' + done + ' / 15 · ' + pct + '%</span></section>' +
      '<div class="dj-grid"><section class="dj-panel" aria-labelledby="dj-processes-title"><div class="dj-panel-head"><h2 id="dj-processes-title">Processos da pauta</h2><span class="dj-panel-meta">15 selecionados · item e assunto</span></div>' +
      '<div class="dj-processes" data-testid="process-list">' + s.rows.map(function (r, i) { return renderProcess(r, i, i === s.selected); }).join('') + '</div></section>' +
      '<section class="dj-panel" aria-labelledby="dj-evidence-title"><div class="dj-panel-head"><h2 id="dj-evidence-title">Evidências retornadas</h2><span class="dj-panel-meta">Dados públicos · revisão necessária</span></div>' +
      renderDetail(s) + '<div class="dj-footnote">A classificação depende dos movimentos fornecidos pela consulta. Ausência ou presença de movimento, isoladamente, não comprova uma conclusão jurídica.</div></section></div>' +
      '<dialog class="dj-dialog" data-testid="dialog-raw-json" aria-label="JSON bruto retornado"><div class="dj-dialog-head"><strong>Resposta bruta da consulta</strong><button type="button" class="dj-btn" data-action="close-raw" data-testid="button-close-raw">Fechar</button></div><pre data-testid="raw-json-content"></pre></dialog>' +
      '</div></main>';
  }
  function safeJson(value) {
    try { return JSON.stringify(value, null, 2); } catch (_) { return String(value); }
  }
  function download(name, content, type) {
    var blob = new Blob([content], { type: type });
    var url = W.URL.createObjectURL(blob);
    var a = D.createElement('a');
    a.href = url; a.download = name; a.style.display = 'none';
    D.body.appendChild(a); a.click(); a.remove();
    W.setTimeout(function () { W.URL.revokeObjectURL(url); }, 1000);
  }
  function csvCell(value) {
    var text = value == null ? '' : String(value);
    return '"' + text.replace(/"/g, '""') + '"';
  }
  function exportRows(s) {
    return s.rows.filter(function (r) { return r.status !== 'pending'; });
  }
  function exportJson(s) {
    var data = exportRows(s).map(function (r) {
      return { item: r.item, numero: fmtNumber(r.number), assunto: r.subject, status: r.status === 'found' ? 'encontrado' : r.status === 'not-found' ? 'nao_localizado' : 'erro_tecnico', consulta: r.response, erro: r.error || undefined };
    });
    download('datajud-triagem.json', '\ufeff' + JSON.stringify(data, null, 2), 'application/json;charset=utf-8');
  }
  function exportSummary(s) {
    var headers = ['item', 'numero', 'assunto', 'status', 'registros', 'movimentos', 'regras_identificadas'];
    var rows = exportRows(s).map(function (r) {
      var movements = r.response && Array.isArray(r.response.movimentos) ? r.response.movimentos : [];
      var tags = {};
      movements.forEach(function (m) { (m.regras || []).forEach(function (rule) { tags[rule.id + ' — ' + rule.titulo] = true; }); });
      var status = r.status === 'found' ? 'encontrado' : r.status === 'not-found' ? 'nao_localizado' : 'erro_tecnico';
      return [r.item, fmtNumber(r.number), r.subject, status, r.response && Array.isArray(r.response.registros) ? r.response.registros.length : 0, movements.length, Object.keys(tags).join('; ')];
    });
    download('datajud-resumo.csv', '\ufeff' + [headers, ...rows].map(function (row) { return row.map(csvCell).join(','); }).join('\r\n'), 'text/csv;charset=utf-8');
  }
  function exportMovements(s) {
    var headers = ['item', 'numero', 'assunto', 'data', 'codigo', 'nome', 'regras', 'complementos_json'];
    var rows = [];
    exportRows(s).forEach(function (r) {
      ((r.response && r.response.movimentos) || []).forEach(function (m) {
        rows.push([r.item, fmtNumber(r.number), r.subject, m.data, m.codigo, m.nome,
          (m.regras || []).map(function (rule) { return rule.id + ' — ' + rule.titulo; }).join('; '),
          safeJson(m.complementos || [])]);
      });
    });
    download('datajud-movimentos.csv', '\ufeff' + [headers, ...rows].map(function (row) { return row.map(csvCell).join(','); }).join('\r\n'), 'text/csv;charset=utf-8');
  }
  async function requestProcess(s, index) {
    var row = s.rows[index];
    row.status = 'running'; row.error = '';
    render(s.root);
    try {
      var response = await W.fetch('/api/datajud/triagem/consultar', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ numero: row.number })
      });
      var payload;
      try { payload = await response.json(); }
      catch (_) { payload = { ok: false, error: 'A resposta do serviço não contém JSON válido.' }; }
      row.raw = payload;
      if (!response.ok || !payload || payload.ok !== true) {
        row.status = 'error';
        row.error = payload && typeof payload.error === 'string' ? payload.error : 'Falha técnica ao consultar o processo.';
      } else if (payload.status === 'encontrado' || payload.status === 'nao_localizado') {
        row.status = payload.status === 'encontrado' ? 'found' : 'not-found';
        row.response = {
          ok: payload.ok, numero: payload.numero, status: payload.status,
          registros: Array.isArray(payload.registros) ? payload.registros : [],
          movimentos: Array.isArray(payload.movimentos) ? payload.movimentos : []
        };
      } else {
        row.status = 'error'; row.error = 'A resposta do serviço não trouxe um status reconhecido.';
      }
    } catch (error) {
      row.status = 'error';
      row.error = error && error.message ? 'Falha de comunicação: ' + error.message : 'Falha de comunicação com o serviço.';
      row.raw = { ok: false, error: row.error };
    }
    s.current = -1;
    render(s.root);
  }
  async function run(s, all) {
    if (s.running) return;
    s.running = true; s.lastError = ''; s.shouldStop = false;
    render(s.root);
    var indices = all ? s.rows.map(function (_, i) { return i; }) : [s.selected];
    try {
      for (var n = 0; n < indices.length; n++) {
        if (s.shouldStop) break;
        var index = indices[n];
        s.current = index;
        await requestProcess(s, index);
        if (s.shouldStop || s.stopAfterCurrent) {
          s.shouldStop = true;
          break;
        }
        if (n < indices.length - 1) {
          s.waiting = true;
          s.current = indices[n + 1];
          render(s.root);
          await new Promise(function (resolve) { W.setTimeout(resolve, 1500); });
          s.waiting = false;
        }
      }
    } finally {
      s.running = false; s.waiting = false; s.current = -1; s.shouldStop = false; s.stopAfterCurrent = false;
      render(s.root);
    }
  }
  function click(event, root) {
    if (!root) return;
    var s = instances.get(root);
    if (!s) { render(root); s = instances.get(root); }
    s.root = root;
    var target = event.target instanceof Element ? event.target.closest('[data-action]') : null;
    if (!target || !root.contains(target)) return;
    var action = target.getAttribute('data-action');
    if (action === 'select-process') {
      var index = Number((target.getAttribute('data-testid') || '').replace('process-row-', ''));
      if (Number.isInteger(index) && index >= 0 && index < s.rows.length) { s.selected = index; render(root); }
    }
    else if (action === 'test') { event.preventDefault(); void run(s, false); }
    else if (action === 'all') { event.preventDefault(); void run(s, true); }
    else if (action === 'stop') { event.preventDefault(); if (s.running) { s.shouldStop = true; s.lastError = ''; render(root); } }
    else if (action === 'stop-toggle') {
      s.stopAfterCurrent = !!target.checked;
    } else if (action === 'raw') {
      var row = s.rows[s.selected], dialog = root.querySelector('[data-testid="dialog-raw-json"]');
      var pre = root.querySelector('[data-testid="raw-json-content"]');
      if (pre) pre.textContent = safeJson(row && row.raw !== null ? row.raw : row && row.response ? row.response : { aviso: 'Nenhum JSON retornado para este processo.' });
      if (dialog && typeof dialog.showModal === 'function') dialog.showModal();
      else if (dialog) dialog.setAttribute('open', '');
    } else if (action === 'close-raw') {
      var d = root.querySelector('[data-testid="dialog-raw-json"]');
      if (d && typeof d.close === 'function') d.close(); else if (d) d.removeAttribute('open');
    } else if (action === 'export-json') exportJson(s);
    else if (action === 'export-summary') exportSummary(s);
    else if (action === 'export-movements') exportMovements(s);
  }
  W.CMTDataJudTriage = { render: render, click: click };
})(window, document);

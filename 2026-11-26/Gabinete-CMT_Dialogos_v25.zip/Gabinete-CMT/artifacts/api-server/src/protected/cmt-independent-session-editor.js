/* Independent session docket editor: adds a 'Montar listagem' tab to the Sessions page. */
(function (W, D) {
  'use strict';
  const S = v => v == null ? '' : String(v);
  const E = v => S(v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const br = v => /^\d{4}-\d{2}-\d{2}/.test(S(v)) ? S(v).slice(8, 10) + '/' + S(v).slice(5, 7) + '/' + S(v).slice(0, 4) : '';
  const iso = v => /^\d{4}-\d{2}-\d{2}/.test(S(v)) ? S(v).slice(0, 10) : '';
  const svc = () => W.CMTIndependentSessions || null;
  const DATES = [
    ['date', 'Julgamento'], ['pecoDia', 'Peço-dia'], ['prepStart', 'Início da preparação'],
    ['minutasDeadline', 'Entrega das minutas'], ['releaseDeadline', 'Liberação dos votos'],
  ];
  const FIELDS = [
    ['Processo', 'Processo (CNJ)', true], ['Item (Pauta de Julgamento)', 'Item', false], ['Partes', 'Partes', false, 'w2'],
    ['classe_judicial', 'Classe', false], ['Assunto', 'Assunto', false, 'w2'], ['SERVIDOR', 'Servidor', false], ['CORRETOR', 'Corretor', false],
  ];
  const st = { session: '', creating: false, editCnj: null, busy: false, msg: '', err: false, pane: null };
  const disabled = new WeakMap();

  function list() { try { return (svc() && svc().list()) || []; } catch (_) { return []; } }
  function rows(s) { try { return (s && svc() && svc().rows(s)) || []; } catch (_) { return []; } }
  const rowOf = r => (r && r.w) || r || {};
  function current() {
    const all = list();
    if (st.session && all.some(x => x.session === st.session)) return st.session;
    st.session = all[0] ? all[0].session : '';
    return st.session;
  }
  function invalidateNative() {
    const host = D.getElementById('cmt-ref-host');
    host && host.querySelectorAll('.cmt-ref-pane:not([data-ref-pane="montar"])').forEach(p => { p.__montado = false; });
  }
  function status(text, err) {
    st.msg = text; st.err = !!err;
    const el = st.pane && st.pane.querySelector('[data-ise-status]');
    if (el) { el.textContent = text; el.className = 'ise-st' + (err ? ' err' : ''); }
  }
  function setBusy(b) {
    st.busy = b;
    st.pane && st.pane.querySelectorAll('button,input,select').forEach(el => {
      if (b) { if (!disabled.has(el)) disabled.set(el, el.disabled); el.disabled = true; }
      else if (disabled.has(el)) { el.disabled = disabled.get(el); disabled.delete(el); }
    });
  }
  async function run(fn, ok) {
    if (st.busy) return;
    setBusy(true); status('Salvando…');
    try { await fn(); invalidateNative(); render(); status(ok); }
    catch (e) { setBusy(false); status('Erro: ' + (e && e.message ? e.message : 'não foi possível salvar.'), true); }
    finally { if (st.busy) setBusy(false); }
  }

  function render() {
    const pane = st.pane; if (!pane) return;
    const all = list(), s = current();
    const sel = all.find(x => x.session === s);
    const d = (sel && sel.details) || {};
    const showForm = st.creating || !all.length;
    const dv = showForm && st.creating ? {} : d;
    const opts = all.map(x => '<option value="' + E(x.session) + '"' + (x.session === s ? ' selected' : '') + '>'
      + E((br(x.details && x.details.date) || x.session) + ' · ' + (x.count || 0) + ' proc.') + '</option>').join('');
    const dateForm = '<form class="ise-card" data-ise-sform novalidate><h4>' + (showForm ? 'Nova sessão' : 'Datas da sessão') + '</h4><div class="ise-grid">'
      + DATES.map(([k, l]) => '<div><label for="ise-d-' + k + '">' + E(l) + '</label><input type="date" id="ise-d-' + k + '" name="' + k + '" value="' + E(iso(dv[k])) + '"'
        + (k === 'date' ? ' required' : '') + ' aria-describedby="ise-e-' + k + '"><span class="ise-err" id="ise-e-' + k + '"></span></div>').join('')
      + '</div><div class="ise-act"><button class="ise-b" type="submit" data-ise-save-session>' + (showForm ? 'Criar sessão' : 'Salvar datas') + '</button>'
      + (st.creating && all.length ? '<button class="ise-b sec" type="button" data-ise-cancel-session>Cancelar</button>' : '') + '</div></form>';
    let procs = '';
    if (!showForm && s) {
      const rs = rows(s).map(rowOf);
      const ed = st.editCnj ? rs.find(r => S(r.Processo) === st.editCnj) || {} : {};
      const body = rs.length ? rs.map((r, i) => {
        const cnj = S(r.Processo);
        return '<tr' + (cnj === st.editCnj ? ' class="is-ed"' : '') + ' data-ise-row="' + E(cnj) + '"><td>' + E(r['Item (Pauta de Julgamento)']) + '</td><td class="cnj">' + E(cnj)
          + '</td><td>' + E(r.Partes) + '</td><td>' + E(r.classe_judicial) + '</td><td>' + E(r.SERVIDOR) + '</td><td class="ops">'
          + '<button class="ise-b sec sm" type="button" data-ise-up="' + E(cnj) + '"' + (i ? '' : ' disabled') + ' aria-label="Subir ' + E(cnj) + '">Subir</button>'
          + '<button class="ise-b sec sm" type="button" data-ise-down="' + E(cnj) + '"' + (i < rs.length - 1 ? '' : ' disabled') + ' aria-label="Descer ' + E(cnj) + '">Descer</button>'
          + '<button class="ise-b sec sm" type="button" data-ise-edit="' + E(cnj) + '" aria-label="Editar ' + E(cnj) + '">Editar</button>'
          + '<button class="ise-b dan sm" type="button" data-ise-remove="' + E(cnj) + '" aria-label="Retirar ' + E(cnj) + ' da listagem">Retirar</button></td></tr>';
      }).join('') : '';
      procs = '<form class="ise-card" data-ise-pform novalidate><h4>' + (st.editCnj ? 'Editar processo ' + E(st.editCnj) : 'Incluir processo') + '</h4><div class="ise-grid">'
        + FIELDS.map(([k, l, req, cls], n) => '<div' + (cls ? ' class="' + cls + '"' : '') + '><label for="ise-p-' + n + '">' + E(l) + '</label><input id="ise-p-' + n + '" name="' + E(k) + '" value="' + E(ed[k]) + '"'
          + (req ? ' required' : '') + ' autocomplete="off" aria-describedby="ise-pe-' + n + '"><span class="ise-err" id="ise-pe-' + n + '"></span></div>').join('')
        + '</div><div class="ise-act"><button class="ise-b" type="submit" data-ise-save-process>' + (st.editCnj ? 'Salvar processo' : 'Incluir na listagem') + '</button>'
        + (st.editCnj ? '<button class="ise-b sec" type="button" data-ise-cancel-edit>Cancelar edição</button>' : '') + '</div></form>'
        + (rs.length ? '<div class="ise-scroll"><table class="ise-t" data-ise-table><caption class="ise-lb" style="text-align:left;padding:8px 11px 0">' + rs.length + ' processo(s) na listagem</caption><thead><tr><th scope="col">Item</th><th scope="col">Processo</th><th scope="col">Partes</th><th scope="col">Classe</th><th scope="col">Servidor</th><th scope="col"><span class="ise-lb" style="position:absolute;left:-9999px">Ações</span></th></tr></thead><tbody>' + body + '</tbody></table></div>'
          : '<p class="ise-nil">Nenhum processo nesta listagem ainda. Inclua o primeiro pelo formulário acima.</p>');
    }
    pane.innerHTML = '<div class="ise" data-ise-root><div class="ise-hd"><h3>Montar listagem</h3><p>Prepare a pauta da sessão neste arquivo, sem conexão. As alterações ficam apenas neste navegador até você exportar a sessão.</p></div>'
      + (all.length ? '<div class="ise-bar"><label for="ise-sel">Sessão</label><select id="ise-sel" data-ise-session>' + opts + '</select>'
        + '<button class="ise-b sec" type="button" data-ise-new>Nova sessão</button>'
        + '<button class="ise-b sec" type="button" data-ise-export' + (s && !st.creating ? '' : ' disabled') + '>Exportar sessão para o app</button></div>' : '')
      + '<p class="ise-st' + (st.err ? ' err' : '') + '" role="status" aria-live="polite" data-ise-status>' + E(st.msg) + '</p>'
      + dateForm + procs + '</div>';
  }

  function fieldErr(form, input, text) {
    input.setAttribute('aria-invalid', text ? 'true' : 'false');
    const el = form.querySelector('#' + input.getAttribute('aria-describedby'));
    if (el) el.textContent = text || '';
  }

  function bind(pane) {
    pane.addEventListener('change', e => {
      const t = e.target;
      if (t.matches('[data-ise-session]')) { st.session = t.value; st.editCnj = null; st.msg = ''; render(); }
    });
    pane.addEventListener('click', e => {
      const b = e.target.closest && e.target.closest('button'); if (!b || st.busy || b.disabled) return;
      const s = current(), sv = svc();
      if (b.matches('[data-ise-new]')) { st.creating = true; st.editCnj = null; st.msg = ''; render(); pane.querySelector('#ise-d-date')?.focus(); }
      else if (b.matches('[data-ise-cancel-session]')) { st.creating = false; render(); }
      else if (b.matches('[data-ise-cancel-edit]')) { st.editCnj = null; render(); }
      else if (b.hasAttribute('data-ise-edit')) { st.editCnj = b.getAttribute('data-ise-edit'); st.msg = ''; render(); pane.querySelector('#ise-p-0')?.focus(); }
      else if (b.hasAttribute('data-ise-up') || b.hasAttribute('data-ise-down')) {
        const up = b.hasAttribute('data-ise-up'), cnj = b.getAttribute(up ? 'data-ise-up' : 'data-ise-down');
        run(() => sv.move(s, cnj, up ? -1 : 1), 'Ordem atualizada: ' + cnj + (up ? ' subiu.' : ' desceu.'));
      } else if (b.hasAttribute('data-ise-remove')) {
        const cnj = b.getAttribute('data-ise-remove');
        if (!W.confirm('Retirar o processo ' + cnj + ' desta listagem local?\n\nIsso apenas desvincula o processo desta sessão neste arquivo. Nada é excluído no Gabinete.')) return;
        if (st.editCnj === cnj) st.editCnj = null;
        run(() => sv.removeProcess(s, cnj), 'Processo ' + cnj + ' retirado desta listagem local.');
      } else if (b.matches('[data-ise-export]')) {
        try { sv.download(s); status('Sessão exportada. Verifique a pasta de downloads.'); }
        catch (err) { status('Erro ao exportar: ' + (err && err.message || 'falha desconhecida.'), true); }
      }
    });
    pane.addEventListener('submit', e => {
      e.preventDefault(); if (st.busy) return;
      const f = e.target, sv = svc();
      if (f.matches('[data-ise-sform]')) {
        const v = {}; let bad = null;
        DATES.forEach(([k]) => { const i = f.elements[k]; v[k] = i.value; fieldErr(f, i, ''); });
        if (!v.date) { fieldErr(f, f.elements.date, 'Informe a data do julgamento.'); bad = f.elements.date; }
        ['pecoDia', 'prepStart', 'minutasDeadline', 'releaseDeadline'].forEach(k => {
          if (v.date && v[k] && v[k] > v.date) { fieldErr(f, f.elements[k], 'Deve ser igual ou anterior ao julgamento.'); bad = bad || f.elements[k]; }
        });
        if (bad) { bad.focus(); status('Corrija as datas destacadas.', true); return; }
        const editing = !st.creating && list().length;
        if (editing) v.session = current();
        run(async () => { const key = await sv.saveSession(v); st.session = S(key) || st.session; st.creating = false; },
          editing ? 'Datas da sessão salvas.' : 'Sessão de ' + br(v.date) + ' criada.');
      } else if (f.matches('[data-ise-pform]')) {
        const v = {}; FIELDS.forEach(([k]) => { v[k] = S(f.elements[k].value).trim(); });
        const pi = f.elements.Processo; fieldErr(f, pi, '');
        let err = '';
        if (!v.Processo) err = 'Informe o número do processo.';
        else if (rows(current()).map(rowOf).some(r => S(r.Processo) === v.Processo && v.Processo !== st.editCnj)) err = 'Este processo já está nesta listagem.';
        if (err) { fieldErr(f, pi, err); pi.focus(); status(err, true); return; }
        const prev = st.editCnj;
        run(async () => { await sv.saveProcess(current(), v, prev ? { previousCnj: prev } : {}); st.editCnj = null; },
          prev ? 'Processo ' + v.Processo + ' atualizado.' : 'Processo ' + v.Processo + ' incluído.');
      }
    });
  }

  function mount() {
    if (W.CMT_INDEPENDENT_SESSION !== true || !svc()) return false;
    const host = D.getElementById('cmt-ref-host');
    const nav = host && host.querySelector(':scope>.cmt-ref-tabs');
    const panes = host && host.querySelector(':scope>.cmt-ref-panes');
    if (!nav || !panes) return false;
    let tab = nav.querySelector('[data-ref-aba="montar"]');
    let pane = panes.querySelector('[data-ref-pane="montar"]');
    const fresh = !tab;
    if (!tab) {
      tab = D.createElement('button');
      tab.type = 'button'; tab.setAttribute('role', 'tab'); tab.setAttribute('data-ref-aba', 'montar');
      tab.setAttribute('data-ise-tab', ''); tab.setAttribute('aria-selected', 'false'); tab.id = 'ise-tab';
      tab.setAttribute('aria-controls', 'ise-pane'); tab.textContent = 'Montar listagem';
      nav.appendChild(tab);
    }
    if (!pane) {
      pane = D.createElement('div');
      pane.className = 'cmt-ref-pane'; pane.id = 'ise-pane';
      pane.setAttribute('data-ref-pane', 'montar'); pane.setAttribute('role', 'tabpanel'); pane.setAttribute('aria-labelledby', 'ise-tab');
      pane.hidden = true; panes.appendChild(pane);
    }
    st.pane = pane;
    if (!pane.__iseBound) { pane.__iseBound = true; bind(pane); }
    if (!nav.__iseBound) {
      nav.__iseBound = true;
      // Capture phase: own tab is handled here; native tabs restore their panes.
      nav.addEventListener('click', e => {
        const b = e.target instanceof Element ? e.target.closest('[data-ref-aba]') : null;
        if (!b) return;
        if (b.getAttribute('data-ref-aba') === 'montar') { e.stopImmediatePropagation(); show(true); }
        else if (!pane.hidden) {
          show(false);
          const api = host.__abasApi, id = b.getAttribute('data-ref-aba');
          if (api) { delete host.dataset.refAba; api.ir(id); e.stopImmediatePropagation(); }
        }
      }, true);
    }
    function show(on) {
      const active = host.dataset.refAba;
      nav.querySelectorAll('[data-ref-aba]').forEach(b => b.setAttribute('aria-selected', String(on ? b === tab : b.getAttribute('data-ref-aba') === active)));
      panes.querySelectorAll(':scope>.cmt-ref-pane').forEach(p => { if (p !== pane) p.hidden = on ? true : p.getAttribute('data-ref-pane') !== active; });
      pane.hidden = !on;
      if (on) render();
    }
    pane.__iseShow = show;
    if (fresh && !list().length) show(true);
    else if (!pane.hidden) render();
    return true;
  }

  D.addEventListener('independent-sessions:changed', () => {
    invalidateNative();
    if (st.pane && !st.pane.hidden && !st.busy) render();
  });

  W.CMTIndependentSessionEditor = { mount, render };
})(window, document);

/* Embedded Ementário views shared by the Generator and the CM workspace. */
(function (W, D) {
  'use strict';
  if (W.CMTGeradorEmentario) return;
  let libraryRequest;
  let activeEmbedded = null;
  const embedded = new Map();

  function library() {
    if (!D.querySelector('link[data-cmt-ementario-library]')) {
      const link = D.createElement('link');
      link.rel = 'stylesheet';
      link.href = '/api/app/geradores-biblioteca.css';
      link.dataset.cmtEmentarioLibrary = 'true';
      D.head.appendChild(link);
    }
    if (W.CMTGerBib?.abrirEmentario) return Promise.resolve(W.CMTGerBib);
    if (libraryRequest) return libraryRequest;
    libraryRequest = new Promise((resolve, reject) => {
      const script = D.createElement('script');
      script.src = '/api/app/geradores-biblioteca.js';
      script.onload = () => {
        script.remove();
        if (W.CMTGerBib?.abrirEmentario) resolve(W.CMTGerBib);
        else reject(new Error('O núcleo do Ementário não foi inicializado.'));
      };
      script.onerror = () => {
        script.remove();
        reject(new Error('Não foi possível carregar a biblioteca do Ementário.'));
      };
      D.head.appendChild(script);
    }).catch(error => {
      libraryRequest = null;
      throw error;
    });
    return libraryRequest;
  }

  function loading(target) {
    target.querySelectorAll('.cmt-ementario-loading,.cmt-ementario-failure').forEach(node => node.remove());
    if (target.querySelector('.gbib')) return;
    const message = D.createElement('p');
    message.className = 'cmt-ementario-loading';
    message.setAttribute('role', 'status');
    message.textContent = 'Carregando a biblioteca de jurisprudência…';
    target.appendChild(message);
  }

  function failure(target, error, retry) {
    if (!target.isConnected) return;
    target.querySelectorAll('.cmt-ementario-loading,.cmt-ementario-failure').forEach(node => node.remove());
    const box = D.createElement('div');
    box.className = 'cmt-ementario-failure';
    const message = D.createElement('p');
    message.setAttribute('role', 'alert');
    message.textContent = error.message;
    const button = D.createElement('button');
    button.type = 'button';
    button.textContent = 'Tentar novamente';
    button.onclick = retry;
    box.append(message, button);
    target.appendChild(box);
  }

  function openEmbedded(target, query) {
    if (!target?.isConnected) return false;
    if (activeEmbedded && activeEmbedded !== target) closeEmbedded(activeEmbedded);
    const existing = embedded.get(target);
    if (existing?.active && !query && !target.querySelector('.cmt-ementario-failure')) return true;
    const addedHeading = !target.querySelector('.gr-h');
    if (addedHeading) {
      const heading = D.createElement('div');
      heading.className = 'gr-h';
      heading.hidden = true;
      target.prepend(heading);
    }
    const state = {
      active: true,
      generation: (existing?.generation || 0) + 1,
      addedViewClass: existing?.addedViewClass || !target.classList.contains('cmt-ementario-view'),
      addedHeading: existing?.addedHeading || addedHeading,
    };
    embedded.set(target, state);
    activeEmbedded = target;
    target.classList.add('cmt-ementario-view');
    target.hidden = false;
    loading(target);
    library().then(core => {
      if (!target.isConnected || embedded.get(target) !== state || !state.active) return;
      target.querySelectorAll('.cmt-ementario-loading,.cmt-ementario-failure').forEach(node => node.remove());
      if (!core.abrirEmentario(target, query)) throw new Error('O espaço embutido do Ementário não está pronto.');
    }).catch(error => {
      if (embedded.get(target) === state && state.active) {
        failure(target, error, () => openEmbedded(target, query));
      }
    });
    return true;
  }

  function closeEmbedded(target) {
    const node = target || activeEmbedded;
    if (!node) {
      embedded.forEach((state, detached) => {
        if (!detached.isConnected) {
          W.CMTGerBib?.fecharEmentario?.();
          embedded.delete(detached);
        }
      });
      return false;
    }
    const state = embedded.get(node);
    if (state) state.active = false;
    W.CMTGerBib?.fecharEmentario?.();
    if (state?.addedViewClass && node.isConnected) node.classList.remove('cmt-ementario-view');
    if (state?.addedHeading && node.isConnected) node.querySelector('.gr-h')?.remove();
    embedded.delete(node);
    if (activeEmbedded === node) activeEmbedded = null;
    return true;
  }

  W.CMTGeradorEmentario = { openEmbedded, closeEmbedded, library };
  /* Compatibility API used by the embedded Generator and CM surfaces only. */
  W.CMTParadigmas = {
    abrirEmMesa: openEmbedded,
    fecharEmMesa: closeEmbedded,
    carrega: () => library().then(core => core.carregarJulgados()),
    dados: () => W.CMTGerBib?.paradigmas?.() || [],
  };
})(window, document);

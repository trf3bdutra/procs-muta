/* Notifications, personal day and cabinet deliveries share the lower left sidebar. */
(function () {
  'use strict';
  if (window.CMTDailyWorkspace) return;
  const D = document, W = window;
  const S = v => String(v ?? '');
  const E = v => S(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const localDay = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const validDay = v => {
    const key = S(v).slice(0,10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(key)) return '';
    const d = new Date(`${key}T12:00:00`);
    return !isNaN(d) && localDay(d) === key ? key : '';
  };
  const today = () => validDay(W.PautaControl?.today?.()) || localDay(new Date());
  const formatDay = key => new Date(`${key}T12:00:00`).toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'});
  const icons = {
    day:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
    done:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v15H4zM8 3v4M16 3v4m-8 7 3 3 5-6"/></svg>',
    notif:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 9a6 6 0 0 0-12 0c0 6.5-2.5 7-3 9h18c-.5-2-3-2.5-3-9ZM10 21h4"/></svg>'
  };
  let selected = today(), month = selected.slice(0,7), lastToday = selected, queued = false;
  const empty = text => `<p class="dw-empty">${E(text)}</p>`;
  function setHTML(node, html) {
    if (node && node._dailyHTML !== html) {
      const open = [...node.querySelectorAll?.('details[data-daily-member][open]') || []].map(n=>n.dataset.dailyMember);
      node.innerHTML = html; node._dailyHTML = html;
      node.querySelectorAll?.('details[data-daily-member]').forEach(n=>{if(open.includes(n.dataset.dailyMember))n.open=true;});
    }
  }
  function data() {
    try { return W.CMTRail?.dailyData?.() || null; }
    catch (error) { console.warn('[Meu dia]', error); return null; }
  }
  function sideShell() {
    const side = D.getElementById('alt-side');
    if (!side) return null;
    let dock = D.getElementById('cmt-sidebar-day');
    if (!dock) {
      dock = D.createElement('section'); dock.id = 'cmt-sidebar-day';
      dock.setAttribute('aria-label','Meu dia e entregas do gabinete');
      dock.innerHTML = `<details open class="dw-team" data-daily-section="team"><summary>${icons.done}<span>Meu time</span><b data-daily-count="deliveries">—</b></summary><details open class="dw-personal-day" data-daily-section="my"><summary>${icons.day}<span>Meu dia</span><b data-daily-count="my">—</b></summary><div class="dw-side-body" data-daily-my></div></details><p class="dw-team-date">Hoje · entregas e pendências da equipe</p><div data-daily-deliveries></div></details>`;
      side.appendChild(dock);
      dock.addEventListener('click',event=>{
        if (dock.dataset.compact !== '1' || !event.target.closest('summary')) return;
        event.preventDefault();
        side.querySelector('.as-collapse')?.click();
        schedule();
      });
    }
    let notice = D.getElementById('cmt-sidebar-notifications-launch');
    if (!notice) {
      notice = D.createElement('button'); notice.id = 'cmt-sidebar-notifications-launch';
      notice.type = 'button'; notice.className = 'dw-side-notifications';
      notice.dataset.centerLaunch = 'notif'; notice.setAttribute('aria-expanded','false');
      notice.setAttribute('aria-label','Abrir painel de notificações e calendário');
      notice.innerHTML = `${icons.notif}<span>Notificações</span><b class="dw-side-unread" hidden></b>`;
      // The shared data-center-launch handler owns this click, including toggle and active state.
    }
    if (notice.parentElement !== side || notice.nextElementSibling !== dock) side.insertBefore(notice,dock);
    D.querySelectorAll('#alt-side .as-bell,#alt-side .gd-bell,#pauta-global-dock .gd-bell').forEach(old=>{
      if(!old.hidden)old.hidden=true;
      if(old.getAttribute('aria-hidden')!=='true')old.setAttribute('aria-hidden','true');
      if(old.style.getPropertyValue('display')!=='none')old.style.setProperty('display','none','important');
    });
    return dock;
  }
  const itemHTML = i => `<li><b>${E(S(i.proc)||i.tipo||'Entrega registrada')}</b><small>${E([i.tipo||'',i.det||'',i.item?'Item '+i.item:'',i.sess?.rot?'Sessão '+i.sess.rot:''].filter(Boolean).join(' · '))}</small></li>`;
  const norm=v=>S(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toUpperCase();
  function eventTime(value){
    const raw=S(value).trim();if(/^\d{2}:\d{2}(?::\d{2})?$/.test(raw))return raw.slice(0,5);
    if(!/T\d{2}:\d{2}/.test(raw))return '';
    const date=new Date(raw);return Number.isFinite(date.getTime())?date.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}):'';
  }
  function teamEvents(v){
    const host=W.PautaApp,day=today(),base=[...(v.entregues||[])];
    const completed=(host?.team?.pendingCompletions||[]).filter(c=>validDay(c.date||c.at)===day);
    const names=new Map((host?.team?.members||[]).map(m=>[S(m.id),S(m.name)]));
    const issues=host?.team?.pendingIssues||[];
    for(const c of completed){
      const name=names.get(S(c.memberId))||S(c.memberName),issue=issues.find(i=>S(i.id)===S(c.issueId));
      const title=S(c.issueTitle||issue?.title),process=S(issue?.process||issue?.processo);
      const same=e=>e.k==='pend'&&norm(e.srv)===norm(name)&&(S(e.issueId)===S(c.issueId)&&!!c.issueId||(!e.issueId&&norm(e.det)===norm(title)));
      const existing=base.findIndex(same);
      const event={k:'pend',tipo:'Pendência concluída',srv:name,issueId:S(c.issueId),proc:process,det:title,at:c.at||c.completedAt||''};
      if(existing>=0)base[existing]={...base[existing],...event};else base.push(event);
    }
    return base.map((e,index)=>{
      const item=S(e.item)||(S(e.tipo).match(/item\s+([^ ·]+)/i)||[])[1]||'';
      return {...e,index,item,time:eventTime(e.at||e.completedAt||e.createdAt),name:S(e.srv)||'Responsável não informado'};
    }).sort((a,b)=>(b.time||'').localeCompare(a.time||'')||a.index-b.index);
  }
  function renderSide() {
    const dock=sideShell();if(!dock)return;
    const compact=D.documentElement.classList.contains('alt-collapsed')||D.getElementById('alt-side').offsetWidth<150?'1':'0';
    if(dock.dataset.compact!==compact)dock.dataset.compact=compact;
    dock.setAttribute('aria-label','Meu time: Meu dia e entregas da equipe');
    const v=data(),count=(key,value)=>{const n=dock.querySelector(`[data-daily-count="${key}"]`);if(n&&n.textContent!==S(value))n.textContent=S(value);};
    if(!v){setHTML(dock.querySelector('[data-daily-my]'),empty('Aguardando os dados.'));setHTML(dock.querySelector('[data-daily-deliveries]'),'<div class="dw-team-empty">'+empty('Aguardando as entregas da equipe.')+'</div>');count('my','—');count('deliveries','—');return;}
    const events=teamEvents(v),person=v.P,personal=person?events.filter(e=>[person.bruto,person.nome,person.k].some(n=>norm(n)===norm(e.name))):[];
    const target=Number(person?.meta),done=Number(person?.feitas||0),hasTarget=Number.isFinite(target)&&target>0;
    const summary=!v.temEu?empty('Entre com sua conta para ver o Meu dia.'):`<div class="dw-target"><b>${E(done)}${hasTarget?' / '+E(target):''}</b><span>${hasTarget?'meta de hoje':'minutas e decisões'}</span></div>${hasTarget?`<progress class="dw-progress" max="${E(target)}" value="${E(Math.min(target,Math.max(0,done)))}" aria-label="Progresso da meta diária"></progress>`:''}<p class="dw-empty">${personal.length} entrega(s) sua(s) na lista da equipe.</p>`;
    setHTML(dock.querySelector('[data-daily-my]'),summary);count('my',personal.length);count('deliveries',events.length);
    const list=events.length?'<ul class="dw-team-list">'+events.map(e=>`<li><div class="dw-event-head"><b>${E(e.name)}</b><time title="${e.time?'Horário registrado':'Horário não registrado'}">${E(e.time||'—')}</time></div><span class="dw-event-kind">${E(e.tipo||'Entrega')}${e.item&&!/item\s/i.test(S(e.tipo))?' · item '+E(e.item):''}</span>${e.proc?`<small>${E(e.proc)}</small>`:''}${e.det?`<small>${E(e.det)}</small>`:''}</li>`).join('')+'</ul>':'<div class="dw-team-empty">'+empty('Aguardando a primeira entrega da equipe.')+'</div>';
    setHTML(dock.querySelector('[data-daily-deliveries]'),list);
    const online=D.querySelector('#alt-side>.cmt-online');if(online&&dock.nextElementSibling!==online)dock.after(online);
  }
  function calendarEvents() {
    const host = W.PautaApp;
    if (!host || typeof W.PautaPublicCalendar?.events !== 'function') return null;
    const events = W.PautaPublicCalendar.events(host);
    if (!Array.isArray(events)) throw new Error('O calendário retornou dados inválidos.');
    return events.map((e,index) => {
      const start = validDay(e.start), end = validDay(e.end) || start;
      return {id:S(e.id)||String(index),start,end,title:S(e.title||e.label||e.name)||'Evento',
        kind:S(e.kind),session:S(e.session||e.sess||''),detail:S(e.description||e.note||'')};
    }).filter(e=>e.start && e.end >= e.start).sort((a,b)=>a.start.localeCompare(b.start)||a.title.localeCompare(b.title,'pt-BR'));
  }
  const eventsOn = (events,key) => events.filter(e=>e.start<=key && key<=e.end);
  function calendarHTML(events) {
    const base = new Date(`${month}-01T12:00:00`);
    const cells = new Date(base); cells.setDate(1 - base.getDay());
    const heading = base.toLocaleDateString('pt-BR',{month:'long',year:'numeric'});
    const td = today();
    let grid = '';
    for (let i=0;i<42;i++) {
      const key = localDay(cells), list = eventsOn(events,key), active = selected===key;
      grid += `<button type="button" class="dw-date${key.slice(0,7)!==month?' is-out':''}${key===td?' is-today':''}" data-daily-date="${key}" aria-pressed="${active}"${key===td?' aria-current="date"':''} aria-label="${E(formatDay(key))}${list.length?' · '+list.length+' evento(s)':''}"><span>${cells.getDate()}</span>${list.length?`<b>${list.length}</b>`:''}</button>`;
      cells.setDate(cells.getDate()+1);
    }
    const dayEvents = eventsOn(events,selected), todayEvents = eventsOn(events,td);
    const listHTML = list => list.length ? `<ul>${list.map(e=>`<li><span class="dw-event-kind">${e.kind==='milestone'?'Marco de sessão':'Evento'}</span><b>${E(e.title)}</b>${e.session?`<small>${E(e.session)}</small>`:''}${e.detail?`<small>${E(e.detail)}</small>`:''}</li>`).join('')}</ul>` : empty('Nenhum marco ou evento registrado neste dia.');
    return `<header class="dw-cal-head"><h3><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16"/></svg><span>Calendário</span><em class="n num" aria-label="Eventos hoje">${todayEvents.length}</em></h3></header><div class="dw-cal-toolbar"><div class="dw-cal-nav" role="group" aria-label="Navegação do calendário"><button type="button" data-daily-month="-1" aria-label="Mês anterior"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 6-6 6 6 6"/></svg></button><strong>${E(heading)}</strong><button type="button" data-daily-month="1" aria-label="Próximo mês"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg></button><button type="button" data-daily-today>Hoje</button></div></div>
      <div class="dw-cal-body"><div><div class="dw-week" aria-hidden="true">${['D','S','T','Q','Q','S','S'].map(s=>`<span>${s}</span>`).join('')}</div><div class="dw-month" role="group" aria-label="Dias do mês">${grid}</div></div>
      <section class="dw-events" aria-label="Marcos e eventos"><h4>${selected===td?'Hoje':'Dia '+formatDay(selected)} · ${dayEvents.length}</h4>${listHTML(dayEvents)}${selected!==td?`<h4>Eventos de hoje · ${todayEvents.length}</h4>${listHTML(todayEvents)}`:''}</section></div>`;
  }
  function renderCalendar(target) {
    if (!target) return;
    try {
      const events = calendarEvents();
      setHTML(target, events ? calendarHTML(events) : '<div class="dw-loading" aria-busy="true"><span></span><span></span><span></span>'+empty('Calendário aguardando os dados do gabinete.')+'</div>');
    } catch (error) {
      setHTML(target, '<p class="dw-empty" role="alert">Não foi possível carregar os eventos. <button type="button" data-daily-retry>Tentar novamente</button></p>');
      console.warn('[calendário do rodapé]',error);
    }
  }
  function refresh() {
    queued = false;
    if (D.hidden) return;
    const td = today();
    if (td !== lastToday) {
      if (selected === lastToday) { selected = td; month = td.slice(0,7); }
      lastToday = td;
    }
    renderSide();
    if (D.querySelector('#cmt-center-panels[data-active="painel"]:not([hidden])')) W.CMTRail?.repaintPanel?.();
    D.querySelectorAll('[data-daily-calendar]').forEach(renderCalendar);
  }
  function schedule() { if (!queued) { queued = true; requestAnimationFrame(refresh); } }
  function focusSide() {
    const dock = sideShell(); if (!dock) return false;
    const section = dock.querySelector('[data-daily-section="my"]');
    section.open = true; section.querySelector('summary').focus(); return true;
  }
  W.CMTDailyWorkspace = {refresh:schedule,mountCalendar:renderCalendar,focusSide};
  D.addEventListener('click',e=>{
    const target = e.target.closest?.('[data-daily-calendar]'); if (!target) return;
    const date = e.target.closest('[data-daily-date]'), nav = e.target.closest('[data-daily-month]');
    if (date) selected = date.dataset.dailyDate;
    else if (nav) { const d = new Date(`${month}-01T12:00:00`); d.setMonth(d.getMonth()+Number(nav.dataset.dailyMonth)); month = localDay(d).slice(0,7); }
    else if (e.target.closest('[data-daily-today]')) { selected=today();month=selected.slice(0,7); }
    else if (!e.target.closest('[data-daily-retry]')) return;
    const focus = date ? `[data-daily-date="${selected}"]` : nav ? `[data-daily-month="${nav.dataset.dailyMonth}"]` : '[data-daily-today]';
    renderCalendar(target); target.querySelector(focus)?.focus();
  });
  for (const event of ['pauta:updated','pauta:team-updated','cmt:session-changed','pauta:pending-updated','pauta:presence-updated']) D.addEventListener(event,schedule);
  D.addEventListener('visibilitychange',schedule); W.addEventListener('focus',schedule); W.addEventListener('resize',schedule);
  D.addEventListener('transitionend',event=>{if(event.target.id==='alt-side')schedule();});
  // Also covers midnight and legacy writers that do not dispatch update events.
  setInterval(schedule,30000);
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded',schedule,{once:true}); else schedule();
})();

(function () {
  'use strict';
  var E = function (v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  function controls(lim, mono) {
    var destination = window.CMT_URGENCY_WHATSAPP_DESTINATION;
    if (!destination) return '<p role="alert">Destino do WhatsApp indisponível. Recarregue a página antes de encaminhar.</p>';
    return '<style>[data-urgency-whatsapp] [hidden]{display:none!important}[data-urgency-whatsapp] textarea{width:100%;box-sizing:border-box;resize:vertical}[data-urgency-whatsapp] [data-uw-status]:not(:empty){padding:10px;border-radius:6px;background:#e4eee8;color:#214d3b}</style>' +
      '<div data-urgency-whatsapp data-opening="' + crypto.randomUUID() + '" data-mono="' + E(mono.id) + '" style="margin-top:12px;border-top:1px solid #cad7d0;padding-top:12px">' +
      '<label style="display:flex;align-items:center;gap:8px"><input type="checkbox" data-uw-enable> Encaminhar pedido ' + (destination.test ? 'ao destinatário de teste' : 'ao desembargador') + ' por WhatsApp ao salvar</label>' +
      '<small>' + (destination.test ? 'Ambiente de testes · ' : '') + 'Destino: ' + E(destination.display) + '. Nenhuma mensagem é enviada sem ativar e salvar.</small>' +
      '<div data-uw-options hidden><label>Conteúdo da mensagem<select data-uw-mode><option value="automatic">Automático · dados do card de urgência</option><option value="custom">Totalmente personalizado</option>' +
      (destination.templateSid ? '<option value="template">Modelo da Twilio</option>' : '') + '</select></label>' +
      '<small>Mensagens automáticas e personalizadas são texto livre: o WhatsApp exige uma conversa iniciada pelo destinatário nas últimas 24 horas. Fora dessa janela, use um modelo aprovado. No Sandbox, o destinatário também precisa aderir ao ambiente de testes da Twilio.</small>' +
      '<p data-uw-auto>A mensagem será composta com os dados salvos do pedido de urgência vinculado: processo, pedido, prioridade, prazo, responsável e demais informações preenchidas.</p>' +
      '<label data-uw-custom-wrap hidden>Mensagem personalizada<textarea data-uw-custom rows="6" maxlength="1500" placeholder="Escreva todo o conteúdo que deseja encaminhar."></textarea><small>Até 1.500 caracteres. O texto substitui integralmente a mensagem automática.</small></label></div>' +
      '<div data-uw-template-wrap hidden><p>Modelo: <code>' + E(destination.templateSid || '') + '</code>. Será enviado o conteúdo cadastrado na Twilio, não o texto automático do card. Confira se esse modelo é adequado ao pedido de urgência e está aprovado para WhatsApp.</p>' +
      '<label>Variáveis do modelo, se necessárias (JSON)<textarea data-uw-vars rows="3" maxlength="20000" placeholder=\'{"1":"valor da primeira variável","2":"valor da segunda"}\'></textarea></label><small>Deixe vazio se o modelo não exigir variáveis. Os números devem corresponder aos campos do modelo aprovado.</small></div>' +
      '<p data-uw-status role="status" aria-live="polite"></p></div>';
  }
  document.addEventListener('change', function (event) {
    var box = event.target.closest && event.target.closest('[data-urgency-whatsapp]');
    if (!box) return;
    box.querySelector('[data-uw-options]').hidden = !box.querySelector('[data-uw-enable]').checked;
    var mode = box.querySelector('[data-uw-mode]').value;
    var custom = mode === 'custom';
    box.querySelector('[data-uw-custom-wrap]').hidden = !custom;
    box.querySelector('[data-uw-auto]').hidden = mode !== 'automatic';
    box.querySelector('[data-uw-template-wrap]').hidden = mode !== 'template' || !box.querySelector('[data-uw-enable]').checked;
  });
  function handleSave(h, form, mono) {
    var box = form.querySelector('[data-urgency-whatsapp]');
    if (!box) return false;
    if (box.dataset.state === 'busy') return true;
    if (!box.querySelector('[data-uw-enable]').checked || box.dataset.state) return false;
    var mode = box.querySelector('[data-uw-mode]').value;
    var custom = box.querySelector('[data-uw-custom]').value.trim();
    var status = box.querySelector('[data-uw-status]');
    var variables;
    if (mode === 'template') {
      try {
        var raw = box.querySelector('[data-uw-vars]').value.trim();
        variables = raw ? JSON.parse(raw) : {};
        if (!variables || Array.isArray(variables) || typeof variables !== 'object' || Object.keys(variables).length > 100 ||
          Object.keys(variables).some(function (k) { return !/^[1-9]\d*$/.test(k) || typeof variables[k] !== 'string' || !variables[k].trim() || variables[k].length > 1500; })) throw new Error();
      } catch (_) {
        status.textContent = 'Confira as variáveis do modelo: informe um objeto JSON com chaves numéricas e valores de texto preenchidos.';
        return true;
      }
    }
    if (mode === 'custom' && !custom) {
      status.textContent = 'Escreva a mensagem personalizada antes de encaminhar.';
      box.querySelector('[data-uw-custom]').focus();
      return true;
    }
    box.dataset.state = 'busy';
    var disabled = Array.from(form.querySelectorAll('input,select,textarea,button')).map(function (el) {
      var item = [el, el.disabled]; el.disabled = true; return item;
    });
    status.textContent = 'Salvando o card antes de encaminhar…';
    (async function () {
      var persisted = false, requested = false;
      try {
        if (typeof h.saveDB !== 'function' || await h.saveDB() !== true) throw new Error('O salvamento não foi confirmado. Nenhuma mensagem foi solicitada.');
        persisted = true;
        status.textContent = 'Card salvo. Encaminhando por WhatsApp…';
        requested = true;
        var response = await fetch('/api/pauta/urgencias/whatsapp', {
          method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ monoId: mono.id, openingId: box.dataset.opening, mode: mode, customText: mode === 'custom' ? custom : undefined,
            contentVariables: mode === 'template' ? variables : undefined })
        });
        var result = await response.json();
        if (!response.ok || result.status !== 'accepted') throw new Error(result.error || 'O encaminhamento não foi confirmado.');
        box.dataset.state = 'sent';
        status.textContent = 'Mensagem enviada · aceita pela Twilio para encaminhamento por WhatsApp. Entrega ainda não confirmada. Para solicitar novo envio, feche e reabra o card, ative o encaminhamento e salve novamente.';
        h.notify('Card salvo; encaminhamento por WhatsApp aceito pela Twilio.');
      } catch (error) {
        box.dataset.state = requested ? 'unconfirmed' : '';
        status.textContent = (persisted ? 'Card salvo. ' : '') + error.message +
          (requested ? ' Confira o resultado antes de reabrir o card para outro envio.' : '');
        h.notify(status.textContent, 'warn');
      } finally {
        disabled.forEach(function (item) { item[0].disabled = item[1]; });
        if (box.dataset.state) {
          box.querySelector('[data-uw-enable]').checked = false;
          box.querySelectorAll('input,select,textarea').forEach(function (el) { el.disabled = true; });
        }
      }
    })();
    return true;
  }
  window.CMTUrgencyWhatsApp = { controls: controls, handleSave: handleSave };
})();

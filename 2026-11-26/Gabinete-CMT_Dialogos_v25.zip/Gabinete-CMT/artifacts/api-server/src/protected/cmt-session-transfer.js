/* Canonical session-file contract, shared by the authenticated app and offline export. */
(function (W) {
  'use strict';
  const copy = value => JSON.parse(JSON.stringify(value));
  const digits = value => String(value || '').replace(/\D/g, '');
  const object = value => value && typeof value === 'object' && !Array.isArray(value);
  const fields = ['pecoDia', 'prepStart', 'minutasDeadline', 'releaseDeadline', 'date'];
  const present = value => value !== '' && value != null && (!Array.isArray(value) || value.length > 0);
  function date(value) {
    if (!value) return '';
    const text = String(value), iso = /^\d{4}-\d{2}-\d{2}$/.test(text);
    const parsed = new Date(text + 'T12:00:00Z');
    return iso && +text.slice(0, 4) >= 1900 && Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === text ? text : '';
  }
  function entries(row) {
    if (Array.isArray(row._pautaEntries) && row._pautaEntries.length) return row._pautaEntries;
    return row['Sessão Destino'] ? [{ session: row['Sessão Destino'], item: String(row['Item (Pauta de Julgamento)'] || ''), status: row['Status de Julgamento'] || 'PAUTADO', closed: false }] : [];
  }
  function validate(data) {
    if (!object(data) || data.formato !== 'controle-pauta-hub-sessoes' || data.versao !== 1) throw Error('Use o JSON de sessão compatível com o GabCMT, versão 1.');
    if (!Array.isArray(data.sessions) || !object(data.sessionDetails) || !Array.isArray(data.rows)) throw Error('Sessões, marcos e processos são obrigatórios.');
    if (!data.sessions.length || data.sessions.length > 2000 || data.rows.length > 200000) throw Error('Quantidade de registros inválida.');
    const sessions = new Set(), ids = new Set(), numbers = new Map(), byId = new Map();
    for (const session of data.sessions) {
      if (typeof session !== 'string' || !session.trim() || session !== session.trim() || sessions.has(session)) throw Error('Sessão vazia ou duplicada.');
      sessions.add(session);
      if (!object(data.sessionDetails[session])) throw Error('Marcos ausentes para ' + session);
      for (const field of fields) if (data.sessionDetails[session][field] && !date(data.sessionDetails[session][field])) throw Error('Data inválida: ' + session + ' · ' + field);
    }
    for (const row of data.rows) {
      const id = digits(row?.Processo);
      if (!object(row) || id.length !== 20 || ids.has(id)) throw Error('CNJ inválido ou duplicado no arquivo: ' + String(row?.Processo || ''));
      ids.add(id);
      byId.set(id, row);
      const seen = new Set();
      const links = entries(row);
      if (!links.length) throw Error('Processo sem vínculo com uma sessão: ' + row.Processo);
      for (const entry of links) {
        if (!object(entry) || !sessions.has(entry.session) || seen.has(entry.session)) throw Error('Vínculo de sessão inválido ou duplicado: ' + row.Processo);
        seen.add(entry.session);
        if (entry.item && !/^[1-9]\d*$/.test(String(entry.item))) throw Error('O item deve ser um inteiro positivo: ' + row.Processo);
        if (entry.item) {
          const key = entry.session + '|' + entry.item;
          if (numbers.has(key)) throw Error('Item ' + entry.item + ' repetido na sessão ' + entry.session);
          numbers.set(key, id);
        }
      }
    }
    for (const [session, list] of Object.entries(data.pautaPreferences?.jsonSessionLists || {})) {
      if (!sessions.has(session) || !Array.isArray(list) || new Set(list.map(digits)).size !== list.length) throw Error('Listagem de sessão inválida.');
      for (const id of list) if (!ids.has(digits(id)) || !entries(byId.get(digits(id))).some(e => e.session === session)) throw Error('A listagem referencia processo sem ficha ou vínculo: ' + id);
    }
    return data;
  }
  function mergeFields(target, source) {
    for (const [key, value] of Object.entries(source)) {
      if (['__proto__', 'constructor', 'prototype'].includes(key) || !present(value)) continue;
      if (object(value)) target[key] = mergeFields(object(target[key]) ? copy(target[key]) : {}, value);
      else target[key] = copy(value);
    }
    return target;
  }
  function mergeRow(old, source, scope) {
    const result = copy(old);
    if (!old['Sessão Destino'] || scope.has(old['Sessão Destino'])) {
      const base = { ...source }; delete base._pautaEntries; delete base._pautaHistory;
      mergeFields(result, base);
    }
    const links = new Map(entries(old).map(entry => [entry.session, copy(entry)]));
    for (const incoming of entries(source).filter(entry => scope.has(entry.session))) {
      const previous = links.get(incoming.session);
      const next = mergeFields(previous ? copy(previous) : {}, incoming);
      // An offline draft cannot silently reopen a completed participation.
      if (previous?.closed || previous?.julgado || previous?.status === 'JULGADO') {
        for (const field of ['closed', 'julgado', 'status', 'work']) if (field in previous) next[field] = copy(previous[field]);
      }
      links.set(incoming.session, next);
    }
    result._pautaEntries = [...links.values()];
    const history = [...(old._pautaHistory || [])], seen = new Set(history.map(JSON.stringify));
    for (const event of source._pautaHistory || []) if (scope.has(event.session) && !seen.has(JSON.stringify(event))) { history.push(copy(event)); seen.add(JSON.stringify(event)); }
    result._pautaHistory = history;
    const current = result._pautaEntries.find(e => e.session === result['Sessão Destino']);
    if (current?.closed || current?.julgado || current?.status === 'JULGADO') result['Status de Julgamento'] = current.status;
    return result;
  }
  function preview(host, data, mode = 'merge') {
    validate(data);
    const scope = new Set(data.sessions), old = new Map((host.rows || []).map(row => [digits(row.Processo), row]));
    const blocking = [], changes = [], occupied = new Map();
    const incoming = new Map(data.rows.map(row => [digits(row.Processo), row]));
    if (mode !== 'replace') for (const row of host.rows || []) for (const entry of entries(row)) {
      if (scope.has(entry.session) && entry.item && !entries(incoming.get(digits(row.Processo)) || {}).some(e => e.session === entry.session)) occupied.set(entry.session + '|' + entry.item, digits(row.Processo));
    }
    for (const row of data.rows) {
      const previous = old.get(digits(row.Processo));
      const conflicts = previous ? Object.keys(row).filter(key => !key.startsWith('_') && present(row[key]) && present(previous[key]) && JSON.stringify(row[key]) !== JSON.stringify(previous[key])) : [];
      for (const entry of entries(row)) {
        const used = occupied.get(entry.session + '|' + entry.item);
        if (entry.item && used && used !== digits(row.Processo)) blocking.push('Item ' + entry.item + ' de ' + entry.session + ' já pertence a outro processo preservado.');
        const active = previous && entries(previous).find(e => e.session === previous['Sessão Destino'] && !e.closed && !e.julgado && !['JULGADO', 'ADIADO', 'RETIRADO DE PAUTA'].includes(e.status));
        if (active && !scope.has(active.session) && !entry.closed) blocking.push(row.Processo + ': participação ativa em ' + active.session + '. Registre a saída dessa pauta antes de incluir em outra.');
        changes.push({ session: entry.session, processo: row.Processo, item: entry.item, kind: previous ? 'Existente' : 'Novo', conflicts });
      }
    }
    return { changes, blocking: [...new Set(blocking)], newProcesses: data.rows.filter(row => !old.has(digits(row.Processo))).length, existingProcesses: data.rows.filter(row => old.has(digits(row.Processo))).length };
  }
  function payload(host, session) {
    if (!host.sessions.includes(session)) throw Error('Selecione uma sessão cadastrada.');
    const rows = host.rows.filter(row => entries(row).some(e => e.session === session)).map(row => {
      const result = copy(row);
      result._pautaEntries = entries(result).filter(e => e.session === session);
      result._pautaHistory = (result._pautaHistory || []).filter(e => e.session === session);
      const entry = result._pautaEntries[0];
      if (entry.closed && entry.work) mergeFields(result, entry.work);
      result['Sessão Destino'] = session; result['Item (Pauta de Julgamento)'] = entry.item; result['Status de Julgamento'] = entry.status || 'PAUTADO';
      return result;
    });
    const data = {
      formato: 'controle-pauta-hub-sessoes', versao: 1, escopo: 'sessão', exportadoEm: new Date().toISOString(),
      sessions: [session], sessionDetails: { [session]: copy(host.sessionDetails[session]) }, rows,
      pautaPreferences: { session, jsonSessionLists: { [session]: rows.map(row => digits(row.Processo)) } },
    };
    validate(data);
    return data;
  }
  W.CMTSessionTransfer = { fields, date, digits, entries, validate, mergeFields, mergeRow, preview, payload };
})(typeof window !== 'undefined' ? window : globalThis);

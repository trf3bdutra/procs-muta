/* Standalone Triagem at /tria. No session tab or process-panel overrides. */
(function (W, D) {
  'use strict';
  function ownsRoute() {
    try {
      return W.parent.location.pathname.toLowerCase().replace(/\/+$/, '') === '/tria';
    } catch (_) { return false; }
  }
  if (!ownsRoute()) return;
  const root = D.documentElement;
  let observedView = null;
  const viewObserver = new MutationObserver(sync);
  function sync() {
    if (!ownsRoute()) return;
    const view = D.getElementById('cmtx-view');
    if (view !== observedView) {
      viewObserver.disconnect();
      observedView = view;
      if (view) viewObserver.observe(view, { childList: true, subtree: true });
    }
    view?.querySelectorAll('.tg-workspace-tabs').forEach(node => node.remove());
    if (W.CMTViews?.active?.() === 'triagem' || root.dataset.cmtxView === 'triagem') {
      D.title = 'Triagem — GabCMT';
    }
  }
  W.addEventListener('message', event => {
    if (!ownsRoute() || event.origin !== W.location.origin || event.source !== W.parent
      || event.data?.type !== 'pauta:workspace-state' || event.data.page !== 'triagem') return;
    if (W.CMTViews?.active?.() !== 'triagem') W.CMTViews?.open?.('triagem');
    sync();
  });
  new MutationObserver(sync).observe(root, { attributes: true, attributeFilter: ['class', 'data-cmtx-view'] });
  D.addEventListener('cmt:route', sync);
  W.CMTTriagemWorkspace = { path: '/tria', sync };
  sync();
})(window, document);

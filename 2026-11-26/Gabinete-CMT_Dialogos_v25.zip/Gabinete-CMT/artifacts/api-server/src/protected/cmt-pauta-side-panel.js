(function(){
  'use strict';
  const W=window,D=document;
  if(W.CMTPautaSidePanel)return;
  function isFixedPauta(){
    return D.documentElement?.dataset?.v2Page==='pauta'||W.CMTPagina?.tipo?.()==='pauta';
  }
  // Other contexts retain their own collapse state; the Pauta always uses the open presentation.
  let collapsed=true,queued=false,observed=null,observer=null,lastScope,lastBody=null,needsPaint=false,needsLayout=true;
  const norm=value=>String(value??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toUpperCase();
  let routeWorkspace=null,routePage=null,routeMain=null,panelPlaceholder=null,routePanel=null,pickerQuery='',routeRetry=0,routeRetryCount=0;
  const digits=value=>String(value??'').replace(/\D/g,'');
  function routeKind(){
    const path=String(location.pathname||'').toLowerCase().replace(/\/+$/,'');
    if(path==='/tria'||path==='/triagem'||path==='/filter'||D.documentElement.dataset.cmtWorkspace==='filter')return 'triagem';
    if(W.CMTSessoes?.aberto?.())return 'sessoes';
    if(W.CMTViews?.active?.()==='triagem')return 'triagem';
    return '';
  }
  function routeRoot(kind){
    return kind==='sessoes'?D.getElementById('cmt-ref-host')
      :kind==='triagem'?D.getElementById('cmtx-view'):null;
  }
  function activePanel(){return routePanel?.isConnected?routePanel:D.querySelector('#controle-pauta-root #pq-side-panel');}
  function movePanelTo(slot){
    let panel=activePanel();
    if(!panel){
      const shell=D.createElement('div');shell.className='pq-side-workspace';shell.dataset.collapsed=String(collapsed);
       shell.innerHTML='<aside id="pq-side-panel" aria-label="Prontuário do processo"><header><span>Prontuário</span><button type="button" data-pq-side-toggle aria-expanded="false" aria-controls="pq-side-body" aria-label="Expandir painel lateral"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14 7-5 5 5 5"/></svg></button></header><div id="pq-side-body" hidden></div><div id="pq-generator-host"></div></aside>';
      panel=shell.firstElementChild;
    }
    if(panel.parentElement===slot)return;
    if(panelPlaceholder?.isConnected)panelPlaceholder.remove();
    panelPlaceholder=D.createComment('prontuario-slot');
    panel.parentNode?.insertBefore(panelPlaceholder,panel);
    routePanel=panel;slot.appendChild(panel);
    panel.querySelector('#pq-side-body')?.setAttribute('data-cmt-context-page',routeKind());
    W.__CMT_ROUTE_PRONTUARIO_PANEL=panel;
  }
  function ensureToggle(panel,allow){
    const header=panel?.querySelector(':scope>header');
    if(!header)return null;
    let button=header.querySelector('[data-pq-side-toggle]');
    if(!allow){button?.remove();return null;}
    if(!button){
      button=D.createElement('button');
      button.type='button';button.dataset.pqSideToggle='';
      button.setAttribute('aria-expanded',String(!collapsed));
      button.setAttribute('aria-controls','pq-side-body');
      button.setAttribute('aria-label',collapsed?'Expandir painel lateral':'Recolher painel lateral');
      button.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14 7-5 5 5 5"/></svg>';
      header.appendChild(button);
    }
    return button;
  }
  function pautaStatusMessage(api,qp,hasRows){
    if(!hasRows||!api)return 'Carregando os dados do Prontuário…';
    if(!String(api.currentProcess?.()||'').trim())return 'Selecione um processo na lista para visualizar sua ficha.';
    if(!api.isOn?.()||!qp||qp.hidden)return 'Carregando a ficha do processo…';
    return '';
  }
  function updatePautaStatus(body,api,qp){
    if(!body)return;
    let status=body.querySelector('[data-pq-side-status]');
    if(!status){
      status=D.createElement('div');status.dataset.pqSideStatus='';
      status.setAttribute('role','status');status.setAttribute('aria-live','polite');
      body.prepend(status);
    }
    const message=pautaStatusMessage(api,qp,Array.isArray(W.PautaApp?.rows));
    if(status.textContent!==message)status.textContent=message;
    status.hidden=!message;
  }
  function restoreRoutePage(){
    if(routeMain?.isConnected){
      routeMain.classList.remove('cmt-route-prontuario-open');
      delete routeMain.dataset.cmtProntuarioPage;
      delete routeMain.dataset.collapsed;
    }
    routePage=null;routeMain=null;
    if(routePanel?.isConnected){
      const current=D.querySelector('#controle-pauta-root .pq-side-workspace');
      if(current){
        const fresh=current.querySelector('#pq-side-panel');
        if(fresh&&fresh!==routePanel){
          const oldBody=routePanel.querySelector('#pq-side-body'),newBody=fresh.querySelector('#pq-side-body');
          const oldGenerator=routePanel.querySelector('#pq-generator-host'),newGenerator=fresh.querySelector('#pq-generator-host');
          if(oldBody&&newBody)while(oldBody.firstChild)newBody.appendChild(oldBody.firstChild);
          if(oldGenerator&&newGenerator)while(oldGenerator.firstChild)newGenerator.appendChild(oldGenerator.firstChild);
          routePanel.remove();
        }else current.insertBefore(routePanel,current.querySelector('.pq-side-list')||null);
      }else if(panelPlaceholder?.parentNode)panelPlaceholder.parentNode.insertBefore(routePanel,panelPlaceholder);
    }
    panelPlaceholder?.remove();panelPlaceholder=null;routePanel=null;
    delete W.__CMT_ROUTE_PRONTUARIO_PANEL;
    routeWorkspace?.remove();routeWorkspace=null;
  }
  function mountRouteWorkspace(){
    const kind=routeKind(),page=routeRoot(kind),main=page?.closest('main.app-main');
    if(!kind){if(routeWorkspace)restoreRoutePage();return;}
    if(!page||!main){
      if(!routeRetry&&routeKind()&&routeRetryCount++<25)routeRetry=setTimeout(()=>{routeRetry=0;mountRouteWorkspace();},120);
      return;
    }
    routeRetryCount=0;
    if(routePage!==page||routeMain!==main||routeMain?.dataset.cmtProntuarioPage!==kind){
      if(routeWorkspace)restoreRoutePage();
      routePage=page;routeMain=main;
      main.classList.add('cmt-route-prontuario-open');
      main.dataset.cmtProntuarioPage=kind;
      main.dataset.collapsed=String(collapsed);
      routeWorkspace=D.createElement('div');
      routeWorkspace.id='cmt-route-prontuario-slot';
      routeWorkspace.className='cmt-route-prontuario-slot';
      main.appendChild(routeWorkspace);
      movePanelTo(routeWorkspace);
      const panel=activePanel(),body=panel?.querySelector('#pq-side-body');
      if(body)body.dataset.cmtContextPage=kind;
      renderProcessPicker(kind,body);
    }else{
      if(!routeWorkspace?.isConnected){routeWorkspace=D.getElementById('cmt-route-prontuario-slot');}
      const panel=activePanel();
      if(panel&&panel.parentElement!==routeWorkspace)movePanelTo(routeWorkspace);
      const body=panel?.querySelector('#pq-side-body');
      if(body&&body.dataset.cmtContextPage!==kind)body.dataset.cmtContextPage=kind;
      renderProcessPicker(kind,body);
    }
  }
  function contextItems(kind){
    if(kind==='sessoes'){
      try{return W.CMTSessoes?.processRows?.()||[];}catch(_){return [];}
    }
    const triage=W.CMTViews?.triagem?.st?.rows;
    if(!Array.isArray(triage))return [];
    const byProcess=new Map((W.PautaApp?.rows||[]).map(row=>[digits(row?.Processo||row?.processo),row]));
    return triage.map(item=>{
      const process=String(item?.processo||item?.Processo||'').trim();
      return {r:byProcess.get(digits(process))||null,w:item,process,item};
    }).filter(item=>item.process);
  }
  function renderProcessPicker(kind,body){
    if(!body)return;
    let picker=body.querySelector('[data-cmt-process-picker]');
    if(kind==='sessoes'){picker?.remove();return;}
    if(!picker){picker=D.createElement('div');picker.dataset.cmtProcessPicker='';body.prepend(picker);}
    const rows=contextItems(kind),current=String(W.CMTProntuario?.currentProcess?.()||'');
    const signature=[kind,pickerQuery,rows.length,rows[0]?.process||rows[0]?.w?.Processo||rows[0]?.r?.Processo,rows.at(-1)?.process||rows.at(-1)?.w?.Processo||rows.at(-1)?.r?.Processo].join('|');
    if(picker.__signature===signature){
      const select=picker.querySelector('[data-cmt-process-select]');
      if(select&&select.value!==current)select.value=current;
      return;
    }
    const filtered=rows.filter(item=>{
      if(!pickerQuery)return true;
      const row=item.r||item.w||{};
      return [item.process,row.Processo,row.Assunto,row.assunto,item.item?.etapa,item.item?.det]
        .map(value=>String(value||'')).join(' ').toLocaleLowerCase('pt-BR').includes(pickerQuery.toLocaleLowerCase('pt-BR'));
    });
    const options=filtered.slice(0,60).map(item=>{
      const row=item.w||item.r||{},process=String(item.process||row.Processo||row.processo||'').trim();
      const matched=item.r||row,subject=String(matched.Assunto||matched.assunto||'').trim();
      const label=[process,subject,item.item?.det||item.item?.etapa].filter(Boolean).join(' · ');
      return `<option value="${process.replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"${digits(process)===digits(current)?' selected':''}${item.r?'':' disabled'}>${label.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}${item.r?'':' · sem ficha compartilhada'}</option>`;
    }).join('');
    const html=`<label for="cmt-prontuario-process-search">Processo da Triagem</label><input id="cmt-prontuario-process-search" data-cmt-process-search type="search" value="${pickerQuery.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;')}" placeholder="Buscar número, assunto ou etapa"><select id="cmt-prontuario-process" data-cmt-process-select aria-label="Processo da Triagem"${rows.length?'':' disabled'}><option value="">${filtered.length?'Selecione um processo':rows.length?'Nenhum resultado; ajuste a busca':'Nenhum processo na Triagem.'}</option>${options}</select><small>${Math.min(filtered.length,60)} de ${filtered.length} encontrados · ${rows.length} na Triagem</small>`;
    if(picker.__html!==html){picker.innerHTML=html;picker.__html=html;}
    picker.__signature=signature;
    picker.querySelector('[data-cmt-process-search]')?.addEventListener('input',event=>{
      pickerQuery=String(event.target.value||'');
      renderProcessPicker(kind,body);
      const next=picker.querySelector('[data-cmt-process-search]');
      if(next){next.focus();next.setSelectionRange(pickerQuery.length,pickerQuery.length);}
    });
  }
  function chooseProcess(process){
    const value=String(process||'').trim();if(!value)return false;
    const selected=W.CMTProntuario?.selectProcess?.(value);
    if(!selected){W.PautaApp?.notify?.('Este processo não está disponível na listagem compartilhada da Pauta.','warn');return false;}
    if(collapsed&&!isFixedPauta())setExpanded(true);
    if(routeKind()&&W.CMTProntuario&&!W.CMTProntuario.isOn?.())W.CMTProntuario.open?.();
    schedule(true);return true;
  }
  function setExpanded(value){
    if(isFixedPauta()){
      const panel=activePanel(),body=panel?.querySelector('#pq-side-body');
      const wrapper=panel?.closest('#cmt-route-prontuario-slot')?.parentElement||panel?.closest('.pq-side-workspace');
      if(wrapper)wrapper.dataset.collapsed='false';
      if(body)body.hidden=false;
      ensureToggle(panel,false);
      schedule(true);
      return;
    }
    collapsed=!value;
    const panel=activePanel(),wrapper=panel?.closest('#cmt-route-prontuario-slot')?.parentElement||panel?.closest('.pq-side-workspace');
    if(wrapper)wrapper.dataset.collapsed=String(collapsed);
    const body=panel?.querySelector('#pq-side-body'),button=panel?.querySelector('[data-pq-side-toggle]');
    if(body)body.hidden=collapsed;
    if(button){button.setAttribute('aria-expanded',String(!collapsed));button.setAttribute('aria-label',collapsed?'Expandir painel lateral':'Recolher painel lateral');}
    needsPaint=true;schedule(true);
  }
  function scope(){
    const host=W.PautaApp,auth=W.CMT_AUTH_SESSION;
    if(!host?.team||auth===null)return null;
    let legacy={};if(auth===undefined)try{legacy=JSON.parse(sessionStorage.getItem('cmt:sessao')||'null')||{};}catch(_){}
    const who=norm(auth?.server||legacy.servidor);
    if(!who)return null;
    const member=(host.team.members||[]).find(m=>m&&!m.archived&&[m.id,m.name,...(m.aliases||[])].some(name=>norm(name)===who));
    if(!member)return null;
    const names=[...new Set([member.id,member.name,...(member.aliases||[])].map(norm).filter(Boolean))];
    const corrector=!!W.PautaTeam?.isAssessoria?.(member)||/^corretor(?:a)?$/i.test(String(member.hierarchy||member.role||'').trim());
    return {key:String(member.id||member.name),names,corrector};
  }
  function matches(item,who=scope()){
    if(!who)return false;
    const row=item?.w||item?.r||item||{};
    return who.names.includes(norm(row.CORRETOR))||(!who.corrector&&who.names.includes(norm(row.SERVIDOR)));
  }
  function render(){
    queued=false;
    const root=D.getElementById('controle-pauta-root');
    if(root!==observed){
      observer?.disconnect();observed=root;
      needsLayout=true;
      if(root)observer=new MutationObserver(()=>schedule(true));
      if(root)observer.observe(root,{childList:true});
    }
    const fixedPauta=isFixedPauta(),viewCollapsed=fixedPauta?false:collapsed;
    const panel=activePanel();
    if(!panel)return;
    if(routePanel?.isConnected&&root)root.querySelectorAll('#pq-side-panel').forEach(duplicate=>{if(duplicate!==panel)duplicate.remove();});
    const wrapper=panel.closest('#cmt-route-prontuario-slot')?.parentElement||panel.closest('.pq-side-workspace');
    if(!wrapper)return;
    const button=ensureToggle(panel,!fixedPauta);
    if(wrapper.dataset.collapsed!==String(viewCollapsed))wrapper.dataset.collapsed=String(viewCollapsed);
    if(button&&button.getAttribute('aria-expanded')!==String(!viewCollapsed))button.setAttribute('aria-expanded',String(!viewCollapsed));
    const label=viewCollapsed?'Expandir painel lateral':'Recolher painel lateral';
    if(button&&button.getAttribute('aria-label')!==label)button.setAttribute('aria-label',label);
    const body=panel.querySelector('#pq-side-body'),contextPage=body?.dataset.cmtContextPage||'';
    if(body.hidden!==viewCollapsed)body.hidden=viewCollapsed;
    const kind=W.CMTPagina?.tipo?.(),active=!D.body.classList.contains('cfg-modal-open')&&(
      (D.documentElement.dataset.v2Page==='pauta'&&(kind===undefined||kind==='pauta'||kind==='gerador'))
      ||(contextPage&&(['triagem','sessoes'].includes(kind)&&contextPage===kind
        ||kind==='gerador'&&['triagem','sessoes'].includes(contextPage)))
    );
    const api=W.CMTProntuario;
    const opening=active&&!viewCollapsed&&api&&!api.isOn?.();
    if((!active||viewCollapsed)&&api?.isOn?.())api.rightPanel?.(false);
    if(opening)api.open?.();
    const qp=D.getElementById('alt-qp'),generator=D.getElementById('cmt-ger'),generatorHost=panel.querySelector('#pq-generator-host');
    if(qp&&qp.parentElement!==body)body.appendChild(qp);
    if(active&&generator&&generatorHost&&generator.parentElement!==generatorHost)generatorHost.appendChild(generator);
    if(fixedPauta)updatePautaStatus(body,api,qp);
    else{
      const status=body?.querySelector('[data-pq-side-status]');
      if(status)status.hidden=true;
    }
    if(active&&!viewCollapsed&&(lastBody!==body||needsPaint)){
      lastBody=body;needsPaint=false;
      if(!opening)api?.refresh?.();
    }
    if(qp){
      for(const name of ['position','top','left','right','bottom','width','height','min-height','max-height','transform']){
        if(qp.style.getPropertyValue(name))qp.style.removeProperty(name);
      }
    }
    if(active&&needsLayout&&!contextPage){
      needsLayout=false;
      const z=parseFloat(getComputedStyle(D.documentElement).zoom)||1,top=panel.getBoundingClientRect().top;
      const foot=D.querySelector('#pauta-global-dock>.gd-foot.is-active')?.getBoundingClientRect();
      const bottom=Number.isFinite(foot?.top)?foot.top:W.innerHeight-58;
      const height=Math.max(0,(bottom-Math.max(0,top)-12)/z);
      const value=Math.round(height)+'px';
      if(panel.style.getPropertyValue('--pq-side-height')!==value)panel.style.setProperty('--pq-side-height',value);
    }else if(!active)needsLayout=true;
    D.getElementById('pa-mesa-workbench-toggle')?.remove();
    const identity=JSON.stringify(scope()),page=W.PautaControl?.page;
    const mineButton=root?.querySelector('[data-fb="mineonly"]');
    if(mineButton&&mineButton.disabled!==!scope())mineButton.disabled=!scope();
    if(lastScope!==identity){lastScope=identity;if(page?.mineOnly)page.render();}
  }
  function schedule(layout=false){if(layout)needsLayout=true;if(!queued){queued=true;requestAnimationFrame(render);}}
  D.addEventListener('click',event=>{
    const processButton=event.target.closest?.('[data-ses-process]');
    if(processButton){event.preventDefault();chooseProcess(processButton.dataset.sesProcess);return;}
    if(event.target.closest?.('#controle-pauta-root [data-action="clear-filters"]')){
      const page=W.PautaControl?.page;if(page)page.mineOnly=false;
    }
    if(!event.target.closest?.('#pq-side-panel [data-pq-side-toggle]'))return;
    setExpanded(collapsed);
  },true);
  D.addEventListener('change',event=>{
    const select=event.target.closest?.('[data-cmt-process-select]');
    if(select&&select.value)chooseProcess(select.value);
  });
  for(const name of ['cmt:route','cmt:page-change','pauta:updated','pauta:team-updated'])D.addEventListener(name,()=>{needsPaint=true;requestAnimationFrame(mountRouteWorkspace);schedule(true);});
  D.addEventListener('cmt:prontuario-process-selected',event=>{
    const process=String(event.detail?.process||'').trim();
    if(!process)return;
    if(collapsed&&!isFixedPauta()){setExpanded(true);return;}
    if(!W.CMTProntuario?.isOn?.()){needsPaint=true;schedule(true);}
  });
  for(const name of ['cmt:route','cmt:page-change','pauta:updated','pauta:team-updated','cmt:prontuario-state','cmt:mesa-state'])D.addEventListener(name,()=>{needsPaint=true;schedule(true);});
  W.addEventListener('focus',()=>schedule());W.addEventListener('resize',()=>schedule(true));
  W.CMTPautaSidePanel={refresh:schedule,scope,matches,isPauta:()=>D.documentElement.dataset.v2Page==='pauta',setExpanded,isExpanded:()=>isFixedPauta()||!collapsed,statusMessage:(api=W.CMTProntuario,qp=D.getElementById('alt-qp'))=>pautaStatusMessage(api,qp,Array.isArray(W.PautaApp?.rows))};
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',()=>{mountRouteWorkspace();schedule();},{once:true});else{mountRouteWorkspace();schedule();}
})();

/* Local editing service. Never loaded by the authenticated application's pages. */
(function (W, D) {
  'use strict';
  if (!W.CMT_INDEPENDENT_SESSION) return;
  const T = W.CMTSessionTransfer, H = () => W.PautaApp;
  const clone = value => JSON.parse(JSON.stringify(value));
  const key = T.digits;
  let busy = false;
  async function change(action) {
    if (busy) throw Error('Aguarde o salvamento em andamento.');
    busy = true;
    const host = H(), backup = host.snapshot();
    try {
      const result = action(host);
      host.syncSessionPlans?.();
      if (await host.saveDB() === false) throw Error('Não foi possível salvar neste navegador. Exporte um backup antes de fechar o arquivo.');
      D.querySelectorAll('#cmt-ref-host [data-ref-pane]').forEach(pane => { pane.__montado = false; });
      D.dispatchEvent(new CustomEvent('independent-sessions:changed'));
      return result;
    } catch (error) { host.restoreSnapshot(backup); throw error; }
    finally { busy = false; }
  }
  const rows = session => H().rows.filter(row => T.entries(row).some(entry => entry.session === session))
    .map(row => ({ ...clone(row), 'Item (Pauta de Julgamento)': String(T.entries(row).find(e => e.session === session).item || '') }))
    .sort((a, b) => Number(a['Item (Pauta de Julgamento)']) - Number(b['Item (Pauta de Julgamento)']));
  function relist(host, session) {
    host.pautaPreferences.jsonSessionLists ||= {};
    host.pautaPreferences.jsonSessionLists[session] = rows(session).map(row => key(row.Processo));
  }
  function assignItem(row, session, item) {
    const entry = T.entries(row).find(e => e.session === session);
    entry.item = String(item);
    if (row['Sessão Destino'] === session) row['Item (Pauta de Julgamento)'] = String(item);
  }
  W.CMTIndependentSessions = {
    list: () => (H().sessions || []).map(session => ({ session, details: clone(H().sessionDetails[session] || {}), count: rows(session).length })),
    rows,
    saveSession(values) { return change(host => {
      if (!T.date(values.date)) throw Error('Informe a data válida do julgamento.');
      for (const field of T.fields) if (values[field] && !T.date(values[field])) throw Error('Data inválida: ' + field);
      const session = values.session || values.date.slice(8, 10) + '/' + values.date.slice(5, 7) + '/' + values.date.slice(0, 4);
      if (values.session && !host.sessions.includes(session)) throw Error('Sessão não encontrada.');
      if (!values.session && host.sessions.includes(session)) throw Error('Esta sessão já existe. Selecione-a para editar.');
      host.ensureSession(session);
      const details = host.sessionDetails[session];
      for (const field of T.fields) details[field] = values[field] || '';
      details.minutasMode = 'manual'; details.releaseMode = 'manual';
      host.pautaPreferences.session = session;
      relist(host, session);
      return session;
    }); },
    saveProcess(session, values, options = {}) { return change(host => {
      if (!host.sessions.includes(session)) throw Error('Cadastre ou selecione uma sessão.');
      const id = key(values.Processo), item = String(values['Item (Pauta de Julgamento)'] || '').trim();
      if (id.length !== 20) throw Error('O processo deve conter um CNJ com 20 dígitos.');
      if (!/^[1-9]\d*$/.test(item)) throw Error('Informe um item inteiro positivo.');
      if (options.previousCnj && key(options.previousCnj) !== id) throw Error('O CNJ identifica o processo e não pode ser trocado na edição. Remova o vínculo e inclua o CNJ correto.');
      const existing = host.rows.find(row => key(row.Processo) === id);
      if (existing && T.entries(existing).some(e => e.session === session) && !options.previousCnj) throw Error('O processo já está nesta listagem. Use Editar.');
      if (rows(session).some(row => key(row.Processo) !== id && row['Item (Pauta de Julgamento)'] === item)) throw Error('Este número de item já está em uso nesta sessão.');
      if (existing && existing['Sessão Destino'] !== session && T.entries(existing).some(e => !e.closed && !e.julgado && !['JULGADO', 'ADIADO', 'RETIRADO DE PAUTA'].includes(e.status))) throw Error('O processo já tem participação ativa em outra sessão.');
      const row = existing || host.ensureShape({ Processo: values.Processo.trim() });
      for (const field of ['Processo', 'Partes', 'classe_judicial', 'Assunto', 'SERVIDOR', 'CORRETOR']) if (values[field] != null) row[field] = String(values[field]).trim();
      row._pautaEntries ||= [];
      let entry = row._pautaEntries.find(e => e.session === session);
      if (entry?.closed || entry?.julgado || entry?.status === 'JULGADO') throw Error('Uma participação concluída não pode ser reaberta por este editor.');
      if (!entry) { entry = { session, status: 'PAUTADO', closed: false }; row._pautaEntries.push(entry); }
      row['Sessão Destino'] = session; row['Status de Julgamento'] = entry.status || 'PAUTADO'; assignItem(row, session, item);
      if (!existing) host.rows.push(row);
      for (const field of ['SERVIDOR', 'CORRETOR']) if (row[field] && !host.names.includes(row[field])) host.names.push(row[field]);
      relist(host, session);
    }); },
    removeProcess(session, cnj) { return change(host => {
      const row = host.rows.find(row => key(row.Processo) === key(cnj));
      if (!row) throw Error('Processo não encontrado.');
      row._pautaEntries = T.entries(row).filter(entry => entry.session !== session);
      if (row['Sessão Destino'] === session) {
        const next = row._pautaEntries.find(entry => !entry.closed);
        row['Sessão Destino'] = next?.session || ''; row['Item (Pauta de Julgamento)'] = next?.item || '';
      }
      // Retain the process record. Removing a draft link is not global deletion.
      relist(host, session);
    }); },
    move(session, cnj, delta) { return change(host => {
      const list = rows(session), index = list.findIndex(row => key(row.Processo) === key(cnj)), target = index + delta;
      if (index < 0 || target < 0 || target >= list.length) return;
      const first = host.rows.find(row => key(row.Processo) === key(cnj)), second = host.rows.find(row => key(row.Processo) === key(list[target].Processo));
      const item = T.entries(first).find(e => e.session === session).item;
      assignItem(first, session, T.entries(second).find(e => e.session === session).item); assignItem(second, session, item);
      relist(host, session);
    }); },
    exportSession: session => T.payload(H(), session),
    download(session) {
      const data = T.payload(H(), session), url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
      const a = D.createElement('a'); a.href = url; a.download = 'Sessao_' + session.replace(/[^a-z0-9-]/gi, '_') + '_GabCMT.json'; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    },
  };
})(window, document);

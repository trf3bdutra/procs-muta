// Owner-only workspace command. There is deliberately no HTTP account creation route.
import { randomUUID } from "node:crypto";
import { and, eq, sql } from "drizzle-orm";
import { db, pool, accountMembershipsTable as accounts, localCredentialsTable as credentials, localSessionsTable as sessions, accountAuditTable as audit } from "@workspace/db";
import { accountEnvironment } from "../lib/account-memberships";
import { accountPasswordSecretKey } from "../lib/account-policy";
import { loadTeamRoster } from "../lib/team-roster-db";
import { provisionOwnerApprovedStaff } from "../lib/owner-approved-staff";

type InitialRosterAccount = {
  email: string;
  name: string;
  role: "equipe" | "administracao";
  server: string | null;
};

const INITIAL_PRODUCTION_ROSTER: readonly InitialRosterAccount[] = [
  { email: "bruno16dutra@gmail.com", name: "Administração", role: "administracao", server: null },
  { email: "asona@trf3.jus.br", name: "ALEXANDER", role: "equipe", server: "ALEXANDER" },
  { email: "bdutra@trf3.jus.br", name: "BRUNO", role: "equipe", server: "BRUNO" },
  { email: "psaffiot@trf3.jus.br", name: "SAFFIOTI", role: "equipe", server: "SAFFIOTI" },
  { email: "vterra@trf3.jus.br", name: "VANILDA", role: "equipe", server: "VANILDA" },
  { email: "gsato@trf3.jus.br", name: "GIOVANA", role: "equipe", server: "GIOVANA" },
  { email: "dportuga@trf3.jus.br", name: "DALETE", role: "equipe", server: "DALETE" },
  { email: "jveggi@trf3.jus.br", name: "JOSÉ", role: "equipe", server: "JOSÉ" },
  { email: "rodcaval@trf3.jus.br", name: "RODRIGO", role: "equipe", server: "RODRIGO" },
  { email: "delouren@trf3.jus.br", name: "DEBORA", role: "equipe", server: "DEBORA" },
  { email: "rnfreita@trf3.jus.br", name: "RENATO", role: "equipe", server: "RENATO" },
  { email: "vsneres@trf3.jus.br", name: "VICTOR", role: "equipe", server: "VICTOR" },
  { email: "ecarneir@trf3.jus.br", name: "ESTELA", role: "equipe", server: "ESTELA" },
  { email: "maresan@trf3.jus.br", name: "MARIA EDUARDA", role: "equipe", server: "MARIA EDUARDA" },
  { email: "wejsilva@trf3.jus.br", name: "WELLINGTON", role: "equipe", server: "WELLINGTON" },
];

const INITIAL_ROSTER_MARKER = "initial-production-roster-v1";
const BRUNO_ADMIN_ACCESS_ACTION = "local:bruno-single-assessoria-admin";
const BRUNO_EMAIL = "bdutra@trf3.jus.br";

async function bootstrapInitialProductionRoster() {
  let alreadyCompleted = false;
  let createdAccounts = 0;
  let createdCredentials = 0;

  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(7210467)`);
    const [marker] = await tx.select({ id: audit.id }).from(audit).where(and(
      eq(audit.environment, "production"),
      eq(audit.targetId, INITIAL_ROSTER_MARKER),
      eq(audit.action, "local:bootstrap-initial-roster"),
    )).limit(1);
    if (marker) {
      alreadyCompleted = true;
      return;
    }

    if (!process.env.ADMIN_LOGIN_PASSWORD || process.env.ADMIN_LOGIN_PASSWORD.length < 6 ||
        !process.env.TEAM_LOGIN_PASSWORD || process.env.TEAM_LOGIN_PASSWORD.length < 6 ||
        !process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 24) {
      throw Error("Os Secrets da Administração, da Equipe e da sessão precisam estar configurados.");
    }

    const existingMembers = await tx.select().from(accounts).where(eq(accounts.environment, "production"));
    const existingCredentials = await tx.select().from(credentials).where(eq(credentials.environment, "production"));
    const membersById = new Map(existingMembers.map((member) => [member.userId, member]));
    const membersByEmail = new Map(existingMembers.map((member) => [member.email.toLowerCase(), member]));
    const membersByServer = new Map(existingMembers.filter((member) => member.server).map((member) => [member.server!, member]));
    const credentialsById = new Map(existingCredentials.map((credential) => [credential.userId, credential]));
    const expectedIds = new Set(INITIAL_PRODUCTION_ROSTER.map((account) => account.email.slice(0, account.email.indexOf("@"))));

    for (const account of INITIAL_PRODUCTION_ROSTER) {
      const userId = account.email.slice(0, account.email.indexOf("@"));
      const passwordSecretKey = accountPasswordSecretKey(account.role, account.server);
      if (!passwordSecretKey) throw Error("A conta inicial não possui uma chave de senha válida.");
      const byId = membersById.get(userId);
      const byEmail = membersByEmail.get(account.email.toLowerCase());
      const byServer = account.server ? membersByServer.get(account.server) : undefined;
      const collisions = new Set([byId, byEmail, byServer].filter((member): member is typeof existingMembers[number] => Boolean(member)));

      for (const existing of collisions) {
        const legacyBrunoEditor = account.server === "BRUNO" && existing.role === "editor";
        if (existing.userId !== userId || existing.email.toLowerCase() !== account.email.toLowerCase() ||
            existing.name !== account.name || (existing.role !== account.role && !legacyBrunoEditor) ||
            existing.server !== account.server) {
          throw Error("Há uma conta de produção que conflita com a lista inicial; nenhuma conta foi alterada.");
        }
        if (existing.status !== "active") {
          throw Error("Uma conta prevista já existe, mas não está ativa; nenhuma conta foi reativada.");
        }
      }

      if (byId) {
        if (!collisions.has(byId)) throw Error("A conta existente não corresponde à lista inicial.");
      } else {
        await tx.insert(accounts).values({
          userId, environment: "production", email: account.email, name: account.name,
          role: account.role, server: account.server, status: "active", adminAccess: account.server === "BRUNO",
        });
        createdAccounts++;
      }
      if (byId && account.server === "BRUNO" && (byId.role !== "equipe" || !byId.adminAccess)) {
        await tx.update(accounts).set({ role: "equipe", adminAccess: true, updatedAt: new Date() })
          .where(and(eq(accounts.userId, userId), eq(accounts.environment, "production")));
      }

      const credential = credentialsById.get(userId);
      const legacyBrunoDedicatedCredential = account.server === "BRUNO" &&
        credential?.passwordSecretKey === "BDUTRA_LOGIN_PASSWORD";
      if (credential && (!expectedIds.has(credential.userId) ||
          (credential.passwordSecretKey !== passwordSecretKey && !legacyBrunoDedicatedCredential))) {
        throw Error("Uma credencial existente conflita com a lista inicial; nenhuma credencial foi alterada.");
      }
      if (!credential) {
        await tx.insert(credentials).values({ userId, environment: "production", passwordSecretKey });
        createdCredentials++;
      } else if (legacyBrunoDedicatedCredential && credential.passwordSecretKey !== passwordSecretKey) {
        await tx.update(credentials).set({ passwordSecretKey, failedAttempts: 0, lockedUntil: null })
          .where(and(eq(credentials.userId, userId), eq(credentials.environment, "production")));
        await tx.delete(sessions).where(and(eq(sessions.userId, userId), eq(sessions.environment, "production")));
      }

      if (!byId || !credential) {
        await tx.insert(audit).values({
          id: randomUUID(), environment: "production", actorId: "workspace-owner",
          targetId: userId, action: "local:bootstrap-initial-roster",
        });
      }
    }

    await tx.insert(audit).values({
      id: randomUUID(), environment: "production", actorId: "workspace-owner",
      targetId: INITIAL_ROSTER_MARKER, action: "local:bootstrap-initial-roster",
    });
  });

  console.log(alreadyCompleted
    ? "Provisionamento inicial de produção já concluído; nenhuma conta foi alterada."
    : `Provisionamento inicial concluído: ${createdAccounts} contas e ${createdCredentials} vínculos de senha criados.`);
}

async function grantBrunoAdminAccess(environment: "development" | "production") {
  let alreadyCompleted = false;
  let changed = false;
  const userId = BRUNO_EMAIL.slice(0, BRUNO_EMAIL.indexOf("@"));
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(7210467)`);
    const [marker] = await tx.select({ id: audit.id }).from(audit).where(and(
      eq(audit.environment, environment),
      eq(audit.targetId, userId),
      eq(audit.action, BRUNO_ADMIN_ACCESS_ACTION),
    )).limit(1);
    if (marker) {
      alreadyCompleted = true;
      return;
    }
    const [member] = await tx.select().from(accounts).where(and(
      eq(accounts.environment, environment),
      eq(accounts.email, BRUNO_EMAIL),
      eq(accounts.server, "BRUNO"),
    )).limit(1);
    if (!member || member.status !== "active" ||
        (member.role !== "equipe" && member.role !== "editor")) {
      if (environment === "production") {
        console.warn("Acesso administrativo adicional de BRUNO não aplicado; a conta não está ativa e nenhuma conta foi alterada.");
        return;
      }
      throw Error("A conta ativa vinculada ao servidor BRUNO não foi encontrada; nenhuma conta foi alterada.");
    }
    const teamPassword = process.env.TEAM_LOGIN_PASSWORD;
    const adminPassword = process.env.ADMIN_LOGIN_PASSWORD;
    if (!teamPassword || teamPassword.length < 6 || !adminPassword || adminPassword.length < 6 ||
        teamPassword === adminPassword) {
      if (environment === "production") {
        console.warn("Acesso administrativo adicional de BRUNO não aplicado; confira as senhas da Equipe e da Administração.");
        return;
      }
      throw Error("Configure as senhas da Equipe e da Administração, e mantenha-as diferentes.");
    }
    const [credential] = await tx.select().from(credentials).where(and(
      eq(credentials.userId, member.userId),
      eq(credentials.environment, environment),
    )).for("update");
    if (!credential || !["TEAM_LOGIN_PASSWORD", "BDUTRA_LOGIN_PASSWORD"].includes(credential.passwordSecretKey)) {
      if (environment === "production") {
        console.warn("Acesso administrativo de BRUNO não aplicado; a credencial precisa ser conferida.");
        return;
      }
      throw Error("A credencial da conta BRUNO precisa ser conferida.");
    }
    if (member.role !== "equipe" || !member.adminAccess ||
        credential.passwordSecretKey !== "TEAM_LOGIN_PASSWORD") {
      await tx.update(accounts).set({ role: "equipe", adminAccess: true, updatedAt: new Date() })
        .where(and(eq(accounts.userId, member.userId), eq(accounts.environment, environment)));
      await tx.update(credentials).set({
        passwordSecretKey: "TEAM_LOGIN_PASSWORD", failedAttempts: 0, lockedUntil: null,
      }).where(and(eq(credentials.userId, member.userId), eq(credentials.environment, environment)));
      await tx.delete(sessions).where(and(eq(sessions.userId, member.userId), eq(sessions.environment, environment)));
      changed = true;
    }
    await tx.insert(audit).values({
      id: randomUUID(), environment, actorId: "workspace-owner", targetId: member.userId, action: BRUNO_ADMIN_ACCESS_ACTION,
    });
  });
  console.log(alreadyCompleted
    ? `Acesso administrativo de BRUNO já foi concedido no ambiente ${environment}; nenhuma conta foi alterada.`
    : `Acesso administrativo de BRUNO ${changed ? "concedido" : "já estava ativo"} no ambiente ${environment}.`);
}

async function main() {
  const args = Object.fromEntries(process.argv.slice(2).filter((arg) => arg.startsWith("--") && arg.includes("=")).map((arg) => {
    const index = arg.indexOf("="); return [arg.slice(2, index), arg.slice(index + 1)];
  }));
  const environment = accountEnvironment();
  if (args.environment !== environment) throw Error("Informe explicitamente o mesmo ambiente de NODE_ENV.");
  if (args.action === "bootstrap-initial-roster") {
    if (environment !== "production") throw Error("O provisionamento inicial só pode ser executado no ambiente de produção.");
    await bootstrapInitialProductionRoster();
    try {
      const result = await provisionOwnerApprovedStaff("production");
      console.log(result.applied ? "Cadastro autorizado da Assessoria aplicado." : "Cadastro autorizado já processado; nenhuma conta foi alterada.");
    } catch {
      console.warn("Cadastro autorizado da Assessoria não aplicado; confira conflitos no cadastro e a senha da Equipe. A pauta não foi substituída.");
    }
    try {
      await grantBrunoAdminAccess("production");
    } catch {
      // Optional role elevation must never prevent the production API from starting.
      console.warn("Acesso administrativo adicional de BRUNO não aplicado; use o gerenciamento de contas após a publicação.");
    }
    return;
  }
  if (args.action === "grant-bruno-admin-access") {
    if (environment !== "development") throw Error("Esta ação manual só pode ser executada no ambiente de desenvolvimento.");
    await grantBrunoAdminAccess("development");
    return;
  }
  if (args.action === "provision-owner-approved-staff") {
    const result = await provisionOwnerApprovedStaff(environment);
    console.log(result.applied ? "Cadastro autorizado da Assessoria aplicado." : "Cadastro autorizado já processado; nenhuma conta foi alterada.");
    return;
  }
  if (!["create", "set-password", "sync-secrets"].includes(args.action ?? "")) throw Error("Ação inválida para o provisionamento de contas.");
  if (args.action === "sync-secrets") {
    if (!process.env.ADMIN_LOGIN_PASSWORD || process.env.ADMIN_LOGIN_PASSWORD.length < 6 ||
        !process.env.TEAM_LOGIN_PASSWORD || process.env.TEAM_LOGIN_PASSWORD.length < 6 ||
        !process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 24) {
      throw Error("Confira os Secrets da Equipe, da Administração (mínimo de 6 caracteres) e da sessão.");
    }
    let total = 0;
    await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(7210467)`);
      const members = await tx.select().from(accounts).where(eq(accounts.environment, environment));
      for (const member of members) {
        const passwordSecretKey = accountPasswordSecretKey(member.role, member.server);
        if (!passwordSecretKey) throw Error(`Não há uma chave de senha definida para o perfil ${member.role}.`);
        if (!process.env[passwordSecretKey] || process.env[passwordSecretKey]!.length < 6) {
          throw Error(`Configure ${passwordSecretKey} nos Secrets com pelo menos 6 caracteres.`);
        }
        await tx.insert(credentials).values({ userId: member.userId, environment, passwordSecretKey })
          .onConflictDoUpdate({ target: credentials.userId, set: { passwordSecretKey, failedAttempts: 0, lockedUntil: null } });
        await tx.delete(sessions).where(eq(sessions.userId, member.userId));
        total++;
      }
      await tx.insert(audit).values({ id: randomUUID(), environment, actorId: "workspace-owner", targetId: "all-accounts", action: "local:sync-secrets" });
    });
    console.log(`Segredos locais vinculados a ${total} contas no ambiente ${environment}. Nenhuma senha foi exibida.`);
    return;
  }
  const email = args.email?.trim().toLowerCase();
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) throw Error("Informe um e-mail válido.");
  if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 24) throw Error("Configure SESSION_SECRET com pelo menos 24 caracteres.");
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(7210467)`);
    const [existing] = await tx.select().from(accounts).where(and(eq(accounts.environment, environment), eq(accounts.email, email)));
    if (args.action === "set-password" && !existing) throw Error("A conta precisa existir antes de trocar a senha.");
    const userId = existing?.userId ?? email.slice(0, email.indexOf("@"));
    const [identityCollision] = await tx.select({ userId: accounts.userId })
      .from(accounts).where(eq(accounts.userId, userId));
    if (identityCollision && identityCollision.userId !== existing?.userId) {
      throw Error("O identificador derivado do e-mail já pertence a outra conta.");
    }
    if (args.action === "create") {
      const role = args.role;
      const server = args.server || null;
      if (!["equipe", "administracao"].includes(role ?? "")) throw Error("Informe --role=equipe ou --role=administracao.");
      const passwordSecretKey = accountPasswordSecretKey(role!, server);
      if (!passwordSecretKey) throw Error("Não há uma chave de senha definida para esse perfil e servidor.");
      if (!process.env[passwordSecretKey] || process.env[passwordSecretKey]!.length < 6) throw Error(`Configure ${passwordSecretKey} nos Secrets com pelo menos 6 caracteres.`);
      if ((role === "equipe" && !server) || (server && !(await loadTeamRoster()).includes(server))) throw Error("Vincule a conta a um servidor da lista cadastrada.");
      const [hasPassword] = await tx.select().from(credentials).where(eq(credentials.userId, userId));
      if (hasPassword) throw Error("Esta conta já tem senha local. Use set-password para alterá-la.");
      await tx.insert(accounts).values({ userId, environment, email, name: server || existing?.name || "Administração",
        role: role!, server, status: "active" }).onConflictDoUpdate({ target: accounts.userId,
        set: { role, server, status: "active", updatedAt: new Date() } });
    }
    const targetRole = args.action === "create" ? String(args.role ?? "") : existing!.role;
    const targetServer = args.action === "create" ? args.server ?? null : existing!.server;
    const passwordSecretKey = accountPasswordSecretKey(targetRole, targetServer);
    if (!passwordSecretKey) throw Error("Não há uma chave de senha definida para esse perfil e servidor.");
    if (!process.env[passwordSecretKey] || process.env[passwordSecretKey]!.length < 6) throw Error(`Configure ${passwordSecretKey} nos Secrets com pelo menos 6 caracteres.`);
    await tx.insert(credentials).values({ userId, environment, passwordSecretKey })
      .onConflictDoUpdate({ target: credentials.userId, set: { passwordSecretKey, failedAttempts: 0, lockedUntil: null } });
    await tx.delete(sessions).where(eq(sessions.userId, userId));
    await tx.insert(audit).values({ id: randomUUID(), environment, actorId: "workspace-owner", targetId: userId, action: `local:${args.action}` });
  });
  console.log(`Conta local configurada no ambiente ${environment}. Nenhuma senha foi exibida.`);
}
main().catch((error) => {
  // SQL exceptions can carry parameters; never print them or the environment.
  console.error(error instanceof Error && !("query" in error) ? error.message : "Não foi possível configurar a conta. Confira vínculos e Secrets.");
  process.exitCode = 1;
}).finally(() => pool.end());

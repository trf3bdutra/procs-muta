import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const source = readFileSync(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");

test("as telas e o atalho do calendário operacional não são montados", () => {
  assert.doesNotMatch(source, /function injectCal\(|data-cmtx-cal|mini-prev|mini-next|mini-day/);
  assert.doesNotMatch(source, /<div class="cal" role="group" aria-label="Calendário do gabinete"/);
  assert.doesNotMatch(source, /\{ key: 'cal', label: 'Calendário'/);
  assert.doesNotMatch(source, /\['cal', 'day'\]\.includes\(root\.dataset\.cmtExpandedPanel\)/);
  assert.match(source, /stripCalendarEntryPoints/);
  assert.match(source, /PautaPublicCalendar/);
  assert.match(source, /#alt-rp-tab,#alt-rp-scrim/);
  assert.doesNotMatch(source, /data-sv="cal"|AltCal\.open\(\)/);
  const legacyCalendar = source.slice(source.indexOf("const RP = (() => {"), source.indexOf("function stripCalendarEntryPoints"));
  assert.match(legacyCalendar, /function toggle\(\) \{ return false; \}/);
  assert.match(legacyCalendar, /function show\(\) \{ return false; \}/);
  assert.doesNotMatch(source, /RP\.render\(\)|RP\.toggle\(\)|e\.code === 'KeyC'/);
  assert.doesNotMatch(source, /\{ key: 'day', label: 'Meu dia'/);
  assert.match(source, /#alt-side#alt-side#alt-side#alt-side#alt-side#alt-side>\.as-body\{\s*flex:1 1 auto!important;min-height:0!important;overflow-y:auto!important/);
  assert.match(source, /D\.getElementById\('cmt-side-logo'\)\?\.remove\(\)/);
  assert.doesNotMatch(source, /#cmt-calendar-dock[^\n]*\{[^\n]*(?:position|display|bottom)/);
  assert.doesNotMatch(source, /#cmt-side-logo[^\n]*\{[^\n]*(?:position|display|bottom)/);
});

test("o rodapé abre o painel por um só botão de ícone, sem botão duplicado na esquerda", () => {
  /* O rodapé passou a ter um botão de ícone único (`painel`) no lugar dos três
     lançadores separados; Meu dia, Notificações e Pendências são caixas dentro do painel. */
  assert.match(source, /button\.dataset\.centerLaunch='painel'/);
  assert.doesNotMatch(source, /\['day','notif','pend'\]\.forEach\(key=>/);
  assert.doesNotMatch(source, /\['day','notif','cal','pend'\]\.forEach\(key=>/);
  /* `painel` é o único lançador criado no arquivo: nenhum outro valor de data-center-launch nasce */
  assert.doesNotMatch(source, /centerLaunch='(?!painel')/);
  /* o botão único alterna: abre quando fechado, fecha quando aberto */
  assert.match(source, /if\(key==='painel'\)\{[\s\S]{0,200}closePanel/);
  /* a nota da rota fecha o rodapé, à direita */
  assert.match(source, /nota\.className='cmt-foot-rota'/);
  /* O sino do rodapé antigo (`.as-foot2 > .as-tools`) fica coberto pela regra abaixo. O sino que
     continua à vista no pé da barra é esse mesmo nó, movido para a faixa `.as-brand` pelo v178, e
     abre a caixa Notificações do painel do rodapé — não é um segundo lançador, e por isso o teste
     não exige que ele suma; exige que ele seja único e que ninguém crie outro. */
  assert.match(source, /#alt-side#alt-side#alt-side#alt-side#alt-side#alt-side :is\(\.as-tools,\.as-brand\)>\[data-alt="bell"\]\{display:none!important\}/);
  assert.match(source, /<div class="as-tools">[\s\S]{0,600}?<button type="button" class="as-bell" data-alt="bell"/);
  assert.match(source, /brand\.appendChild\(bell\)/);
  assert.equal(source.match(/class="as-bell" data-alt="bell"/g).length, 1, "o sino é escrito no molde uma vez só");
  assert.match(source, /brand\.querySelectorAll\(':scope > \.as-bell'\)\.forEach\(function \(x\) \{ if \(x !== bell\) x\.remove\(\); \}\)/);
});

test("Meu dia sai do rodapé, que recebe o calendário integrado sem reativar o antigo", () => {
  assert.match(source, /function ensureCenterPanelViews\(shell\)/);
  assert.match(source, /\{ key: 'painel', label: 'Visão geral'/);
  assert.doesNotMatch(source, /\{ key: 'day', label: 'Meu dia'/);
  assert.match(source, /data-daily-calendar/);
  assert.match(source, /daily-workspace\.js/);
  assert.match(source, /data-act="view-orders"[^>]*>Ordem do dia/);
  assert.match(source, /data-act="view-myday"[^>]*>Meu dia/);
  const moduleStart = source.indexOf('<script id="cmt-v265-cal">');
  const moduleEnd = source.indexOf("</script>", moduleStart);
  const orderDay = source.slice(moduleStart, moduleEnd);
  assert.ok(moduleStart >= 0 && moduleEnd > moduleStart, "módulo da Ordem do dia existe");
  assert.doesNotMatch(orderDay, /function renderCal|function calFoot|function renderDay|data-act="view-calendar"|class="cal"|data-r="cal"/);
  assert.doesNotMatch(source, /\{ k: 'cal', t: 'Calendário', src:/);
  assert.match(source, /root\.classList\.contains\('cmt-center-panels-open'\)[\s\S]*?root\.dataset\.cmtExpandedPanel/);
  assert.match(source, /attributeFilter:\['data-cmtExpandedPanel'\]/);
});

test("a base da barra esquerda não guarda resto do frame antigo", () => {
  /* A pílula de atalhos do servidor (`.v225-dock`, com a Mesa de trabalho e o Ementário) e a
     cápsula `.v225-caps` ocupavam a faixa que hoje é do calendário. A Mesa virou botão sobre o
     Prontuário e o Ementário é item da seção APOIO; as duas saíram do arquivo — regra, criação
     e medida —, não foram escondidas por CSS. */
  assert.doesNotMatch(source, /v225-dock/);
  assert.doesNotMatch(source, /v225-caps/);
  /* ninguém mais reserva altura na base da barra para a pílula */
  assert.doesNotMatch(source, /--as-pad-bottom/);
  assert.doesNotMatch(source, /--pa-dk-pb/);
  assert.doesNotMatch(source, /--v225-gfp/);
  /* o Ementário entra só pela navegação: um registro NAV e nenhum botão avulso que o duplique */
  assert.match(source, /\{ id: 'ementario', label: 'Ementário'/);
  assert.doesNotMatch(source, /class="cmt-ementario-dock"/);
  assert.doesNotMatch(source, /data-cmt-ementario="open"/);
  /* quem acende o item da navegação é o paintNav() da barra, sozinho */
  assert.doesNotMatch(source, /marcarNav/);
  assert.match(source, /li\.classList\.toggle\('is-active', !!n\.active\?\.\(\)\)/);
});

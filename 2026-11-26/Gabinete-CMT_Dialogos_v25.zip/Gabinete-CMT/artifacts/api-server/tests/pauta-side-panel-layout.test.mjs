import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const css = readFileSync(
  new URL("../src/protected/cmt-pauta-side-panel.css", import.meta.url),
  "utf8",
);

test("Pauta keeps the prontuário docked beside the process list", () => {
  assert.match(css, /grid-template-areas:"list panel"/);
  assert.match(css, /#pq-side-panel\{grid-area:panel;position:sticky;top:12px/);
  assert.match(css, /#controle-pauta-root \.pq-side-list\{grid-area:list;/);
  assert.match(css, /margin-left:0!important/);
});

test("the narrow layout stacks the process list before the prontuário", () => {
  assert.match(css, /grid-template-areas:"list" "panel"/);
  assert.match(css, /#pq-side-panel\{height:min\(52dvh/);
});

test("the fixed Pauta panel has a visible loading/empty-state surface", () => {
  assert.match(css, /data-collapsed="false"\] #pq-side-body\{display:flex;flex-direction:column\}/);
  assert.match(css, /#pq-side-status\{display:grid;flex:1 1 auto/);
  assert.match(css, /#pq-side-status\[hidden\]\{display:none!important\}/);
});

test("the dock wrapper does not add a second frame around the prontuário", () => {
  assert.match(
    css,
    /data-collapsed="false"\] #pq-side-panel\{\s*padding:0!important;\s*border:0!important;\s*border-radius:0!important;\s*background:transparent!important;/,
  );
  assert.match(
    css,
    /#alt-qp#alt-qp#alt-qp\{\s*padding:8px 10px!important;\s*border:1px solid #d5dfd1!important;\s*border-radius:12px!important;/,
  );
});

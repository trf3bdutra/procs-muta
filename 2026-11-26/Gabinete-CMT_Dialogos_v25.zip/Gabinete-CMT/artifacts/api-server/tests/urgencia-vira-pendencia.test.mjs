import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const source = readFileSync(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");

test("urgência registrada nas Monocráticas abre pendência no quadro", () => {
  /* Espelha a intercorrência, que já fazia isso pela incPend. */
  assert.match(source, /function urgPend\(h,x\)\{/);
  assert.match(source, /kind:'urgencia',origin:'urgencia'/);
  assert.match(source, /list\.unshift\(issue\);x\.pendenciaId=issue\.id;/);

  /* O vínculo precisa sobreviver à gravação: cleanLim reconstrói o objeto campo a campo. */
  assert.match(source, /function cleanLim\(x\)\{return \{id:String\(x\.id\|\|uid\(\)\),linkedMonoId:String\(x\.linkedMonoId\|\|''\),pendenciaId:String\(x\.pendenciaId\|\|''\),/);

  /* Prazo e responsável do pedido viram prazo e responsável da pendência. */
  assert.match(source, /dueDate:String\(x\.prazo\|\|''\)/);
  assert.match(source, /assignees:x\.responsavel\?\{\[String\(x\.responsavel\)\]:true\}:\{\}/);

  /* Decidida a urgência, a pendência conclui e registra o resultado. */
  assert.match(source, /if\(concluida&&ex\.stage!=='done'\)\{ex\.stage='done';ex\.status='done';/);
  assert.match(source, /Urgência decidida: \$\{String\(x\.resultado\|\|''\)\.trim\(\)\|\|'sem resultado registrado'\}/);
  /* Pedido que já chega decidido não abre acompanhamento. */
  assert.match(source, /if\(concluida\)return null;/);

  /* A chamada fica no caminho de gravação da urgência, e o quadro é avisado. */
  assert.match(source, /const linked=kind==='lim'\?syncLimToMono\(h,saved,now\):null;if\(kind==='lim'\)urgPend\(h,saved\);/);
  assert.match(source, /window\.PautaPendencias\?\.checkNotifications\?\.\(\);window\.PautaPendencias\?\.decorateFooter\?\.\(h\);/);
  assert.match(source, /monoRevItems,urgPend,queueMonoUrgency\};/);
});

test("Pendências tem uma aba própria e não aparece como cópia na Visão geral", () => {
  assert.match(source, /\{ key: 'pend', label: 'Pendências', id: 'cmt-center-tab-pend' \}/);
  assert.match(source, /window\.PautaPendencias\.mount\(state\.content\)/);
  const start = source.indexOf("function painelHTML() {");
  const end = source.indexOf("\n  let cpSeg", start);
  assert.ok(start >= 0 && end > start, "a Visão geral deve ter um limite de extração estável");
  const overview = source.slice(start, end);
  assert.doesNotMatch(overview, /Pendências|Urgências e vencidas|Indicadores de pendência/);
});

test("o detalhe do cartão de Pendências cabe no painel e não corta os status", () => {
  assert.match(source, /width:min\(620px,78%\)!important/);
  assert.match(source, /grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important;gap:6px!important/);
  assert.match(source, /@media\(max-width:700px\)[\s\S]*?grid-template-columns:repeat\(2,minmax\(0,1fr\)\)!important/);
});

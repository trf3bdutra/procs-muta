import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";
import test from "node:test";
import {
  prepareDialogDocument,
  preparePautaQuickSearch,
  prepareSinglePautaExpansion,
} from "../src/lib/gabcmt-dialog-document.ts";

const html = fs.readFileSync(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");

function enhancementSource(document) {
  const tag = document.match(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)?.find((item) =>
    /\bid=["']cmt-mod-enhancements["']/.test(item),
  );
  assert.ok(tag, "Pauta enhancement data block exists");
  const payload = tag.match(/<script\b[^>]*>([\s\S]*?)<\/script>/)?.[1];
  return JSON.parse(payload);
}

test("native Pauta cards expose only one expanded process at a time", () => {
  const start = html.indexOf("    toggleExpandedRow(i) {");
  const end = html.indexOf("\n    isOpen(x)", start);
  assert.ok(start >= 0 && end > start);
  const method = html.slice(start, end).trim();
  const page = vm.runInNewContext(`({${method}, isOpen(x) { return this.expanded.has(x.i); }})`);
  page.expanded = new Set();
  page.collapsed = new Set([99]);
  page.expandAll = true;

  assert.equal(page.isOpen({ i: 1 }), false, "cards begin collapsed");
  page.toggleExpandedRow(1);
  assert.deepEqual(Array.from(page.expanded), [1]);
  assert.equal(page.expandAll, false);
  page.toggleExpandedRow(2);
  assert.deepEqual(Array.from(page.expanded), [2], "opening another card replaces the prior one");
  assert.equal(page.collapsed.size, 0);
  page.toggleExpandedRow(2);
  assert.equal(page.expanded.size, 0, "clicking the open card closes it");
});

test("compact list expansion clears the previously open process", () => {
  const original = enhancementSource(html);
  const prepared = prepareSinglePautaExpansion(original);
  assert.equal(
    prepared.split("expandedListItems.clear();\n      expandedListItems.add(key);").length - 1,
    1,
  );
  assert.ok(prepared.includes("const expanded = viewMode === 'list' && !!key"));
});

test("the delivered Pauta enhancement contains the single-card rule", () => {
  const prepared = prepareDialogDocument(html);
  const source = enhancementSource(prepared);
  assert.ok(source.includes("expandedListItems.clear();\n      expandedListItems.add(key);"));
  assert.equal(source.split("expandedListItems.clear();\n      expandedListItems.add(key);").length - 1, 1);
});

test("quick item/process search is integrated into the main bar and survives Pauta rerenders", () => {
  const source = enhancementSource(html);
  const prepared = preparePautaQuickSearch(source);
  assert.doesNotThrow(() => new vm.Script(prepared), "transformed enhancement remains valid JavaScript");
  assert.ok(prepared.includes("window.__pautaQuickJumpElement = jump;"));
  assert.ok(prepared.includes("const searchBar = app?.querySelector('.pc-filter-card .pq-search-main');"));
  assert.ok(prepared.includes("if (jump.parentElement !== searchBar) searchBar.appendChild(jump);"));
  assert.ok(prepared.includes("quickSearchObserver.observe(app, { childList: true, subtree: true });"));
  assert.ok(prepared.includes("if (searchBarAdded) queueMicrotask(attachQuickJump);"));
  assert.ok(prepared.includes("document.addEventListener('input', (event) => {"));
  assert.ok(prepared.includes("jumpToItem();\n    }, 260);"));
  assert.doesNotMatch(prepared, /data-pauta-jump>Ir<\/button>/);
  assert.doesNotMatch(prepared, /target\.closest\('\[data-pauta-jump\]'\)/);
  assert.ok(prepared.includes("#controle-pauta-root .pc-filter-card .pq-filter-workspace>.pc-active-filters{order:1!important;"));
  assert.ok(prepared.includes(".pc-filter-card .pq-search-main"));
  assert.ok(prepared.includes(".pq-search-main>.pauta-quick-jump"));
  assert.ok(!prepared.includes(">.pc-heading>.pauta-quick-jump"));
  assert.ok(prepared.includes(">.cmt-fb2{position:relative!important"));
});

test("the prepared page syncs the quick-search focus from its new location", () => {
  const prepared = prepareDialogDocument(html);
  assert.ok(prepared.includes("D.querySelector('#controle-pauta-root .pauta-quick-jump')"));
  assert.ok(!prepared.includes("#pauta-global-dock>.gd-foot[data-page-footer=\"pauta\"] .pauta-quick-jump"));
});

test("the old expand-all control cannot be recreated", () => {
  assert.doesNotMatch(html, /className='c130-exp'/);
  assert.match(html, /function todos\(btn\)\{recolherTodos\(\);void btn;\}/);
  assert.match(html, /pg\.expandAll=false/);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../src/protected/gabcmt.html',import.meta.url),'utf8');
const script=source.match(/<script id="cmt-dialog-surfaces-js">([\s\S]*?)<\/script>/)[1];
function setup(){
 const events={},devents={};let focused=0,opened='',warnings=[];
 const opener={isConnected:true,focus(){focused++}};
 const dialog={open:false,classList:{remove(){}},removeAttribute(){},setAttribute(){},addEventListener(k,f){devents[k]=f},showModal(){this.open=true},close(){this.open=false;devents.close?.()}};
 const document={activeElement:opener,body:{},getElementById(id){return id==='pauta-public-profile'?dialog:null},querySelector(){return null}};
 const window={PautaApp:{team:{members:[{id:'1',name:'BRUNO',aliases:['Bruno Dutra']},{id:'2',name:'DALETE'}]},notify(t){warnings.push(t)}},CMT_AUTH_SESSION:{server:'BRUNO'},CMTNativeProfile:{open(n){opened=n;dialog.showModal()}},addEventListener(k,f){events[k]=f}};
 vm.runInNewContext(script,{window,document,Element:class{},MutationObserver:class{observe(){}}});
 return {window,dialog,get opened(){return opened},get focused(){return focused},warnings};
}
test('profile resolves authenticated member and restores focus without workspace/navigation access',()=>{
 const c=setup();assert.equal(c.window.CMTProfileDialog.open(),true);assert.equal(c.opened,'BRUNO');assert.equal(c.dialog.open,true);
 c.window.CMTProfileDialog.close();assert.equal(c.dialog.open,false);assert.equal(c.focused,1);
});
test('named profiles reuse the native editor; unknown identity does not invent a profile',()=>{
 const c=setup();assert.equal(c.window.CMTProfileDialog.open('DALETE'),true);assert.equal(c.opened,'DALETE');
 c.window.CMTProfileDialog.close();assert.equal(c.window.CMTProfileDialog.open('desconhecido'),false);assert.equal(c.dialog.open,false);assert.equal(c.warnings.length,1);
});
test('page entry points are modal-only and compact/page bridge is removed',()=>{
 assert.match(source,/function abre\(slug\)\{return window.CMTProfileDialog\?\.open\(slug\)/);
 assert.doesNotMatch(source,/<script id="cmt-v193-perfil">/);
 const ir=source.slice(source.indexOf('  function ir(txt, opt)'),source.indexOf('  function postaPai(r)'));
 assert.ok(ir.indexOf("r.page === 'servidor'")<ir.indexOf('escreve(r, true)'));
});
test('notifications use native modal lifecycle and clones never inherit open state',()=>{
 assert.match(source,/centerPanelNode = doc.createElement\('dialog'\)/);
 assert.match(source,/if \(!shell.open\) shell.showModal\(\)/);
 assert.match(source,/if \(shell.open\) shell.close\(\)/);
 assert.match(source,/next.removeAttribute\('open'\)/);
});
test('all executable inline scripts and embedded enhancements parse',()=>{
 for(const m of source.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)){
   if(/src=|application\/octet-stream/.test(m[1]))continue;
   if(/application\/json/.test(m[1])){const data=JSON.parse(m[2]);if(m[1].includes('cmt-mod-enhancements'))assert.doesNotThrow(()=>new vm.Script(data));continue;}
   assert.doesNotThrow(()=>new vm.Script(m[2]),m[1]);
 }
});

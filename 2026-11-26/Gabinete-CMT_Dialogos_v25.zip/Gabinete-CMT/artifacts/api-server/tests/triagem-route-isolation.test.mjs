import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";
import test from "node:test";

const source = readFileSync(new URL("../src/protected/cmt-triagem-workspace.js", import.meta.url), "utf8");
function boot(path) {
  const listeners = {}, opened = [];
  let removed = 0;
  const view = { querySelectorAll: () => [{ remove: () => removed++ }] };
  const document = {
    documentElement: { dataset: { cmtxView: "triagem" } },
    getElementById: () => view,
    addEventListener: () => {},
  };
  const window = {
    parent: { location: { pathname: path } },
    location: { origin: "https://gabinete.example" },
    CMTViews: { active: () => "", open: page => opened.push(page) },
    addEventListener: (name, listener) => { listeners[name] = listener; },
  };
  vm.runInNewContext(source, {
    window, document,
    MutationObserver: class { observe() {} disconnect() {} },
  });
  return { window, document, listeners, opened, removed: () => removed };
}
test("o módulo só atua em /tria, sem efeitos nas demais páginas", () => {
  for (const path of ["/", "/gabinete", "/controle-de-pauta", "/serv-user", "/sessions", "/triagem"]) {
    const state = boot(path);
    assert.equal(state.window.CMTTriagemWorkspace, undefined);
    assert.equal(state.listeners.message, undefined);
    assert.equal(state.removed(), 0);
  }
});
test("/tria abre Triagem, remove abas antigas e ignora pedidos de Sessões", () => {
  const state = boot("/tria");
  assert.equal(state.window.CMTTriagemWorkspace.path, "/tria");
  assert.equal(state.document.title, "Triagem — GabCMT");
  assert.equal(state.removed(), 1);
  const event = {
    origin: state.window.location.origin,
    source: state.window.parent,
    data: { type: "pauta:workspace-state", page: "sessions" },
  };
  state.listeners.message(event);
  assert.deepEqual(state.opened, []);
  event.data.page = "triagem";
  state.listeners.message(event);
  assert.deepEqual(state.opened, ["triagem"]);
  assert.doesNotMatch(source, /PautaSessionHub|PautaCalendario|CMTProntuario|data-tg-workspace-tab/);
});

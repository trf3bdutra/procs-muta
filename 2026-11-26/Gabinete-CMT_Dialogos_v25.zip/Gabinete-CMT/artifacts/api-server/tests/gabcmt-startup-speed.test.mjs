import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";
import test from "node:test";
import { prepareStartupDocument } from "../src/lib/gabcmt-startup-document.ts";
import { prepareGabcmtFeatureDocument } from "../src/lib/gabcmt-feature-modules.ts";

const html = fs.readFileSync(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");
const prepared = prepareStartupDocument(html);
function boot(path) {
  const classes = new Set();
  const timers = [];
  const window = { location: { pathname: path } };
  window.parent = window;
  const source = prepared.match(/<script\b[^>]*id="cmt-route-boot"[^>]*>([\s\S]*?)<\/script>/)[1];
  vm.runInNewContext(source, {
    window, location: window.location,
    document: { documentElement: { classList: { add: c => classes.add(c), remove: c => classes.delete(c) } } },
    setTimeout: (fn, delay) => timers.push({ fn, delay }),
  });
  return { classes, timers };
}

test("application pages never wait for the public-profile visibility timeout", () => {
  for (const path of ["/", "/gabinete", "/pauta", "/mono", "/controle-de-pauta", "/controle-de-decisoes", "/tria", "/sessions", "/serv-user", "/cm", "/cmt", "/datajud-triagem"]) {
    const result = boot(path);
    assert.equal(result.classes.has("cmt-route-srv"), false, path);
    assert.equal(result.timers.some(t => t.delay === 30000), false, path);
  }
});

test("public profiles retain their anti-flash guard", () => {
  const result = boot("/perfil-teste");
  assert.equal(result.classes.has("cmt-route-srv"), true);
  assert.equal(result.timers[0].delay, 30000);
  result.timers[0].fn();
  assert.equal(result.classes.has("cmt-route-srv"), false);
  assert.equal(prepareStartupDocument(prepared), prepared, "preparation is idempotent");
});

test("all extracted features preload in the head without changing execution order", () => {
  const result = prepareGabcmtFeatureDocument(html);
  const head = result.html.slice(0, result.html.indexOf("</head>"));
  assert.ok(Object.keys(result.assets).length > 10);
  for (const [key, asset] of Object.entries(result.assets)) {
    const url = `/api/app/gabcmt-feature-modules/${key}?v=${asset.etag}`;
    const as = asset.contentType === "text/css" ? "style" : "script";
    assert.ok(head.includes(`<link rel="preload" as="${as}" href="${url}">`), key);
    const tag = as === "style"
      ? `<link id="${key.slice(0, -4)}" rel="stylesheet" href="${url}">`
      : `<script id="${key.slice(0, -3)}" src="${url}"></script>`;
    if (key !== "cmt-operational-center.js") assert.ok(result.html.includes(tag), key);
  }
  assert.doesNotMatch(result.html, /<script[^>]*(?:async|defer)[^>]*gabcmt-feature-modules/);
});

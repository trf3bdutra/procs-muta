import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";
import vm from "node:vm";
import { prepareGabcmtUiResponsivenessDocument } from "../src/lib/gabcmt-ui-responsiveness.ts";

const html = fs.readFileSync(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");
const transformed = prepareGabcmtUiResponsivenessDocument(html);
const script = (id) => {
  const escaped = id.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return transformed.match(new RegExp(`<script\\b[^>]*\\bid="${escaped}"[^>]*>([\\s\\S]*?)<\\/script>`))[1];
};

test("sidebar collapse restores the left day panels using width changes, not polling", () => {
  const source = script("cmtx-v37-rrail-script");
  assert.match(source, /cmt-left-day-width-observer/);
  assert.match(source, /new ResizeObserver\(syncDayWidth\)/);
  assert.match(source, /day\?\.classList\.toggle\('is-narrow', narrow\)/);
  assert.match(source, /team\?\.classList\.toggle\('is-narrow', narrow\)/);
});

test("settings lifecycle updates are scoped to open settings and user changes", () => {
  const source = script("cmt-v247-cfg-acompanhamento");
  assert.match(source, /cmt-settings-event-refresh/);
  assert.match(source, /cfgStateObserver\.observe\(D\.body,\{attributes:true,attributeFilter:\['class'\]\}\)/);
  assert.match(source, /cfgRailObserver\.disconnect\(\)/);
  assert.doesNotMatch(source, /setInterval\(/);
});

test("the shared shell and rules panel no longer poll on sub-second intervals", () => {
  assert.doesNotMatch(script("alt-shell-script"), /setInterval\(\(\) => \{ const version = currentRpDataVersion\(\)/);
  assert.match(script("alt-shell-script"), /addEventListener\('pauta:updated', scheduleShellSync\)/);
  assert.doesNotMatch(script("cmt-v253-cg-regras"), /setInterval\(function \(\) \{ agenda\(\); \}, 1200\)/);
  assert.match(script("cmt-v253-cg-regras"), /cmt-rules-event-refresh/);
});

test("all transformed scripts parse and the response transform is idempotent", () => {
  for (const id of ["alt-shell-script", "cmtx-v37-rrail-script", "cmt-v247-cfg-acompanhamento", "cmt-v253-cg-regras"]) {
    assert.doesNotThrow(() => new vm.Script(script(id)), id);
  }
  assert.equal(prepareGabcmtUiResponsivenessDocument(transformed), transformed);
});

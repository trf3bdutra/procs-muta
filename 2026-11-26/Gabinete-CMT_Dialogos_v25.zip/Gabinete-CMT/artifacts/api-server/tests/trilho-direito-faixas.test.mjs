import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const source = readFileSync(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");

test("o trilho recolhido não desenha o miolo por trás das faixas", () => {
  /* O trilho direito virou faixa permanente de 58px: no alto as descargas, na base a
     Administração, a marca do TRF3 na ponta. O miolo herdado (`.rr-slot`, com a frase
     "Selecione um painel nos botões abaixo") é de quando o trilho ainda abria em painel.
     O bloco `cmt-center-panels-style` o desliga com `display:none!important`. */
  assert.match(source, /html\.alt-on\.cmtx-rr-on #cx-rrail#cx-rrail>\.rr-top,html\.alt-on\.cmtx-rr-on #cx-rrail#cx-rrail>\.rr-slot,html\.alt-on\.cmtx-rr-on #cx-rrail#cx-rrail>\.rr-foot\{display:none!important\}/);

  /* O bloco `cmt-frame-stability-css` só governa o trilho ABERTO. A regra do miolo precisa do
     mesmo `:not(.cmtx-rr-min)` que as irmãs dela já trazem — sem ele vence por ter três ids,
     o miolo reaparece e a frase atravessa as faixas, por baixo dos botões. */
  const estabilidade = source.slice(
    source.indexOf('<style id="cmt-frame-stability-css">'),
    source.indexOf("</style>", source.indexOf('<style id="cmt-frame-stability-css">')),
  );
  assert.ok(estabilidade.length > 0, "o bloco de estabilidade do frame deve existir");
  assert.match(estabilidade, /html\.alt-on\.cmtx-rr-on:not\(\.cmtx-rr-min\) #cx-rrail#cx-rrail#cx-rrail \.rr-slot\{/);
  assert.doesNotMatch(estabilidade, /html\.alt-on\.cmtx-rr-on #cx-rrail#cx-rrail#cx-rrail \.rr-slot\{/);

  /* Nenhuma regra do arquivo pode voltar a acender o miolo no trilho recolhido.
     A varredura é linear: corta em "}" e olha só os pedaços que citam o miolo. */
  for (const pedaco of source.split("}")) {
    const abre = pedaco.lastIndexOf("{");
    if (abre < 0) continue;
    const seletor = pedaco.slice(0, abre);
    if (!seletor.includes(".rr-slot")) continue;
    const corpo = pedaco.slice(abre + 1);
    /* só pesa quem traz !important: sem ele o `display:none!important` vence sempre */
    if (!/display\s*:\s*(?!none)[a-z-]+\s*!important/.test(corpo)) continue;
    assert.ok(
      seletor.includes(":not(.cmtx-rr-min)"),
      "regra que acende o miolo sem excluir o trilho recolhido: " + seletor.trim().slice(-160),
    );
  }
});

test("a base do trilho não recria a marca/presença e remove o botão de Sessões", () => {
  const inicio = source.indexOf("function railToday(rail)");
  const fim = source.indexOf("function railHead()", inicio);
  assert.ok(inicio >= 0 && fim > inicio, "a rotina da base do trilho deve existir");
  const baseTrilho = source.slice(inicio, fim);
  assert.match(baseTrilho, /getElementById\('v2-rr-today'\)[\s\S]*?\.remove\(\)/);
  assert.doesNotMatch(baseTrilho, /marca-trf3|v2-rr-online|railOnline|fetch\(/);
  assert.doesNotMatch(source, /ses\.title='Controle de Sessões'|W\.CMTRotas\?\.ir\('sessoes'\)|RR_IC\.ses/);
  assert.match(source, /settings&&settings\.parentElement!==stack\)stack\.appendChild\(settings\)/);
  assert.match(source, /if\(settings&&settings\.hidden!==!adm\)settings\.hidden=!adm/);
  assert.match(source, /if\(stack\.hidden!==!adm\)stack\.hidden=!adm/);
  assert.match(source, /stack\.querySelectorAll\('\[data-rr-sessoes\]'\)\.forEach\(button=>button\.remove\(\)\)/);
});

test("Configurações Globais usa o botão circular do grupo inferior", () => {
  assert.match(
    source,
    /cmt-right-library-tools>#v2-rr-mintag\{[^}]*width:32px!important[^}]*height:32px!important[^}]*border-radius:50%!important/,
  );
  assert.match(
    source,
    /D\.querySelectorAll\('\[data-app="config-dialog"\],\[data-cmt-cfg-nav\],#alt-side \[data-alt="cfg"\]/,
  );
});

test("a marca e o título do Gabinete fecham o crachá, sem sair da barra", () => {
  assert.match(source, /#cmt-profile-dock>\.cmt-crach-st\{[^}]*grid-row:3/);
  assert.match(source, /#cmt-profile-dock>\.as-session\{[^}]*grid-row:4/);
  assert.match(source, /#cmt-profile-dock>\.v2-logo\{[^}]*grid-row:5/);
  assert.match(source, /if\(logo&&logo!==group\.lastElementChild\)group\.appendChild\(logo\)/);
  assert.match(source, /if \(dock && \(logo\.parentElement !== dock \|\| logo !== dock\.lastElementChild\)\) dock\.appendChild\(logo\)/);
  assert.match(source, /html\.alt-collapsed #cmt-profile-dock>\.v2-logo,html\.cmt-srv-on #cmt-profile-dock>\.v2-logo\{grid-row:3/);
});

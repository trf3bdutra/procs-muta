import assert from "node:assert/strict";
import test from "node:test";
import {
  createSettingsSessionToken,
  verifySettingsSessionToken,
} from "../src/lib/pauta-settings-session.ts";

test("global settings unlock is bound to the authenticated navigation session", () => {
  const now = 1_800_000_000_000;
  const sessionExpiry = Math.floor(now / 1000) + 60 * 60 * 8;
  const token = createSettingsSessionToken("test-session-secret", "session-a", sessionExpiry, now);

  assert.equal(
    verifySettingsSessionToken("test-session-secret", token, "session-a", sessionExpiry, now),
    true,
  );
  assert.equal(
    verifySettingsSessionToken("test-session-secret", token, "session-b", sessionExpiry, now),
    false,
  );
  assert.equal(
    verifySettingsSessionToken("different-secret", token, "session-a", sessionExpiry, now),
    false,
  );
  assert.equal(
    verifySettingsSessionToken(
      "test-session-secret",
      token,
      "session-a",
      sessionExpiry,
      sessionExpiry * 1000,
    ),
    false,
  );
  assert.equal(
    verifySettingsSessionToken(
      "test-session-secret",
      token,
      "session-a",
      sessionExpiry - 1,
      now,
    ),
    false,
  );
});

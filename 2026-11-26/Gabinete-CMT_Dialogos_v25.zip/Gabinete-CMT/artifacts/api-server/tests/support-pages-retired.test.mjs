import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";
import test from "node:test";
import { prepareDialogDocument } from "../src/lib/gabcmt-dialog-document.ts";
import { prepareGabcmtDataDocument } from "../src/lib/gabcmt-data-modules.ts";

const source = readFileSync(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");
const prepared = prepareDialogDocument(prepareGabcmtDataDocument(source).html);

test("standalone Ementário, Protocolo, and Repositório pages are removed", () => {
  assert.doesNotMatch(prepared, /id:\s*'(?:ementario|diretrizes|repertorio)',\s*label:/);
  assert.doesNotMatch(prepared, /CMTDiretrizes|CMTRepertorio|CMTEmentario/);
  assert.doesNotMatch(prepared, /\/api\/app\/referenciais/);
  assert.doesNotMatch(prepared, /id=["']cmt-(?:ementario-dialog|referenciais|ref-(?:mapa|paragrafos|vade|regimento|diretrizes|protocolo)-src)["']/);
  assert.doesNotMatch(prepared, /\{ sec: 'APOIO' \}/);
});

test("embedded Ementário remains while the standalone Sessions page is retired", () => {
  assert.match(prepared, /CMTParadigmas\?\.abrirEmMesa/);
  assert.match(prepared, /cmt-geradores-ementario-runtime/);
  assert.match(prepared, /cmt-retired-sessions-route/);
  assert.doesNotMatch(prepared, /cmt-sessions-page-runtime|sessions-page\.(?:css|js)/);
  assert.doesNotMatch(prepared, /id:\s*'sessoes',\s*label:\s*'Controle de Sessões'/);
  assert.match(prepared, /Sessões e marcos/);
  const embedded = readFileSync(new URL("../src/protected/cmt-geradores-ementario.js", import.meta.url), "utf8");
  assert.match(embedded, /abrirEmMesa:\s*openEmbedded/);
  assert.match(embedded, /fecharEmMesa:\s*closeEmbedded/);
  assert.match(readFileSync(new URL("../../pauta-compartilhada/public/cmt-geradores-biblioteca.js", import.meta.url), "utf8"), /abrirEmentario:\s*abrirEmentario/);
});

test("all inline scripts in the served document and retained modules parse", () => {
  const scripts = [...prepared.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)]
    .filter(([, attributes]) => !/\bsrc=/i.test(attributes)
      && (!/\btype=/i.test(attributes) || /\btype=["'](?:text|application)\/(?:java|ecma)script["']/i.test(attributes)));
  assert.ok(scripts.length > 0, "the prepared document contains executable inline scripts");
  for (const [index, script] of scripts.entries()) {
    new vm.Script(script[2], { filename: `prepared-inline-${index}.js` });
  }
  new vm.Script(readFileSync(new URL("../src/protected/cmt-geradores-ementario.js", import.meta.url), "utf8"), { filename: "cmt-geradores-ementario.js" });
});

test("retired top-level URLs redirect to the Gabinete shell", () => {
  const app = readFileSync(new URL("../../pauta-compartilhada/src/App.tsx", import.meta.url), "utf8");
  for (const route of ["/sessions", "/ementario", "/protocolo", "/repositorio", "/repertorio", "/diretrizes", "/diretrizes-e-fluxos", "/conformidade", "/jurisprudencia", "/precedentes"]) {
    assert.match(app, new RegExp(`<Route path="${route}" component=\\{LegacyGabinetePageRedirect\\} \\/>`));
  }
});

import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";
import test from "node:test";

const source = readFileSync(new URL("../src/protected/gabcmt.html",import.meta.url),"utf8");
const runtime = readFileSync(new URL("../src/protected/cmt-daily-workspace.js",import.meta.url),"utf8");
const workspaceCss = readFileSync(new URL("../src/protected/cmt-daily-workspace.css",import.meta.url),"utf8");
const node = () => ({innerHTML:"",querySelector:()=>({focus(){}})});
function fixture(events) {
  const handlers = {}, target=node();
  const window = {
    PautaApp:{},PautaControl:{today:()=> "2026-11-06"},PautaPublicCalendar:{events:()=>events},
    addEventListener(){},setInterval(){},
  };
  const document={readyState:"loading",addEventListener:(k,fn)=>handlers[k]=fn,hidden:false};
  vm.runInNewContext(runtime,{window,document,console,setInterval(){},requestAnimationFrame(){}});
  window.CMTDailyWorkspace.mountCalendar(target);
  return {window,target,handlers};
}
test("entregas gerais incluem toda a equipe e todos os tipos de produção do dia",()=>{
  const start=source.indexOf("  function painelDados()"),end=source.indexOf("\n  function painelHTML()",start);
  const model={
    pessoas:[
      {k:"ANA",entregues:[{tipo:"Minuta",proc:"111"}],outras:[]},
      {k:"BEATRIZ",entregues:[{tipo:"Monocrática",proc:"222"}],outras:[{tipo:"Diligência",proc:"333"}]},
    ],itens:[{srv:"ANA",minDia:"2026-11-06"},{srv:"BEATRIZ",minDia:"2026-11-05"}],
  };
  const data=vm.runInNewContext(`${source.slice(start,end)};painelDados()`,{
    window:{__cmtOD2:{modeloDiaCompleto:()=>model}},today:()=> "2026-11-06",me:()=> "ANA",K:v=>String(v??"").toUpperCase(),S:v=>String(v??"")
  });
  assert.equal(data.meuFeito.length,1);
  assert.equal(data.entregues.length,3);
  assert.deepEqual(Array.from(data.entregues,x=>x.srv),["ANA","BEATRIZ","BEATRIZ"]);
  assert.deepEqual(Array.from(data.entregues,x=>x.tipo),["Minuta","Monocrática","Diligência"]);
  assert.doesNotMatch(source,/data-cppane="meudia"|data-cppane="entregas"/);
  assert.match(source,/data-daily-calendar/);
  assert.match(source,/dailyData:painelDados/);
  assert.match(source,/modeloDiaCompleto:\(\)=>modelo\(null,true\)/);
});
test("calendário mantém marcos simultâneos, eventos por período e seleção de outro dia",()=>{
  const {target,handlers}=fixture([
    {id:"a",kind:"milestone",start:"2026-11-06",end:"2026-11-06",title:"Entrega da sessão A"},
    {id:"b",kind:"milestone",start:"2026-11-06",end:"2026-11-06",title:"Liberação da sessão B"},
    {id:"c",kind:"event",start:"2026-11-05",end:"2026-11-07",title:"Evento do gabinete"},
    {id:"unsafe",start:"2026-11-06",title:"<script>não executar</script>"},
    {id:"invalid",start:"2026-02-30",title:"Data inválida"},
  ]);
  assert.match(target.innerHTML,/Entrega da sessão A/);
  assert.match(target.innerHTML,/Liberação da sessão B/);
  assert.match(target.innerHTML,/Hoje · 4/);
  assert.match(target.innerHTML,/&lt;script&gt;/);
  assert.doesNotMatch(target.innerHTML,/Data inválida|<script>/);
  const date={dataset:{dailyDate:"2026-11-07"}};
  handlers.click({target:{closest:selector=>selector==="[data-daily-calendar]"?target:selector==="[data-daily-date]"?date:null}});
  assert.match(target.innerHTML,/Dia 07\/11 · 1/);
  assert.match(target.innerHTML,/Eventos de hoje · 4/);
  const nav={dataset:{dailyMonth:"1"}};
  handlers.click({target:{closest:selector=>selector==="[data-daily-calendar]"?target:selector==="[data-daily-month]"?nav:null}});
  assert.match(target.innerHTML,/dezembro de 2026/);
});
test("falha de calendário tem aviso explícito e opção de nova tentativa",()=>{
  const {window,target}=fixture([]);
  window.PautaPublicCalendar.events=()=>{throw new Error("indisponível");};
  window.CMTDailyWorkspace.mountCalendar(target);
  assert.match(target.innerHTML,/role="alert"/);
  assert.match(target.innerHTML,/data-daily-retry/);
  window.PautaPublicCalendar.events=()=>[];
  window.CMTDailyWorkspace.mountCalendar(target);
  assert.match(target.innerHTML,/Nenhum marco ou evento/);
  assert.doesNotMatch(target.innerHTML,/role="alert"/);
});
test("notificações, calendário e pendências usam um único painel acima de Meu dia",()=>{
  assert.match(runtime,/id = 'cmt-sidebar-notifications-launch'/);
  assert.match(runtime,/side\.insertBefore\(notice,dock\)/);
  assert.match(source,/label: 'Notificações'/);
  assert.match(source,/data-center-notif-feed/);
  assert.match(source,/data-daily-calendar/);
  assert.match(source,/function syncNotificationFeed\(\)/);
  assert.match(source,/function releaseNotificationFeed\(\)/);
  assert.match(source,/if \(k === 'notif'\) k = 'painel'/);
  assert.match(source,/window\.PautaPendencias\.mount\(state\.content\)/);
  assert.match(source,/data-center-minimize/);
  assert.ok(workspaceCss.includes("#alt-side>#cmt-sidebar-notifications-launch"));
  assert.ok(workspaceCss.includes("#alt-side .as-notif"));
  assert.ok(source.includes("--cmt-notif-left"));
});
test("recursos novos são autenticados, carregados pelo frame e copiados no build",()=>{
  const routes=readFileSync(new URL("../src/routes/gabcmt.ts",import.meta.url),"utf8");
  const build=readFileSync(new URL("../build.mjs",import.meta.url),"utf8");
  assert.match(routes,/"daily-workspace.js": "cmt-daily-workspace.js"/);
  assert.match(routes,/"daily-workspace.css": "cmt-daily-workspace.css"/);
  assert.match(source,/src="\/api\/app\/daily-workspace.js" defer/);
  assert.match(source,/href="\/api\/app\/daily-workspace.css"/);
  assert.match(build,/`cmt-daily-workspace\.\$\{extension\}`/);
});

import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const html = readFileSync(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");
const start = html.indexOf("function workbenchToggle(){");
const end = html.indexOf("</script>", start);
const workbench = html.slice(start, end);

test("Mesa de trabalho sai do seletor do rodapé e vira botão sobre o Prontuário", () => {
  assert.ok(start >= 0 && end > start, "o módulo da Mesa de trabalho deve existir");
  assert.doesNotMatch(workbench, /Pauta completa|data-pa-tab|footerControls\(/);
  assert.match(workbench, /id='pa-mesa-workbench-toggle'/);
  assert.match(workbench, /<span>Mesa de trabalho<\/span>/);
  assert.match(html, /#pa-mesa-workbench-toggle\{position:fixed/);
  assert.match(workbench, /setMesa\(!mesa\)/);
  assert.match(html, /workbenchLabel&&!workbenchLabel\.hidden\?34\/z:0/);
  assert.match(workbench, /if\(mesa&&!antes\)prontuario\(\)/);
  assert.match(workbench, /CMTProntuario\?\.isOn\?\.\(\)\)window\.CMTProntuario\.toggle\(false\)/);
  assert.doesNotMatch(workbench, /if\(r\)r\.remove\(\)/);
  assert.doesNotMatch(html, /className=['"]cmt-pauta-footer-controls['"]|class=['"]cmt-pauta-footer-controls['"]/);
});

import assert from 'node:assert/strict';
import test from 'node:test';
import {
  buildDatajudTriageResult,
  consultarDatajudTriageProcess,
} from '../src/lib/datajud-triagem.ts';

const numero = '50059724320244036000';

test('identifies the nine candidate-rule families and returns movement evidence', () => {
  const movements = [
    ['Recurso de apelação interposto', 85, '2026-01-01'],
    ['Sentença publicada', 51, '2026-01-02'],
    ['Expedição de intimação', 60, '2026-01-03'],
    ['Decurso de prazo', 1051, '2026-01-04'],
    ['Certidão de custas e preparo', 999, '2026-01-05'],
    ['Juntada de procuração e substabelecimento', 999, '2026-01-06'],
    ['Emenda para regularização', 999, '2026-01-07'],
    ['Recurso não conhecido por inadmissibilidade', 237, '2026-01-08'],
    ['Homologada desistência', 999, '2026-01-09'],
  ].map(([nome, codigo, dataHora]) => ({ nome, codigo, dataHora, complementosTabelados: [] }));
  movements[4].nome = 'Juntada de documento';
  movements[4].complementosTabelados = [{ codigo: 57, descricao: 'Preparo recursal' }];
  const result = buildDatajudTriageResult(numero, [{ numeroProcesso: numero, movimentos: movements }]);

  assert.equal(result.status, 'encontrado');
  assert.deepEqual(
    [...new Set(result.movimentos.flatMap((movement) => movement.regras.map((rule) => rule.id)))].sort(),
    ['R01', 'R02', 'R03', 'R04', 'R05', 'R06', 'R07', 'R08', 'R09'],
  );
  assert.equal(result.movimentos[0].data, '2026-01-01');
  assert.equal(result.movimentos[0].codigo, 85);
  assert.equal(result.movimentos[0].nome, 'Recurso de apelação interposto');
  assert.equal(result.movimentos[4].regras.some((rule) => rule.id === 'R05'), true);
  assert.match(result.movimentos[4].complementos[0], /Preparo recursal/);
});

test('keeps exact process matches, preserves raw records, and separates missing from empty movements', () => {
  const raw = { numeroProcesso: numero, movimentos: [{ nome: 'Movimento sem candidato', codigo: 777 }] };
  const result = buildDatajudTriageResult(numero, [
    raw,
    { numeroProcesso: '50059724320244036001', movimentos: [{ nome: 'Apelação', codigo: 85 }] },
  ]);

  assert.equal(result.status, 'encontrado');
  assert.deepEqual(result.registros, [raw]);
  assert.deepEqual(result.movimentos, []);
  assert.equal(buildDatajudTriageResult(numero, []).status, 'nao_localizado');
});

test('queries a single CNJ number and lets technical failures remain failures', async () => {
  let sent;
  const result = await consultarDatajudTriageProcess(numero, async (numbers) => {
    sent = numbers;
    return [{ numeroProcesso: numero, movimentos: [] }];
  });
  assert.deepEqual(sent, [numero]);
  assert.equal(result.status, 'encontrado');

  await assert.rejects(
    consultarDatajudTriageProcess(numero, async () => { throw new Error('DataJud indisponível'); }),
    /DataJud indisponível/,
  );
  await assert.rejects(
    consultarDatajudTriageProcess('123', async () => { throw new Error('não deveria consultar'); }),
    /20 dígitos/,
  );
});

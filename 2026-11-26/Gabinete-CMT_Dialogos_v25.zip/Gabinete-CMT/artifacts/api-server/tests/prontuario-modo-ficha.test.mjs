import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const source = readFileSync(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");

test("a ficha do Prontuário mostra só o que tem dado; os previstos ficam no modo Preencher", () => {
  /* O modo é do servidor e fica no navegador dele; o padrão é a leitura. */
  assert.match(source, /const QP_MODO_K='cmt\.prontuario\.modo\.v1';/);
  assert.match(source, /function qpModo\(\)\{[^}]*localStorage\.getItem\(QP_MODO_K\)==='preencher'\?'preencher':'leitura'/);

  /* Em leitura o painel filtra pelos campos com dado. */
  assert.match(source, /if\(leitura\)list=list\.filter\(f=>qpTemDado\(p,f\)\);/);
  /* Campos de conteúdo próprio não entram na conta e ficam sempre à vista. */
  assert.match(source, /function qpSempre\(f\)\{return \['voto','acess','pecas','resource-list'\]\.includes\(f\.type\);\}/);
  assert.match(source, /function qpTemDado\(p,f\)\{return qpSempre\(f\)\|\|filled\(p,\[f\]\)\[0\]>0;\}/);
  /* Painel sem nada lançado diz onde lançar, em vez de ficar mudo. */
  assert.match(source, /if\(leitura&&!n&&t\)rows\+=`<div class="qp-vazio">/);

  /* O roteiro guiado, em leitura, é registro do que foi respondido. */
  assert.match(source, /if\(modo==='leitura'\)\{const resp=L\.filter\(x=>pm\[x\.src\+'\.'\+x\.i\]\);if\(!resp\.length\)return '';L=resp;\}/);
  /* A conferência de conformidade é lista de trabalho: não entra na ficha de leitura. */
  assert.match(source, /\$\{modo==='leitura'\?'':pmConformBloco\(p,k\)\}/);

  /* O seletor traz as duas contas, e elas vêm do app — não são escritas à mão.
     Contam pelo mesmo critério do que é desenhado (qpTemDado), e não por filled(), que
     deixa de fora voto, acessórios e peças: era daí que vinha a divergência do rótulo. */
  assert.match(source, /const previstos=todos\.length,cheios=todos\.filter\(f=>qpTemDado\(p,f\)\)\.length;/);
  assert.doesNotMatch(source, /const \[cheios,previstos\]=filled\(p,todos\);/);
  assert.match(source, /data-qp-modo="leitura"[\s\S]{0,120}\$\{cheios\} com dado/);
  assert.match(source, /data-qp-modo="preencher"[\s\S]{0,120}\$\{previstos\} previstos/);

  /* Trocar de modo repinta o prontuário; nada de recarregar a página. */
  assert.match(source, /qpModoSet\(b\.dataset\.qpModo\);\s*\n\s*window\.CMTProntuario\?\.paint\?\.\(true\);/);
});

import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import { preparePendingPanel } from "../src/lib/gabcmt-pending-panel.ts";

const source = readFileSync(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");
const prepared = preparePendingPanel(source);
const payload = prepared.match(/<script\b[^>]*\bid="cmt-mod-enhancements"[^>]*>([\s\S]*?)<\/script>/);
assert.ok(payload, "prepared page should contain the shared panel module");
const code = JSON.parse(payload[1]);
const start = code.indexOf("  function dialogHTML()");
const end = code.indexOf("\n  const rootEl", start);
assert.ok(start >= 0 && end > start, "prepared shared panel should retain its renderer");
const dialogMarkup = code.slice(start, end);

test("Pendências começa pela faixa de filtros, sem resumo anterior", () => {
  assert.doesNotMatch(dialogMarkup, /class="pnb-bar"/);
  assert.match(dialogMarkup, /const pills = \[\['all', 'Todas'\][\s\S]*\['late', 'Atrasadas', late\]\]/);
  assert.match(
    dialogMarkup,
    /class="pnb-tools"[\s\S]*class="pnb-pill"[\s\S]*class="pnb-view"[\s\S]*data-pnd="new"[\s\S]*data-footer-pending-close/,
  );
});

test("painel de Pendências sobe mantendo a base junto ao rodapé", () => {
  assert.match(
    prepared,
    /#pauta-global-dock #cmt-footer-pending\{[\s\S]*?bottom:var\(--pending-bottom\)!important/,
  );
  assert.match(
    prepared,
    /#cmt-footer-pending:not\(\[hidden\]\) \[data-pnd-root\]/,
  );
  assert.match(
    prepared,
    /if \(!visiblePendingFooter\(\)\) return false/,
  );
});

test("atualizar o rodapé preserva o painel independente já montado", () => {
  assert.match(source, /const pendingPanel=old\?\.querySelector\(':scope > #cmt-footer-pending'\);\s*if\(pendingPanel\)dock\.appendChild\(pendingPanel\)/);
  const start = source.indexOf('  function ensureCenterPanelViews(shell)');
  const end = source.indexOf('  function ensureCenterPanel()', start);
  assert.doesNotMatch(source.slice(start, end), /key: 'pend'/);
});

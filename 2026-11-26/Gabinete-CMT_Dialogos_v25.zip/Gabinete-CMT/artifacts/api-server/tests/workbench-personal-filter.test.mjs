import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const source = readFileSync(
  new URL("../src/protected/gabcmt.html", import.meta.url),
  "utf8",
);

test("the active team account defines Mesa de Trabalho identity", () => {
  assert.match(source, /var who=S\(a\.server\|\|s\.servidor\)/);
  assert.match(source, /S\(m\.id\)===who\|\|N\(m\.name\)===N\(who\)/);
  assert.match(source, /window\.__cmtSrvFoco=\{k:k,nomes:\[m\.name\]\.concat\(Array\.isArray\(m\.aliases\)\?m\.aliases:\[\]\).*mesa:1\}/);
});

test("Mesa de Trabalho includes own-server and own-corrector assignments", () => {
  assert.match(source, /if\(focoN\)\{const servidor=norm\(x\.w\.SERVIDOR\),corretor=norm\(x\.w\.CORRETOR\);if\(!focoN\.includes\(servidor\)&&!focoN\.includes\(corretor\)\)return false;\}/);
  assert.match(source, /foco\?\[foco\.k,focoN\]:''/);
});

test("opening Mesa opens the Prontuário without selecting a first process", () => {
  assert.match(source, /function prontuario\(\)\{setTimeout\(function\(\)\{try\{var P=window\.CMTProntuario;if\(!P\|\|!mesa\)return;if\(window\.CMTRail&&window\.CMTRail\.go\)window\.CMTRail\.go\('qp'\);else if\(P\.open\)P\.open\(\);else P\.toggle\(true\);/);
  assert.match(source, /function vis\(\) \{ return !!\(on && elegivel\(\)\); \}/);
  assert.match(source, /Escolha um processo da sua lista para carregar os dados\. Nenhum processo foi selecionado automaticamente\./);
  assert.match(source, /function selectInitial\(\)[\s\S]*?const initial = stored \? groupForProcess\(stored\) : null;/);
});

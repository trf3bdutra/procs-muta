import assert from "node:assert/strict";
import test from "node:test";
import { canAccessGlobalSettings, canDeleteProcessCards } from "../src/lib/app-auth.ts";
import {
  accountPasswordSecretKey,
  enforceLastAdministrator,
  isBrunoAccountTarget,
  resolveServerLoginMode,
  validateMembershipChange,
} from "../src/lib/account-policy.ts";
import { loginServersFromLinkedAccounts } from "../src/lib/login-options.ts";

const brunoEmail = "bdutra@trf3.jus.br";

test("Editor is an administrative role for protected operations", () => {
  assert.equal(canAccessGlobalSettings("editor"), true);
  assert.equal(canDeleteProcessCards("editor"), true);
  assert.equal(canAccessGlobalSettings("equipe"), false);
  assert.equal(canDeleteProcessCards("equipe"), false);
});

test("privileged BRUNO access is limited to his registered identity", () => {
  assert.equal(isBrunoAccountTarget(brunoEmail, "BRUNO", brunoEmail), true);
  assert.equal(isBrunoAccountTarget(brunoEmail.toUpperCase(), " bruno ", brunoEmail), true);
  assert.equal(isBrunoAccountTarget("other@example.test", "BRUNO", brunoEmail), false);
  assert.equal(isBrunoAccountTarget(brunoEmail, "RODRIGO", brunoEmail), false);
  assert.equal(isBrunoAccountTarget(brunoEmail, "BRUNO", ""), false);
  assert.throws(
    () => validateMembershipChange("admin", "staff", { status: "active", role: "editor", server: "RODRIGO" }, ["BRUNO", "RODRIGO"]),
    { code: "editor_removed" },
  );
});

test("BRUNO uses the team password while retaining selected-account admin access", () => {
  assert.equal(accountPasswordSecretKey("editor", "BRUNO"), "TEAM_LOGIN_PASSWORD");
  assert.equal(accountPasswordSecretKey("editor", " bruno "), "TEAM_LOGIN_PASSWORD");
  assert.equal(accountPasswordSecretKey("editor", "RODRIGO"), null);
  assert.equal(accountPasswordSecretKey("administracao", null), "ADMIN_LOGIN_PASSWORD");
  assert.equal(accountPasswordSecretKey("equipe", "BRUNO"), "TEAM_LOGIN_PASSWORD");
  assert.equal(accountPasswordSecretKey("equipe", "RODRIGO"), "TEAM_LOGIN_PASSWORD");
  assert.deepEqual(resolveServerLoginMode({
    teamPasswordMatches: true,
    adminPasswordMatches: false,
    selectedServerHasAdminAccess: true,
    selectedServerIsBruno: true,
    selectedServerRole: "equipe",
    selectedServerPasswordMatches: true,
  }), { accessRole: "administracao", useSelectedAccount: true });
  assert.deepEqual(resolveServerLoginMode({
    teamPasswordMatches: false,
    adminPasswordMatches: true,
    selectedServerHasAdminAccess: true,
    selectedServerIsBruno: true,
    selectedServerRole: "equipe",
    selectedServerPasswordMatches: false,
  }), null);
  assert.deepEqual(resolveServerLoginMode({
    teamPasswordMatches: true,
    adminPasswordMatches: false,
    selectedServerHasAdminAccess: false,
    selectedServerIsBruno: false,
    selectedServerRole: "equipe",
  }), { accessRole: "equipe", useSelectedAccount: true });
  assert.equal(resolveServerLoginMode({
    teamPasswordMatches: true,
    adminPasswordMatches: false,
    selectedServerHasAdminAccess: true,
    selectedServerIsBruno: true,
    selectedServerRole: "equipe",
  }), null);
  assert.equal(resolveServerLoginMode({
    teamPasswordMatches: false,
    adminPasswordMatches: true,
    selectedServerHasAdminAccess: false,
    selectedServerRole: "equipe",
  })?.accessRole, "administracao");
});

test("only one BRUNO identity remains selectable with the team key or legacy dedicated key", () => {
  assert.deepEqual(loginServersFromLinkedAccounts([
    { server: "BRUNO", role: "equipe", status: "active", passwordSecretKey: "BDUTRA_LOGIN_PASSWORD" },
    { server: "RODRIGO", role: "equipe", status: "active", passwordSecretKey: "TEAM_LOGIN_PASSWORD" },
    { server: "ESTELA", role: "editor", status: "active", passwordSecretKey: "TEAM_LOGIN_PASSWORD" },
    { server: "SALA", role: "editor", status: "active", passwordSecretKey: "BDUTRA_LOGIN_PASSWORD" },
  ]), ["BRUNO", "RODRIGO"]);
});

test("BRUNO stays selectable before and after the credential key migrates", () => {
  assert.deepEqual(loginServersFromLinkedAccounts([
    { server: "BRUNO", role: "equipe", status: "active", passwordSecretKey: "TEAM_LOGIN_PASSWORD" },
    { server: "SALAH", role: "equipe", status: "active", passwordSecretKey: "TEAM_LOGIN_PASSWORD" },
  ]), ["BRUNO", "SALAH"]);
  assert.deepEqual(loginServersFromLinkedAccounts([
    { server: "BRUNO", role: "editor", status: "active", passwordSecretKey: "BDUTRA_LOGIN_PASSWORD" },
  ]), ["BRUNO"]);
  assert.deepEqual(resolveServerLoginMode({
    teamPasswordMatches: false,
    adminPasswordMatches: false,
    selectedServerHasAdminAccess: false,
    selectedServerIsBruno: true,
    selectedServerRole: "editor",
    selectedServerPasswordMatches: true,
  }), { accessRole: "administracao", useSelectedAccount: true });
});

test("BRUNO's admin flag protects the last administrator", () => {
  const accounts = [
    { userId: "bdutra", status: "active", role: "equipe", adminAccess: true },
    { userId: "admin", status: "active", role: "administracao" },
  ];
  assert.doesNotThrow(() => enforceLastAdministrator(
    accounts, "admin", { status: "disabled", role: "administracao", server: null },
  ));
  assert.throws(
    () => enforceLastAdministrator(
      [accounts[0]], "bdutra", { status: "disabled", role: "equipe", server: "BRUNO", adminAccess: false },
    ),
    { code: "last_admin" },
  );
});

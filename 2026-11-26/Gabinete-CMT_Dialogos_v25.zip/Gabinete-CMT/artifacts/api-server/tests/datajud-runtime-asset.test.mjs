import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';

test('build copies the authenticated DataJud UI module to the route runtime directory', async () => {
  const build = await readFile(new URL('../build.mjs', import.meta.url), 'utf8');
  const route = await readFile(new URL('../src/routes/gabcmt.ts', import.meta.url), 'utf8');

  assert.match(build, /src\/protected\/cmt-datajud-triage\.js[\s\S]*?path\.join\(distDir,\s*"protected\/cmt-datajud-triage\.js"\)/);
  assert.match(route, /"datajud\.js":\s*"cmt-datajud-triage\.js"/);
});

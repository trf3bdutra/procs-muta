import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";
import test from "node:test";
import { forwardOnce, forwardingText, linkedUrgency, urgencyWhatsappDestination, splitWhatsappText } from "../src/lib/urgency-whatsapp.ts";
import { prepareUrgencyWhatsappDocument } from "../src/lib/gabcmt-urgency-whatsapp.ts";
import { credencialTwilio, twilioMessageForm } from "../src/lib/envio.ts";
import { createUrgencyImageToken, isUrgencyImageTokenValid } from "../src/lib/urgency-whatsapp-media-token.ts";

test("Twilio API secret supplied as TWILIO_API_KEY is used with its API key SID", () => {
  const names = ["TWILIO_ACCOUNT_SID", "TWILIO_API_KEY_SID", "TWILIO_API_KEY_SECRET", "TWILIO_API_KEY", "TWILIO_AUTH_TOKEN"];
  const original = Object.fromEntries(names.map((name) => [name, process.env[name]]));
  try {
    process.env.TWILIO_ACCOUNT_SID = "AC" + "a".repeat(32);
    process.env.TWILIO_API_KEY_SID = "SK" + "b".repeat(32);
    delete process.env.TWILIO_API_KEY_SECRET;
    process.env.TWILIO_API_KEY = "test-api-key-secret";
    process.env.TWILIO_AUTH_TOKEN = "test-auth-token";
    assert.deepEqual(credencialTwilio(), {
      conta: "AC" + "a".repeat(32),
      usuario: "SK" + "b".repeat(32),
      senha: "test-api-key-secret",
    });
  } finally {
    for (const name of names) {
      if (original[name] === undefined) delete process.env[name];
      else process.env[name] = original[name];
    }
  }
});

test("Twilio form follows the supplied curl without exposing credentials or mixing Body with ContentSid", () => {
  const sid = "HX" + "a".repeat(32);
  const form = twilioMessageForm("whatsapp", "+17372508034", "+556699313888", "", { contentSid: sid });
  assert.equal(form.get("From"), "whatsapp:+17372508034");
  assert.equal(form.get("To"), "whatsapp:+556699313888");
  assert.equal(form.get("ContentSid"), sid);
  assert.equal(form.has("Body"), false);
  assert.equal(form.has("ContentVariables"), false);
  assert.equal(form.has("Authorization"), false);
  const variables = twilioMessageForm("whatsapp", "whatsapp:+17372508034", "whatsapp:+556699313888", "", {
    contentSid: sid, variables: { "1": "Ação & decisão", "2": "Prazo: 24h" },
  });
  assert.deepEqual(JSON.parse(new URLSearchParams(variables.toString()).get("ContentVariables")), { "1": "Ação & decisão", "2": "Prazo: 24h" });
  assert.equal(variables.get("From"), "whatsapp:+17372508034");
  assert.equal(variables.has("Body"), false);
  const image = twilioMessageForm("whatsapp", "+17372508034", "+556699313888", "Legenda exata", undefined,
    ["https://example.test/urgency.png"]);
  assert.equal(image.get("Body"), "Legenda exata");
  assert.equal(image.get("MediaUrl"), "https://example.test/urgency.png");
  assert.throws(() => twilioMessageForm("whatsapp", "+17372508034", "+556699313888", "x".repeat(1025), undefined,
    ["https://example.test/urgency.png"]), /legenda/);
});

test("free-form automatic and custom text remain unchanged; invalid template variables fail explicitly", () => {
  for (const body of ["Mensagem automática da urgência", "Conteúdo totalmente personalizado"]) {
    const form = twilioMessageForm("whatsapp", "+17372508034", "+5566999313888", body);
    assert.equal(form.get("Body"), body);
    assert.equal(form.has("ContentSid"), false);
  }
  assert.throws(() => twilioMessageForm("whatsapp", "+12345678900", "+12345678901", "", { contentSid: "bad" }), /inválido/);
  for (const variables of [{ foo: "x" }, { "1": "" }, { "1": 42 }]) {
    assert.throws(() => twilioMessageForm("whatsapp", "+12345678900", "+12345678901", "", { contentSid: "HX" + "a".repeat(32), variables }), /Variáveis/);
  }
  assert.throws(() => twilioMessageForm("whatsapp", "+12345678900", "+12345678901", "a".repeat(1601)), /excede/);
});

const state = {
  team: { members: [{ id: "r1", name: "Responsável de teste" }] },
  decisoes: {
    monocraticas: [{ id: "m1", linkedLimId: "u1" }],
    liminares: [{ id: "u1", processo: "0000000-00.2026.4.03.0000", pedido: "Suspensão de ato",
      medida: "Efeito suspensivo", urgencia: "Urgente (24 h)", prazo: "2026-11-06", responsavel: "r1" }],
  },
};
const urgency = linkedUrgency(state, "m1");

test("text splitting preserves every original character and stays within WhatsApp limits", () => {
  const exact = "Abertura.\n\nParágrafo com *destaque*.\n> Trecho citado.\n\n" + "á".repeat(2000) + "\n\nFecho.";
  const parts = splitWhatsappText(exact);
  assert.equal(parts.join(""), exact);
  assert.ok(parts.length > 1);
  assert.ok(parts.every((part) => part.length <= 950));
  assert.deepEqual(splitWhatsappText("texto curto"), ["texto curto"]);
  assert.throws(() => splitWhatsappText(""), /vazia/);
});

test("temporary media links are signed and expire", () => {
  const now = Date.now(), token = createUrgencyImageToken(now, "session-secret-test");
  assert.equal(isUrgencyImageTokenValid(token, now + 1, "session-secret-test"), true);
  assert.equal(isUrgencyImageTokenValid(token, now + 1, "wrong-secret"), false);
  assert.equal(isUrgencyImageTokenValid(token, now + 20 * 60 * 1000 + 1, "session-secret-test"), false);
  assert.equal(isUrgencyImageTokenValid(token + "x", now + 1, "session-secret-test"), false);
});

test("edition uses the exact number from the user's WhatsApp command", () => {
  assert.equal(urgencyWhatsappDestination({ NODE_ENV: "development" }).number, "+556699313888");
  assert.equal(urgencyWhatsappDestination({ NODE_ENV: "development" }).display, "+55 66 9931-3888");
  assert.equal(urgencyWhatsappDestination({ NODE_ENV: "development" }).test, true);
  for (const env of [{ NODE_ENV: "production" }, { NODE_ENV: "development", REPLIT_DEPLOYMENT: "1" }, {}]) {
    assert.equal(urgencyWhatsappDestination(env).number, "+5511999001336");
    assert.equal(urgencyWhatsappDestination(env).test, false);
  }
});

test("automatic message uses persisted linked urgency; custom replaces it entirely", () => {
  const automatic = forwardingText("automatic", undefined, urgency, state);
  for (const part of ["0000000", "Suspensão de ato", "Urgente (24 h)", "2026-11-06", "Responsável de teste"]) assert.ok(automatic.includes(part));
  assert.equal(forwardingText("custom", "  Só este texto.  ", urgency, state), "Só este texto.");
  assert.throws(() => forwardingText("custom", " ", urgency, state), /Escreva/);
  assert.throws(() => forwardingText("custom", "a".repeat(1501), urgency, state), /excede/);
  assert.throws(() => linkedUrgency(state, "absent"), /não foi encontrado/);
});

test("same opening cannot send twice, including concurrent requests; reopening permits another", async () => {
  const rows = new Map(); let sends = 0;
  const io = {
    claim: async (key, payload) => { if (rows.has(key)) return false; rows.set(key, payload); return true; },
    read: async (key) => rows.get(key),
    finish: async (key, payload) => { rows.set(key, payload); },
    send: async () => { sends++; await new Promise((r) => setTimeout(r, 5)); return { sid: "SMtest", status: "queued" }; },
  };
  const results = await Promise.allSettled([forwardOnce("opening1", {}, io), forwardOnce("opening1", {}, io)]);
  assert.equal(results.filter((r) => r.status === "fulfilled").length, 1);
  assert.equal(sends, 1);
  assert.equal((await forwardOnce("opening1", {}, io)).status, "accepted");
  assert.equal(sends, 1);
  await forwardOnce("opening2", {}, io);
  assert.equal(sends, 2);
});

test("uncertain provider error persists and never automatically repeats the attempt", async () => {
  let row, sends = 0;
  const io = {
    claim: async (_key, payload) => { if (row) return false; row = payload; return true; },
    read: async () => row,
    finish: async (_key, payload) => { row = payload; },
    send: async () => { sends++; throw new Error("timeout"); },
  };
  await assert.rejects(forwardOnce("opening", {}, io), /timeout/);
  assert.equal(row.status, "unconfirmed");
  await assert.rejects(forwardOnce("opening", {}, io), /já iniciou/);
  assert.equal(sends, 1);
});

test("serving-boundary hook preserves HTML and parses every executable inline script", () => {
  const original = readFileSync(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");
  const html = prepareUrgencyWhatsappDocument(original);
  assert.equal(html.slice(0, 100), original.slice(0, 100));
  assert.ok(html.includes("CMTUrgencyWhatsApp?.controls(lim,x)"));
  assert.ok(html.includes("CMTUrgencyWhatsApp?.handleSave(h,form,saved)"));
  assert.ok(html.includes('src="/api/app/urgency-whatsapp.js"'));
  const alertFeature = html.match(/<script id="cmt-alert-feature">([\s\S]*?)<\/script>/)?.[1] || "";
  assert.ok(alertFeature, "the alert feature must remain in the protected app");
  assert.match(alertFeature, /window\.addEventListener\('pauta:updated',scheduleTick\)/);
  assert.match(alertFeature, /observe\(modal,\{childList:true,subtree:true\}\)/);
  assert.doesNotMatch(alertFeature, /observe\(document\.body/);
  assert.doesNotMatch(alertFeature, /setInterval\(\(\)=>\{tick\(\);\},12000\)/);
  let executable = 0;
  for (const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)) {
    if (/type=["'](?!text\/javascript|application\/javascript)/i.test(match[1]) || !match[2].trim()) continue;
    new vm.Script(match[2], { filename: match[1].match(/id=["']([^"']+)/)?.[1] || `inline-${executable}` });
    executable++;
  }
  assert.ok(executable > 20, "the complete executable document must be checked");
  const integration = html.indexOf('<script src="/api/app/urgency-whatsapp.js">');
  assert.ok(integration > html.lastIndexOf("</script>", integration - 1));
  assert.match(html.slice(integration), /^<script src="\/api\/app\/urgency-whatsapp.js"><\/script><\/body>/);
  assert.throws(() => prepareUrgencyWhatsappDocument("<html></html>"), /contract changed/);
});

const client = readFileSync(new URL("../src/protected/cmt-urgency-whatsapp.js", import.meta.url), "utf8");
function clientHarness({ checked = true, mode = "automatic", custom = "", variables = "", save = true, fetchError = false } = {}) {
  const status = { textContent: "" }, enable = { checked }, select = { value: mode }, textarea = { value: custom, focus() {} };
  const mapping = { "[data-uw-enable]": enable, "[data-uw-mode]": select, "[data-uw-custom]": textarea, "[data-uw-status]": status, "[data-uw-vars]": { value: variables } };
  const inputs = [enable, select, textarea];
  const box = { dataset: { opening: "opening" }, querySelector: (s) => mapping[s], querySelectorAll: () => inputs };
  const form = { querySelector: () => box, querySelectorAll: () => inputs };
  let saves = 0, sends = 0;
  const host = { saveDB: async () => { saves++; return save; }, notify() {} };
  const window = { CMT_URGENCY_WHATSAPP_DESTINATION: { ...urgencyWhatsappDestination({ NODE_ENV: "development" }), templateSid: "HX" + "a".repeat(32) } };
  const context = { window, document: { addEventListener() {} }, crypto: { randomUUID: () => "opening" },
    fetch: async (_url, request) => { sends++; if (fetchError) throw new Error("rede indisponível");
      assert.equal(saves, 1); assert.equal(JSON.parse(request.body).mode, mode);
      if (mode === "template") {
        assert.deepEqual(JSON.parse(request.body).contentVariables, variables ? JSON.parse(variables) : {});
        assert.equal("customText" in JSON.parse(request.body), false);
      }
      return { ok: true, json: async () => ({ status: "accepted" }) }; } };
  vm.runInNewContext(client, context);
  return { api: window.CMTUrgencyWhatsApp, box, form, host, status, enable, saves: () => saves, sends: () => sends };
}
const settle = () => new Promise((r) => setTimeout(r, 0));

test("UI does not send unless armed; saves first and locks until reopening", async () => {
  const off = clientHarness({ checked: false });
  const markup = off.api.controls(urgency, { id: "m1" });
  assert.ok(markup.includes("+55 66 9931-3888"));
  assert.ok(markup.includes("Ambiente de testes"));
  assert.ok(!markup.includes("+55 11 99900-1336"));
  assert.equal(off.api.handleSave(off.host, off.form, { id: "m1" }), false);
  assert.equal(off.saves(), 0); assert.equal(off.sends(), 0);
  const on = clientHarness();
  assert.equal(on.api.handleSave(on.host, on.form, { id: "m1" }), true);
  on.api.handleSave(on.host, on.form, { id: "m1" }); // duplicate while awaiting save
  await settle();
  assert.equal(on.sends(), 1);
  assert.equal(on.box.dataset.state, "sent");
  assert.ok(on.status.textContent.includes("Mensagem enviada"));
  assert.equal(on.enable.disabled, true);
  assert.equal(on.api.handleSave(on.host, on.form, { id: "m1" }), false);
  assert.equal(on.sends(), 1);
  const reopened = clientHarness({ mode: "custom", custom: "Mensagem inteira de teste" });
  reopened.api.handleSave(reopened.host, reopened.form, { id: "m1" });
  await settle(); assert.equal(reopened.sends(), 1);
});

test("UI never sends on save failure or empty custom message and never claims success on network error", async () => {
  for (const config of [{ save: false }, { mode: "custom", custom: "" }]) {
    const h = clientHarness(config); h.api.handleSave(h.host, h.form, { id: "m1" });
    await settle(); assert.equal(h.sends(), 0); assert.notEqual(h.box.dataset.state, "sent");
  }
  const h = clientHarness({ fetchError: true });
  h.api.handleSave(h.host, h.form, { id: "m1" }); await settle();
  assert.equal(h.box.dataset.state, "unconfirmed");
  assert.ok(!h.status.textContent.includes("Mensagem enviada"));
});

test("template UI requires explicit activation and validates variables before requesting an actual send", async () => {
  for (const variables of ["", '{"1":"Processo de teste"}']) {
    const h = clientHarness({ mode: "template", variables });
    const markup = h.api.controls(urgency, { id: "m1" });
    assert.ok(markup.includes('value="template"'));
    assert.ok(markup.includes("não o texto automático do card"));
    h.api.handleSave(h.host, h.form, { id: "m1" });
    await settle();
    assert.equal(h.sends(), 1); assert.equal(h.box.dataset.state, "sent");
  }
  for (const variables of ["not-json", "[]", '{"1":42}', '{"foo":"bar"}', '{"1":""}']) {
    const h = clientHarness({ mode: "template", variables });
    h.api.handleSave(h.host, h.form, { id: "m1" });
    await settle();
    assert.equal(h.sends(), 0); assert.equal(h.saves(), 0);
  }
});

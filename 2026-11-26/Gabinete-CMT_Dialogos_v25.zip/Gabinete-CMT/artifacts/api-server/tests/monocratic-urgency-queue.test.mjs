import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const source = readFileSync(
  new URL("../src/protected/gabcmt.html", import.meta.url),
  "utf8",
);

function extractFunction(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `function ${name} should exist`);
  const open = source.indexOf("{", start);
  let depth = 0;
  let quote = "";
  let escaped = false;
  for (let i = open; i < source.length; i += 1) {
    const char = source[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (char === "\\") escaped = true;
      else if (char === quote) quote = "";
      continue;
    }
    if (char === "'" || char === '"' || char === "`") {
      quote = char;
      continue;
    }
    if (char === "{") depth += 1;
    if (char === "}" && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Could not extract ${name}`);
}

function buildUrgencyFactory() {
  const monoUrgencyRequiresQueue = new Function(
    "MONO",
    `return (${extractFunction("monoUrgencyRequiresQueue")});`,
  )({
    urgencias: [
      "Urgentíssima (mesmo dia)",
      "Urgente (24 h)",
      "Prioritária (48 h)",
      "Ordinária (5 dias)",
    ],
  });
  const ensureMonoUrgency = new Function(
    "ensure",
    "N",
    "MONO",
    "LIM",
    "LIM_FROM_MONO",
    "cleanLim",
    "P",
    "monoUrgencyRequiresQueue",
    `return (${extractFunction("ensureMonoUrgency")});`,
  );
  let nextLimId = 0;
  return ensureMonoUrgency(
    (host) => host.decisoes,
    (value) => String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase(),
    {
      urgencias: monoUrgencyRequiresQueue
        ? ["Urgentíssima (mesmo dia)", "Urgente (24 h)", "Prioritária (48 h)", "Ordinária (5 dias)"]
        : [],
      done: ["Assinada"],
    },
    { done: ["Decidida"] },
    {
      "A minutar": "Pendente",
      "Em elaboração": "Em análise",
      "Em revisão": "Em análise",
      "Pronta para assinatura": "Minuta pronta",
      Assinada: "Decidida",
    },
    (record) => ({ ...record, id: record.id || `lim-${++nextLimId}` }),
    { today: () => "2026-11-05" },
    monoUrgencyRequiresQueue,
  );
}

test("a monocrática urgente cria um único pedido ligado à mesma decisão", () => {
  const ensureMonoUrgency = buildUrgencyFactory();
  const host = { decisoes: { monocraticas: [], liminares: [] } };
  const mono = {
    id: "mono-1",
    processo: "5001234-56.2026.4.03.0000",
    classe: "AI",
    assunto: "Assunto de teste",
    status: "A minutar",
    urgencia: "Urgente (24 h)",
    entrada: "2026-11-05",
    prazo: "2026-11-06",
    responsavel: "servidor-1",
  };

  const first = ensureMonoUrgency(host, mono, "2026-11-05T12:00:00.000Z");
  const second = ensureMonoUrgency(host, mono, "2026-11-05T12:01:00.000Z");

  assert.equal(host.decisoes.liminares.length, 1);
  assert.equal(first.id, second.id);
  assert.equal(mono.linkedLimId, first.id);
  assert.equal(first.linkedMonoId, mono.id);
  assert.equal(first.geradaPorMonoUrgente, true);
  assert.equal(first.urgencia, mono.urgencia);
  assert.equal(first.pedido, "Acompanhamento urgente da decisão monocrática");
});

test("nível ordinário e decisão já assinada não abrem fila nova", () => {
  const ensureMonoUrgency = buildUrgencyFactory();
  const host = { decisoes: { monocraticas: [], liminares: [] } };

  assert.equal(ensureMonoUrgency(host, {
    id: "mono-normal",
    processo: "5001234-56.2026.4.03.0000",
    status: "A minutar",
    urgencia: "Ordinária (5 dias)",
  }), null);
  assert.equal(ensureMonoUrgency(host, {
    id: "mono-signed",
    processo: "5001234-56.2026.4.03.0001",
    status: "Assinada",
    urgencia: "Urgentíssima (mesmo dia)",
  }), null);
  assert.equal(host.decisoes.liminares.length, 0);
});

test("uma urgência aberta já cadastrada no processo é reutilizada", () => {
  const ensureMonoUrgency = buildUrgencyFactory();
  const existing = {
    id: "lim-existing",
    processo: "5001234-56.2026.4.03.0000",
    status: "Pendente",
    pedido: "Pedido previamente registrado",
  };
  const host = { decisoes: { monocraticas: [], liminares: [existing] } };
  const mono = {
    id: "mono-2",
    processo: existing.processo,
    status: "A minutar",
    urgencia: "Prioritária (48 h)",
  };

  const result = ensureMonoUrgency(host, mono);

  assert.equal(host.decisoes.liminares.length, 1);
  assert.equal(result.id, existing.id);
  assert.equal(result.pedido, "Pedido previamente registrado");
  assert.equal(result.linkedMonoId, mono.id);
  assert.equal(mono.linkedLimId, existing.id);
});

test("Monocráticas oferecem filtro mensal pela data de assinatura", () => {
  assert.match(source, /data-dec-filter="period" data-kind="mono"/);
  assert.match(source, /Todas as decisões do mês/);
  assert.match(source, /x\.dataAssinatura\|\|''\)\.startsWith\(month\)/);
  assert.match(source, /ui\.mono\.scope='todas'/);
});

test("Monocráticas ocultam o cabeçalho repetido e usam o seletor cinza", () => {
  assert.match(source, /monoHTMLNoDuplicateHeader=monoHTML;monoHTML=function\(h\)\{return monoHTMLNoDuplicateHeader\(h\)\.replace\(mainHeader\(h\),''\);\}/);
  assert.match(source, /\.dec-area\.dec-mono-area \.dec-toolbar \.dec-view-toggle\{background:#d2d7da!important/);
  assert.match(source, /aria-pressed="true"\]\{background:#aeb8bc!important/);
});

test("importações de Monocráticas sincronizam urgências recém-incluídas", () => {
  assert.match(source, /const importFileBase=importFile;importFile=async function\(h,kind,file\)/);
  assert.match(source, /importedMonoUrgenciesSeeded=false/);
  assert.match(source, /monoRevItems,urgPend,queueMonoUrgency/);
  assert.match(source, /lim\.updatedAt=now;urgPend\(h,lim\);return true/);
});

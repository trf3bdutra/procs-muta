import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import test from 'node:test';

const exec = promisify(execFile);
const chromium = '/repl/tools/bin/chromium';
const moduleSource = await readFile(new URL('../src/protected/cmt-datajud-triage.js', import.meta.url), 'utf8');

test('DataJud UI keeps partial/error states and exports fixture results', async () => {
  const dir = await mkdtemp(path.join(tmpdir(), 'cmt-datajud-triage-'));
  try {
    const htmlPath = path.join(dir, 'triagem.html');
    const fixture = `<!doctype html><meta charset="utf-8"><body><div id="root"></div><pre id="result"></pre>
<script>${moduleSource.replaceAll('</script', '<\\/script')}</script>
<script>
const nativeSetTimeout = window.setTimeout.bind(window);
window.setTimeout = (fn) => nativeSetTimeout(fn, 0);
let calls = 0, active = 0, maxActive = 0;
const requested = [];
window.fetch = async (url, options) => {
  active++; maxActive = Math.max(maxActive, active); calls++;
  const call = calls, body = JSON.parse(options.body); requested.push({url, number: body.numero});
  try {
    if (call === 2) return {ok:false, status:502, json:async()=>({ok:false,error:'DataJud indisponível'})};
    if (call === 3) throw new Error('conexão interrompida');
    const found = call === 1;
    return {ok:true, status:200, json:async()=>({
      ok:true, numero:body.numero, status:found?'encontrado':'nao_localizado',
      registros:found?[{numeroProcesso:body.numero,movimentos:[{nome:'Apelação interposta',codigo:85}]}]:[],
      movimentos:found?[{data:'2026-01-05T10:30:00',codigo:85,nome:'Apelação interposta',complementos:['Petição de apelação'],regras:[{id:'R01',titulo:'Interposição'}]}]:[]
    })};
  } finally { active--; }
};
const objectUrls = new Map(), downloads = [];
let blobIndex = 0;
URL.createObjectURL = (blob) => { const id='blob:test-'+(++blobIndex); objectUrls.set(id, blob); return id; };
HTMLAnchorElement.prototype.click = function(){downloads.push({name:this.download,url:this.href});};
const root=document.getElementById('root');
CMTDataJudTriage.render(root);
root.addEventListener('click', event => CMTDataJudTriage.click(event, root));
const wait=()=>new Promise(resolve=>nativeSetTimeout(resolve,100));
(async()=>{
  root.querySelector('[data-testid="button-query-all"]').click();
  for(let i=0;i<50 && root.querySelector('[data-testid="status-progress"]').textContent==='Próxima consulta em 1,5 s';i++) await wait();
  for(let i=0;i<50 && root.querySelector('[data-testid="status-process-14"]').textContent!=='Não localizado';i++) await wait();
  root.querySelector('[data-testid="button-open-raw"]').click();
  const rawOpen=root.querySelector('[data-testid="dialog-raw-json"]').hasAttribute('open');
  const rawText=root.querySelector('[data-testid="raw-json-content"]').textContent;
  root.querySelector('[data-testid="button-export-json"]').click();
  root.querySelector('[data-testid="button-export-summary-csv"]').click();
  root.querySelector('[data-testid="button-export-movements-csv"]').click();
  const exported=await Promise.all(downloads.map(async d=>({name:d.name,text:await objectUrls.get(d.url).text()})));
  const json=JSON.parse(exported.find(d=>d.name.endsWith('.json')).text.replace(/^\\uFEFF/,''));
  const result={
    calls, maxActive, requested,
    states:[0,1,2,14].map(i=>root.querySelector('[data-testid="status-process-'+i+'"]').textContent),
    rawOpen, rawContainsProcess:rawText.includes('50059724320244036000'),
    exportNames:exported.map(d=>d.name),
    jsonCount:json.length, jsonStatuses:json.slice(0,3).map(row=>row.status),
    summaryHasError:exported.find(d=>d.name==='datajud-resumo.csv').text.includes('erro_tecnico'),
    movementHasEvidence:exported.find(d=>d.name==='datajud-movimentos.csv').text.includes('Apelação interposta')
  };
  document.getElementById('result').textContent=encodeURIComponent(JSON.stringify(result));
})();
</script></body>`;
    await writeFile(htmlPath, fixture);
    const args = [
      '--headless', '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage',
      `--user-data-dir=${path.join(dir, 'profile')}`, '--virtual-time-budget=7000',
      '--dump-dom', `file://${htmlPath}`,
    ];
    const { stdout } = await exec(chromium, args, { timeout: 30000, maxBuffer: 5_000_000 });
    const encoded = stdout.match(/<pre id="result">([^<]+)<\/pre>/)?.[1];
    assert.ok(encoded, stdout.slice(-2000));
    const result = JSON.parse(decodeURIComponent(encoded));
    assert.equal(result.calls, 15);
    assert.equal(result.maxActive, 1, 'lote deve consultar um processo por vez');
    assert.ok(result.requested.every((request) => request.url === '/api/datajud/triagem/consultar' && /^\d{20}$/.test(request.number)));
    assert.deepEqual(result.states, ['Encontrado', 'Erro técnico', 'Erro técnico', 'Não localizado']);
    assert.equal(result.rawOpen, true);
    assert.equal(result.rawContainsProcess, true);
    assert.deepEqual(result.exportNames.sort(), ['datajud-movimentos.csv', 'datajud-resumo.csv', 'datajud-triagem.json']);
    assert.equal(result.jsonCount, 15);
    assert.deepEqual(result.jsonStatuses, ['encontrado', 'erro_tecnico', 'erro_tecnico']);
    assert.equal(result.summaryHasError, true);
    assert.equal(result.movementHasEvidence, true);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

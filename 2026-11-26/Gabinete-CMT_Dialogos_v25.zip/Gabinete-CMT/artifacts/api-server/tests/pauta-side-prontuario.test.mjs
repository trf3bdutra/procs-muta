import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";
import test from "node:test";
const source=fs.readFileSync(new URL("../src/protected/gabcmt.html",import.meta.url),"utf8");
const runtime=fs.readFileSync(new URL("../src/protected/cmt-pauta-side-panel.js",import.meta.url),"utf8");
const normalize=v=>String(v??"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").trim().toUpperCase();
function setup(){
  const handlers={},windowHandlers={};
  const members=[{id:"a",name:"ÁNA",aliases:["Aninha"]},{id:"b",name:"BIA",hierarchy:"Corretora",aliases:["Beatriz"]}];
  const window={PautaApp:{team:{members},rows:[]},CMT_AUTH_SESSION:{server:"a"},PautaTeam:{isAssessoria:m=>m.id==="b"},addEventListener:(name,fn)=>windowHandlers[name]=fn};
  const context={window,location:{pathname:"/pauta"},requestAnimationFrame:fn=>fn(),document:{documentElement:{dataset:{v2Page:"pauta"}},readyState:"loading",addEventListener:(name,fn)=>handlers[name]=fn,getElementById:()=>null,querySelector:()=>null,querySelectorAll:()=>[]},localStorage:{getItem:()=>null},sessionStorage:{getItem:()=>JSON.stringify({servidor:"Aninha"})},console};
  vm.runInNewContext(runtime,context);
  return {window,context,handlers,windowHandlers,api:window.CMTPautaSidePanel};
}
const rows=[
  {w:{Processo:"111",SERVIDOR:"Aninha",CORRETOR:"Outro"}},
  {w:{Processo:"222",SERVIDOR:"Outro",CORRETOR:"ANA"}},
  {w:{Processo:"333",SERVIDOR:"BIA",CORRETOR:"Outro"}},
  {w:{Processo:"444",SERVIDOR:"Outro",CORRETOR:"Beatriz"}},
  {w:{Processo:"555",SERVIDOR:"Outro",CORRETOR:"Outro"}},
];
function nativePage(window){
  const start=source.indexOf("    list(skip) {"),end=source.indexOf("\n    ",source.indexOf("\n    }",start)+6);
  assert.ok(start>0&&end>start);
  const method=source.slice(start,end).trim();
  const code=vm.runInNewContext(`({${method}})`,{window,norm:normalize,sessionRows:()=>rows,filterFields:[]});
  return Object.assign({session:"S",search:"",searchField:"*",searchTerms:[],advancedRules:[],tags:[],filters:{},metric:"",mineOnly:false,host:{rows},_listCache:new Map()},code);
}
test("Meus usa identidade autenticada, aliases e as designações de correção",()=>{
  const {window,api}=setup();
  assert.deepEqual(rows.filter(x=>api.matches(x)).map(x=>x.w.Processo),["111","222"]);
  window.CMT_AUTH_SESSION.server="b";
  assert.deepEqual(rows.filter(x=>api.matches(x)).map(x=>x.w.Processo),["444"],"corretora vê suas correções, não a fila de minutas de outro papel");
  window.CMT_AUTH_SESSION.server="BEATRIZ";
  assert.equal(api.scope().key,"b");
});
test("Prontuário da Pauta já inicia aberto e não pode ser recolhido",()=>{
  const {api,handlers}=setup();
  assert.equal(api.isExpanded(),true);
  api.setExpanded(false);
  assert.equal(api.isExpanded(),true);
  handlers["cmt:prontuario-process-selected"]({detail:{process:"111"}});
  assert.equal(api.isExpanded(),true);
  api.setExpanded(false);
  handlers["cmt:prontuario-process-selected"]({detail:{process:""}});
  assert.equal(api.isExpanded(),true);
});
test("moldura da Pauta mantém estados de carregamento, vazio e ficha pronta",()=>{
  const {api}=setup();
  assert.equal(api.statusMessage(null,null),"Carregando os dados do Prontuário…");
  assert.equal(api.statusMessage({isOn:()=>true,currentProcess:()=>""},{hidden:true}),"Selecione um processo na lista para visualizar sua ficha.");
  assert.equal(api.statusMessage({isOn:()=>false,currentProcess:()=>"111"},{hidden:true}),"Carregando a ficha do processo…");
  assert.equal(api.statusMessage({isOn:()=>true,currentProcess:()=>"111"},{hidden:false}),"");
});
test("navegação e redimensionamento não recolhem o Prontuário da Pauta",()=>{
  const {api,handlers,windowHandlers}=setup();
  api.setExpanded(false);
  handlers["cmt:page-change"]();
  windowHandlers.resize();
  assert.equal(api.isExpanded(),true);
});
test("a Pauta não monta o botão de recolher e começa com a moldura e o estado visíveis",()=>{
  assert.match(source,/<div class="pq-side-workspace" data-collapsed="false">[\s\S]*?<aside id="pq-side-panel" aria-label="Prontuário da Pauta"><header><span>Prontuário<\/span><\/header><div id="pq-side-body"><div id="pq-side-status" data-pq-side-status role="status" aria-live="polite">/);
  assert.doesNotMatch(source,/<aside id="pq-side-panel" aria-label="Prontuário da Pauta"><header><span>Prontuário<\/span><button/);
});
test("não usa servidor fixado e não mostra toda a sessão se faltar identidade",()=>{
  const {window,api}=setup(),page=nativePage(window);
  window.CMT_AUTH_SESSION=null;
  assert.equal(api.scope(),null,"sessão encerrada não usa identidade antiga no sessionStorage");
  page.mineOnly=true;
  assert.equal(page.list().length,0);
  window.CMT_AUTH_SESSION={server:"não vinculado"};
  assert.equal(page.list().length,0);
});
test("filtro nativo e seu cache acompanham alternância e troca de usuário",()=>{
  const {window}=setup(),page=nativePage(window);
  assert.equal(page.list().length,5,"Prontuário aberto não ativa um filtro automaticamente");
  page.mineOnly=true;
  assert.deepEqual(Array.from(page.list(),x=>x.w.Processo),["111","222"]);
  window.CMT_AUTH_SESSION={server:"b"};
  assert.deepEqual(Array.from(page.list(),x=>x.w.Processo),["444"],"cache não reaproveita processos do usuário anterior");
  page.mineOnly=false;
  assert.equal(page.list().length,5);
});
test("Prontuário e Mesa não fazem polling nem observam o corpo de cada processo",()=>{
  assert.match(runtime,/observer\.observe\(root,\{childList:true\}\)/,"a reconciliação observa somente remontagens diretas da raiz");
  assert.doesNotMatch(runtime,/observer\.observe\(root,\{childList:true,subtree:true\}\)/);
  const start=source.indexOf("if(window.__paProc)"),end=source.indexOf("/* ── Solicitações do processo",start);
  assert.ok(start>0&&end>start,"runtime da Mesa encontrado");
  const mesa=source.slice(start,end);
  assert.doesNotMatch(mesa,/setInterval\s*\(/,"a Mesa não deve recalcular foco e DOM em intervalos");
  assert.match(mesa,/mesaRootObserver\.observe\(root,\{childList:true\}\)/,"a Mesa acompanha apenas remontagens da raiz");
  assert.match(mesa,/\['cmt:route','cmt:page-change','pauta:updated','pauta:team-updated','cmt:mesa-state'\]/,"sincronização orientada pelos eventos da aplicação");
});
test("Meus não interfere na página individual do servidor",()=>{
  const {window,context}=setup(),page=nativePage(window);page.mineOnly=true;
  assert.equal(page.list().length,2);
  context.document.documentElement.dataset.v2Page="serv-user";
  assert.equal(page.list().length,5);
  context.document.documentElement.dataset.v2Page="pauta";
  assert.equal(page.list().length,2);
});
test("controle Meus é adjacente a Meta e não muda seleção ou paginação",()=>{
  const {window}=setup(),page={mineOnly:false,selected:new Set([4]),limit:25,render(){this.renders=(this.renders||0)+1;}};
  const start=source.indexOf("        toggleMine() {"),end=source.indexOf("\n",start);
  const adapter=vm.runInNewContext(`({${source.slice(start,end).trim()}})`,{window});
  adapter.page=()=>page;adapter.toggleMine();
  assert.equal(page.mineOnly,true);assert.equal(page.limit,25);assert.equal(page.selected.has(4),true);assert.equal(page.renders,1);
  adapter.toggleMine();assert.equal(page.mineOnly,false);
  assert.match(source,/class="fbp-t fbp-meta"[\s\S]*?<\/button><button type="button" class="fbp-t fbp-mine"/);
  assert.doesNotMatch(source,/button\.innerHTML=ICT\+'<span>Mesa de trabalho/);
});
test("Gerador continua exigindo o mesmo processo em foco no Prontuário",()=>{
  const start=source.indexOf("      function openGenerator() {"),end=source.indexOf("      function selectInitial()",start);
  let process="",selected=false;const calls=[];
  const window={CMTProntuario:{isSelectedProcess:()=>selected},CMTMesa:{on:()=>true,abrir(){},face:(face,proc)=>{calls.push({face,proc});return face;}}};
  const doc={getElementById:()=>null};
  const run=()=>vm.runInNewContext(`${source.slice(start,end)};openGenerator()`,{window,doc,cur:()=>({}),processOfGroup:()=>process});
  assert.equal(run(),false);process="111";assert.equal(run(),false);selected=true;assert.equal(run(),true);
  assert.equal(calls.length,1);assert.deepEqual(calls[0],{face:"gerador",proc:"111"});
});
test("selecionar o mesmo processo também sinaliza abertura quando o painel está recolhido",()=>{
  const start=source.indexOf("function select(g) { if (!g) return;"),end=source.indexOf("function nextProcess()",start);
  assert.ok(start>=0&&end>start);
  const group={dataset:{preRow:"5"},process:"111",classList:{add(){},remove(){}},querySelector:selector=>selector==="[data-row]"?{dataset:{row:"5"}}:null};
  const events=[];
  const select=vm.runInNewContext(`(${source.slice(start,end).trim()})`,{
    selectedGroup:group,gid:"5",focusedProcess:"111",keyOf:g=>g.dataset.preRow,processOfGroup:g=>g.process,
    paint(){},window:{PautaControl:{page:{}}},doc:{dispatchEvent:event=>events.push(event)},
    CustomEvent:function(name,options){this.type=name;this.detail=options.detail;},
  });
  select(group);
  assert.equal(events.length,1);
  assert.equal(events[0].type,"cmt:prontuario-process-selected");
  assert.equal(events[0].detail.process,"111");
  assert.equal(events[0].detail.changed,false);
});
test("Próximo processo percorre a lista filtrada e volta ao primeiro item",()=>{
  const start=source.indexOf("function nextProcess() {"),end=source.indexOf("\n      function openGenerator()",start);
  assert.ok(start>=0&&end>start);
  const makeGroup=(preRow,process)=>{
    let scrolled=false;
    const summary={scrollIntoView(){scrolled=true;}};
    const group={dataset:{preRow:String(preRow)},process,isConnected:true,querySelector:selector=>selector===".pauta-compact-summary"?summary:null};
    return {group,wasScrolled:()=>scrolled};
  };
  const first=makeGroup(1,"111"),second=makeGroup(2,"222"),byProcess=new Map([["111",first.group],["222",second.group]]);
  const items=[{i:1,r:{Processo:"111"}},{i:2,r:{Processo:"222"}}];
  let current=first.group,selected=null;
  const next=vm.runInNewContext(`(${source.slice(start,end).trim()})`,{
    window:{PautaControl:{page:{list:()=>items}}},
    cur:()=>current,processOfGroup:g=>g?.process||"",digits:value=>String(value||"").replace(/\D/g,""),
    groupForProcess:value=>byProcess.get(String(value)),select:g=>{selected=g;},
    groups:()=>[first.group,second.group],requestAnimationFrame:fn=>fn(),
  });
  assert.equal(next(),true);
  assert.equal(selected,second.group);
  assert.equal(second.wasScrolled(),true);
  current=second.group;selected=null;
  assert.equal(next(),true);
  assert.equal(selected,first.group,"o último item retorna ao início da lista");
  assert.equal(first.wasScrolled(),true);
  assert.match(source,/if \(a === 'prox'\) \{ nextProcess\(\); return; \}/,"o botão do cabeçalho aciona a navegação");
});
test("clique numa linha da Pauta seleciona o processo mesmo com o Prontuário fechado",()=>{
  const guard=source.indexOf("if (QP.passing()) return;");
  const start=source.lastIndexOf("window.addEventListener('click', (e) => {",guard);
  const end=source.indexOf("}, true);",start);
  assert.ok(start>=0&&end>start);
  const handler=source.slice(start,end);
  assert.ok(handler.includes("pautaActive=window.CMTPagina?.tipo?.()==='pauta'"));
  assert.match(handler,/if \(!prontuarioOn && !inMesa && !pautaActive\) return;/);
  assert.match(handler,/QP\.select\(g\)/);
});

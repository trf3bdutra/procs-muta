import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";
import test from "node:test";

const source = fs.readFileSync(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");

test("notification tabs tolerate a close button nested inside header tools", () => {
  const start = source.indexOf("  function ensureCenterPanelViews(shell) {");
  const end = source.indexOf("    const content = shell.querySelector", start);
  assert.ok(start > 0 && end > start);
  let tabs = null, created = 0;
  const close = { parentElement: {} };
  const head = {
    querySelector(selector) { return selector.includes("tabs") ? tabs : close; },
    insertBefore(node, reference) {
      assert.ok(reference === null || reference.parentElement === head);
      tabs = node;
    },
  };
  const context = {
    doc: { createElement() { created++; return { setAttribute() {} }; } },
    shell: { querySelector: () => head },
  };
  const run = () => vm.runInNewContext(`${source.slice(start, end)}return tabs;};ensureCenterPanelViews(shell)`, context);
  assert.ok(run());
  run();
  assert.equal(created, 1, "settled reconciliation does not recreate tabs");
});

test("notification geometry uses the module's actual window and is idempotent", () => {
  const start = source.indexOf("  function positionCenterPanel(");
  const end = source.indexOf("  function centerPanelState(", start);
  const values = new Map();
  let writes = 0;
  const shell = { style: {
    getPropertyValue: key => values.get(key),
    setProperty(key, value) { writes++; values.set(key, value); },
  } };
  const context = {
    doc: { getElementById(id) {
      return id === "alt-side" ? { getBoundingClientRect: () => ({ left: 0 }) }
        : { getClientRects: () => [1], getBoundingClientRect: () => ({ top: 550 }) };
    } },
    root: {}, innerWidth: 1440, innerHeight: 1000,
    window: { getComputedStyle: () => ({ zoom: "1" }) },
    shell,
  };
  const run = () => vm.runInNewContext(`${source.slice(start, end)};positionCenterPanel(shell)`, context);
  run(); run();
  assert.equal(writes, 4);
  assert.equal(values.get("--cmt-notif-width"), "760px");
});

test("a closed Prontuário returns before mounting, modeling or measuring", () => {
  const start = source.indexOf("      function paint(force) {\n        const inPauta = vis();");
  const end = source.indexOf("        const current=cur()", start);
  assert.ok(start > 0 && end > start);
  const el = { hidden: false };
  const context = { vis: () => false, el, geoReady: true, root: { classList: { remove() {} } } };
  vm.runInNewContext(`${source.slice(start, end)}};paint(false)`, context);
  assert.equal(el.hidden, true);
  assert.equal(context.geoReady, false);
});

test("R3 restores at most one expanded process even with old saved state", () => {
  const start = source.indexOf("let S={open:[],help:''};");
  const end = source.indexOf("\nconst keep=", start);
  const state = vm.runInNewContext(`${source.slice(start,end)};S`, {
    sessionStorage: { getItem: () => '["0","12","299"]' },
  });
  assert.deepEqual(Array.from(state.open), ["299"]);
  assert.match(source, /case 'toggle':S\.open=S\.open\.includes\(p\.id\)\?\[\]:\[p\.id\]/);
  assert.match(source, /if\(S\.open\.length!==1\|\|S\.open\[0\]!==id\)\{S\.open=\[id\]/);
});

test("R3 pagination keys follow session and filtered membership, not field edits", () => {
  const start = source.indexOf("function pageKey(L){");
  const end = source.indexOf("\nfunction pagination(", start);
  let session = "13/11/2026";
  const key = rows => vm.runInNewContext(`${source.slice(start,end)};pageKey(L)`, {
    PG: () => ({ session }), L: rows,
  });
  assert.equal(key([{ i: 0 }, { i: 299 }]), key([{ i: 0, edited: true }, { i: 299 }]));
  assert.notEqual(key([{ i: 0 }]), key([{ i: 299 }]));
  const old = key([{ i: 0 }]); session = "20/11/2026";
  assert.notEqual(key([{ i: 0 }]), old);
  assert.match(source, /const LIST_PAGE_SIZE=25/);
  assert.match(source, /const visible=L\.slice\(listPage\*LIST_PAGE_SIZE,\(listPage\+1\)\*LIST_PAGE_SIZE\)/);
});

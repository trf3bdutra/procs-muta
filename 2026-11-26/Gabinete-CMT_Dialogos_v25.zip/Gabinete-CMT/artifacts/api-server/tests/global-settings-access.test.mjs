import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { canAccessGlobalSettings } from "../src/lib/app-auth.ts";
import { hasAdminOnlyPautaSettingsChanges } from "../src/lib/pauta-admin-settings.ts";

const artifactsRoot = new URL("../../", import.meta.url);
const readSource = (path) => readFile(new URL(path, artifactsRoot), "utf8");

test("Administration and Editor can access Global Settings", () => {
  assert.equal(canAccessGlobalSettings("administracao"), true);
  assert.equal(canAccessGlobalSettings("editor"), true);
  assert.equal(canAccessGlobalSettings("equipe"), false);
  assert.equal(canAccessGlobalSettings(null), false);
  assert.equal(canAccessGlobalSettings(undefined), false);
});

test("shared Pauta edits remain available while settings state is protected", () => {
  const before = {
    rows: [{ Processo: "case-1", status: "open" }],
    sessions: [{ date: "2026-11-13" }],
    sessionDetails: { "13/11/2026": { minutasDeadline: "2026-11-10" } },
    workCalendar: { weekdays: [1, 2, 3, 4, 5], excluded: [] },
    pautaPreferences: { session: "13/11/2026" },
    pautaDaily: { Bruno: { completed: 2 } },
    team: { members: [{ name: "Bruno" }], diligencias: [], ordemDia: [], pendingTickets: [] },
  };
  const ordinaryWork = {
    ...before,
    rows: [{ Processo: "case-1", status: "done" }],
    pautaPreferences: { session: "20/11/2026" },
    pautaDaily: { Bruno: { completed: 3 } },
    team: { ...before.team, diligencias: [{ id: "d-1" }], pendingTickets: [{ id: "p-1" }] },
  };
  assert.equal(hasAdminOnlyPautaSettingsChanges(before, ordinaryWork), false);

  const changedMilestone = {
    ...ordinaryWork,
    sessionDetails: { ...before.sessionDetails, "13/11/2026": { minutasDeadline: "2026-11-12" } },
  };
  assert.equal(hasAdminOnlyPautaSettingsChanges(before, changedMilestone), true);

  const changedTeamCatalog = {
    ...before,
    team: { ...before.team, members: [{ name: "Admin added a role" }] },
  };
  assert.equal(hasAdminOnlyPautaSettingsChanges(before, changedTeamCatalog), true);
});

test("settings page, unlock, and exclusive write APIs enforce the admin boundary", async () => {
  const app = await readSource("pauta-compartilhada/src/App.tsx");
  const dialogs = await readSource("api-server/src/protected/cmt-app-dialogs.js");
  const pauta = await readSource("api-server/src/routes/pauta.ts");
  const datajud = await readSource("api-server/src/routes/datajud.ts");
  const twilio = await readSource("api-server/src/routes/twilio-messages.ts");
  const acervo = await readSource("api-server/src/routes/acervo-importado.ts");
  const rail = await readSource("api-server/src/protected/gabcmt.html");

  assert.ok(app.includes("canAccessGlobalSettings(session.role) ? <SharedPauta /> : <RestrictedSettingsPage />"));
  assert.ok(app.includes('<Route path="/configuracoes-globais" component={Home} />'));
  assert.ok(dialogs.includes("W.CMT_AUTH_SESSION?.role === 'editor'"));
  assert.ok(dialogs.includes("type: 'pauta:open-global-settings'"));
  assert.ok(dialogs.includes("/api/pauta/settings/access"));
  assert.ok(dialogs.includes("/api/pauta/settings/unlock"));
  assert.ok(dialogs.includes('type="password" autocomplete="current-password"'));
  const sharedPauta = await readSource("pauta-compartilhada/src/pages/shared-pauta.tsx");
  assert.ok(sharedPauta.includes("type === 'pauta:close-global-settings'"));
  assert.ok(sharedPauta.includes("settingsReturnLocationRef.current || '/gabinete', { replace: true }"));
  assert.ok(sharedPauta.includes("frameWindow.CMTAppDialogs.openSettings?.({ page: true })"));
  assert.ok(pauta.includes('router.get("/pauta/settings/access", requireAdministration,'));
  assert.ok(pauta.includes('router.post("/pauta/settings/unlock", requireAdministration,'));
  assert.ok(pauta.includes("process.env.ADMIN_LOGIN_PASSWORD"));
  assert.ok(!pauta.includes("process.env.GLOBAL_SETTINGS_PASSWORD"));
  assert.ok(rail.includes(".cmt-right-library-tools>#v2-rr-mintag"));
  assert.ok(pauta.includes('router.get("/pauta/sheets/status", requireAdministration,'));
  assert.ok(pauta.includes('router.post("/pauta/sheets/sync", requireAdministration,'));
  assert.ok(pauta.includes('router.put("/pauta/assuntos", requireAdministration,'));
  assert.ok(pauta.includes("hasAdminOnlyPautaSettingsChanges(current.state, protectedState.state)"));
  assert.ok(datajud.includes('router.put("/datajud/notificacoes/config", requireAdministration,'));
  assert.ok(twilio.includes('router.put("/pauta/mensagens/twilio/config", requireAdministration,'));
  assert.ok(acervo.includes('router.get("/acervo/fontes", requireAdministration,'));
  assert.ok(acervo.includes('!canAccessGlobalSettings(getAppSession(req)?.role)'));
});

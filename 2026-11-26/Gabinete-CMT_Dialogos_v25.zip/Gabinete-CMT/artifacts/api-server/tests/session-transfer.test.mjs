import fs from 'node:fs';
import vm from 'node:vm';
import test from 'node:test';
import assert from 'node:assert/strict';
const path = new URL('../src/protected/', import.meta.url);
const source = fs.readFileSync(new URL('gabcmt.html', path), 'utf8');
const script = [...source.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)].find(m => m[2].includes('function validateImport(data)'))[2];
function runtime() {
  const W = { PautaControl: {}, PautaCalendario: { render() {} } };
  const context = vm.createContext({ window: W, globalThis: W, document: { addEventListener() {} }, console, setTimeout, clearTimeout, Date, Map, Set });
  vm.runInContext(fs.readFileSync(new URL('cmt-session-transfer.js', path), 'utf8'), context);
  W.PautaControl.date = W.CMTSessionTransfer.date;
  vm.runInContext(script.replace('window.PautaSessionHub={render,', 'window.__sessionTests={validateImport,importHub,ui};window.PautaSessionHub={render,'), context);
  return { W, T: W.CMTSessionTransfer, api: W.__sessionTests };
}
const A = '04/02/2027', B = '18/02/2027', cnj = '9000001-00.2027.4.03.0000', other = '9000002-00.2027.4.03.0000';
const clone = x => JSON.parse(JSON.stringify(x));
function row(proc = cnj, session = A, item = '1') {
  return { Processo: proc, Partes: 'A × B', Assunto: 'Assunto', SERVIDOR: 'Exemplo', 'Sessão Destino': session, 'Item (Pauta de Julgamento)': item, 'Status de Julgamento': 'PAUTADO', _pautaEntries: [{ session, item, status: 'PAUTADO', closed: false }] };
}
function host(rows = []) {
  return { rows, sessions: [A, B], sessionDetails: { [A]: { date: '2027-02-04', pecoDia: '2027-01-10' }, [B]: { date: '2027-02-18' } },
    pautaPreferences: { jsonSessionLists: {} }, pautaDaily: {}, importLog: [], team: { sentinel: true }, workCalendar: { sentinel: true },
    ensureSession(s) { if (!this.sessions.includes(s)) this.sessions.push(s); this.sessionDetails[s] ||= {}; },
    ensureShape: clone, syncSessionPlans() {}, saveDeb() {}, saveNow: async () => true, notify() {} };
}
function file(rows = [row()]) {
  return { formato: 'controle-pauta-hub-sessoes', versao: 1, sessions: [A], sessionDetails: { [A]: { pecoDia: '2027-01-12', prepStart: '2027-01-18', minutasDeadline: '2027-01-28', releaseDeadline: '2027-02-02', date: '2027-02-04' } }, rows,
    pautaPreferences: { jsonSessionLists: { [A]: rows.map(r => r.Processo.replace(/\D/g, '')) } } };
}
test('exported session uses native fields and all five dates', () => {
  const { T } = runtime(), h = host([row(), row(other, B)]);
  h.sessionDetails[A] = file().sessionDetails[A];
  const data = T.payload(h, A);
  assert.equal(data.formato, 'controle-pauta-hub-sessoes');
  assert.equal(data.rows.length, 1); assert.equal(T.validate(data), data);
  for (const key of T.fields) assert.equal(data.sessionDetails[A][key], h.sessionDetails[A][key]);
  assert.equal(data.team, undefined); assert.equal(data.workCalendar, undefined);
});
test('native import is idempotent and preserves absent/blank fields and other sessions', async () => {
  const { api } = runtime(), h = host([row(), row(other, B)]);
  h.rows[0].CORRETOR = 'Corretor existente'; h.rows[0].Observações = 'Não apagar';
  const data = file(); data.rows[0].CORRETOR = ''; data.rows[0].Assunto = 'Novo assunto';
  const outside = clone(h.rows[1]), meta = clone(h.sessionDetails[B]);
  await api.importHub(h, data); const after = clone(h.rows);
  await api.importHub(h, data);
  assert.deepEqual(clone(h.rows), after); assert.deepEqual(clone(h.rows[1]), outside); assert.deepEqual(clone(h.sessionDetails[B]), meta);
  assert.equal(h.rows[0].CORRETOR, 'Corretor existente'); assert.equal(h.rows[0].Observações, 'Não apagar');
  assert.equal(h.rows[0].Assunto, 'Novo assunto');
  assert.equal(h.pautaPreferences.jsonSessionLists[A].length, 1);
  assert.deepEqual(h.team, { sentinel: true }); assert.deepEqual(h.workCalendar, { sentinel: true });
  for (const [key, value] of Object.entries(data.sessionDetails[A])) assert.equal(h.sessionDetails[A][key], value);
});
test('same item in different sessions is valid; duplicate CNJ/items and invalid dates are rejected', () => {
  const { T } = runtime(), data = file([row(), row(other, B)]);
  data.sessions.push(B); data.sessionDetails[B] = { date: '2027-02-18' }; data.pautaPreferences.jsonSessionLists[A] = [cnj.replace(/\D/g, '')];
  assert.doesNotThrow(() => T.validate(data));
  for (const bad of [
    { ...file(), rows: [row(), row()] },
    file([row(), row(other)]),
    file([{ ...row(), Processo: 'inválido' }]),
    { ...file(), sessionDetails: { [A]: { pecoDia: '2027-02-30' } } },
  ]) assert.throws(() => T.validate(bad));
});
test('preview blocks item collisions and active participation elsewhere before any mutation', async () => {
  const { T, api } = runtime(), h = host([row(other)]);
  const before = clone(h);
  assert.ok(T.preview(h, file()).blocking.length);
  await assert.rejects(() => api.importHub(h, file()));
  assert.deepEqual(clone(h), before);
  assert.ok(T.preview(host([row(cnj, B)]), file()).blocking.length);
});
test('completed links and snapshots survive draft import', () => {
  const { T } = runtime(), previous = row();
  previous._pautaEntries[0] = { session: A, item: '1', status: 'JULGADO', closed: true, julgado: true, work: { Assunto: 'Histórico' } };
  const merged = T.mergeRow(previous, row(), new Set([A]));
  assert.equal(merged._pautaEntries[0].status, 'JULGADO'); assert.equal(merged._pautaEntries[0].work.Assunto, 'Histórico');
  assert.equal(merged['Status de Julgamento'], 'JULGADO');
});
test('missing local links do not remove processes from the imported session', async () => {
  const { api } = runtime(), h = host([row(other, A, '2')]);
  h.pautaPreferences.jsonSessionLists[A] = [other.replace(/\D/g, '')];
  await api.importHub(h, file());
  assert.equal(h.rows.length, 2); assert.equal(h.pautaPreferences.jsonSessionLists[A].length, 2);
});
test('failure to acknowledge saving rejects the import', async () => {
  const { api } = runtime(), h = host(); h.saveNow = async () => false;
  await assert.rejects(() => api.importHub(h, file()), /confirm/);
});
test('native preview shows differences, five dates and unchecked team/calendar options', () => {
  const { W, T } = runtime(), h = host([row()]);
  const start = source.indexOf('  const pendingImport=ui.importPending;'), end = source.indexOf('  const clearName=', start);
  const context = vm.createContext({ window: W, h, ui: { importPending: { name: 'sessao.json', data: file() } }, esc: x => String(x ?? '') });
  const html = vm.runInContext(source.slice(start, end) + ';importDialog;', context);
  assert.match(html, /Prévia/); assert.match(html, /Peço-dia/); assert.match(html, /2027-01-12/); assert.match(html, /Campos diferentes/);
  assert.doesNotMatch(html, /name="(?:team|calendar)" checked/);
  assert.ok(T.preview(h, file()).existingProcesses);
});

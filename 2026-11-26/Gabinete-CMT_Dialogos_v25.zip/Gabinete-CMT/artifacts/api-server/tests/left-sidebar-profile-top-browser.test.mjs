import assert from "node:assert/strict";
import { readFile, mkdtemp, writeFile, rm } from "node:fs/promises";
import { spawn } from "node:child_process";
import { setTimeout as delay } from "node:timers/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import test from "node:test";
import vm from "node:vm";

const source = await readFile(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");
// Todas as folhas reais do arquivo, cada uma em sua própria <style>, para que overrides legados e ocultações valham no fixture.
const allCss = [...source.matchAll(/(?:^|\n|<\/style>|<\/script>|<\/head>|">)\s*<style\b[^>]*>([\s\S]*?)<\/style>/g)]
  .map((m) => `<style>${m[1].replace(/<\/script/gi, "")}</style>`).join("\n");
const dock = source.match(/(function profileDock\(\)\{[\s\S]*?\n  \})\n  function syncButtons/)?.[1];
assert.ok(dock, "profileDock encontrado");
const chromium = "/repl/tools/bin/chromium";
const dailyRuntime = await readFile(new URL("../src/protected/cmt-daily-workspace.js",import.meta.url),"utf8");
const dailyCss = await readFile(new URL("../src/protected/cmt-daily-workspace.css",import.meta.url),"utf8");
const cardStart = source.indexOf("  function cardHTML(member, has, self, editing, draft)");
const cardRenderer = source.slice(cardStart, source.indexOf("\n  const secHead", cardStart));
assert.ok(cardStart > 0 && cardRenderer.includes("cxp-band"), "renderizador real do crachá encontrado");

// O Chromium desta máquina trava com --dump-dom (é morto pelo timeout e devolve stdout vazio);
// a página é lida pelo protocolo DevTools, como nos demais testes de navegador do repositório.
async function aguardar(condicao, mensagem, limite = 20_000) {
  const prazo = Date.now() + limite;
  while (Date.now() < prazo) {
    if (await condicao()) return;
    await delay(100);
  }
  throw new Error(mensagem);
}

class DevTools {
  #socket; #id = 0; #pendentes = new Map();
  constructor(socket) {
    this.#socket = socket;
    socket.addEventListener("message", (event) => {
      const msg = JSON.parse(event.data);
      const pendente = msg.id && this.#pendentes.get(msg.id);
      if (!pendente) return;
      this.#pendentes.delete(msg.id);
      if (msg.error) pendente.reject(new Error(msg.error.message));
      else pendente.resolve(msg.result);
    });
  }
  send(method, params = {}) {
    const id = ++this.#id;
    const resposta = new Promise((resolve, reject) => this.#pendentes.set(id, { resolve, reject }));
    this.#socket.send(JSON.stringify({ id, method, params }));
    return resposta;
  }
  async evaluate(expression) {
    const r = await this.send("Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
    return r.result?.value;
  }
}

async function abrirNavegador(args, dir) {
  const perfil = path.join(dir, "p");
  const child = spawn(chromium, [...args, `--user-data-dir=${perfil}`, "--remote-debugging-address=127.0.0.1",
    "--remote-debugging-port=0", "about:blank"], { stdio: "ignore", detached: true });
  const fecharNavegador = async () => {
    const saiu = new Promise((resolve) => child.once("exit", resolve));
    for (const sinal of ["SIGTERM", "SIGKILL"]) {
      try { process.kill(-child.pid, sinal); } catch { child.kill(sinal); }
      if (await Promise.race([saiu.then(() => true), delay(1_500).then(() => false)])) break;
    }
  };
  try {
    let porta;
    await aguardar(async () => {
      try { porta = Number((await readFile(path.join(perfil, "DevToolsActivePort"), "utf8")).split("\n")[0]); } catch { return false; }
      return porta > 0;
    }, "o Chromium não abriu o endpoint de depuração remota");
    const alvos = await (await fetch(`http://127.0.0.1:${porta}/json/list`)).json();
    const alvo = alvos.find((item) => item.type === "page");
    assert.ok(alvo?.webSocketDebuggerUrl, "o Chromium não expôs um alvo de página");
    const socket = new WebSocket(alvo.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => {
      socket.addEventListener("open", resolve, { once: true });
      socket.addEventListener("error", reject, { once: true });
    });
    return { devtools: new DevTools(socket), fechar: async () => { socket.close(); await fecharNavegador(); } };
  } catch (erro) {
    await fecharNavegador();
    throw erro;
  }
}

test("sideLine procura o perfil em toda a barra e profileDock não reanexa o grupo à barra", () => {
  assert.match(source, /var me = \$\('#alt-side \.v2-me'\);/);
  assert.doesNotMatch(dock, /if\(group\.parentElement!==side\)side\.appendChild\(group\);\n\s*\/\* sidebar v2/);
  assert.doesNotMatch(dock, /innerHTML='<b>/, "a marca não é recriada");
});

const fixture = (collapsed) => `<!doctype html><html class="alt-on v2 cmtx-authed${collapsed ? " alt-collapsed" : ""}" data-v2-page="pauta"><head><meta charset="utf-8">
${allCss}</head><body>
<aside id="alt-side" aria-label="Painel lateral do Gabinete CMT"><div class="as-top">
<div class="as-brand"><b>Gabinete CMT</b><button type="button" class="as-collapse" data-alt="collapse" aria-label="Recolher painel">&lsaquo;</button></div>
<div class="as-who"><div class="as-avatar" data-alt="me" role="button" tabindex="0"><span class="face">MS</span></div><div class="as-whotx"><div class="as-name">MARIA SALES</div><div class="as-sub">Assessora</div></div></div>
<div class="as-session"><i></i><span>Sessão 12/06 · em 3 d</span></div></div>
<div class="as-body"><ul class="as-nav"><li class="as-sec">Trabalho</li>
<li class="as-item is-active" data-nav="pauta"><button class="as-link"><svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h10"/></svg><span class="lbl">Controle de Pauta</span></button></li>
<li class="as-item" data-nav="decisoes"><button class="as-link"><svg viewBox="0 0 24 24"><path d="M5 4h14v16H5z"/></svg><span class="lbl">Controle de Decisões</span></button></li>
<li class="as-item" data-nav="servidor"><button class="as-link"><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/></svg><span class="lbl">Servidor</span></button></li>
  </ul></div><div class="cmt-online" hidden><button title="Maria · online">MS</button><button title="Bruno · online">BR</button></div>
<button type="button" class="cmtx-logout" aria-label="Sair"><svg viewBox="0 0 24 24"><path d="M9 4H5v16h4M15 8l4 4-4 4M19 12H9"/></svg></button>
</aside>
<pre id="result" style="position:fixed;right:0;top:0;font-size:9px"></pre><script>
const D=document,W=window;
const doc=D,root=D.documentElement,R=root,$=s=>D.querySelector(s);
${dock}
const check=(c,m)=>{if(!c)throw Error(m);};
function legacy(){ /* imita sideLine: cria .v2-me só se faltar na barra inteira */
  if(!D.querySelector('#alt-side .v2-me')){const me=D.createElement('button');me.type='button';me.className='v2-me';me.innerHTML='<span class="v2-av">MS</span><span class="v2-nm"><b>Maria sales</b><small>Equipe</small></span>';me.addEventListener('click',()=>W.clicks=(W.clicks||0)+1);D.querySelector('#alt-side .as-brand').prepend(me);}
}
(async()=>{try{
  const side=D.getElementById('alt-side'),brand=D.querySelector('.as-brand'),mark=D.querySelector('.as-brand>b');
  legacy();const original=D.querySelector('.v2-me');
  for(let i=0;i<4;i++){legacy();profileDock();}
  /* um build antigo deixa no DOM a âncora de logo do frame velho; ela sai sem alterar
     o perfil ou os nós originais da navegação */
  const velhoLogo=D.createElement('div');velhoLogo.id='cmt-side-logo';velhoLogo.innerHTML='<b>Gabinete CMT</b>';side.appendChild(velhoLogo);
  legacy();profileDock();
  check(!D.getElementById('cmt-side-logo')&&!velhoLogo.isConnected,'#cmt-side-logo do frame antigo sobreviveu');
  const g=D.getElementById('cmt-profile-dock');
  const session=D.querySelector('#cmt-profile-dock>.as-session');
   const logo=D.createElement('button');logo.type='button';logo.className='v2-logo';logo.innerHTML='<span class="v2-lg-c"></span><span class="v2-lg-t"><b>Gabinete CMT</b><small>Turma Regional MS</small></span>';
  g.appendChild(logo);profileDock();
  const records=[];const mo=new MutationObserver(r=>records.push(...r));mo.observe(side,{childList:true,subtree:true});
  const parents=[g.parentElement,original.parentElement,mark.parentElement,brand.parentElement,logo.parentElement];
  for(let i=0;i<6;i++){legacy();profileDock();}
  await new Promise(r=>setTimeout(r,0));mo.disconnect();
  check(records.length===0,'reparentamento após estabilizar: '+records.length);
  check([g.parentElement,original.parentElement,mark.parentElement,brand.parentElement,logo.parentElement].every((p,i)=>p===parents[i]),'pai mudou');
  check(D.querySelectorAll('#alt-side .v2-me').length===1,'perfil duplicado');
  /* Expandido, o logo integra a faixa rosa; recolhido, volta ao slot compacto. */
   check([...D.querySelectorAll('#alt-side .as-brand>b')].filter(b=>b.textContent.trim()==='Gabinete CMT').length===1,'marca duplicada');
  check(mark.parentElement===brand&&D.querySelectorAll('#alt-side .as-brand>b').length===1,'marca movida ou duplicada');
  check(getComputedStyle(mark).display==='none','marca crua aparece na faixa');
  check(!/Menu/i.test(getComputedStyle(brand,'::before').content||''),'o rótulo Menu permaneceu');
   const compactBase=D.querySelector('#alt-side>.cmt-sidebar-brand-base');
   check(logo.parentElement===(root.classList.contains('alt-collapsed')?compactBase:g.dataset.wide==='1'?session:brand),'marca fora do slot do modo atual');
  check(session&&session.parentElement===g&&g.lastElementChild===session,'a faixa rosa não fecha o crachá');
   const presence=D.querySelector('#cmt-profile-dock .cmt-crach-presence');
   check(presence&&presence.querySelector('[data-cmt-online-count]').textContent==='2','quantidade online incorreta no crachá');
   D.querySelector('#alt-side .cmt-online').appendChild(D.createElement('button'));profileDock();
   check(presence.querySelector('[data-cmt-online-count]').textContent==='3','quantidade online não atualizou');
  check(D.querySelectorAll('#alt-side .v2-nm>b').length===1,'nome do perfil duplicado');
  check(D.querySelector('.v2-me')===original,'nós originais substituídos');
  const top=D.querySelector('#alt-side>.as-top');
  check(g.parentElement===top&&brand.parentElement===side&&top.nextElementSibling===brand&&brand.nextElementSibling===D.querySelector('#alt-side>.as-body'),'crachá, faixa e navegação fora de ordem');
  original.click();check(W.clicks===1,'evento do perfil perdido');
  const r=n=>n.getBoundingClientRect(),vis=n=>{const b=r(n);return b.width>0&&b.height>0&&getComputedStyle(n).visibility!=='hidden';};
  const nav=[...D.querySelectorAll('.as-body .as-item')].filter(vis).map(r),gr=r(g),body=D.querySelector('#alt-side>.as-body'),br=r(body),sr=r(side);
  [g,original].forEach((n,i)=>check(vis(n),'invisível #'+i+' '+JSON.stringify(r(n))));
  check(!D.querySelector('#alt-side .cal, #alt-side [data-cmtx-cal]'),'calendário operacional permanece na barra esquerda');
  check(nav.length===3,'navegação oculta');
  check(vis(D.querySelector('.as-collapse')),'controle de expansão oculto');
  check(getComputedStyle(D.querySelector('.as-item.is-active>.as-link'),'::before').display==='none','recorte antigo no item ativo');
  check(gr.bottom<=nav[0].top+1,'perfil sobrepõe a navegação');
  if(${collapsed}){
     /* recolhida, o crachá fica acima e a marca ocupa a base da barra */
     check([...side.children].every(n=>!vis(n)||n.classList.contains('as-top')||n.classList.contains('as-brand')||n.classList.contains('as-body')||n.classList.contains('cmt-sidebar-brand-base')),'faixa estranha na base da barra recolhida');
     check(vis(compactBase)&&Math.abs(r(compactBase).bottom-sr.bottom)<10,'marca não ficou na base do trilho');
     check(logo.parentElement===compactBase,'marca não foi movida para a base recolhida');
      check(getComputedStyle(logo,'::before').content.includes('JF'),'ícone da Justiça não aparece na base recolhida');
  }else{
    /* sem calendário no fim da barra, a navegação ocupa o espaço até a base */
    check(vis(body),'navegação invisível');
    check(br.bottom>=sr.bottom-2,'navegação não alcança a base');
    check([...side.children].filter(vis).pop()===body,'há faixa visível depois da navegação');
  }
  const av=r(D.querySelector('.v2-av'));check(av.top>=sr.top+2&&av.left>=sr.left,'avatar cortado no topo '+JSON.stringify(av)+JSON.stringify(gr)+JSON.stringify(r(original))+['paddingTop','height','display','flexDirection','gridTemplateRows','position'].map(k=>k+'='+getComputedStyle(g)[k]).join(',')+' me:'+['height','overflow','alignItems','flexDirection','position','top','transform'].map(k=>k+'='+getComputedStyle(original)[k]).join(',')+' av:'+['marginTop','position','top','transform'].map(k=>k+'='+getComputedStyle(D.querySelector('.v2-av'))[k]).join(','));
  check(r(original).right<=sr.right+1&&r(brand).right<=sr.right+1&&br.right<=sr.right+1,"vaza a largura");
  const wide=side.offsetWidth>150;check(g.dataset.wide===(wide?'1':'0'),'modo largo incorreto');
  check(${collapsed}?!wide:wide,'largura inesperada '+side.offsetWidth);
  check((getComputedStyle(D.querySelector('.v2-nm')).display!=='none')===wide,'nome do perfil no modo errado');
  D.getElementById('result').textContent=JSON.stringify({ok:true,width:side.offsetWidth});
}catch(e){D.getElementById('result').textContent=JSON.stringify({error:String(e)});}})();
</script></body></html>`;

for (const collapsed of [true, false]) {
  const name = collapsed ? "recolhida" : "expandida";
  test(`perfil no topo, base sem calendário e sem reparentar · barra ${name}`, async () => {
    const dir = await mkdtemp(path.join(tmpdir(), "cmt-side-"));
    let navegador;
    try {
      const file = path.join(dir, "side.html");
      await writeFile(file, fixture(collapsed));
      // 1440px: entre 761 e 1180px o CSS real força a barra recolhida.
      const args = ["--headless=new", "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage",
        "--no-first-run", "--no-default-browser-check", "--window-size=1440,900"];
      navegador = await abrirNavegador(args, dir);
      const { devtools } = navegador;
      await devtools.send("Page.enable");
      await devtools.send("Runtime.enable");
      await devtools.send("Page.navigate", { url: `file://${file}` });
      let enc;
      await aguardar(async () => {
        enc = await devtools.evaluate("document.getElementById('result')?.textContent || ''");
        return Boolean(enc);
      }, "o fixture não publicou #result", 30_000).catch(() => {});
      const dom = await devtools.evaluate("document.documentElement.outerHTML");
      assert.ok(enc, String(dom ?? "").slice(-2000));
      const result = JSON.parse(enc);
      const { data } = await devtools.send("Page.captureScreenshot", { format: "png" });
      await writeFile(`/tmp/cmt-sidebar-${collapsed ? "collapsed" : "expanded"}.png`, Buffer.from(data, "base64"));
      assert.equal(result.ok, true, JSON.stringify(result));
    } finally {
      await navegador?.fechar();
      await rm(dir, { recursive: true, force: true });
    }
  });
}

for (const width of [1440, 700]) {
  test(`banner do servidor preserva campos, edição e limites · ${width}px`, async () => {
    const dir = await mkdtemp(path.join(tmpdir(), "cmt-banner-"));
    let navegador;
    try {
      const file = path.join(dir, "banner.html");
      await writeFile(file, `<!doctype html><html class="cmtx-authed alt-on v2 cmt-srv-on"><head>${allCss}</head><body>
<main id="cmt-srv" style="position:static!important;display:block!important;width:auto!important;margin:16px!important;inset:auto!important;height:auto!important">
<dialog open id="pauta-public-profile" class="cmt-srv-embed cxp2 pfp-perfil" style="position:static!important;width:100%!important;height:auto!important;display:block!important;margin:0!important;padding:0!important;inset:auto!important;max-width:none!important;max-height:none!important"><div class="cxp-wrap"><div class="cxp-panel"></div></div></dialog></main>
<script>
const S=v=>String(v??''),E=v=>S(v).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const statusOf=()=>({tone:'ok',label:'Disponível'}),photoUrl=()=>'',initials=()=> 'PT',titleCase=S,groupLabel=()=> 'Assessoria';
const HEX=(v,f)=>v||f,BADGE_MAIN='#44484c',BADGE_SUB='#d34f89',monthYear=S,birthdayLabel=S,cpfLabel=S;
const IC={pencil:'Editar',camera:'Foto',upload:'Importar'};
${cardRenderer}
const member={name:'Pessoa de teste',personal:{origin:'Cidade/UF',birthday:'01/01',possession:'2020-01-01',cabinet:'2021-01-01',rf:'Teste',ramal:'0000',contact:'Contato de teste'}};
window.renderBadge=editing=>document.querySelector('.cxp-panel').innerHTML=cardHTML(member,true,true,editing,{});
renderBadge(false);
</script></body></html>`);
      navegador = await abrirNavegador(["--headless=new", "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage",
        "--no-first-run", "--no-default-browser-check", `--window-size=${width},900`], dir);
      const { devtools } = navegador;
      await devtools.send("Page.enable");
      await devtools.send("Page.navigate", { url: `file://${file}` });
      await aguardar(() => devtools.evaluate("!!document.querySelector('.cxp-card .cxp-band')"), "banner não renderizou");
      await devtools.evaluate("new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))");
      assert.ok(await devtools.evaluate("document.querySelector('.cxp-card').checkVisibility({checkOpacity:true,checkVisibilityCSS:true})"), "banner realmente visível");
      const measure = () => devtools.evaluate(`(()=>{
        const rect=s=>{const r=document.querySelector(s).getBoundingClientRect();return {left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width};};
        return {card:rect('.cxp-card'),wrap:rect('.cxp-wrap'),photo:rect('.cxp-photo'),facts:rect('.cxp-facts'),band:rect('.cxp-band'),fields:document.querySelectorAll('.cxp-fact').length};
      })()`);
      const view = await measure();
      assert.equal(view.fields, 8, "todos os dados existentes continuam visíveis");
      assert.ok(view.card.width > view.wrap.width * .95, `perfil ocupa a largura do conteúdo: ${JSON.stringify(view)}`);
      for (const part of [view.photo, view.facts, view.band]) {
        assert.ok(part.left >= view.card.left - 1 && part.right <= view.card.right + 1, `conteúdo fora do banner: ${JSON.stringify(view)}`);
      }
      assert.ok(Math.abs(view.band.bottom - view.card.bottom) < 3, "faixa rosa encerra o banner");
      if (process.env.CMT_PROFILE_CAPTURE) {
        const shot = await devtools.send("Page.captureScreenshot", { format: "png" });
        await writeFile(`${process.env.CMT_PROFILE_CAPTURE}-${width}.png`, Buffer.from(shot.data, "base64"));
      }
      await devtools.evaluate("renderBadge(true)");
      const edit = await measure();
      assert.equal(edit.fields, 10, "campos e personalização preservados na edição");
      assert.ok(edit.facts.right <= edit.card.right + 1, "formulário de edição cabe no banner");
    } finally {
      await navegador?.fechar();
      await rm(dir, { recursive: true, force: true });
    }
  });
}

test("Meu dia e entregas ficam na base esquerda; calendário atualiza sem duplicá-los no rodapé",async()=>{
  const dir=await mkdtemp(path.join(tmpdir(),"cmt-daily-"));let navegador;
  try {
    const file=path.join(dir,"daily.html");
    const base=fixture(false).split('<pre id="result"')[0];
    await writeFile(file,`${base}<style>${dailyCss}</style>
<section style="position:fixed;top:30px;left:300px;width:750px;padding:16px;background:#f4f7f8"><div data-daily-calendar></div></section>
<script>
window.sample={temEu:true,P:{feitas:1,meta:3,entregues:[{proc:'111',tipo:'Minuta'}],outras:[]},meuFeito:[{proc:'111'}],meuCurso:[],entregues:[{proc:'111',srv:'ANA',tipo:'Minuta'},{proc:'222',srv:'BEATRIZ',tipo:'Monocrática'}]};
window.CMTRail={dailyData:()=>window.sample};window.PautaApp={};window.PautaControl={today:()=> '2026-11-06'};
window.PautaPublicCalendar={events:()=>[{kind:'milestone',title:'Entrega das minutas · sessão A',start:'2026-11-06',end:'2026-11-06'},{kind:'event',title:'Evento do gabinete',start:'2026-11-06',end:'2026-11-06'}]};
${dailyRuntime}
</script></body></html>`);
    navegador=await abrirNavegador(["--headless=new","--no-sandbox","--disable-gpu","--disable-dev-shm-usage","--window-size=1440,900"],dir);
    const {devtools}=navegador;
    await devtools.send("Page.enable");await devtools.send("Page.navigate",{url:`file://${file}`});
    await aguardar(()=>devtools.evaluate("document.querySelector('[data-daily-count=\"deliveries\"]')?.textContent==='2'"),"resumo diário não montou");
    const state=await devtools.evaluate(`(()=>{
      const r=s=>{const x=document.querySelector(s).getBoundingClientRect();return {top:x.top,bottom:x.bottom,left:x.left,right:x.right};};
      return {side:r('#alt-side'),badge:r('#alt-side>.as-top'),dock:r('#cmt-sidebar-day'),nav:r('.as-body'),firstNav:r('.as-body .as-sec'),my:document.querySelector('[data-daily-my]').textContent,all:document.querySelector('[data-daily-deliveries]').textContent,calendar:document.querySelector('[data-daily-calendar]').textContent,sideBg:getComputedStyle(document.querySelector('#alt-side')).backgroundImage,navFlex:getComputedStyle(document.querySelector('.as-body')).flexGrow};
    })()`);
    assert.ok(state.nav.bottom<=state.dock.top+1,"navegação não sobrepõe os painéis da base");
    assert.ok(Math.abs(state.side.bottom-state.dock.bottom)<3,"painéis ancorados na base da barra");
    assert.ok(state.firstNav.top-state.badge.bottom<14,"espaço vazio entre o crachá e a navegação");
    assert.equal(state.navFlex,"0","a navegação não deve esticar sob o crachá");
    assert.match(state.sideBg,/linear-gradient/,"a barra não recebe o degradê de cima para baixo");
    assert.match(state.my,/111/);assert.doesNotMatch(state.my,/222/);
    assert.match(state.all,/ANA/);assert.match(state.all,/BEATRIZ/);
    assert.match(state.calendar,/Entrega das minutas/);assert.match(state.calendar,/Evento do gabinete/);
    assert.doesNotMatch(state.calendar,/Meu dia|Entregas do dia/);
    await devtools.evaluate("window.sample.entregues.push({proc:'333',srv:'BEATRIZ',tipo:'Diligência'});document.dispatchEvent(new Event('pauta:updated'))");
    await aguardar(()=>devtools.evaluate("document.querySelector('[data-daily-count=\"deliveries\"]').textContent==='3'"),"entregas não atualizam");
    await devtools.evaluate("document.documentElement.classList.add('alt-collapsed');window.dispatchEvent(new Event('resize'))");
    await aguardar(()=>devtools.evaluate("document.querySelector('#cmt-sidebar-day').dataset.compact==='1'"),"base não acompanha a barra recolhida");
     assert.equal(await devtools.evaluate("getComputedStyle(document.querySelector('#cmt-sidebar-day')).display"),"none","ícones de Meu dia e Entregas continuam visíveis na barra recolhida");
     assert.notEqual(await devtools.evaluate("getComputedStyle(document.querySelector('#cmt-sidebar-notifications-launch')).display"),"none","atalho de Notificações também desapareceu");
    await devtools.evaluate("window.sample={...window.sample,P:null,temEu:false,meuFeito:[],meuCurso:[]};window.CMTDailyWorkspace.refresh()");
    await aguardar(()=>devtools.evaluate("document.querySelector('[data-daily-my]').textContent.includes('Entre com sua conta')"),"conteúdo pessoal não é limpo ao sair");
     await devtools.evaluate("document.documentElement.classList.remove('alt-collapsed');window.dispatchEvent(new Event('resize'))");
     await aguardar(()=>devtools.evaluate("document.querySelector('#cmt-sidebar-day').dataset.compact==='0'"),"painel diário não atualizou ao reabrir a barra");
     assert.notEqual(await devtools.evaluate("getComputedStyle(document.querySelector('#cmt-sidebar-day')).display"),"none","Meu dia e Entregas não voltaram ao expandir");
  } finally {await navegador?.fechar();await rm(dir,{recursive:true,force:true});}
});

for(const width of [1440,900]){
  test(`Prontuário integrado e Centro Operacional padronizado em ${width}px`,async()=>{
    const sideRuntime=await readFile(new URL("../src/protected/cmt-pauta-side-panel.js",import.meta.url),"utf8");
    const sideCss=await readFile(new URL("../src/protected/cmt-pauta-side-panel.css",import.meta.url),"utf8");
    const aside=source.match(/<aside id="pq-side-panel"[\s\S]*?<\/aside>/)?.[0];
    const setterStart=source.indexOf("    _cmtSetRoot(html){"),setterEnd=source.indexOf("    sheetTable(",setterStart);
    const setter=source.slice(setterStart,setterEnd);
    assert.ok(aside,"moldura vem do renderizador real da Pauta");
    const begin=source.indexOf("  const cpTag ="),end=source.indexOf("  function pintaPainel()",begin);
    const escape=v=>String(v??"").replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const markup=vm.runInNewContext(`${source.slice(begin,end)};painelHTML()`,{
      window:{__cmtOD2:{modeloDiaCompleto:()=>({pessoas:[],itens:[{srv:"ANA",proc:"111",duv:[{}],sess:{rot:"13/11"}},{srv:"",proc:"222",duv:[],sess:{rot:"13/11"}}],semResp:1,ativas:[{rot:"13/11",entrega:"2026-11-10",semSrv:1}]})}},
      S:v=>String(v??""),K:v=>String(v??"").toUpperCase(),me:()=>"ANA",today:()=>"2026-11-06",title:v=>String(v),esc:escape,
    });
    const dir=await mkdtemp(path.join(tmpdir(),"cmt-operational-"));let browser;
    try{
      const file=path.join(dir,"panels.html");
      await writeFile(file,`<!doctype html><html class="v2 cmtx-authed cmt-center-panels-open" data-v2-page="pauta" lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
${allCss}<style>${dailyCss}${sideCss}
body{margin:0!important;padding:20px!important;background:#edf1ed}
#controle-pauta-root{position:static!important;display:block!important}
.test-head{height:55px;color:#fff;background:#214e3a;padding:10px;box-sizing:border-box}
.test-filters{height:36px;background:#fff;margin-bottom:8px}
#cmt-center-panels{position:relative!important;display:block!important;inset:auto!important;width:100%!important;height:auto!important;margin-top:20px!important}
#cmt-center-panels .cmt-center-panel-content{height:auto!important;max-height:none!important}
</style></head><body>
<div id="controle-pauta-root"><div class="pc-pauta"><header class="test-head">Pauta de Julgamento · sessão 13/11</header><section class="pc-card pc-sheet-card"><div class="test-filters">Filtros da sessão</div><div class="pq-side-workspace">${aside}<div class="pq-side-list"><div style="height:360px;background:white;padding:12px">Lista da sessão · espaço de trabalho<button type="button" id="native-control">Ação da lista</button></div></div></div></section></div></div>
<section id="cmt-center-panels" data-active="painel"><div class="cmt-center-panel-content"><div class="cp-grade">${markup}</div></div></section>
<script>window.PautaApp={};window.PautaControl={today:()=> '2026-11-06'};window.PautaPublicCalendar={events:()=>[{kind:'milestone',title:'Prazo de minutas · sessão 13/11',start:'2026-11-06',end:'2026-11-06'},{kind:'event',title:'Reunião da equipe',start:'2026-11-06',end:'2026-11-06'}]};
window.originalQP=document.createElement('aside');originalQP.id='alt-qp';originalQP.hidden=true;originalQP.innerHTML='<header class="qp-h"><strong>Processo 111</strong></header><textarea id="test-note">Texto inicial</textarea>';document.body.append(originalQP);
window.originalGenerator=document.createElement('section');originalGenerator.id='cmt-ger';originalGenerator.hidden=true;originalGenerator.innerHTML='<textarea id="test-draft">Minuta em edição</textarea>';document.body.append(originalGenerator);
window.qpOpen=false;window.CMTProntuario={isOn:()=>qpOpen,open:()=>{qpOpen=true;originalQP.hidden=false;}};
window.nativeReplace=({${setter}})._cmtSetRoot;
${sideRuntime}\n${dailyRuntime}</script></body></html>`);
      browser=await abrirNavegador(["--headless=new","--no-sandbox","--disable-gpu","--disable-dev-shm-usage",`--window-size=${width},1050`],dir);
      const {devtools}=browser;await devtools.send("Page.enable");await devtools.send("Page.navigate",{url:`file://${file}`});
      await aguardar(()=>devtools.evaluate("document.querySelectorAll('.dw-date').length===42&&document.querySelector('.pq-side-workspace')?.dataset.collapsed==='false'"),"painéis não montaram");
      const measure=()=>devtools.evaluate(`(()=>{
        const rect=s=>{const r=document.querySelector(s).getBoundingClientRect();return {left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height};};
        return {side:rect('#pq-side-panel'),list:rect('.pq-side-list'),head:rect('.test-head'),filters:rect('.test-filters'),empty:document.querySelector('#pq-side-body').childNodes.length,notif:rect('.cp-notif-column'),cal:rect('.cp-calendar-column'),bell:rect('.cp-bell'),calTitle:rect('.dw-cal-head h3'),nav:rect('.dw-cal-nav'),scroll:document.documentElement.scrollWidth,viewport:innerWidth};
      })()`);
      const before=await measure();
      assert.equal(before.empty,1,"painel recebe um único Prontuário");
      assert.ok(before.side.height>=360,"altura do painel ampliada");
      assert.ok(await devtools.evaluate("document.querySelector('#pq-side-body>#alt-qp')===originalQP&&!originalQP.hidden&&document.querySelector('#pq-generator-host>#cmt-ger')===originalGenerator"),"mesmos nós do Prontuário e Gerador no painel");
      assert.ok(await devtools.evaluate("originalQP.getBoundingClientRect().height>100&&originalQP.getBoundingClientRect().width>200&&getComputedStyle(originalQP.querySelector('.qp-h')).position==='sticky'"),"conteúdo do Prontuário visível e cabeçalho do processo fixo");
      assert.ok(await devtools.evaluate("document.querySelector('#test-note')?.getBoundingClientRect().height>0&&document.querySelector('#test-note')?.value==='Texto inicial'"),"campos editáveis continuam visíveis dentro do Prontuário");
      const recordHeight=await devtools.evaluate("originalQP.getBoundingClientRect().height");
      await devtools.evaluate("originalGenerator.hidden=false");
      assert.ok(await devtools.evaluate("originalGenerator.getBoundingClientRect().height>100&&originalQP.getBoundingClientRect().height<"+recordHeight),"Gerador abre dentro da mesma coluna sem expulsar a ficha");
      await devtools.evaluate("originalGenerator.hidden=true");
      assert.ok(before.side.top>=before.filters.bottom,"painel fica abaixo dos filtros e do cabeçalho");
      assert.ok(width>1000?before.side.right<=before.list.left:before.side.bottom<=before.list.top,"posição lateral ou responsiva correta");
      assert.ok(before.bell.height>=28&&before.calTitle.height>=28,"títulos dos dois painéis legíveis");
      assert.ok(before.nav.width>200,"navegação do calendário não foi comprimida");
      assert.ok(before.cal.right<=before.viewport+1,"calendário não escapa da tela");
      await devtools.evaluate(`(()=>{
        const note=document.getElementById('test-note');note.value='Anotação não salva';note.focus();note.setSelectionRange(3,9);document.getElementById('test-draft').value='Rascunho preservado';
        const root=document.getElementById('controle-pauta-root'),template=document.createElement('template');template.innerHTML=root.innerHTML;template.content.querySelectorAll('#alt-qp,#cmt-ger').forEach(n=>n.remove());
        nativeReplace.call({root},template.innerHTML);
      })()`);
      assert.ok(await devtools.evaluate("document.querySelectorAll('#alt-qp').length===1&&document.querySelectorAll('#cmt-ger').length===1&&document.getElementById('alt-qp')===originalQP&&document.getElementById('cmt-ger')===originalGenerator"),"re-renderizar preserva identidade dos painéis, sem clones");
      assert.ok(await devtools.evaluate("document.activeElement===document.getElementById('test-note')&&document.activeElement.value==='Anotação não salva'&&document.activeElement.selectionStart===3&&document.getElementById('test-draft').value==='Rascunho preservado'"),"formulário, foco, seleção do texto e rascunho preservados");
      await devtools.evaluate("document.querySelector('[data-pq-side-toggle]').click()");
      await aguardar(()=>devtools.evaluate("document.querySelector('[data-pq-side-toggle]').getAttribute('aria-expanded')==='false'"),"painel não recolhe");
      const after=await measure();
      assert.deepEqual(after.head,before.head,"recolher não desloca o cabeçalho");
      assert.deepEqual(after.filters,before.filters,"recolher não desloca os filtros");
      assert.ok(after.side.width<=50,"recolher deixa um acionador estreito também em telas responsivas");
      assert.ok(await devtools.evaluate("document.querySelector('#pq-side-body').hidden"));
      await devtools.evaluate(`(()=>{
        const root=document.getElementById('controle-pauta-root'),template=document.createElement('template');template.innerHTML=root.innerHTML;template.content.querySelectorAll('#alt-qp,#cmt-ger').forEach(n=>n.remove());
        nativeReplace.call({root},template.innerHTML);
      })()`);
      await aguardar(()=>devtools.evaluate("document.querySelector('[data-pq-side-toggle]').getAttribute('aria-expanded')==='false'&&document.querySelector('#pq-side-body').hidden"),"re-renderizar a lista não preserva o painel recolhido");
      await devtools.evaluate(`window.changes=0;new MutationObserver(xs=>window.changes+=xs.length).observe(document.querySelector('#controle-pauta-root'),{childList:true,subtree:true,attributes:true});window.CMTPautaSidePanel.refresh()`);
      await delay(80);
      assert.equal(await devtools.evaluate("window.changes"),0,"reconciliação estável não reescreve o DOM");
      await devtools.evaluate("document.querySelector('[data-pq-side-toggle]').click()");
      await aguardar(()=>devtools.evaluate("document.querySelector('[data-pq-side-toggle]').getAttribute('aria-expanded')==='true'"),"painel não reabre");
      await devtools.evaluate("document.documentElement.dataset.v2Page='serv-user'");
      assert.equal(await devtools.evaluate("getComputedStyle(document.querySelector('#pq-side-panel')).display"),"none","o painel não aparece em outras páginas");
      await devtools.evaluate("document.documentElement.dataset.v2Page='pauta';document.dispatchEvent(new Event('cmt:route'))");
      if(width===1440){
        const shot=await devtools.send("Page.captureScreenshot",{format:"png",captureBeyondViewport:false});
        await writeFile("/tmp/cmt-operational-center-1440.png",Buffer.from(shot.data,"base64"));
      }
    }finally{await browser?.fechar();await rm(dir,{recursive:true,force:true});}
  });
}

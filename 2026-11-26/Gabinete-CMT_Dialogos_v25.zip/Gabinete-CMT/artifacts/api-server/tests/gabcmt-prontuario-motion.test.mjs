import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";
import vm from "node:vm";
import { prepareProntuarioMotionDocument } from "../src/lib/gabcmt-prontuario-motion.ts";

const html = fs.readFileSync(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");

test("reopening the same process reuses its DOM and defers expensive content", () => {
  const prepared = prepareProntuarioMotionDocument(html);
  const script = prepared.match(/<script\b[^>]*id="alt-shell-script"[^>]*>([\s\S]*?)<\/script>/)[1];
  assert.match(script, /paintGroup===g&&paintKey===key&&p\.firstChild/);
  assert.match(script, /paintRevision\]\)/);
  assert.doesNotMatch(script, /JSON\.stringify\(\[rowForGroup\(current\)/);
  assert.match(script, /if\(deferHeavy\).*requestIdleCallback/s);
  assert.match(script, /keyOf\(active\)===targetKey/);
  assert.match(script, /if\(el&&!el\.hidden\)el\.hidden=true/);
  assert.match(prepared, /@keyframes cmt-qp-enter/);
  assert.doesNotThrow(() => new vm.Script(script));
  assert.doesNotMatch(script, /if \(on && \(changed \|\| moved\)\) requestAnimationFrame\(geo\)/);
  assert.equal(prepared.split('id="cmt-prontuario-motion-v1"').length - 1, 1);
  assert.equal(prepareProntuarioMotionDocument(prepared), prepared);
});

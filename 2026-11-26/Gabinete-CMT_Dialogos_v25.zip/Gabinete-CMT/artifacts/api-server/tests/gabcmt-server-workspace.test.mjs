import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";
import test from "node:test";
import { prepareServerFooterDocument } from "../src/lib/gabcmt-server-footer.ts";
import { prepareServerLayoutDocument } from "../src/lib/gabcmt-server-layout.ts";

const html = fs.readFileSync(new URL("../src/protected/gabcmt.html", import.meta.url), "utf8");
const prepared = prepareServerLayoutDocument(prepareServerFooterDocument(html));

test("Campo do Servidor owns a native standard footer", () => {
  assert.ok(prepared.includes("['pauta','decisoes','triagem','servidor'].filter"));
  assert.ok(prepared.includes("servidor:'Rodapé do Campo do Servidor'"));
  const source = prepared.match(/<script\b[^>]*id="cmt-v280-page-footers"[^>]*>([\s\S]*?)<\/script>/)[1];
  const page = source.slice(source.indexOf("function page()"), source.indexOf("\nfunction hide("));
  const context = {
    R: { classList: { contains: key => key === "cmt-srv-on" } },
    B: {}, D: {}, window: {},
  };
  assert.equal(vm.runInNewContext(`(${page})()`, context), "servidor");
  assert.ok(prepared.includes("const footer = activePage\n"));
  assert.ok(!prepared.includes("const footer = activePage && activePage !== 'servidor'"));
});

test("server-only legacy footer hiding and positioning are retired", () => {
  for (const style of prepared.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style>/g)) {
    if (style[0].includes('id="cmt-server-standard-footer-css"')) continue;
    for (const rule of style[1].matchAll(/([^{}]+)\{([^{}]*)\}/g)) {
      assert.ok(!(rule[1].includes("#pauta-global-dock") && /cmt-srv-on|data-cmt-frame-page="servidor"/.test(rule[1])), rule[1]);
    }
  }
  assert.ok(prepared.includes("#cmt-footer-pending"), "shared Pendências stays available");
});

test("server presentation transforms preserve scripts and are idempotent", () => {
  assert.equal(prepareServerLayoutDocument(prepareServerFooterDocument(prepared)), prepared);
  assert.equal(prepared.split('id="cmt-srv-layout-v2-css"').length - 1, 1);
  assert.ok(prepared.indexOf('id="cmt-srv-layout-v2-css"') < prepared.lastIndexOf("</body>"));
  for (const script of prepared.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)) {
    if (/type=["']application\/json|type=["']application\/octet-stream|\bsrc=/.test(script[1])) continue;
    assert.doesNotThrow(() => new vm.Script(script[2]), script[1]);
  }
});

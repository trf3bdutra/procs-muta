# Contas individuais do Gabinete CMT

Não existe cadastro público nem botão para criar contas no app. Apenas o proprietário do projeto pode solicitar **aqui** um convite, informando endereço de e-mail, perfil (Equipe ou Administração) e, para Equipe, um servidor da lista fixa. O servidor só lê convites registrados por este projeto; criar uma identidade diretamente no provedor não dá acesso à pauta. O convite exige que o destinatário ative a conta e verifique o e-mail; depois a Administração a aprova no painel **Gerenciar contas**. Nenhuma pessoa recebe dados da pauta antes da aprovação.

O perfil **Editor** tem os mesmos poderes administrativos da Administração e mantém sua identidade de servidor. Ele é reservado exclusivamente à conta já vinculada a BRUNO; outras contas não podem receber esse perfil. Editor usa a credencial exclusiva `BDUTRA_LOGIN_PASSWORD`, aparece como BRUNO no seletor de servidores e mantém acesso ao próprio perfil. A senha da Administração continua separada em `ADMIN_LOGIN_PASSWORD`; alterá-la não troca a senha do Editor. Promover ou reconfigurar a conta invalida as sessões atuais. As contas de Administração existentes permanecem independentes e inalteradas.

O cadastro da conta **não solicita nem armazena senhas no projeto**: o destinatário define a senha pela página do convite. Esqueci a senha fica disponível na tela de entrada. O acesso antigo por senhas compartilhadas não funciona mais. A senha das Configurações Globais continua distinta e só é solicitada a administradores.

## Convite sob solicitação do proprietário

Estas instruções são para o agente do projeto executar **somente após** o proprietário informar o destinatário e autorizar o envio do convite. Executar no ambiente correto; o comando envia e-mail e não pode ser desfeito após a entrega.

1. Informe e confirme e-mail, perfil e servidor (quando for Equipe).
2. Execute no desenvolvimento: `NODE_ENV=development pnpm --filter @workspace/api-server run account:provision -- --environment=development --action=invite --email=ENDERECO --role=equipe --server=RODRIGO`. Para o administrador inicial, use `--role=administracao` e não indique servidor. Não use endereços fictícios.
3. O convite chega pelo provedor ao e-mail indicado. A pessoa abre o link e verifica a própria conta. Antes da aprovação, o acesso fica pendente.
4. Para conceder a **primeira** Administração, **após confirmação do e-mail pelo destinatário**, o proprietário solicita a execução de `NODE_ENV=development pnpm --filter @workspace/api-server run account:provision -- --environment=development --action=bootstrap --email=ENDERECO`. O comando localiza **somente** esse e-mail principal verificado na instância de desenvolvimento. Um registro permanente impede que repetir o comando restaure acesso revogado ou promova outra pessoa. Não há regra de "primeiro usuário a entrar".
5. A Administração ativa usa **Gerenciar contas** para aprovar os convites recebidos e ajustar ou desativar membros. Ela não cria convites. Um servidor só pode estar vinculado a uma conta por ambiente; para realocar, desvincule-o antes. A última Administração ativa não pode ser removida.

Para o ambiente publicado, é necessário publicar por decisão do proprietário e **então** repetir o convite e o bootstrap com `NODE_ENV=production --environment=production`, a chave de produção e `--activation-url=https://DOMINIO_PUBLICADO/ativar` obtida da configuração real do deploy. Desenvolvimento e produção têm identidades do provedor separadas; um login feito no desenvolvimento não existe automaticamente em produção. Não transportar IDs de usuário ou copiar tabelas de contas entre ambientes. Se houver banco compartilhado, o campo `environment` mantém os registros distintos.

## Verificação segura

- Sem sessão ou com cookie antigo, `/api/auth/session`, `/api/app/gabcmt`, dados, eventos e operações de gravação negam acesso. `/api/auth/login` e `/api/auth/logout` respondem 410; a sessão individual é encerrada pelo provedor.
- Um usuário do provedor sem convite emitido por este projeto permanece sem conta do Gabinete. Convite sem confirmação de e-mail ou pendente/desativado não lê dados. Administração e servidor vinculado sempre são resolvidos no banco no servidor, nunca em campos enviados pelo navegador.
- Desativar uma conta fecha suas conexões de eventos e sua próxima solicitação é recusada. No navegador, os dados e o iframe são descartados; rascunhos de outra pessoa não são salvos na troca de conta.
- As informações judiciais permanecem nas tabelas existentes da pauta; criar contas não as migra nem as apaga.

**Nota sobre o provedor:** ocultar o cadastro público no app e exigir convite no servidor não altera necessariamente a configuração de autoinscrição do provedor de identidade. Mesmo que uma pessoa crie uma identidade de autenticação diretamente nele, sem convite do proprietário e aprovação ela não cria conta do Gabinete nem acessa a pauta. Se o proprietário exigir impedir também a criação de identidades externas no próprio provedor, isso é uma configuração separada do provedor que requer acesso administrativo apropriado.

import path from 'path';
import { readFileSync, statSync } from 'node:fs';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { defineConfig, type Plugin } from 'vite';

import runtimeErrorOverlay from '@replit/vite-plugin-runtime-error-modal';

const rawPort = process.env.PORT;

if (!rawPort) {
  throw new Error(
    'PORT environment variable is required but was not provided.',
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const basePath = process.env.BASE_PATH;

if (!basePath) {
  throw new Error(
    'BASE_PATH environment variable is required but was not provided.',
  );
}

const buildId = Date.now().toString(36);

function legacyLoginPagePlugin(): Plugin {
  const sourcePath = path.resolve(import.meta.dirname, 'src', 'auth-login-template.html');
  let cached: { mtimeMs: number; html: string } | null = null;
  const createLoginPage = () => {
    const { mtimeMs } = statSync(sourcePath);
    if (cached?.mtimeMs === mtimeMs) return cached.html;
    const html = readFileSync(sourcePath, 'utf8');
    if (!html.includes('id="cmtx-sign-in-mount"') || /H_PIN|H_ADMIN|authLocal/i.test(html)) {
      throw new Error('A página de acesso separada está ausente ou contém autenticação legada.');
    }
    cached = { mtimeMs, html };
    return cached.html;
  };
  return {
    name: 'gabinete-existing-login-page',
    configureServer(server) {
      server.middlewares.use('/auth-login.html', (_request, response, next) => {
        try {
          response.statusCode = 200;
          response.setHeader('Content-Type', 'text/html; charset=utf-8');
          response.setHeader('Cache-Control', 'no-store');
          response.end(createLoginPage());
        } catch (error) {
          next(error instanceof Error ? error : new Error(String(error)));
        }
      });
    },
    generateBundle() {
      this.emitFile({ type: 'asset', fileName: 'auth-login.html', source: createLoginPage() });
    },
  };
}

function publicSafeAssetsPlugin(): Plugin {
  const contentTypes: Record<string, string> = {
    'logo.svg': 'image/svg+xml', 'favicon.svg': 'image/svg+xml',
    'manifest.webmanifest': 'application/manifest+json',
    'service-worker.js': 'text/javascript; charset=utf-8',
    'apple-touch-icon.png': 'image/png', 'pwa-192.png': 'image/png', 'pwa-512.png': 'image/png',
    'robots.txt': 'text/plain; charset=utf-8',
    'cmt-brand/command/banner_acervo.svg': 'image/svg+xml',
    'cmt-brand/command/banner_painel.svg': 'image/svg+xml',
    'cmt-brand/command/banner_referencias.svg': 'image/svg+xml',
    'cmt-brand/command/banner_tarefas.svg': 'image/svg+xml',
    'cmt-brand/command/banner_relatorios.svg': 'image/svg+xml',
    'cmt-brand/command/banner_recursos.svg': 'image/svg+xml',
    'cmt-brand/command/banner_regimento.svg': 'image/svg+xml',
    'cmt-brand/command/banner_competencia.svg': 'image/svg+xml',
  };
  const baseSegments = basePath.split('/').filter(Boolean);
  const basePrefix = baseSegments.length ? `/${baseSegments.join('/')}/` : '/';
  return {
    name: 'gabinete-allowlisted-static-assets',
    configureServer(server) {
      server.middlewares.use((request, response, next) => {
        const pathname = decodeURIComponent(new URL(request.url ?? '/', 'http://vite.local').pathname);
        // Neither source HTML nor its old login screen may bypass membership via Vite.
        if (pathname.includes('pauta-original.html')) {
          response.statusCode = 404;
          response.end('Not found');
          return;
        }
        const filename = pathname.startsWith(basePrefix)
          ? pathname.slice(basePrefix.length)
          : pathname.replace(/^\/+/, '');
        if (!(filename in contentTypes)) { next(); return; }
        response.setHeader('Content-Type', contentTypes[filename]);
        if (filename === 'manifest.webmanifest' || filename === 'service-worker.js') {
          response.setHeader('Cache-Control', 'no-cache');
        }
        response.end(readFileSync(path.resolve(import.meta.dirname, 'public', filename)));
      });
    },
    generateBundle() {
      for (const filename of Object.keys(contentTypes)) {
        this.emitFile({ type: 'asset', fileName: filename,
          source: readFileSync(path.resolve(import.meta.dirname, 'public', filename)) });
      }
    },
  };
}

export default defineConfig({
  base: basePath,
  publicDir: false,
  define: {
    __PAUTA_BUILD__: JSON.stringify(buildId),
  },
  plugins: [
    legacyLoginPagePlugin(),
    publicSafeAssetsPlugin(),
    react(),
    tailwindcss({ optimize: false }),
    runtimeErrorOverlay(),
    ...(process.env.NODE_ENV !== 'production' &&
    process.env.REPL_ID !== undefined
      ? [
          await import('@replit/vite-plugin-cartographer').then((m) =>
            m.cartographer({
              root: path.resolve(import.meta.dirname, '..'),
            }),
          ),
          await import('@replit/vite-plugin-dev-banner').then((m) =>
            m.devBanner(),
          ),
        ]
      : []),
  ],
  resolve: {
    alias: {
      '@': path.resolve(import.meta.dirname, 'src'),
      '@assets': path.resolve(
        import.meta.dirname,
        '..',
        '..',
        'attached_assets',
      ),
    },
    dedupe: ['react', 'react-dom'],
  },
  root: path.resolve(import.meta.dirname),
  build: {
    outDir: path.resolve(import.meta.dirname, 'dist/public'),
    emptyOutDir: true,
  },
  server: {
    port,
    strictPort: true,
    host: '0.0.0.0',
    allowedHosts: true,
    fs: {
      strict: true,
      deny: ['**/pauta-original.html'],
    },
  },
  preview: {
    port,
    host: '0.0.0.0',
    allowedHosts: true,
  },
});

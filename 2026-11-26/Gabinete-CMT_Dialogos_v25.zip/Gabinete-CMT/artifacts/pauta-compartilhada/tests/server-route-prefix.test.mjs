import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import test from "node:test";
import {
  applySharedPautaRoute,
  gabCmtRouteForLocation,
  locationForGabCmtPage,
  shellPathForEmbeddedPage,
  shellPathForEmbeddedRoute,
} from "../src/lib/shared-pauta-startup.ts";
import { profilePathForLoggedInServer } from "../src/lib/server-profile-route.ts";

test("o endereço único do servidor só é gerado para a sessão autenticada", () => {
  assert.equal(profilePathForLoggedInServer("BRUNO", "Bruno"), "/serv-user");
  assert.equal(profilePathForLoggedInServer("JOSÉ", "Jose"), "/serv-user");
  assert.equal(profilePathForLoggedInServer("RODRIGO", "Bruno"), null);
  assert.equal(profilePathForLoggedInServer("BRUNO", null), null);
});

test("a página do servidor tem rota canônica própria dentro do shell GabCMT", () => {
  const app = readFileSync(new URL("../src/App.tsx", import.meta.url), "utf8");
  for (const path of [
    "/pauta",
    "/mono",
    "/session",
    "/repertorio",
    "/diretrizes-e-fluxos",
    "/controle-de-pauta",
    "/controle-de-decisoes",
    "/controle-de-triagem",
    "/configuracoes-globais",
    "/serv-user",
  ]) assert.ok(app.includes(`path="${path}"`), `rota ausente: ${path}`);
  assert.ok(app.includes('<Route path="/ementario" component={LegacyGabinetePageRedirect} />'));
  assert.ok(app.includes('<Route path="/servidor" component={LegacyServerProfileRedirect} />'));
  assert.match(app, /function LegacyServerProfileRedirect\(\)[\s\S]*?navigate\('\/serv-user', \{ replace: true \}\)/);
  assert.doesNotMatch(app, /ServerProfilePage|AuthenticatedServerProfile|ServerProfileRoute/);
  assert.equal(existsSync(new URL("../src/pages/server-profile-page.tsx", import.meta.url)), false);
  assert.match(app, /navigate\('\/gabinete', \{ replace: true \}\)/);
});

test("endereços antigos de servidores levam ao perfil do usuário da sessão", () => {
  const app = readFileSync(new URL("../src/App.tsx", import.meta.url), "utf8");
  assert.match(app, /<Route path="\/serv-:serverSlug" component={LegacyServerRoute} \/>/);
  assert.match(app, /navigate\('\/serv-user', \{ replace: true \}\)/);
  assert.doesNotMatch(app, /<Route path="\/serv-:serverSlug" component={ServerProfileRoute} \/>/);
});

test("o login padrão abre o Gabinete e mantém as páginas internas na rota única", () => {
  const app = readFileSync(new URL("../src/App.tsx", import.meta.url), "utf8");
  const page = readFileSync(new URL("../src/pages/shared-pauta.tsx", import.meta.url), "utf8");
  assert.ok(app.includes("session && pathname === '/'"));
  assert.ok(app.includes("navigate('/gabinete', { replace: true });"));
  assert.ok(app.includes('<Route path="/" component={Home} />'));
  assert.ok(app.includes('<Route path="/gabinete" component={Home} />'));
  assert.ok(app.includes('<Route path="/tria" component={Home} />'));
  assert.ok(app.includes('<Route path="/sessions" component={LegacyGabinetePageRedirect} />'));
  assert.ok(app.includes('<Route path="/session" component={LegacyGabinetePageRedirect} />'));
  assert.ok(app.includes('<Route path="/filter" component={LegacyTriagemRedirect} />'));
  assert.ok(app.includes('<Route path="/cmt" component={LegacyCmRedirect} />'));
  assert.ok(app.includes('<Route path="/ass" component={LegacyGabinetePageRedirect} />'));
  assert.ok(!app.includes('<Route path="/ass" component={Home} />'));
  assert.ok(app.includes('<Route path="/pauta" component={Home} />'));
  assert.ok(app.includes('<Route path="/mono" component={Home} />'));
  assert.ok(app.includes('<Route path="/session" component={LegacyGabinetePageRedirect} />'));
  assert.ok(app.includes('<Route path="/repertorio" component={LegacyGabinetePageRedirect} />'));
  assert.ok(app.includes('<Route path="/diretrizes-e-fluxos" component={LegacyGabinetePageRedirect} />'));
  assert.ok(app.includes('<Route path="/controle-de-pauta" component={LegacyPautaRedirect} />'));
  assert.ok(app.includes('<Route path="/controle-de-decisoes" component={LegacyMonoRedirect} />'));
  assert.match(app, /function LegacyPautaRedirect\(\)[\s\S]*?navigate\('\/pauta', \{ replace: true \}\)/);
  assert.match(app, /function LegacyMonoRedirect\(\)[\s\S]*?navigate\('\/mono', \{ replace: true \}\)/);
  assert.match(page, /key=\{`shared-pauta:\$\{session\.userId\}:\$\{triageWorkspace \? "filter" : "gabinete"\}`\}/);
  assert.match(page, /tipo === 'cmt:page'[\s\S]*?shellPathForEmbeddedPage\(event\.data\.pagina, window\.location\.pathname\)/);
});

test("cada página tem a sua rota; os endereços antigos continuam resolvendo", () => {
  assert.equal(gabCmtRouteForLocation("/gabinete"), "pauta");
  assert.equal(gabCmtRouteForLocation("/pauta"), "pauta");
  assert.equal(gabCmtRouteForLocation("/mono"), "decisoes");
  assert.equal(gabCmtRouteForLocation("/session"), null);
  assert.equal(gabCmtRouteForLocation("/sessions"), null);
  assert.equal(gabCmtRouteForLocation("/filter"), "triagem");
  assert.equal(gabCmtRouteForLocation("/FILTER"), "triagem");
  assert.equal(gabCmtRouteForLocation("/triagem"), "triagem");
  assert.equal(gabCmtRouteForLocation("/ementario"), null);
  assert.equal(gabCmtRouteForLocation("/repertorio"), null);
  assert.equal(gabCmtRouteForLocation("/diretrizes-e-fluxos"), null);
  assert.equal(gabCmtRouteForLocation("/controle-de-pauta"), "pauta");
  assert.equal(gabCmtRouteForLocation("/controle-de-decisoes"), "decisoes");
  assert.equal(gabCmtRouteForLocation("/controle-de-triagem"), null);
  assert.equal(gabCmtRouteForLocation("/configuracoes-globais/acervo"), null);
  assert.equal(gabCmtRouteForLocation("/serv-user"), "servidor");
  assert.equal(locationForGabCmtPage("pauta", "#/pauta"), "/pauta");
  assert.equal(locationForGabCmtPage("decisoes", "#/decisoes"), "/mono");
  assert.equal(locationForGabCmtPage("mono", "#/decisoes"), "/mono");
  assert.equal(locationForGabCmtPage("session", "#/session"), null);
  assert.equal(locationForGabCmtPage("sessoes", "#/sessoes"), null);
  assert.equal(locationForGabCmtPage("repertorio", "#/repertorio"), null);
  assert.equal(locationForGabCmtPage("diretrizes", "#/diretrizes"), null);
  assert.equal(gabCmtRouteForLocation("/tria"), "triagem");
  assert.equal(locationForGabCmtPage("triagem", "#/triagem"), "/tria");
  assert.equal(locationForGabCmtPage("sessions", "#/sessions"), null);
  assert.equal(locationForGabCmtPage("configuracoes", "#/configuracoes/acervo"), "/gabinete");
  assert.equal(locationForGabCmtPage("servidor", "#/servidor/rodcaval"), "/serv-user");
  assert.equal(locationForGabCmtPage("ementario", "#/ementario"), null);
  assert.equal(shellPathForEmbeddedPage("pauta", "/mono"), "/pauta");
  assert.equal(shellPathForEmbeddedPage("decisoes", "/pauta"), "/mono");
  assert.equal(shellPathForEmbeddedPage("decisoes", "/mono"), null);
  assert.equal(shellPathForEmbeddedPage("configuracoes", "/mono"), null);
  assert.equal(shellPathForEmbeddedPage("triagem", "/gabinete"), "/tria");
  assert.equal(shellPathForEmbeddedPage("pauta", "/cm"), null);
  assert.equal(shellPathForEmbeddedPage("triagem", "/cm"), null);
  // O GabCMT ainda emite os endereços antigos: eles chegam às rotas novas.
  assert.equal(shellPathForEmbeddedRoute("/controle-de-pauta"), "/pauta");
  assert.equal(shellPathForEmbeddedRoute("/controle-de-decisoes"), "/mono");
  assert.equal(shellPathForEmbeddedRoute("/pauta"), "/pauta");
  assert.equal(shellPathForEmbeddedRoute("/mono"), "/mono");
  assert.equal(shellPathForEmbeddedRoute("/decisoes"), "/mono");
  assert.equal(shellPathForEmbeddedRoute("/session"), null);
  assert.equal(shellPathForEmbeddedRoute("/sessions"), null);
  assert.equal(shellPathForEmbeddedRoute("/repertorio"), null);
  assert.equal(shellPathForEmbeddedRoute("/diretrizes-e-fluxos"), null);
});

test("Triagem abre em rota própria e a antiga página de Sessões volta ao Gabinete", () => {
  const app = readFileSync(new URL("../src/App.tsx", import.meta.url), "utf8");
  const html = readFileSync(new URL("../../api-server/src/protected/gabcmt.html", import.meta.url), "utf8");
  const workspace = readFileSync(new URL("../../api-server/src/protected/cmt-triagem-workspace.js", import.meta.url), "utf8");
  const apiBuild = readFileSync(new URL("../../api-server/build.mjs", import.meta.url), "utf8");
  assert.ok(app.includes("'filter'"));
  assert.ok(app.includes('<Route path="/controle-de-triagem" component={LegacyTriagemRedirect} />'));
  assert.ok(app.includes('<Route path="/tria" component={Home} />'));
  assert.ok(app.includes('<Route path="/triagem" component={LegacyTriagemRedirect} />'));
  assert.ok(app.includes('<Route path="/sessions" component={LegacyGabinetePageRedirect} />'));
  assert.ok(app.includes('<Route path="/session" component={LegacyGabinetePageRedirect} />'));
  assert.ok(app.includes('<Route path="/filter" component={LegacyTriagemRedirect} />'));
  assert.match(html, /triagem: \{ hidden: true,/);
  assert.match(app, /navigate\('\/tria', \{ replace: true \}\)/);
  assert.match(workspace, /if \(!ownsRoute\(\)\) return/);
  assert.match(workspace, /type !== 'pauta:workspace-state'/);
  assert.ok(html.includes("script.src = '/api/app/painel-lateral/workspace.js'"));
  assert.doesNotMatch(workspace, /PautaSessionHub|data-tg-workspace-tab|PautaCalendario|CMTProntuario/);
  assert.match(apiBuild, /src\/protected\/cmt-triagem-workspace\.js/);
  assert.match(apiBuild, /protected\/cmt-triagem-workspace\.js/);
});

test("eventos antigos do iframe não devolvem a navegação interna à rota de perfil", () => {
  assert.equal(shellPathForEmbeddedRoute("/"), "/gabinete");
  assert.equal(shellPathForEmbeddedRoute("/padrao"), "/gabinete");
  assert.equal(shellPathForEmbeddedRoute("/servidor"), "/serv-user");
  assert.equal(shellPathForEmbeddedRoute("/ementario"), null);
  assert.equal(shellPathForEmbeddedRoute("/filter"), "/tria");
  assert.equal(shellPathForEmbeddedRoute("/triagem"), "/tria");
  assert.equal(shellPathForEmbeddedRoute("/session"), null);
  assert.equal(shellPathForEmbeddedRoute("/sessions"), null);
  assert.equal(shellPathForEmbeddedRoute("/cmt"), "/cm");
  assert.equal(shellPathForEmbeddedRoute("/cm"), "/cm");
  assert.equal(shellPathForEmbeddedRoute("/", "/cm"), null);
  assert.equal(shellPathForEmbeddedRoute("/servidor", "/cm"), null);
  assert.equal(shellPathForEmbeddedRoute("/padrao", "/cm"), null);
  assert.equal(shellPathForEmbeddedRoute("/", "/cmt"), null);
  assert.equal(shellPathForEmbeddedRoute("/cm", "/cm"), "/cm");
  assert.equal(shellPathForEmbeddedRoute("/", "/gabinete"), "/gabinete");
  assert.equal(shellPathForEmbeddedRoute("/controle-de-decisoes"), "/mono");
  assert.equal(shellPathForEmbeddedRoute("/", "/ass"), "/gabinete");
});

test("a Mesa da Assessoria foi removida e /ass volta ao Gabinete", () => {
  const app = readFileSync(new URL("../src/App.tsx", import.meta.url), "utf8");
  const page = readFileSync(new URL("../src/pages/shared-pauta.tsx", import.meta.url), "utf8");
  assert.ok(app.includes('<Route path="/ass" component={LegacyGabinetePageRedirect} />'));
  assert.doesNotMatch(page, /CMTAssessoria|isAssRoute|canOpenAss|data-ass-route/);
});

test("a URL do servidor abre a rota nativa e as outras telas fecham módulos flutuantes", () => {
  let closed = 0;
  let opened = 0;
  const routes = [];
  applySharedPautaRoute(
    "/serv-user",
    true,
    { close: () => { closed += 1; } },
    { close: () => { closed += 1; } },
    { ir: (route) => { routes.push(route); return true; }, atual: () => ({ pagina: "pauta" }) },
  );
  assert.deepEqual(routes, ["servidor"]);
  assert.equal(closed, 2);
  assert.equal(opened, 0);

  assert.equal(applySharedPautaRoute(
    "/mono",
    true,
    { close: () => { closed += 1; } },
    { close: () => { closed += 1; } },
    { ir: (route) => { routes.push(route); return true; }, atual: () => ({ pagina: "pauta" }) },
  ), true);
  assert.deepEqual(routes, ["servidor", "decisoes"]);
  const app = readFileSync(new URL("../src/App.tsx", import.meta.url), "utf8");
  const page = readFileSync(new URL("../src/pages/shared-pauta.tsx", import.meta.url), "utf8");
  assert.match(app, /<Route path="\/comando-:tab" component={LegacyCommandRedirect} \/>/);
  assert.match(page, /'\/mono': 'Controle de Monocráticas'/);
  assert.match(page, /'\/serv-user': 'Campo do Servidor'/);
  assert.doesNotMatch(page, /'\/sessions?': 'Controle de Sessões'/);
  assert.match(page, /\?\? 'Pauta de Julgamento'/);
  // O gabcmt.html ainda anuncia os endereços antigos; o shell os traduz em
  // shellPathForEmbeddedRoute. Ao renomeá-los lá, atualizar esse mapa também.
  const frameHtml = readFileSync(new URL("../../api-server/src/protected/gabcmt.html", import.meta.url), "utf8");
  assert.match(frameHtml, /r\.page === 'decisoes' \? '\/controle-de-decisoes'/);
  assert.match(frameHtml, /r\.page === 'pauta' \? '\/controle-de-pauta'/);
  assert.match(frameHtml, /r\.page === 'configuracoes' \? \(tab === 'monocraticas' \? '\/controle-de-decisoes' : '\/controle-de-pauta'\)/);
  const html = readFileSync(new URL("../../api-server/src/protected/gabcmt.html", import.meta.url), "utf8");
  assert.match(html, /servidor: \{ titulo: 'Campo do Servidor'/);
  assert.match(html, /class="cmt-srv-cab"/);
  assert.match(html, /html\.cmt-srv-on body[\s\S]*?#pauta-global-dock\.gd-dock>\.gd-foot\{display:none!important\}/);
});

test("Sessões fica nas Configurações Globais; a rota individual é aposentada", () => {
  for (const path of ["/session", "/sessions"]) {
    const calls = [];
    assert.equal(gabCmtRouteForLocation(path), null);
    assert.equal(applySharedPautaRoute(
      path,
      true,
      null,
      null,
      { ir: (route) => { calls.push(route); return true; }, atual: () => ({ pagina: "pauta" }) },
    ), false, `a rota não deve abrir uma página de Sessões: ${path}`);
    assert.deepEqual(calls, []);
  }
  for (const path of ["/ementario", "/protocolo", "/repositorio", "/repertorio", "/diretrizes-e-fluxos"]) {
    assert.equal(gabCmtRouteForLocation(path), null);
    assert.equal(applySharedPautaRoute(path, true, null, null, null), false);
  }
});

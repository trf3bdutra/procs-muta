import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import vm from "node:vm";

const html=readFileSync(new URL("../../api-server/src/protected/gabcmt.html",import.meta.url),"utf8");
const start=html.indexOf("const RESOURCE_TYPES=");
const end=html.indexOf("\nconst PANELS=",start);
const resourceBundle=html.slice(start,end);
const norm=value=>String(value??"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim();
const escapeHtml=value=>String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const makeResourceHelpers=({pg={},grava=(p,mutate)=>{const result=mutate(p.r);return result!==false;}}={})=>{
  const scope={
    esc:escapeHtml,svg:()=>"<svg></svg>",norm,
    ESP:{apel:{n:"#123456",rot:"Apelação"},agint:{n:"#456789",rot:"Agravo interno"},ed:{n:"#112233",rot:"Embargos"}},
    ORDER:["apel","agint","ed"],
    detectar:p=>({k:p?.tipoManual||p?.r?.tipoManual||"apel",fonte:"classe"}),
    Z:r=>r._r3 ||= {f:{}},
  };
  const bundle=vm.runInNewContext(`${resourceBundle}\n({resourceHTML,resourceRows,defaultResourceSpecies,responseStatus,hydrateResourceModel,syncResourceCompatibility})`,scope);
  const editStart=html.indexOf("function editResource(p,index,field,value){");
  const editEnd=html.indexOf("\n}\n\n/* ───────── estado de exibição",editStart)+2;
  const editResource=vm.runInNewContext(`(${html.slice(editStart,editEnd)})`,{
    ...scope,resourceRows:bundle.resourceRows,defaultResourceSpecies:bundle.defaultResourceSpecies,
    responseStatus:bundle.responseStatus,hydrateResourceModel:bundle.hydrateResourceModel,
    syncResourceCompatibility:bundle.syncResourceCompatibility,PG:()=>pg,grava,MODELS:{delete(){}},
  });
  return {...bundle,editResource};
};
const resourceHelpers=makeResourceHelpers();
const {resourceHTML}=resourceHelpers;
const tipoStart=html.indexOf("function tipoSelectHTML(");
const tipoEnd=html.indexOf("\nfunction resourceHTML",tipoStart);
const tipoSelectHTML=vm.runInNewContext(`${html.slice(tipoStart,tipoEnd)}\ntipoSelectHTML`,{
  esc:value=>String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])),
  ESP:{apel:{n:"#123456",rot:"Apelação"},agint:{n:"#456789",rot:"Agravo interno"}},
  ORDER:["apel","agint"],
  detectar:p=>p.tipoManual?{k:p.tipoManual,fonte:"escolha manual"}:{k:"apel",fonte:"classe"},
});

test("o card mostra vários recursos do mesmo processo e grava cada um na coleção compartilhada",()=>{
  const row={_recursos:[
    {especie:"Apelação",parte:"parte autora",ids:"101",contra:{situacao:"apresentadas",ids:"111",data:"2026-10-20"}},
    {especie:"Agravo interno",parte:"parte ré",ids:"202",contra:{situacao:"nao",ids:"",data:""}},
  ]};
  const output=resourceHTML({r:row});
  assert.equal((output.match(/data-resource-row=/g)||[]).length,2);
  assert.match(output,/value="101"/);
  assert.match(output,/value="202"/);
  assert.equal((output.match(/data-resource-field="contra\.situacao"/g)||[]).length,2);
  assert.match(output,/data-resource-field="contra\.ids"[^>]*value="111"/);
  assert.match(output,/data-resource-field="contra\.data"[^>]*value="2026-10-20"/);
  assert.match(output,/RESPOSTA VINCULADA · Contraminuta/);
  assert.match(output,/data-act="resource-add"/);
  assert.match(output,/data-act="resource-remove"/);
  assert.doesNotMatch(output,/data-act="peca"/);
});

test("cada recurso usa a peça resposta correta e não presume que ela já foi apresentada",()=>{
  const row={"Contrarrazões - Situação":"apresentadas",_recursos:[
    {especie:"Embargos de declaração",parte:"parte ré",contra:{situacao:"",ids:"",data:""}},
    {especie:"Agravo interno",parte:"INSS",contra:{situacao:"apresentadas",ids:"303",data:"2026-10-22"}},
  ]};
  const output=resourceHTML({r:row});
  assert.match(output,/RESPOSTA VINCULADA · Manifestação da parte embargada/);
  const select=/<select data-resource-field="contra\.situacao"[^>]*>([\s\S]*?)<\/select>/.exec(output)?.[1]||"";
  assert.match(select,/<option value="" selected>Não informado<\/option>/);
  assert.doesNotMatch(select,/<option value="apresentadas" selected>/);
  assert.match(output,/RESPOSTA VINCULADA · Contraminuta/);
  const rows=resourceHelpers.resourceRows({r:row});
  assert.equal(rows[0].contra.situacao,"","a situação agregada não é atribuída ao recurso errado");
  assert.equal(rows[1].contra.ids,"303");
  assert.match(output,/class="r3-resource-no-id"/);
  assert.equal(resourceHelpers.responseStatus("Dispensada / não se aplica"),"dispensada");
});

test("Adicionar recurso cria registro próprio e permite editar contrarrazões/contraminuta vinculadas",()=>{
  const pg={
    relRecursos:r=>{if(!Array.isArray(r._recursos))r._recursos=[];if(!r._recursos.length)r._recursos.push({especie:"",parte:"parte autora",ids:"",contra:{situacao:"",ids:"",data:"",semId:false}});return r._recursos;},
    recEspecieAuto:r=>r.tipoManual==="agint"?"Agravo interno":"Apelação",
    edTemplate:()=>({especie:"",parte:"parte autora",ids:"",data:"",semId:false,contra:{situacao:"",ids:"",data:"",semId:false}}),
    genSync:()=>{},
  };
  const {editResource:edit}=makeResourceHelpers({pg});
  const p={id:"1",r:{tipoManual:"agint",_recursos:[],_r3:{f:{pecas:["Memoriais"]}}}};
  assert.equal(edit(p,0,"__add"),true);
  assert.equal(p.r._recursos.length,1);
  assert.equal(p.r._recursos[0].especie,"Agravo interno");
  assert.equal(p.r._recursos[0].contra.situacao,"");
  assert.equal(edit(p,0,"__add"),true);
  assert.equal(p.r._recursos.length,2,"um novo recurso é incluído sem virar peça nem duplicar o primeiro");
  assert.equal(p.r._recursos[1].especie,"Agravo interno");
  assert.equal(edit(p,1,"contra.ids","222"),true);
  assert.equal(edit(p,1,"contra.data","2026-10-21"),true);
  assert.equal(edit(p,1,"contra.situacao","apresentadas"),true);
  assert.equal(edit(p,1,"contra.semId",true),true);
  assert.deepEqual({...p.r._recursos[1].contra},{situacao:"apresentadas",ids:"",data:"2026-10-21",semId:true});
  assert.deepEqual(Array.from(p.r._r3.f.pecas),["Memoriais"]);
});

test("dados legados de recurso e contrarrazões migram juntos para o recurso principal",()=>{
  const row={Recorrente:"INSS","Recurso - ID":"101","Recurso - Data":"2026-10-18","Contrarrazões - Situação":"apresentadas","Contrarrazões - ID":"202","Contrarrazões - Data":"2026-10-20"};
  const output=resourceHTML({r:row});
  assert.match(output,/Recurso principal/);
  assert.match(output,/value="101"/);
  assert.match(output,/value="202"/);
  assert.match(output,/value="2026-10-18"/);
  assert.match(output,/value="2026-10-20"/);
  assert.match(output,/value="INSS"/);
  const pg={
    relRecursos:r=>{if(!Array.isArray(r._recursos))r._recursos=[{especie:"",parte:"parte autora",ids:"",contra:undefined}];return r._recursos;},
    recEspecieAuto:()=>"Apelação",edTemplate:()=>({especie:"",parte:"parte autora",ids:"",contra:{situacao:"",ids:"",semId:false,data:""}}),
    genSync:()=>{},
  };
  const {editResource:edit}=makeResourceHelpers({pg}),p={id:"legacy",r:row};
  assert.equal(edit(p,0,"__add"),true);
  assert.equal(p.r._recursos.length,2);
  assert.equal(p.r._recursos[0].ids,"101");
  assert.equal(p.r._recursos[0].parte,"INSS");
  assert.equal(p.r._recursos[0].parteCustom,"");
  assert.equal(p.r._recursos[0].contra.situacao,"apresentadas");
  assert.equal(p.r._recursos[0].contra.ids,"202");
  assert.equal(p.r._recursos[0].contra.data,"2026-10-20");
  assert.equal(p.r._recursos[1].contra.situacao,"");
});

test("painel de recursos não duplica os campos legados de recurso principal e resposta",()=>{
  const start=html.indexOf("F('recursos','','resource-list')");
  const end=html.indexOf("jul:k=>",start);
  const recPanel=html.slice(start,end);
  assert.ok(start>=0&&end>start);
  assert.doesNotMatch(recPanel,/F\('(recurso|recorrente|contrarrazoes)'/);
  assert.doesNotMatch(recPanel,/Recursos processuais/);
  const recRender=html.slice(html.indexOf("if(id==='rec'){"),html.indexOf("}else if(id==='jul'){",html.indexOf("if(id==='rec'){")));
  assert.match(recRender,/if\(f\.type==='resource-list'\)return `<div class="resource-list-row">\$\{valueHTML\(p,f,k\)\}<\/div>`;let lab/);
});

test("Prontuário renderiza os mesmos painéis e campos editáveis do card",()=>{
  const start=html.indexOf("const FMAP=");
  const end=html.indexOf("\nconst TEMPESTIVIDADE",start);
  const map=vm.runInNewContext(`${html.slice(start,end)}\nFMAP`,{});
  assert.deepEqual({...map},{
    tempest:"Tempestividade",preparo:"Preparo",mpf:"MPF",mpfAtuacao:"MPF - Custos Legis",
    mpfId:"ID do Parecer MPF",mpfSentido:"Parecer - Sentido",mpfInfo:"MPF - Info adicional",
    midias:"Mídias",obs:"Observações",
  });
  for(const field of ["Tempestividade","Preparo","MPF","MPF - Custos Legis","ID do Parecer MPF","Parecer - Sentido","MPF - Info adicional","Mídias"]){
    assert.ok(html.includes(`writeField:(i,key,value)=>{const allowed=['Tempestividade','Preparo','Mídias','MPF','MPF - Custos Legis','ID do Parecer MPF','Parecer - Sentido','MPF - Info adicional']`));
    assert.ok(html.includes(`'${field}'`),`campo ausente: ${field}`);
  }
  assert.ok(html.includes("prontuarioHTML:i=>"));
  assert.ok(html.includes("['adm','Regularidade'],['pro','Processo e origem'],['rec','Recursos'],['jul','Julgamento']"));
  assert.ok(html.includes("panelHTML(p,id,k,{hideTipo:id==='jul'})"));
  assert.ok(html.includes("window.CMTCardR3?.prontuarioHTML(rowIndex)"));
  assert.ok(html.includes("prontuarioTipoHTML:i=>"));
  assert.ok(html.includes("<div class=\"qp-ass-row\">${window.CMTCardR3?.prontuarioTipoHTML(rowIndex)||''}<b class=\"qp-ass\""));
  assert.ok(html.includes("rows=`<div class=\"jtop\">${opts.hideTipo?'':tipoSelectHTML(p)}"));
  assert.ok(html.includes("const refresh=()=>{window.CMTCardR3?.refreshProcess(p.i);if(qp)window.CMTProntuario?.paint(true);};"));
  assert.ok(html.includes("data-qp=\"save\""));
  assert.ok(html.includes("saveLocalDrafts()"));
  assert.ok(html.includes("restoreLocalDrafts()"));
  assert.ok(html.includes("isPending:i=>i==null?ST.pending:ST.rows.has(Number(i))"));
  assert.ok(html.includes("isPending?.(Number(i))"));
  assert.ok(html.includes("window.CMTManualSave?.saveNow?.(false)"));
});

test("Controle de Triagem não renderiza prontuário lateral e mantém a sincronização com a Pauta",()=>{
  assert.doesNotMatch(html,/function tqSelect|function tqMount|function tqPaint/);
  assert.doesNotMatch(html,/#tg-qp(?:-tab)?|data-tg="open"|TG\.prontuario/);
  assert.match(html,/function pjGet\(/);
  assert.match(html,/function pjSet\(/);
  assert.match(html,/function pjSyncAll\(/);
  assert.match(html,/pj: \{ get: pjGet, set: pjSet, sync: pjSyncAll \}/);
  const pautaStart=html.indexOf("function select(g) { if (!g) return;");
  const pautaEnd=html.indexOf("function openGenerator()",pautaStart);
  const pautaSelection=html.slice(pautaStart,pautaEnd);
  assert.ok(pautaStart>=0&&pautaEnd>pautaStart,"a seleção do Prontuário da Pauta continua disponível");
  assert.match(pautaSelection,/g\.classList\.add\('alt-qp-sel'\)/);
  assert.match(pautaSelection,/paint\(true\)/);
});

test("seletor de tipo do prontuário é dropdown e fica no header antes do assunto",()=>{
  const output=tipoSelectHTML({tipoManual:"agint"},"qp-tipo");
  assert.match(output,/<select class="tipo qp-tipo"/);
  assert.match(output,/data-tipo aria-label="Tipo de julgamento"/);
  assert.match(output,/<option value="agint" selected>Agravo interno<\/option>/);
  assert.match(output,/Automático · Apelação/);
  assert.ok(html.includes("<div class=\"qp-ass-row\">${window.CMTCardR3?.prontuarioTipoHTML(rowIndex)||''}<b class=\"qp-ass\""));
  assert.ok(html.includes("panelHTML(p,id,k,{hideTipo:id==='jul'})"),"o seletor não se repete dentro do painel Julgamento");
});

test("Acervo do app só completa campos vazios do Gerador e mantém dados editados",()=>{
  const start=html.indexOf("function acervoTexto(v) {");
  const end=html.indexOf("\n  async function completarDoAcervo()",start);
  const helpers=vm.runInNewContext(`${html.slice(start,end)}\n({camposAcervo,aplicarAcervoNosVazios})`,{
    S:value=>String(value??""),
    semValor:value=>value==null||(Array.isArray(value)?!value.some(item=>String(item??"").trim()):!String(value??"").trim()),
    linhas:value=>String(value??"").split(/\r?\n/).map(item=>item.trim()).filter(Boolean),
    get:(object,path)=>path.split(".").reduce((value,key)=>value==null?"":value[key],object),
    set:(object,path,value)=>{const keys=path.split("."),last=keys.pop();let target=object;for(const key of keys){if(target[key]==null)target[key]={};target=target[key];}target[last]=value;},
  });
  const campos=helpers.camposAcervo({linha:{
    classe_judicial:"Classe vinda do Acervo",assunto_judicial:"Assunto do Acervo",
    "Questões":["Saber se há direito"],"Recurso - ID":"901",Recorrente:"INSS",
  }});
  const F={em:{classe:"",assunto:"Assunto já editado",quest:[],raz:[]},recs:[{rec:"Parte já informada",recId:""}]};
  const total=helpers.aplicarAcervoNosVazios(F,campos);
  assert.equal(F.em.classe,"Classe vinda do Acervo");
  assert.equal(F.em.assunto,"Assunto já editado","o preenchimento não sobrescreve o Gerador");
  assert.deepEqual(Array.from(F.em.quest),["Saber se há direito"]);
  assert.equal(F.recs[0].rec,"Parte já informada");
  assert.equal(F.recs[0].recId,"901");
  assert.equal(total,3);
});

test("AJG e DPU vindos do card refletem preparo dispensado no Prontuário",()=>{
  const modelStart=html.indexOf("function model(x){");
  const modelEnd=html.indexOf("\nconst Z=",modelStart);
  const localNorm=value=>norm(value);
  const model=vm.runInNewContext(`(${html.slice(modelStart,modelEnd)})`,{
    STR:value=>String(value??""),norm:localNorm,
    yes:value=>["sim","s","true","1","x","ok"].includes(localNorm(value))||/^sim\s+/.test(localNorm(value)),
    CAP:value=>{const text=String(value??"").trim();return text?text[0].toUpperCase()+text.slice(1):"";},
    responseStatus:()=>"",
    C:()=>({etiquetasDe:()=>[],date:()=>""}),H:()=>({}),solsDe:()=>[],
  });
  const result=model({i:7,r:{"DPU (controle)":"Sim",Preparo:"—",Partes:""},e:{}});
  assert.equal(result.f.dpu,true);
  assert.equal(result.f.ajg,false);
  assert.equal(result.f.preparo,"Dispensado");
});

test("marcar e desmarcar DPU grava no card e restaura o preparo manual anterior",()=>{
  const start=html.indexOf("function setF(p,key,val){");
  const end=html.indexOf("\nfunction editResource",start);
  const setF=vm.runInNewContext(`(${html.slice(start,end)})`,{
    STR:value=>String(value??""),norm:value=>norm(value),
    yes:value=>["sim","s","true","1","x","ok"].includes(norm(value))||/^sim\s+/.test(norm(value)),
    Z:row=>{row._r3||={};row._r3.f||={};return row._r3;},
    grava:(p,mutate)=>mutate(p.r)!==false,FMAP:{},TEMPESTIVIDADE:[],
  });
  const row={Preparo:"Comprovado",AJG:"Não","DPU (controle)":"Não",_r3:{f:{}}};
  const card={r:row,closed:false};
  assert.equal(setF(card,"dpu",true),true);
  assert.equal(row["DPU (controle)"],"Sim");
  assert.equal(row.Preparo,"Dispensado");
  assert.equal(setF(card,"dpu",false),true);
  assert.equal(row["DPU (controle)"],"Não");
  assert.equal(row.Preparo,"Comprovado");
});

test("o Prontuário deixa o painel Paradigmas e mostra a contagem junto ao Gerador",()=>{
  assert.doesNotMatch(html,/qp-pdg/);
  assert.match(html,/data-qpt-sim/);
  assert.match(html,/Expandir o Gerador de Acórdão deste processo/);
});

test("consulta do Acervo por processo entrega os dados normalizados ao Gerador",()=>{
  const route=readFileSync(new URL("../../api-server/src/routes/acervo-importado.ts",import.meta.url),"utf8");
  assert.match(route,/completeAcervoLines\(processo, imported, linhaDaPauta\(imported, operational\)\)/);
  assert.match(route,/linha: linhas\[0\] \|\| \{ processo \}/);
  assert.match(html,/fetch\('\/api\/acervo\/' \+ encodeURIComponent\(r\.Processo\)/);
  assert.match(html,/data-gr="acervo"/);
});

test("rascunho local reaplica só os campos alterados e preserva os demais dados remotos",()=>{
  const start=html.indexOf("const DRAFT_PREFIX=");
  const end=html.indexOf("\nfunction saveLocalDrafts()",start);
  const helpers=vm.runInNewContext(`${html.slice(start,end)}\n({diffTree,applyDraftPatch})`,{structuredClone,JSON,Object});
  const before={Processo:"50000000000000000001",_r3:{f:{tempest:"Não Verificado",mpf:"—",vicio:""}},servidor:"A"};
  const edited={...before,_r3:{f:{tempest:"Tempestivo",mpf:"—",vicio:""}}};
  const patch=helpers.diffTree(before,edited);
  const latest={Processo:before.Processo,_r3:{f:{tempest:"Não Verificado",mpf:"Com Parecer",vicio:""}},servidor:"B"};
  helpers.applyDraftPatch(latest,patch);
  assert.equal(latest._r3.f.tempest,"Tempestivo");
  assert.equal(latest._r3.f.mpf,"Com Parecer");
  assert.equal(latest.servidor,"B");
});

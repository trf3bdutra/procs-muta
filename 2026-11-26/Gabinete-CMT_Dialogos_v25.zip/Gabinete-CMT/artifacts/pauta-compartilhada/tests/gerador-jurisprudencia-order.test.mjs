import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";

const url = new URL("../public/cmt-geradores-biblioteca.js", import.meta.url);
const src = readFileSync(url, "utf8");
const ctx = { module: { exports: {} } };
vm.runInNewContext(src, ctx);
const biblioteca = ctx.module.exports;

test("ordenar por data aceita ISO, formato brasileiro e ano; datas ausentes ficam ao final", () => {
  const rows = [
    { id: "antigo", dataJulgamento: "2021-04-12" },
    { id: "recente", dataJulgamento: "2025-11-20" },
    { id: "sem-data" },
    { id: "formato-br", dataJulgamento: "13/04/2023" },
    { id: "ano", ano: "2022" },
    { id: "publicacao-sem-julgamento", dataPublicacao: "2026-01-01" },
  ];
  const recentes = biblioteca.ordenaJulgadosPorData(rows, "recentes").map(row => row.id);
  const antigos = biblioteca.ordenaJulgadosPorData(rows, "antigos").map(row => row.id);

  assert.deepEqual(recentes, ["recente", "formato-br", "ano", "antigo", "sem-data", "publicacao-sem-julgamento"]);
  assert.deepEqual(antigos, ["antigo", "ano", "formato-br", "recente", "sem-data", "publicacao-sem-julgamento"]);
  assert.deepEqual(rows.map(row => row.id), ["antigo", "recente", "sem-data", "formato-br", "ano", "publicacao-sem-julgamento"]);
});

test("o Ementário reutiliza a aba nativa Jurisprudência do Gerador, com Precedentes e Modelos", () => {
  const html = readFileSync(new URL("../../api-server/src/protected/gabcmt.html", import.meta.url), "utf8");
  const adapter = html.slice(html.indexOf("  var queryAoAbrir="), html.indexOf("window.CMTParadigmas={", html.indexOf("  var queryAoAbrir=")));
  assert.match(html, /ementario: \{ titulo: 'Ementário'/);
  assert.match(adapter, /B\.abrirEmentario\(root/);
  assert.doesNotMatch(adapter, /fetch\(['"]\/api\/paradigmas\/precedentes/);
  assert.match(src, /function abrirEmentario\(host, query\)/);
  assert.match(src, /data-testid="tab-jurisprudencia-precedentes"/);
  assert.match(src, /data-testid="tab-jurisprudencia-modelos"/);
  assert.match(html, /#pa-pdg #gbib-tabs \[data-gbib-aba="doc"\]/);
  assert.match(html, /data-sim="ementario"/);
});

test("filtros da jurisprudência combinam classificação, ano e órgão julgador", () => {
  const base = {
    pronunciamento: "Acórdão",
    classeSigla: "ApCiv",
    tipoJulgamento: "1º julgamento",
    dataJulgamento: "2024-07-18",
    orgao: "3ª Turma",
  };
  const filtros = { decisao: "Acórdão", classe: "APCIV", julgamento: "1º julgamento", ano: "2024", orgao: "3ª Turma" };

  assert.equal(biblioteca.passaFiltrosJurisprudencia(base, filtros), true);
  assert.equal(biblioteca.passaFiltrosJurisprudencia({ ...base, dataJulgamento: "2023-07-18" }, filtros), false);
  assert.equal(biblioteca.passaFiltrosJurisprudencia({ ...base, orgao: "4ª Turma" }, filtros), false);
  assert.equal(biblioteca.passaFiltrosJurisprudencia({ ...base, classeSigla: "AI" }, filtros), false);
});

test("a busca encontra assunto e temas sem diferenciar acentos", () => {
  const rows = [{
    id: "A3",
    assunto: "Benefício previdenciário",
    temas: ["Pensão por morte"],
    palavrasChave: ["dependência econômica"],
  }];
  const result = biblioteca.filtra(rows, "previdenciario pensao dependencia", ["assunto", "temas", "palavrasChave"]);
  assert.equal(result.length, 1);
  assert.equal(result[0].id, "A3");
});

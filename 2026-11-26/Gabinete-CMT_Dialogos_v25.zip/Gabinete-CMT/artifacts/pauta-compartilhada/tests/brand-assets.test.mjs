import assert from "node:assert/strict";
import { readdirSync, readFileSync, statSync } from "node:fs";
import test from "node:test";

const root = new URL("../", import.meta.url);
const banners = [
  "banner_acervo.svg",
  "banner_painel.svg",
  "banner_referencias.svg",
  "banner_tarefas.svg",
  "banner_relatorios.svg",
  "banner_recursos.svg",
  "banner_regimento.svg",
  "banner_competencia.svg",
];

test("o build publica os banners oficiais e apenas os PNGs necessários à instalação", () => {
  const output = new URL("dist/public/cmt-brand/command/", root);
  for (const banner of banners) {
    const file = new URL(banner, output);
    assert.ok(statSync(file).isFile(), `banner ausente do build: ${banner}`);
    assert.ok(statSync(file).size > 0, `banner vazio no build: ${banner}`);
  }

  const publicFiles = readdirSync(new URL("dist/public/", root), { recursive: true });
  assert.deepEqual(
    publicFiles.filter((file) => String(file).toLowerCase().endsWith(".png")).map(String).sort(),
    ["apple-touch-icon.png", "pwa-192.png", "pwa-512.png"],
  );

  const html = readFileSync(new URL("dist/public/index.html", root), "utf8");
  assert.match(html, /href="\/favicon\.svg"/);
  assert.match(html, /rel="manifest" href="\/manifest\.webmanifest"/);
  assert.match(html, /rel="apple-touch-icon" href="\/apple-touch-icon\.png"/);
});

test("o favicon usa a estrela CMT em SVG, sem fundo genérico cinza", () => {
  const icon = readFileSync(new URL("public/favicon.svg", root), "utf8");
  assert.match(icon, /fill="#e9c46f"/);
  assert.match(icon, /fill="#173c35"/);
  assert.doesNotMatch(icon, /#757577/);
});

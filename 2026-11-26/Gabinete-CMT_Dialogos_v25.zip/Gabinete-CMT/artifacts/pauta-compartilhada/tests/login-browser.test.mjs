import { existsSync } from "node:fs";
import { createRequire } from "node:module";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createServer } from "node:http";
import { access, mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { setTimeout as delay } from "node:timers/promises";
import test from "node:test";

const appDirectory = new URL("../dist/public/", import.meta.url);
// Resolve o Chromium no Replit, no PATH ou no Playwright instalado (CI e máquinas locais).
const chromiumPath = (() => {
  const candidates = [
    process.env.CHROMIUM_PATH,
    "/repl/tools/bin/chromium",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/usr/bin/google-chrome",
  ].filter(Boolean);
  for (const candidate of candidates) {
    if (existsSync(candidate)) return candidate;
  }
  try {
    return createRequire(import.meta.url)("playwright").chromium.executablePath();
  } catch {
    return candidates[0];
  }
})();
const activeServers = ["RODRIGO", "BRUNO"];
const loginState = { account: null, request: null, optionsResponse: null, pautaReads: 0, nativeReads: 0, logoutAttempts: 0, failNextLogout: false };
const mimeTypes = {
  ".css": "text/css",
  ".html": "text/html",
  ".ico": "image/x-icon",
  ".js": "text/javascript",
  ".json": "application/json",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".woff2": "font/woff2",
};

function respond(response, status, body, headers = {}) {
  response.writeHead(status, {
    "Cache-Control": "no-store",
    "Content-Type": "application/json; charset=utf-8",
    ...headers,
  });
  response.end(JSON.stringify(body));
}

const server = createServer(async (request, response) => {
  const url = new URL(request.url || "/", "http://localhost");
  if (url.pathname === "/api/auth/login-options" && request.method === "GET") {
    loginState.optionsResponse = { servers: activeServers };
    respond(response, 200, loginState.optionsResponse);
    return;
  }
  if (url.pathname === "/api/auth/account" || url.pathname === "/api/auth/session") {
    if (!loginState.account) {
      respond(response, 401, { code: "signed_out", error: "Entre para acessar." });
    } else if (url.pathname.endsWith("/account")) {
      respond(response, 200, loginState.account.account);
    } else {
      respond(response, 200, loginState.account.session);
    }
    return;
  }
  if (url.pathname === "/api/auth/login" && request.method === "POST") {
    const chunks = [];
    for await (const chunk of request) chunks.push(chunk);
    loginState.request = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    const isAdmin = loginState.request.password === "admin-browser-test";
    const account = isAdmin
      ? { userId: "admin-fixture", name: "Administração", email: "admin@example.test", role: "administracao", status: "active" }
      : { userId: "server-fixture", name: loginState.request.server, email: "server@example.test", role: "equipe", status: "active", server: loginState.request.server };
    loginState.account = {
      account,
      session: {
        authenticated: true,
        userId: account.userId,
        role: account.role,
        name: account.name,
        ...(account.server ? { server: account.server } : {}),
      },
    };
    respond(response, 200, { authenticated: true, account });
    return;
  }
  if (url.pathname === "/api/auth/logout" && request.method === "POST") {
    loginState.logoutAttempts += 1;
    if (loginState.failNextLogout) {
      loginState.failNextLogout = false;
      respond(response, 503, { error: "Serviço temporariamente indisponível." });
    } else {
      loginState.account = null;
      respond(response, 200, { ok: true });
    }
    return;
  }
  if (url.pathname === "/api/pauta" && request.method === "GET") {
    if (!loginState.account) {
      respond(response, 401, { error: "Entre para acessar." });
    } else {
      loginState.pautaReads += 1;
      respond(response, 200, {
        revision: 1,
        state: {
          rows: [],
          sessions: [],
          sessionDetails: {},
          team: {
            members: [{
              id: "profile-fixture",
              name: "RODRIGO",
              hierarchy: "Membro de teste",
              functions: ["minutar"],
              primary: "minutar",
              personal: { origin: "DADO-PERFIL-PRIVADO-TESTE" },
              absences: [],
              logs: [],
              daily: [],
            }],
            catalog: { functions: { minutar: { name: "Função demonstrativa" } } },
          },
        },
      });
    }
    return;
  }
  if (url.pathname === "/api/app/gabcmt") {
    if (!loginState.account) {
      respond(response, 401, { error: "Entre para acessar." });
    } else {
      loginState.nativeReads += 1;
      const identity = JSON.stringify(loginState.account.session).replace(/</g, "\\u003c");
      response.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
      response.end(`<!doctype html><html><head><script>window.CMT_AUTH_SESSION=${identity};</script></head><body><main id="native-editor-fixture">Editor nativo autenticado</main></body></html>`);
    }
    return;
  }
  if (url.pathname.startsWith("/api/")) {
    respond(response, 404, { error: "Not found" });
    return;
  }

  const relativePath = decodeURIComponent(url.pathname).replace(/^\/+/, "");
  let filename = path.join(appDirectory.pathname, relativePath || "index.html");
  try {
    await access(filename);
  } catch {
    filename = path.join(appDirectory.pathname, "index.html");
  }
  try {
    const contents = await readFile(filename);
    response.writeHead(200, {
      "Cache-Control": "no-store",
      "Content-Type": mimeTypes[path.extname(filename)] || "application/octet-stream",
    });
    response.end(contents);
  } catch {
    response.writeHead(404);
    response.end("Not found");
  }
});

class DevTools {
  #socket;
  #nextId = 0;
  #pending = new Map();

  constructor(socket) {
    this.#socket = socket;
    socket.addEventListener("message", (event) => {
      const message = JSON.parse(event.data);
      if (!message.id) return;
      const pending = this.#pending.get(message.id);
      if (!pending) return;
      this.#pending.delete(message.id);
      if (message.error) pending.reject(new Error(message.error.message));
      else pending.resolve(message.result);
    });
  }

  async send(method, params = {}) {
    const id = ++this.#nextId;
    const result = new Promise((resolve, reject) => this.#pending.set(id, { resolve, reject }));
    this.#socket.send(JSON.stringify({ id, method, params }));
    return result;
  }

  async evaluate(expression) {
    const response = await this.send("Runtime.evaluate", {
      expression,
      awaitPromise: true,
      returnByValue: true,
      userGesture: true,
    });
    if (response.exceptionDetails) {
      throw new Error(response.exceptionDetails.text || "Browser evaluation failed");
    }
    return response.result?.value;
  }

  close() {
    this.#socket.close();
  }
}

async function waitFor(predicate, message, timeout = 12_000) {
  const deadline = Date.now() + timeout;
  let lastError;
  while (Date.now() < deadline) {
    try {
      if (await predicate()) return;
    } catch (error) {
      lastError = error;
    }
    await delay(100);
  }
  throw new Error(message, { cause: lastError });
}

async function stopBrowser(child, userDataDir) {
  const exited = new Promise((resolve) => child.once("exit", resolve));
  try {
    process.kill(-child.pid, "SIGTERM");
  } catch {
    child.kill("SIGTERM");
  }
  await Promise.race([exited, delay(2_000)]);
  try {
    process.kill(-child.pid, "SIGKILL");
  } catch {
    child.kill("SIGKILL");
  }
  await Promise.race([exited, delay(1_000)]);
  await rm(userDataDir, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
}

async function startBrowser() {
  const userDataDir = await mkdtemp(path.join(tmpdir(), "gabinete-login-browser-"));
  const child = spawn(chromiumPath, [
    "--headless=new",
    "--no-sandbox",
    "--disable-gpu",
    "--no-first-run",
    "--no-default-browser-check",
    "--remote-debugging-address=127.0.0.1",
    "--remote-debugging-port=0",
    `--user-data-dir=${userDataDir}`,
    "about:blank",
  ], { stdio: "ignore", detached: true });

  try {
    const portFile = path.join(userDataDir, "DevToolsActivePort");
    let port;
    await waitFor(async () => {
      try {
        port = Number((await readFile(portFile, "utf8")).split("\n")[0]);
        return port > 0;
      } catch {
        return false;
      }
    }, "Chromium did not start its remote debugging endpoint.");
    const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    const target = targets.find((item) => item.type === "page");
    assert.ok(target?.webSocketDebuggerUrl, "Chromium did not expose a page target.");
    const socket = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => {
      socket.addEventListener("open", resolve, { once: true });
      socket.addEventListener("error", reject, { once: true });
    });
    return {
      child,
      userDataDir,
      devtools: new DevTools(socket),
    };
  } catch (error) {
    await stopBrowser(child, userDataDir);
    throw error;
  }
}

test("browser login renders only API options and submits the selected server and password for both roles", async (t) => {
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
  let browser;
  t.after(async () => {
    browser?.devtools.close();
    if (browser) {
      await stopBrowser(browser.child, browser.userDataDir);
    }
    server.closeAllConnections();
    server.close();
  });
  browser = await startBrowser();

  const address = server.address();
  const appUrl = `http://127.0.0.1:${address.port}`;
  await browser.devtools.send("Page.enable");
  await browser.devtools.send("Runtime.enable");

  for (const scenario of [
    { server: "RODRIGO", password: "team-browser-test", role: "equipe", userName: "RODRIGO" },
    { server: "BRUNO", password: "admin-browser-test", role: "administracao", userName: "Administração" },
  ]) {
    loginState.account = null;
    loginState.request = null;
    loginState.optionsResponse = null;
    await browser.devtools.send("Page.navigate", { url: `${appUrl}/sign-in?flow=${scenario.role}` });
    await waitFor(
      () => browser.devtools.evaluate(`Boolean(document.querySelector('iframe')?.contentDocument?.querySelector('[aria-label="Servidor"] button[aria-label="Selecionar BRUNO"]'))`),
      "Login did not show the server options returned by the API.",
    );

    const visibleOptions = await browser.devtools.evaluate(
      `Array.from(document.querySelector('iframe').contentDocument.querySelectorAll('[aria-label="Servidor"] button')).map((button) => button.getAttribute('aria-label'))`,
    );
    assert.deepEqual(loginState.optionsResponse, { servers: activeServers });
    assert.deepEqual(visibleOptions, ["Selecionar RODRIGO", "Selecionar BRUNO"]);
    const loginForm = await browser.devtools.evaluate(`(() => {
      const doc = document.querySelector('iframe').contentDocument;
      return {
        emailFields: doc.querySelectorAll('input[type="email"]').length,
        passwordLabel: [...doc.querySelectorAll('label')].some((label) => label.textContent.trim() === 'Senha'),
        passwordPlaceholder: doc.querySelector('#account-password')?.getAttribute('placeholder'),
      };
    })()`);
    assert.deepEqual(loginForm, {
      emailFields: 0,
      passwordLabel: true,
      passwordPlaceholder: "Digite sua senha",
    });

    await browser.devtools.evaluate(`(() => {
      const doc = document.querySelector('iframe').contentDocument;
      doc.querySelector('[aria-label="Servidor"] button[aria-label="Selecionar ${scenario.server}"]').click();
      return Boolean(doc.querySelector('#account-password'));
    })()`);
    await waitFor(
      () => browser.devtools.evaluate(`(() => {
        const frame = document.querySelector('iframe');
        const doc = frame?.contentDocument;
        const input = doc?.querySelector('#account-password');
        return Boolean(input && doc.activeElement === input && !input.disabled);
      })()`),
      "Selecting a server did not focus the enabled password field.",
    );
    await browser.devtools.send("Input.insertText", { text: scenario.password });
    const typedLength = await browser.devtools.evaluate(
      `document.querySelector('iframe').contentDocument.querySelector('#account-password').value.length`,
    );
    assert.equal(typedLength, scenario.password.length, "The password field did not accept keyboard input.");
    await browser.devtools.evaluate(`document.querySelector('iframe').contentDocument.querySelector('form.local-sign-in button[type="submit"]').click()`);

    await waitFor(() => loginState.request !== null, "Login did not send a request to the API.");
    assert.deepEqual(loginState.request, {
      role: "equipe",
      server: scenario.server,
      password: scenario.password,
    });
    // Desde 30/10/2026 (login-destination.ts) o login sem destino abre o Gabinete, não a página do servidor.
    await waitFor(
      () => browser.devtools.evaluate(`location.pathname === '/gabinete'`),
      `The ${scenario.role} login did not continue to the requested app route.`,
    );
    assert.equal(loginState.account.session.role, scenario.role);
    assert.equal(loginState.account.account.name, scenario.userName);
  }

  // Direct legacy profile links must never load the shared snapshot before login.
  loginState.account = null;
  loginState.pautaReads = 0;
  loginState.nativeReads = 0;
  const profileSlugs = [
    "alex", "bruno", "saffioti", "vanilda", "giovana", "dalete", "jose",
    "rodrigo", "duda", "debora", "renato", "victor", "estela", "cm",
  ];
  for (const route of [...profileSlugs.map((slug) => `/serv-${slug}`), "/perfil-que-nao-existe"]) {
    await browser.devtools.send("Page.navigate", { url: `${appUrl}${route}` });
    await waitFor(
      () => browser.devtools.evaluate(`Boolean(document.querySelector('iframe')?.contentDocument?.querySelector('input[type="password"]'))`),
      `Direct route ${route} did not show the restricted sign-in screen.`,
    );
    const restrictedView = await browser.devtools.evaluate(`(() => {
      const doc = document.querySelector('iframe').contentDocument;
      return {
        passwordField: !!doc.querySelector('input[type="password"]'),
        profileHeading: !!doc.querySelector('#server-name'),
        privateMarker: doc.body.textContent.includes('DADO-PERFIL-PRIVADO-TESTE'),
      };
    })()`);
    assert.deepEqual(restrictedView, {
      passwordField: true,
      profileHeading: false,
      privateMarker: false,
    }, `Route ${route} exposed profile UI without an authenticated session.`);
    assert.equal(loginState.pautaReads, 0, `Route ${route} fetched the shared profile snapshot before login.`);
    assert.equal(loginState.nativeReads, 0, `Route ${route} opened the private native editor before login.`);
  }

  // A valid login opens the native editor, not the retired standalone React badge.
  await browser.devtools.evaluate(`(() => {
    const doc = document.querySelector('iframe').contentDocument;
    doc.querySelector('[aria-label="Servidor"] button[aria-label="Selecionar RODRIGO"]').click();
    const input = doc.querySelector('#account-password');
    Object.getOwnPropertyDescriptor(doc.defaultView.HTMLInputElement.prototype, 'value').set.call(input, 'team-browser-test');
    input.dispatchEvent(new doc.defaultView.Event('input', { bubbles: true }));
    input.dispatchEvent(new doc.defaultView.Event('change', { bubbles: true }));
    doc.querySelector('form.local-sign-in button[type="submit"]').click();
    return true;
  })()`);
  await waitFor(() => loginState.account?.session?.role === "equipe", "Authorized profile login did not complete.");
  await waitFor(
    () => browser.devtools.evaluate(`Boolean(document.querySelector('iframe')?.contentDocument?.querySelector('#native-editor-fixture'))`),
    "Authorized login did not request the protected native editor.",
  );
  const authorizedEditor = await browser.devtools.evaluate(`(() => {
    const frame = document.querySelector('iframe');
    return { path: location.pathname, source: frame.getAttribute('src'), session: frame.contentWindow.CMT_AUTH_SESSION, standalone: !!document.querySelector('#server-name') };
  })()`);
  assert.equal(authorizedEditor.path, "/serv-user");
  assert.match(authorizedEditor.source, /\/api\/app\/gabcmt/);
  assert.equal(authorizedEditor.session.userId, loginState.account.session.userId);
  assert.equal(authorizedEditor.session.server, "RODRIGO");
  assert.equal(authorizedEditor.standalone, false);
  assert.ok(loginState.nativeReads > 0, "Authorized login did not request the native editor.");
  assert.ok(loginState.pautaReads > 0, "Authorized profile did not fetch the shared profile snapshot.");

  // A rejected logout must show an error, restore the control, and leave the server session usable.
  loginState.account.account.status = "pending";
  loginState.failNextLogout = true;
  const previousLogoutAttempts = loginState.logoutAttempts;
  await browser.devtools.send("Page.navigate", { url: `${appUrl}/gabinete` });
  await waitFor(
    () => browser.devtools.evaluate(`Boolean(document.querySelector('[data-testid="button-sign-out"]'))`),
    "The account notice did not render its session-ending action.",
  );
  const signOutLabel = await browser.devtools.evaluate(
    `document.querySelector('[data-testid="button-sign-out"]').innerText.trim()`,
  );
  assert.match(signOutLabel, /Encerrar sessão/);

  await browser.devtools.evaluate(`document.querySelector('[data-testid="button-sign-out"]').click()`);
  await waitFor(
    () => browser.devtools.evaluate(`Boolean(document.querySelector('[data-testid="button-sign-out"]:not(:disabled)') && document.querySelector('[role="alert"].cmt-logout-error'))`),
    "A failed logout did not show an error and re-enable the action.",
  );
  assert.equal(loginState.logoutAttempts, previousLogoutAttempts + 1);
  assert.ok(loginState.account, "A failed logout cleared the server-side session.");
  const retainedSession = await browser.devtools.evaluate(
    `fetch('/api/auth/session', { credentials: 'same-origin' }).then((response) => response.json())`,
  );
  assert.equal(retainedSession.authenticated, true, "The valid session was not retained after the failed logout.");

  await browser.devtools.evaluate(`document.querySelector('[data-testid="button-sign-out"]').click()`);
  await waitFor(
    () => loginState.account === null && loginState.logoutAttempts === previousLogoutAttempts + 2,
    "The session-ending action could not be retried successfully.",
  );
  await waitFor(
    () => browser.devtools.evaluate(`location.pathname === '/sign-in'`),
    "A successful retry did not return to the sign-in page.",
  );
});

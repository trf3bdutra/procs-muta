import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const html = fs.readFileSync(new URL('../../api-server/src/protected/gabcmt.html', import.meta.url), 'utf8');
const script = html.split('<script id="cmt-v265-cal">')[1].split('</script>')[0];
const mount = script.slice(script.indexOf('function monta(){rotula();'), script.indexOf('\nfunction liga(){'));

function fixture() {
  const classes = () => {
    const values = new Set();
    return { add: k => values.add(k), remove: k => values.delete(k),
      contains: k => values.has(k), toggle(k, on) { on ? values.add(k) : values.delete(k); } };
  };
  const box = { classList: classes(), dataset: {}, setAttribute() {}, parentNode: null, prepend(el) { this.status = el; } };
  const root = { classList: classes() };
  const rs = { appendChild(el) { el.parentNode = this; } };
  const context = vm.createContext({
    box, sig: 'old', rs, active: true, ready: true, fail: false, bindings: 0,
    rotula() {}, lugar() { return context.active ? rs : null; },
    tudo() { if (context.fail) throw new Error('model failed'); return context.ready; },
    liga() { context.bindings++; },
    $() { return box.status || null; },
    D: { documentElement: root, createElement() { return { dataset: {}, setAttribute() {} }; } },
    console: { warn() {} }, HTML: '',
  });
  vm.runInContext(mount, context);
  return { context, box, root, rs };
}

test('calendar script parses and host keeps its native fixed positioning', () => {
  assert.doesNotThrow(() => new Function(script));
  assert.doesNotMatch(html, /html\.pa-cal-on #alt-rside\{position:relative!important\}/);
});

test('ready calendar mounts, and switching away removes only its visibility class', () => {
  const { context: c, box, root, rs } = fixture();
  c.monta();
  assert.equal(box.parentNode, rs);
  assert.equal(box.status.hidden, true);
  assert.equal(root.classList.contains('pa-cal-on'), true);
  c.active = false;
  c.monta();
  assert.equal(root.classList.contains('pa-cal-on'), false);
  c.active = true;
  c.monta();
  assert.equal(root.classList.contains('pa-cal-on'), true);
});

test('model not ready shows loading rather than a blank calendar, then recovers', () => {
  const { context: c, box } = fixture();
  c.ready = false;
  c.monta();
  assert.match(box.status.textContent, /Carregando calendário/);
  assert.equal(box.classList.contains('pa-cal-pending'), true);
  c.ready = true;
  c.monta();
  assert.equal(box.status.hidden, true);
  assert.equal(box.classList.contains('pa-cal-pending'), false);
});

test('render failure shows an explicit error and retries without rebinding handlers', () => {
  const { context: c, box } = fixture();
  c.fail = true;
  c.monta();
  assert.match(box.status.textContent, /Não foi possível/);
  c.fail = false;
  c.monta();
  assert.equal(box.status.hidden, true);
  assert.equal(c.bindings, 0);
  // The signature is committed only after all renderers succeed, so failed data can retry.
  assert.match(script, /renderCal\(V\);renderDay\(V\);renderList\(V\);renderTeam\(V\);aplicaVista\(\);[\s\S]*?sig=s;return true;/);
});

test('mount failure restores native content instead of hiding both calendars', () => {
  const { context: c, root, rs } = fixture();
  rs.appendChild = () => { throw new Error('host being replaced'); };
  c.monta();
  assert.equal(root.classList.contains('pa-cal-on'), false);
});

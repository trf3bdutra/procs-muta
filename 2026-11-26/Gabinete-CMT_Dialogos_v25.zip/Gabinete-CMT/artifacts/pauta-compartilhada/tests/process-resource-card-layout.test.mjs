import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import vm from "node:vm";

const html=readFileSync(new URL("../../api-server/src/protected/gabcmt.html",import.meta.url),"utf8");
const start=html.indexOf("    recursosMini(x) {");
const end=html.indexOf("\n    // altera um recurso",start);
assert.notEqual(start,-1,"o renderer dos recursos deve existir");
assert.notEqual(end,-1,"o renderer dos recursos deve terminar antes dos handlers");
const source=html.slice(start,end);

function render(row){
  const method=vm.runInNewContext(`({${source}}).recursosMini`,{
    EDITOR_PARTES:[["parte autora","Parte autora"],["parte ré","Parte ré"]],
    PRELIM_TITLE:"Preliminar",
    esc:value=>String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])),
  });
  const page={
    host:{},
    prelOpen:new Set(),
    relRecursos:r=>r._recursos||[],
    edTipo:()=>"apelacao",
    off:()=>false,
    isPrelimRec:()=>false,
    edLines:value=>String(value||"").split(/\n+/).filter(Boolean),
    edLower:value=>String(value||"").toLowerCase(),
    recEspecieAuto:()=>"Apelação",
    edSel:(_x,path)=>`<select data-ed="${path}"></select>`,
    edIn:(_x,path)=>`<input data-ed="${path}">`,
    edIds:(_x,path)=>`<div class="pq-idrow" data-ed-path="${path}.ids"></div>`,
    dtIc:(_x,path)=>`<span class="pq-icrow" data-ed-path="${path}"></span>`,
    edAdd:()=>"",
  };
  return method.call(page,{r:row,i:7});
}

test("cada recurso apresenta documento, data e ID em linha compacta",()=>{
  const output=render({_recursos:[{especie:"Apelação",parte:"parte autora",data:"2026-10-20",ids:"101",contra:{situacao:"apresentadas",data:"2026-10-22",ids:"111"}}]});
  assert.match(output,/pq-om-ref-document[\s\S]*DOC[\s\S]*_recursos\.0\.especie/);
  assert.match(output,/pq-om-ref-date[\s\S]*DATA[\s\S]*_recursos\.0\.data/);
  assert.match(output,/pq-om-ref-id[\s\S]*ID[\s\S]*_recursos\.0\.ids/);
  assert.match(output,/pq-om-ref-status[\s\S]*SIT\.[\s\S]*_recursos\.0\.contra\.situacao/);
  assert.match(output,/pq-om-ref-date[\s\S]*_recursos\.0\.contra\.data/);
  assert.match(output,/pq-om-ref-id[\s\S]*_recursos\.0\.contra\.ids/);
});

test("a resposta permanece logo abaixo e vinculada ao índice do próprio recurso",()=>{
  const output=render({_recursos:[
    {especie:"Apelação",parte:"parte autora",contra:{situacao:"apresentadas",data:"2026-10-22",ids:"111"}},
    {especie:"Agravo interno",parte:"parte ré",contra:{situacao:"nao",data:"",ids:""}},
  ]});
  assert.match(output,/Contrarraz\./);
  assert.match(output,/Contramin\./);
  assert.match(output,/data-ed="_recursos\.0\.contra\.situacao"/);
  assert.match(output,/data-ed-path="_recursos\.0\.contra\.ids"/);
  assert.match(output,/data-ed="_recursos\.1\.contra\.situacao"/);
  assert.doesNotMatch(output,/data-ed-path="_recursos\.1\.contra\.ids"/);
});

test("os rótulos compactos são aplicados ao card e ao Prontuário",()=>{
  assert.match(html,/:is\(#controle-pauta-root \.k148,#cmtx-view \.tgx2 \.k148\) \.pq-om-ref-field/);
  assert.match(html,/:is\(#controle-pauta-root \.k148,#cmtx-view \.tgx2 \.k148\) \.pq-om-rec\.pq-om-rec-c\{padding:4px 6px!important;margin:4px 0!important\}/);
});

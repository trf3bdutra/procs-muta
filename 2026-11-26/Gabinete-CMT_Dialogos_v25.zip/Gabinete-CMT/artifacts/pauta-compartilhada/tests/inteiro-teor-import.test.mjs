import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import vm from "node:vm";

const html=readFileSync(new URL("../../api-server/src/protected/gabcmt.html",import.meta.url),"utf8");
const start=html.indexOf("async function applySuggestions(rowIndex,items,parsed){");
const end=html.indexOf("\n\n/* ───────────────────────── 6 · IA OPCIONAL",start);
assert.ok(start>=0&&end>start,"função de gravação do inteiro teor encontrada");
const source=html.slice(start,end);
const identityStart=html.indexOf("function identitySuggestions(parsed,r,add){");
const identityEnd=html.indexOf("\nfunction buildSuggestions",identityStart);
assert.ok(identityStart>=0&&identityEnd>identityStart,"mapeamento dos campos de identificação encontrado");
const identitySource=html.slice(identityStart,identityEnd);
const identitySuggestions=vm.runInNewContext(`(()=>{${identitySource};return identitySuggestions;})()`,{
  S:value=>String(value??"").trim(),
  N:value=>String(value??"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/\s+/g," ").trim(),
});

function importer({saveResult=true}={}){
  const row={
    Processo:"5005972-43.2024.4.03.6000",
    _pautaEntries:[{session:"13/11/2026",closed:false}],
    _recursos:[{ids:"",preliminares:"",teses:"",pedidos:"",lista:[]}],
  };
  const host={rows:[row],_pautaViewVersion:0,recompute(){}};
  const calls={marked:null,saves:0,renders:0};
  const pg={
    host,session:"13/11/2026",
    relRecursos(record){record._recursos ||= [];return record._recursos;},
    edTemplate(){return {ids:"",preliminares:"",teses:"",pedidos:"",lista:[]};},
    genSync(){},
    invalidateSearchCache(){},
    render(){calls.renders++;},
  };
  const manual={
    markPending(index,before){calls.marked={index,before};},
    isBusy(){return false;},
    async saveNow(){calls.saves++;return saveResult;},
  };
  const apply=vm.runInNewContext(`(()=>{${source};return applySuggestions;})()`,{
    S:value=>String(value??"").trim(),
    page:()=>pg,
    window:{CMTManualSave:manual},
    cnjDigits:value=>String(value||"").replace(/\D/g,""),
    PC:()=>({}),
    PARTES:["parte autora"],
  });
  return {apply,row,calls};
}

test("inteiro teor grava campos do card/prontuário e aguarda confirmação do salvamento",async()=>{
  const {apply,row,calls}=importer();
  const before=JSON.parse(JSON.stringify(row));
  const result=await apply(0,[
    {kind:"field",key:"Preparo",value:"Dispensado",doc:"901",apply:true},
    {kind:"rec",idx:1,key:"ids",value:"902",doc:"902",apply:true},
  ],{processo:row.Processo});

  assert.deepEqual({...result},{count:2,saved:true});
  assert.equal(row.Preparo,"Dispensado");
  assert.equal(row._recursos[1].ids,"902");
  assert.equal(row._pautaHistory.at(-1).action,"Importação do inteiro teor (TXT)");
  assert.equal(calls.marked.index,0);
  assert.deepEqual(JSON.parse(JSON.stringify(calls.marked.before)),before);
  assert.equal(calls.saves,1);
  assert.ok(calls.renders>=1);
});

test("falha de sincronização preserva campos preenchidos e sinaliza que não houve confirmação",async()=>{
  const {apply,row,calls}=importer({saveResult:false});
  const result=await apply(0,[
    {kind:"field",key:"Tempestividade",value:"Tempestivo",doc:"903",apply:true},
  ],{processo:row.Processo});

  assert.deepEqual({...result},{count:1,saved:false});
  assert.equal(row.Tempestividade,"Tempestivo","não descarta a edição local");
  assert.equal(calls.saves,1);
});

test("nenhum campo confirmado não dispara salvamento",async()=>{
  const {apply,row,calls}=importer();
  const result=await apply(0,[
    {kind:"field",key:"Preparo",value:"Dispensado",doc:"901",apply:false},
  ],{processo:row.Processo});

  assert.deepEqual({...result},{count:0,saved:true});
  assert.equal(row.Preparo,undefined);
  assert.equal(calls.saves,0);
  assert.equal(calls.marked,null);
});

test("inteiro teor sugere assunto, classe e partes sem confundir recorrente com polo original",()=>{
  const items=[];
  identitySuggestions({
    assunto:"Benefício por incapacidade",
    classeAbbr:"AP",
    polos:{
      autor:["Maria da Silva"],
      reu:["INSS"],
      agravante:["INSS"],
      agravado:["Maria da Silva"],
    },
  },{Assunto:"",classe_judicial:"","Polo Ativo":"","Polo Passivo":"","Partes":""},item=>items.push(item));

  const values=Object.fromEntries(items.map(item=>[item.key,item.value]));
  assert.equal(values.Assunto,"Benefício por incapacidade");
  assert.equal(values.classe_judicial,"AP");
  assert.equal(values["Polo Ativo"],"Maria da Silva");
  assert.equal(values["Polo Passivo"],"INSS");
  assert.equal(values.Partes,"Maria da Silva × INSS");
});

test("CNJ diferente bloqueia a gravação para evitar preencher outro processo",async()=>{
  const {apply,row,calls}=importer();
  await assert.rejects(
    apply(0,[{kind:"field",key:"Preparo",value:"Dispensado",doc:"901",apply:true}],{
      processo:"5000000-00.2024.4.03.6000",
      main:"50000000020244036000",
    }),
    /Nenhum campo foi alterado/,
  );
  assert.equal(row.Preparo,undefined);
  assert.equal(calls.saves,0);
});

import assert from "node:assert/strict";
import test from "node:test";
import { resolveLoginDestination } from "../src/lib/login-destination.ts";

const origin = "https://gabinete.example";

test("usa o Gabinete quando o login não tem destino explícito", () => {
  assert.equal(resolveLoginDestination("", origin), "/gabinete");
  assert.equal(resolveLoginDestination("?next=", origin), "/gabinete");
});

test("mantém no Gabinete as entradas gerais, sem redirecionar ao perfil", () => {
  for (const path of ["/", "/gabinete", "/cmt", "/ass", "/gabinete/", "/cmt/"]) {
    assert.equal(resolveLoginDestination(`?next=${encodeURIComponent(path)}`, origin), "/gabinete");
  }
});

test("normaliza o endereço antigo do servidor para o perfil dentro do GabCMT", () => {
  assert.equal(resolveLoginDestination("?next=%2Fservidor", origin), "/serv-user");
  assert.equal(resolveLoginDestination("?next=%2Fservidor%2F%3Ftab%3Dperfil%23dados", origin), "/serv-user?tab=perfil#dados");
});

test("preserva destinos internos explícitos e seguros", () => {
  assert.equal(
    resolveLoginDestination("?next=%2Fcontrole-de-decisoes%3Faba%3Dcalendario%23agenda", origin),
    "/controle-de-decisoes?aba=calendario#agenda",
  );
  assert.equal(resolveLoginDestination("?next=%2Fserv-user", origin), "/serv-user");
  assert.equal(resolveLoginDestination("?next=%2Faccounts", origin), "/accounts");
});

test("destinos inválidos voltam ao Gabinete", () => {
  for (const candidate of [
    "https://fora.example",
    "//fora.example",
    "/sign-in",
    "/api/auth/session",
    "/\\fora.example",
  ]) {
    assert.equal(resolveLoginDestination(`?next=${encodeURIComponent(candidate)}`, origin), "/gabinete");
  }
});

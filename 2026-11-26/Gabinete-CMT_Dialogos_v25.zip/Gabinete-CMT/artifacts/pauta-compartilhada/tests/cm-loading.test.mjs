import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';

const page = await readFile(new URL('../src/pages/shared-pauta.tsx', import.meta.url), 'utf8');
const loader = await readFile(new URL('../src/components/loading/GabineteLoader.tsx', import.meta.url), 'utf8');

test('CM has a dedicated loader and does not display login welcome copy', () => {
  assert.match(page, /heading=\{cmRoute \? 'Mesa do Desembargador'/);
  assert.match(page, /welcome=\{!cmRoute && loginWelcome\}/);
  assert.match(loader, /heading \|\|/);
});

test('CM reveal waits for its visible rendered view and two animation frames', () => {
  assert.match(page, /const cmLoading = cmRoute && !cmReady/);
  assert.match(page, /!pautaQuery\.isError && !cmLoading/);
  assert.match(page, /!root\.hidden/);
  assert.match(page, /root\.querySelector\('\.cm3-brand, \.cmt2-top, \.cmt-adv-top'\)/);
  assert.match(page, /paint = requestAnimationFrame\(\(\) => \{\s*reveal = requestAnimationFrame\(\(\) => setCmReady\(true\)\)/);
});

test('CM readiness wait is bounded and canceled when navigation changes', () => {
  assert.match(page, /performance\.now\(\) \+ 20_000/);
  assert.match(page, /performance\.now\(\) >= deadline\) \{\s*setModuleError\(true\)/);
  assert.match(page, /clearTimeout\(timer\);\s*cancelAnimationFrame\(paint\);\s*cancelAnimationFrame\(reveal\)/);
});

import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import vm from "node:vm";

const html=readFileSync(new URL("../../api-server/src/protected/gabcmt.html",import.meta.url),"utf8");
const allowed=["Não Verificado","Tempestivo","Intempestivo","Não se Aplica"];
const escape=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const begin=html.indexOf("    sel(x,field,vals,current,write='')");
const end=html.indexOf("    area(x,field",begin);
const native=vm.runInNewContext("({"+html.slice(begin,end)+"})",{esc:escape});
native.attr=()=> 'data-field="Tempestividade"';
const options=markup=>Array.from(markup.matchAll(/<option[^>]*>([^<]*)<\/option>/g),m=>m[1]);
const selected=markup=>markup.match(/<option[^>]*selected[^>]*>([^<]*)<\/option>/)?.[1];

test("seletor original não acrescenta valores estranhos já cadastrados nem de outros campos",()=>{
  for(const value of ["Regular","Comprovado","Dispensado","Cabimento",null,""]){
    const out=native.sel({},"Tempestividade",["Preparo","Comprovado"],value);
    assert.deepEqual(options(out),allowed);
    assert.equal(selected(out),"Não Verificado");
  }
});
test("opções corretas são preservadas e os demais campos continuam aceitando seu valor existente",()=>{
  for(const value of allowed)assert.equal(selected(native.sel({},"Tempestividade",[],value)),value);
  assert.equal(selected(native.sel({},"Tempestividade",[],"intempestivo")),"Intempestivo");
  assert.ok(options(native.sel({},"Outro campo",["A"],"Legado")).includes("Legado"));
});
const r3=html.slice(html.indexOf('<script id="cmt-v261-card-r3">'));
const helpers=r3.slice(r3.indexOf("const TEMPESTIVIDADE="),r3.indexOf("/* ───────── estado de exibição"));
const valueStart=r3.indexOf("function valueHTML(");
const valueFn=r3.slice(valueStart,r3.indexOf("\n}\n",valueStart)+3);
let writes=0;
const current=vm.runInNewContext(helpers+"\n"+valueFn+"\n({valueHTML,setF,tempestValue});",{
  esc:escape,grava(p,fn){writes++;return fn(p.r);},FMAP:{tempest:"Tempestividade"},
});
test("card atual usa apenas opções de prazo e não presume Não se Aplica por espécie",()=>{
  for(const kind of ["apel","ed","agint","rn","jr"]){
    const p={f:{tempest:"Regular",intimacao:"2026-11-03"}};
    const out=current.valueHTML(p,{key:"tempest",type:"tempest"},kind);
    assert.deepEqual(options(out),allowed);
    assert.equal(selected(out),"Não Verificado");
    assert.equal(p.f.tempest,"Regular","renderizar não altera informações existentes");
    assert.match(out,/Data da intimação/);
  }
});
test("card só grava opções próprias de tempestividade",()=>{
  const p={r:{Tempestividade:"Tempestivo"}};
  assert.equal(current.setF(p,"tempest","Comprovado"),false);
  assert.equal(writes,0);
  for(const value of allowed){current.setF(p,"tempest",value);assert.equal(p.r.Tempestividade,value);}
});

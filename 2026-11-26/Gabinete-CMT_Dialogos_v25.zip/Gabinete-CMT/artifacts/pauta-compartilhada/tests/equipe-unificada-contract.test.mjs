import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';

const mod = readFileSync(new URL('../src/lib/equipe-unificada/index.ts', import.meta.url), 'utf8');
const page = readFileSync(new URL('../src/pages/shared-pauta.tsx', import.meta.url), 'utf8');

test('equipe unificada: single installer, old profile CSS removed', () => {
  assert.ok(!existsSync(new URL('../src/pages/server-profile-settings.css', import.meta.url)));
  assert.ok(!page.includes('server-profile-settings.css'));
  assert.equal(page.match(/installEquipeUnificada\(/g)?.length, 1);
  assert.match(mod, /__cmtEquipeUnificada\?\.\(\)/, 'previous install is cleaned up before reinstall');
  assert.doesNotMatch(mod, /subtree:\s*true/, 'observers stay narrow');
  assert.doesNotMatch(mod, /setInterval/, 'no periodic rerender');
  assert.doesNotMatch(mod, /cloneNode/, 'no cloned controls');
});

const gab = readFileSync(new URL('../../api-server/src/protected/gabcmt.html', import.meta.url), 'utf8');

test('equipe area opens on the unified matrix; full profile and admin accounts remain', () => {
  const a = gab.indexOf('const AREAS=['), b = gab.indexOf('const TODOS=');
  const AREAS = new Function(gab.slice(a, b) + ';return AREAS')();
  const subs = AREAS.find((x) => x[0] === 'equipe')[2];
  // Desde a publicação de 30/10/2026 a área Equipe é um painel único (designações, perfil, presença, metas e correção).
  assert.deepEqual(subs.map((x) => x[0]), ['equipe', 'contas']);
  assert.equal(subs[0][2].painel, 'equipe');
  assert.match(subs[0][3], /designações/);
  assert.equal(subs.find((x) => x[0] === 'contas')[2].admin, true);
});

test('selected server panel reuses real per-member controls', () => {
  const side = gab.slice(gab.indexOf('function atuSide'), gab.indexOf('function unifiedAssignHTML'));
  for (const part of ['class="atu-id"', 'presencaHTML(h,m)', 'class="atu-scopes"', 'metaPontos(h,m)', 'data-team-task-add', 'data-team="profile"']) {
    assert.ok(side.includes(part), part);
  }
  const uni = gab.slice(gab.indexOf('function unifiedAssignHTML'), gab.indexOf('let tasksMode'));
  assert.ok(uni.includes('data-team="assign-focus"'), 'matrix heading selects server');
  assert.ok(!uni.includes('membersHTML('), 'full profile is not rendered twice on the matrix page');
  new Function(side);
});

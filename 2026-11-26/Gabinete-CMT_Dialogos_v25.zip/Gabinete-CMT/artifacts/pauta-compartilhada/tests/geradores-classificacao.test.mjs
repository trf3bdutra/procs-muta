import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";
const src=readFileSync(new URL("../public/cmt-geradores-biblioteca.js",import.meta.url),"utf8");
const ctx={module:{exports:{}}};vm.runInNewContext(src,ctx);const p=ctx.module.exports;

test("tipo de decisão, classe do processo e julgamento são dimensões independentes",()=>{
  const r={tipo:"acórdão",classes:{ApCiv:20},especie:"Embargos de declaração"};
  const c=p.classifica(r);
  assert.equal(c.decisao,"Acórdão");
  assert.deepEqual(Array.from(c.classes),["APCIV"]);
  assert.equal(c.julgamento,"Embargos de declaração");
  assert.equal(p.passaClassificacao(r,{decisao:"Acórdão",classe:"APCIV",julgamento:"Embargos de declaração"}),true);
  assert.equal(p.passaClassificacao(r,{decisao:"Decisão monocrática"}),false);
  assert.equal(p.passaClassificacao(r,{classe:"AI"}),false);
  assert.equal(p.classifica({tipo:"acórdão",classeSigla:"ApCiv",tipoJulgamento:"ED"}).julgamento,"Embargos de declaração");
  assert.equal(p.classifica({tipo:"acórdão",classeSigla:"ApCiv",tipoJulgamento:"AgInt"}).julgamento,"Agravo interno / regimental");
});

test("não presumir primeiro julgamento nem ED pela menção incidental no corpo",()=>{
  const c=p.classifica({t:"A",classeSigla:"ApCiv",ementa:"APELAÇÃO CÍVEL. Mérito. A parte menciona embargos de declaração em outra ação."});
  assert.equal(c.julgamento,"Não informado");
  assert.equal(p.classifica({tipo:"monocrática",classes:{AI:2},tipoJulgamento:"1º julgamento"}).julgamento,"1º julgamento");
  const ed=p.classifica({t:"A",classeSigla:"ApCiv",ementa:"EMENTA. PROCESSUAL CIVIL. EMBARGOS DE DECLARAÇÃO. OMISSÃO."});
  assert.equal(ed.julgamento,"Embargos de declaração");
  assert.match(ed.indicio,/abertura/);
});

test("agravo de instrumento não é agravo interno; sentenças/despachos não são acórdãos",()=>{
  assert.equal(p.classifica({tipo:"monocrática",especie:"Agravo de instrumento"}).julgamento,"Não informado");
  assert.equal(p.classifica({tipo:"acórdão",especie:"Agravo regimental",classes:{AI:2}}).julgamento,"Agravo interno / regimental");
  assert.equal(p.classifica({pronunciamento:"Sentença"}).decisao,"Sentença");
  assert.equal(p.classifica({pronunciamento:"Despacho"}).decisao,"Despacho");
});

test("parágrafo repetido mantém todas as origens e o filtro escolhe a fonte correspondente",()=>{
  const fontes=[
    {id:"a",nome:"Acórdão de apelação",meta:p.classifica({tipo:"acórdão",classes:{ApCiv:2}})},
    {id:"b",nome:"Monocrática de agravo",meta:p.classifica({tipo:"monocrática",classes:{AI:3}})},
  ];
  const list=[{id:"pub:a:0",txt:"Mesmo parágrafo.",sec:"fundamentacao",fontes}];
  const b=p.selecionaFontesParagrafos(list,{decisao:"Decisão monocrática",classe:"AI"},"");
  assert.equal(b.length,1);assert.equal(b[0].fonteId,"b");assert.equal(b[0].meta.decisao,"Decisão monocrática");
  assert.equal(p.selecionaFontesParagrafos(list,{classe:"APCIV"},"b").length,0);
  assert.equal(p.selecionaFontesParagrafos(list,{},"a")[0].fonteId,"a");
  assert.equal(list[0].fontes.length,2);
});

test("sem aba Redação assistida: modelos, parágrafos e Padrão vão ao painel lateral do Documento",()=>{
  const tabs=src.slice(src.indexOf("var ABAS ="),src.indexOf("function ger()"));
  assert.doesNotMatch(tabs,/Redação assistida|\['minutas'|\['paragrafos'|\['padrao'/);
  assert.match(tabs,/\['doc', 'Documento'/);assert.match(tabs,/\['paradigmas', 'Jurisprudência'/);
  assert.match(tabs,/var APOIO = \{ minutas: 'par', modelo: 'mod', modelos: 'mod', paragrafos: 'par', paragrafo: 'par', padrao: 'dir' \}/);
  assert.match(src,/W\.CMTGerador\.apoio\(apoio\)/);
  assert.doesNotMatch(src,/data-gbib-section=/);
  assert.match(src,/p\.addEventListener\('change', muda\)/);
});

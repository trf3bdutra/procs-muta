import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';
import vm from 'node:vm';

const gate = await readFile(new URL('../src/components/app-access-gate.tsx', import.meta.url), 'utf8');
const app = await readFile(new URL('../src/App.tsx', import.meta.url), 'utf8');

test('CM session fallback works on all pages, without forcing a redirect to /cm', () => {
  assert.match(gate, /if \(value\.status === 401\) \{\s*const cmResponse = await fetch/);
  assert.doesNotMatch(gate, /if \(currentPath === "\/cm" && value\.status === 401\)/);
  assert.doesNotMatch(app, /session\?\.userId === 'cm-link' && pathname !== '\/cm'/);
  assert.match(gate, /data\.userId !== "cm-link" \|\| data\.role !== "equipe" \|\| data\.server !== "CM"/);
});

test('the actual CM fallback validates the server response and keeps the identity on /gabinete', async () => {
  const start = gate.indexOf('if (value.status === 401) {');
  const end = gate.indexOf('\n        throw error;', start);
  const fallback = gate.slice(start, end).replace(' as AppSession', '');
  const stored = new Map();
  const pinned = new Map();
  let cleared = 0;
  let accepted;
  const context = {
    value: { status: 401 }, currentPath: '/gabinete', authApi: '/api/auth',
    controller: { signal: undefined }, current: 1, generation: { current: 1 },
    fetch: async path => {
      assert.equal(path, '/api/auth/cm-session');
      return { ok: true, json: async () => ({ authenticated: true, userId: 'cm-link', role: 'equipe', name: 'Desembargador', server: 'CM' }) };
    },
    sessionStorage: { setItem: (key, value) => stored.set(key, value), getItem: key => stored.get(key) },
    localStorage: { setItem: (key, value) => pinned.set(key, value) },
    queryClient: { clear: () => { cleared++; } },
    window: { dispatchEvent() {} }, Event,
    setSignedIn() {}, setEmail() {}, setStatus() {}, setMessage() {}, setCmAccessError() {},
    setSession: fn => { accepted = fn(null); },
  };
  vm.createContext(context);
  const response = await vm.runInContext(`(async () => { ${fallback} })()`, context);
  assert.equal(response.userId, 'cm-link');
  assert.equal(accepted.name, 'Desembargador');
  assert.equal(stored.get('cmt:user-id'), 'cm-link');
  assert.equal(pinned.get('pauta.footer-pinned-server.v1'), '["CM"]');
  stored.set('cmt:user-id', 'old-account');
  await vm.runInContext(`(async () => { ${fallback} })()`, context);
  assert.equal(cleared, 1);
  context.fetch = async () => ({ ok: true, json: async () => ({ authenticated: true, userId: 'forged', role: 'administracao', server: 'CM' }) });
  await assert.rejects(vm.runInContext(`(async () => { ${fallback} })()`, context), /não é válida/);
});

import assert from "node:assert/strict";
import { readFileSync, readdirSync, statSync } from "node:fs";
import test from "node:test";

const root = new URL("../", import.meta.url);

test("o build publica manifesto e ícones PWA com dimensões de instalação", () => {
  const output = new URL("dist/public/", root);
  const html = readFileSync(new URL("index.html", output), "utf8");
  const manifest = JSON.parse(readFileSync(new URL("manifest.webmanifest", output), "utf8"));
  const scripts = readdirSync(new URL("assets/", output))
    .filter((file) => file.endsWith(".js"))
    .map((file) => readFileSync(new URL(`assets/${file}`, output), "utf8"))
    .join("\n");

  assert.match(html, /rel="manifest" href="\/manifest\.webmanifest"/);
  assert.match(scripts, /service-worker\.js/);
  assert.equal(manifest.name, "Gabinete CMT");
  assert.equal(manifest.start_url, "/");
  assert.equal(manifest.scope, "/");
  assert.equal(manifest.display, "standalone");

  for (const [name, size] of [["pwa-192.png", 192], ["pwa-512.png", 512], ["apple-touch-icon.png", 180]]) {
    const image = readFileSync(new URL(name, output));
    assert.equal(image.toString("hex", 0, 8), "89504e470d0a1a0a", `${name} deve ser PNG válido`);
    assert.equal(image.readUInt32BE(16), size, `${name} deve ter largura ${size}`);
    assert.equal(image.readUInt32BE(20), size, `${name} deve ter altura ${size}`);
    assert.ok(statSync(new URL(name, output)).size < 60_000, `${name} deve continuar leve`);
  }
});

test("o service worker atualiza páginas sem armazenar HTML, API ou dados autenticados", () => {
  const worker = readFileSync(new URL("dist/public/service-worker.js", root), "utf8");
  assert.match(worker, /request\.mode !== 'navigate'/);
  assert.match(worker, /cache: 'no-cache'/);
  assert.doesNotMatch(worker, /caches\.open|caches\.put|cache\.addAll/);
});

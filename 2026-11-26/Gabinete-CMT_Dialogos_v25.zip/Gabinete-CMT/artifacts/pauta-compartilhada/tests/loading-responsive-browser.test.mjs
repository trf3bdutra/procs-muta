import { existsSync } from "node:fs";
import { createRequire } from "node:module";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createServer } from "node:http";
import { access, mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import test from "node:test";
import { setTimeout as delay } from "node:timers/promises";

const appDirectory = new URL("../dist/public/", import.meta.url);
// Resolve o Chromium no Replit, no PATH ou no Playwright instalado (CI e máquinas locais).
const chromiumPath = (() => {
  const candidates = [
    process.env.CHROMIUM_PATH,
    "/repl/tools/bin/chromium",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/usr/bin/google-chrome",
  ].filter(Boolean);
  for (const candidate of candidates) {
    if (existsSync(candidate)) return candidate;
  }
  try {
    return createRequire(import.meta.url)("playwright").chromium.executablePath();
  } catch {
    return candidates[0];
  }
})();
const mimeTypes = { ".css": "text/css", ".svg": "image/svg+xml", ".woff2": "font/woff2" };

const server = createServer(async (request, response) => {
  const url = new URL(request.url || "/", "http://localhost");
  if (url.pathname === "/") {
    const index = await readFile(new URL("index.html", appDirectory), "utf8");
    const stylesheets = [...index.matchAll(/<link[^>]+rel="stylesheet"[^>]+href="([^"]+)"/g)]
      .map(([, href]) => `<link rel="stylesheet" href="${href}">`)
      .join("");
    const error = url.searchParams.get("state") === "error";
    response.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    response.end(`<!doctype html>
      <html><head><meta name="viewport" content="width=device-width, initial-scale=1">${stylesheets}
      <style>html, body { width: 100%; min-height: 100%; margin: 0; } body { overflow: hidden; }</style></head>
      <body><div class="cmt-loader cmt-loader--fullscreen cmt-loader--cover${error ? " is-error" : ""}"
        role="status" aria-live="polite" aria-busy="${!error}">
        <section class="cmt-loader__content">
          <span class="cmt-loader__mark" role="img" aria-label="Logotipo do Gabinete CMT"><span class="cmt-loader__star"></span></span>
          <p class="cmt-loader__identity">GABINETE DO DESEMBARGADOR</p>
          <p class="cmt-loader__greeting">Bom dia, <em>RODRIGO.</em></p>
          ${error ? "" : '<p class="cmt-loader__welcome">Que bom ter você aqui. A Turma estava esperando por você.</p>'}
          ${error ? "" : '<div class="cmt-loader__track cmt-loader__track--determinate" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="63" aria-label="Progresso da operação"><div class="cmt-loader__progress" style="width:63%"></div></div>'}
          <p class="cmt-loader__stage">${error
            ? "Não foi possível carregar a pauta compartilhada. A conexão demorou e a resposta do servidor ainda não chegou."
            : "Carregando os dados compartilhados da equipe e preparando a visualização da pauta para você."}</p>
          <p class="cmt-loader__detail">${error
            ? "Verifique sua conexão e tente novamente. Se o problema continuar, saia e entre de novo."
            : "A etapa atual está em andamento; seus dados e o progresso continuam disponíveis enquanto o sistema prepara a tela."}</p>
          ${error ? '<div class="cmt-loader__actions"><button type="button" id="retry">Verificar acesso</button><button type="button" class="cmt-loader__secondary" id="logout">Sair e voltar ao login</button><p class="cmt-loader__action-error" role="alert">Não foi possível validar o acesso. Você pode tentar novamente.</p></div>' : ""}
        </section>
      </div></body></html>`);
    return;
  }

  const filename = path.resolve(appDirectory.pathname, `.${decodeURIComponent(url.pathname)}`);
  if (!filename.startsWith(path.resolve(appDirectory.pathname))) {
    response.writeHead(403).end();
    return;
  }
  try {
    await access(filename);
    const contents = await readFile(filename);
    response.writeHead(200, { "Content-Type": mimeTypes[path.extname(filename)] || "application/octet-stream" });
    response.end(contents);
  } catch {
    response.writeHead(404).end();
  }
});

class DevTools {
  #socket;
  #nextId = 0;
  #pending = new Map();

  constructor(socket) {
    this.#socket = socket;
    socket.addEventListener("message", (event) => {
      const message = JSON.parse(event.data);
      if (!message.id) return;
      const pending = this.#pending.get(message.id);
      if (!pending) return;
      this.#pending.delete(message.id);
      if (message.error) pending.reject(new Error(message.error.message));
      else pending.resolve(message.result);
    });
  }

  send(method, params = {}) {
    const id = ++this.#nextId;
    const result = new Promise((resolve, reject) => this.#pending.set(id, { resolve, reject }));
    this.#socket.send(JSON.stringify({ id, method, params }));
    return result;
  }

  async evaluate(expression) {
    const response = await this.send("Runtime.evaluate", { expression, returnByValue: true });
    if (response.exceptionDetails) throw new Error(response.exceptionDetails.text || "Browser evaluation failed");
    return response.result?.value;
  }
}

async function waitFor(predicate, message, timeout = 10_000) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    if (await predicate()) return;
    await delay(100);
  }
  throw new Error(message);
}

async function startBrowser() {
  const userDataDir = await mkdtemp(path.join(tmpdir(), "gabinete-loader-browser-"));
  const child = spawn(chromiumPath, [
    "--headless=new", "--no-sandbox", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
    "--remote-debugging-address=127.0.0.1", "--remote-debugging-port=0", `--user-data-dir=${userDataDir}`, "about:blank",
  ], { stdio: "ignore", detached: true });

  try {
    const portFile = path.join(userDataDir, "DevToolsActivePort");
    let port;
    await waitFor(async () => {
      try {
        port = Number((await readFile(portFile, "utf8")).split("\n")[0]);
        return port > 0;
      } catch {
        return false;
      }
    }, "Chromium did not start its remote debugging endpoint.");
    const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    const target = targets.find((item) => item.type === "page");
    assert.ok(target?.webSocketDebuggerUrl, "Chromium did not expose a page target.");
    const socket = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => {
      socket.addEventListener("open", resolve, { once: true });
      socket.addEventListener("error", reject, { once: true });
    });
    return { child, userDataDir, socket, devtools: new DevTools(socket) };
  } catch (error) {
    await stopBrowser(child, userDataDir);
    throw error;
  }
}

async function stopBrowser(child, userDataDir) {
  const exited = new Promise((resolve) => child.once("exit", resolve));
  try {
    process.kill(-child.pid, "SIGTERM");
  } catch {
    child.kill("SIGTERM");
  }
  await Promise.race([exited, delay(1_500)]);
  try {
    process.kill(-child.pid, "SIGKILL");
  } catch {
    child.kill("SIGKILL");
  }
  await Promise.race([exited, delay(500)]);
  await rm(userDataDir, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
}

test("loading and recovery remain readable, scrollable, and keyboard-accessible on small screens", async (t) => {
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
  let browser;
  t.after(async () => {
    browser?.socket.close();
    if (browser) await stopBrowser(browser.child, browser.userDataDir);
    server.closeAllConnections();
    server.close();
  });
  browser = await startBrowser();
  const appUrl = `http://127.0.0.1:${server.address().port}`;
  const viewportCases = [
    { name: "narrow portrait", width: 320, height: 480 },
    { name: "short landscape", width: 360, height: 240 },
    { name: "extra narrow", width: 280, height: 360 },
  ];

  await browser.devtools.send("Page.enable");
  await browser.devtools.send("Runtime.enable");
  for (const viewport of viewportCases) {
    await browser.devtools.send("Emulation.setDeviceMetricsOverride", {
      width: viewport.width, height: viewport.height, deviceScaleFactor: 1, mobile: true,
    });
    for (const state of ["loading", "error"]) {
      const query = state === "error" ? "?state=error" : "";
      await browser.devtools.send("Page.navigate", { url: `${appUrl}/${query}` });
      await waitFor(
        () => browser.devtools.evaluate(`Boolean(document.querySelector('.cmt-loader__stage'))`),
        `${state} screen did not render at ${viewport.name}.`,
      );

      const initial = await browser.devtools.evaluate(`(() => {
        const root = document.querySelector('.cmt-loader');
        return {
          width: root.clientWidth, height: root.clientHeight, scrollHeight: root.scrollHeight,
          top: document.querySelector('.cmt-loader__stage').getBoundingClientRect().top,
          progress: document.querySelector('[role="progressbar"]')?.getAttribute('aria-valuenow') ?? null,
          buttons: [...root.querySelectorAll('button')].map((button) => button.textContent.trim()),
          message: document.querySelector('.cmt-loader__stage').textContent.trim(),
          detail: document.querySelector('.cmt-loader__detail').textContent.trim(),
        };
      })()`);
      assert.equal(initial.width, viewport.width, `The loader width was clipped at ${viewport.name}.`);
      assert.ok(initial.top >= 0, `The loading/error message starts above the scrollable area at ${viewport.name}.`);
      assert.ok(initial.message.length > 30 && initial.detail.length > 30, "The status message and its detail must remain rendered.");
      if (state === "loading") {
        assert.equal(initial.progress, "63", "Known progress is exposed through an accessible progress bar.");
        const progressVisibleAfterScroll = await browser.devtools.evaluate(`(() => {
          const root = document.querySelector('.cmt-loader');
          const progress = document.querySelector('[role="progressbar"]');
          progress.scrollIntoView({ block: 'center' });
          const bounds = progress.getBoundingClientRect();
          return bounds.top >= root.getBoundingClientRect().top && bounds.bottom <= root.getBoundingClientRect().bottom;
        })()`);
        assert.equal(progressVisibleAfterScroll, true, `Progress cannot be reached by scrolling at ${viewport.name}.`);
        const messagesVisibleAfterScroll = await browser.devtools.evaluate(`(() => {
          const root = document.querySelector('.cmt-loader');
          return ['.cmt-loader__stage', '.cmt-loader__detail'].every((selector) => {
            const message = document.querySelector(selector);
            message.scrollIntoView({ block: 'center' });
            const bounds = message.getBoundingClientRect();
            return bounds.top >= root.getBoundingClientRect().top && bounds.bottom <= root.getBoundingClientRect().bottom;
          });
        })()`);
        assert.equal(messagesVisibleAfterScroll, true, `Loading messages cannot be reached by scrolling at ${viewport.name}.`);
      } else {
        assert.deepEqual(initial.buttons, ["Verificar acesso", "Sair e voltar ao login"]);
        assert.ok(initial.scrollHeight >= initial.height, "Recovery content must fit or scroll within the viewport.");

        await browser.devtools.send("Input.dispatchKeyEvent", { type: "keyDown", key: "Tab", code: "Tab", windowsVirtualKeyCode: 9 });
        await browser.devtools.send("Input.dispatchKeyEvent", { type: "keyUp", key: "Tab", code: "Tab", windowsVirtualKeyCode: 9 });
        const firstFocus = await browser.devtools.evaluate(`({
          id: document.activeElement.id,
          focusVisible: document.activeElement.matches(':focus-visible'),
          outline: getComputedStyle(document.activeElement).outlineStyle
        })`);
        assert.equal(firstFocus.id, "retry", `Keyboard focus must reach the access check first at ${viewport.name}.`);
        assert.equal(firstFocus.focusVisible, true, "The focused recovery action must have a visible keyboard focus state.");

        await browser.devtools.send("Input.dispatchKeyEvent", { type: "keyDown", key: "Tab", code: "Tab", windowsVirtualKeyCode: 9 });
        await browser.devtools.send("Input.dispatchKeyEvent", { type: "keyUp", key: "Tab", code: "Tab", windowsVirtualKeyCode: 9 });
        assert.equal(await browser.devtools.evaluate("document.activeElement.id"), "logout",
          `Keyboard focus must reach the exit action at ${viewport.name}.`);

        const errorMessagesVisibleAfterScroll = await browser.devtools.evaluate(`(() => {
          const root = document.querySelector('.cmt-loader');
          return ['.cmt-loader__stage', '.cmt-loader__detail', '.cmt-loader__action-error'].every((selector) => {
            const message = document.querySelector(selector);
            message.scrollIntoView({ block: 'center' });
            const bounds = message.getBoundingClientRect();
            return bounds.top >= root.getBoundingClientRect().top && bounds.bottom <= root.getBoundingClientRect().bottom;
          });
        })()`);
        assert.equal(errorMessagesVisibleAfterScroll, true, `Recovery messages cannot be reached by scrolling at ${viewport.name}.`);

        const actionAccess = await browser.devtools.evaluate(`(() => {
          const root = document.querySelector('.cmt-loader');
          root.scrollTop = root.scrollHeight;
          const actions = [...root.querySelectorAll('button')];
          const bounds = actions.map((button) => button.getBoundingClientRect());
          const viewport = root.getBoundingClientRect();
          return {
            scrollable: root.scrollHeight > root.clientHeight,
            scrolled: root.scrollTop > 0,
            visible: bounds.every((rect) => rect.top >= viewport.top && rect.bottom <= viewport.bottom),
          };
        })()`);
        assert.equal(actionAccess.visible, true, `Recovery buttons must be visible after scrolling at ${viewport.name}.`);
        if (actionAccess.scrollable) {
          assert.equal(actionAccess.scrolled, true, `Recovery actions overflow but cannot be reached by scrolling at ${viewport.name}.`);
        } else {
          assert.equal(actionAccess.visible, true, `Recovery actions must fit visibly when scrolling is unnecessary at ${viewport.name}.`);
        }
      }
    }
  }
});

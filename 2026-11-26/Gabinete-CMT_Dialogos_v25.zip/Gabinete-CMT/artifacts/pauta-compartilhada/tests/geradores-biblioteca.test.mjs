import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";

const here = new URL(".", import.meta.url);
const jsPath = new URL("../public/cmt-geradores-biblioteca.js", here);
const src = readFileSync(jsPath, "utf8");
const ctx = { module: { exports: {} } };
vm.runInNewContext(src, ctx);
const puro = ctx.module.exports;
const html = readFileSync(new URL("../../api-server/src/protected/gabcmt.html", here), "utf8");

test("normaliza preenche os campos da biblioteca sem perder extras", () => {
  const l = puro.normaliza({ extra: 1, paragrafos: [{ id: "a", txt: "x" }, { txt: "sem id" }] });
  assert.equal(JSON.stringify(Object.keys(l).sort()), JSON.stringify(["extra", "modelos", "modelosOcultos", "padraoMuta", "paradigmasOcultos", "paradigmasProprios", "paragrafos"].sort()));
  assert.equal(l.paragrafos.length, 1);
  assert.equal(l.padraoMuta, null);
});

test("mescla: próprio substitui estático e ocultos saem do uso", () => {
  const est = [{ id: "1", ementa: "a" }, { id: "2", ementa: "b" }];
  const out = puro.mescla(est, [{ id: "1", ementa: "nova" }, { id: "3" }], ["2"], false);
  assert.equal(JSON.stringify(out.map((x) => x.id).sort()), JSON.stringify(["1", "3"]));
  assert.equal(out.find((x) => x.id === "1").ementa, "nova");
  assert.equal(puro.mescla(est, [], ["2"], true).length, 2);
});

test("importação só acrescenta, nunca sobrescreve", () => {
  const r = puro.acrescenta([{ id: "a", txt: "orig" }], [{ id: "a", txt: "novo" }, { id: "b", txt: "b" }]);
  assert.equal(r.acrescentados, 1);
  assert.equal(r.lista.find((x) => x.id === "a").txt, "orig");
});

test("filtro ignora acentos", () => {
  assert.equal(puro.filtra([{ n: "Previdência" }], "previdencia", ["n"]).length, 1);
});

test("interface não mostra repositório e avisos técnicos, mas mantém atualização e erros", () => {
  const faixa = src.slice(src.indexOf("  function faixaPublica()"), src.indexOf("  function filtrados("));
  assert.doesNotMatch(faixa, /GitHub|repository|f\.url|Nada desta aba|Somente leitura|E\(er\)|E\(ST\.erro\)/);
  assert.match(faixa, /data-gbib="fonte-recarregar"/);
  assert.match(faixa, /role="alert"/);
  assert.match(faixa, /A última consulta continua disponível/);
  /* as diretrizes saíram da biblioteca: ficam na aba Diretrizes do painel lateral do Gerador (Manual CMT) */
  assert.doesNotMatch(src, /function telaPadrao|function diretrizesHTML|Embutida no arquivo|status-padrao-biblioteca|repositório público/);
});

test("contrato da API e bloqueio de escrita por canEditLibrary", () => {
  assert.match(src, /'\/api\/generator-library'/);
  assert.match(src, /d\.canEditLibrary === true/);
  const acao = src.slice(src.indexOf("  function padraoAcao(a) {"), src.indexOf("  function digita("));
  assert.match(acao, /if \(!ST\.can\) \{ avisa\('Somente a Assessoria/);
  assert.match(acao, /a === 'pm-importar'/);
  assert.match(src, /padraoAcao: padraoAcao/);
  assert.match(src, /baseRevision: ST\.rev/);
  assert.match(src, /r\.status === 409/);
  assert.match(src, /if \(!ST\.can\) \{ avisa\('Biblioteca somente leitura/);
  assert.doesNotMatch(src, /(fetch|import)\([^)]*github/i);
  assert.doesNotMatch(src, /\/api\/central\/estado/);
  for (const a of ["par-novo", "par-importar", "mod-novo", "mod-importar"]) {
    assert.doesNotMatch(src, new RegExp(`data-gbib="${a}"`), `${a} não deve sugerir uma escrita local para o catálogo GitHub`);
  }
  /* sem escrita de parágrafos pela biblioteca: o pessoal é salvo na aba Parágrafos do Gerador */
  assert.doesNotMatch(src, /data-gbib="pg-pessoal"|data-gbib="pg-inserir"|data-gbib="mod-usar"/);
  assert.match(src, /\/api\/paradigmas\/modelos/);
});

test("gabcmt: Paradigmas e Minutas saíram das Configurações e o atalho vai aos Geradores", () => {
  assert.doesNotMatch(html, /\['paradigmas','Paradigmas',\{painel:'paradigmas'\}/);
  assert.doesNotMatch(html, /\['minutas','Minutas',\{painel:'minutas'\}/);
  assert.match(html, /window\.CMTGerBib && window\.CMTGerBib\.ir/);
  assert.match(html, /B\.abrirEmentario\(root/);
  assert.match(html, /<script src="\/api\/app\/geradores-biblioteca\.js" defer><\/script>/);
  assert.match(readFileSync(new URL("../../api-server/src/routes/gabcmt.ts", here), "utf8"), /:is\(#cmt-ger,#pa-pdg\)/);
});

const gerSrc = (() => { const i = html.indexOf('<script id="cmt-v269-gerador">'); return html.slice(i, html.indexOf("</script>", i)); })();

test("Gerador consome a biblioteca: Padrão publicado e parágrafos do acervo na aba Parágrafos (sem aba Modelos)", () => {
  assert.match(gerSrc, /BIB\(\)\.padraoMuta\(\)/);
  assert.match(gerSrc, /pub\.roteiros && pub\.redacao && Array\.isArray\(pub\.redacao\.registros\)/);
  assert.match(gerSrc, /BIB\(\)\.paragrafosCompartilhados\(\)/);
  assert.match(gerSrc, /var APS = \[\['dir', 'Diretrizes'\], \['sim', 'Similares'\], \['par', 'Parágrafos'\]\];/);
  assert.doesNotMatch(gerSrc, /function bibModHTML|function modHTML|\['mod', 'Modelos'\]|data-gr="minutas"/);
  assert.match(gerSrc, /b\.dataset\.ins === 'par'[^\n]*inserir\(/);
  assert.match(gerSrc, /BIB\(\)\.padraoAcao\(a\)/);
  assert.match(gerSrc, /addEventListener\('gerbib:changed'/);
  assert.match(gerSrc, /window\.CMTGerador = \{ inserir: function \(t\) \{ inserir\(t\); \}/);
  assert.doesNotMatch(gerSrc, /fechar\(false\); window\.CMTCentralIr\(/);
  assert.doesNotMatch(gerSrc, /<button type="button" data-gr="publicar-par"/);
});

test("módulo dispara gerbib:changed e insere pelo inserir() do Gerador, sem área de transferência como substituto", () => {
  assert.match(src, /new CustomEvent\('gerbib:changed'/);
  assert.match(src, /G\.inserir\(txt\)/);
  assert.doesNotMatch(src, /function usaModelo/);
  assert.match(src, /publicarParagrafo: function \(p\) \{ if \(!ST\.can\)/);
});

test("sem volta às Configurações: atalho espera a biblioteca e aliases removidos", () => {
  const i = html.indexOf("  function ir(acao, dados) {\n    /* v270");
  const bloco = html.slice(i, html.indexOf("window.CMTCentralIr = ir;", i));
  assert.doesNotMatch(bloco, /configuracoes|CMTCfgNav/);
  assert.match(bloco, /não carregou/);
  assert.doesNotMatch(html, /modelos:'minutas'|central:'paradigmas'|jurisprudencia:'paradigmas'|minuta:'minutas'/);
});

function navegador(respostas, publico = {}) {
  const eventos = [], intervals = [], urls = [];
  const ger = { hidden: false, querySelector: () => null, querySelectorAll: () => [], classList: { toggle() {} } };
  const document = {
    visibilityState: "visible", activeElement: null,
    getElementById: (id) => (id === "cmt-ger" ? ger : null),
    querySelector: () => null, addEventListener() {}, createElement: () => ({ setAttribute() {}, addEventListener() {} }),
  };
  let n = 0;
  const win = {
    document, localStorage: { getItem: () => null, setItem() {} }, sessionStorage: { getItem: () => null, setItem() {} },
    dispatchEvent: (e) => eventos.push(e.detail), console,
  };
  const ctx = {
    window: win, CustomEvent: class { constructor(t, o) { this.type = t; this.detail = o.detail; } },
    setInterval: (f, ms) => intervals.push([f, ms]), setTimeout: () => 0, clearTimeout() {}, console, JSON, Promise, Set, Map, Object, String, Number, Array, Date, Math,
    fetch: async (url) => {
      urls.push(String(url));
      if (String(url).includes("precedentes")) return { ok: true, status: 200, json: async () => ({ registros: publico.registros || [], source: publico.source }) };
      if (String(url).includes("/paradigmas/modelos")) return { ok: true, status: 200, json: async () => ({ modelos: publico.modelos || [], source: publico.source }) };
      const r = respostas[Math.min(n++, respostas.length - 1)];
      return { ok: true, status: 200, json: async () => r };
    },
  };
  ctx.globalThis = ctx;
  vm.runInNewContext(src.replace("})(typeof window !== 'undefined' ? window : null);", "})(window);"), ctx);
  return { win, eventos, intervals, ger, urls };
}
const tick = () => new Promise((r) => setTimeout(r, 20));

test("GET com revisão e permissão inalteradas não dispara repintura", async () => {
  const lib = { paradigmasProprios: [{ id: "x", ementa: "e" }] };
  const b = navegador([{ library: lib, revision: 3, canEditLibrary: false }, { library: lib, revision: 3, canEditLibrary: false }, { library: lib, revision: 4, canEditLibrary: false }]);
  assert.equal(b.eventos.length, 0, "outras páginas não carregam a biblioteca");
  await b.win.CMTGerBib.recarregar();
  await tick();
  assert.equal(b.eventos.length, 1, "carga inicial avisa uma vez");
  await b.win.CMTGerBib.recarregar(); await tick();
  assert.equal(b.eventos.length, 1, "mesma revisão não avisa");
  await b.win.CMTGerBib.recarregar(); await tick();
  assert.equal(b.eventos.length, 2, "revisão nova avisa");
  assert.ok(b.intervals.some(([, ms]) => ms === 20000), "atualiza a cada 20 s");
});

test("atualização periódica respeita Gerador oculto e diálogo aberto", async () => {
  const b = navegador([{ library: {}, revision: 1, canEditLibrary: true }]);
  await b.win.CMTGerBib.recarregar();
  await tick();
  assert.equal(b.win.CMTGerBib.podeAtualizar(), true);
  b.ger.hidden = true;
  assert.equal(b.win.CMTGerBib.podeAtualizar(), false);
  b.ger.hidden = false; b.win.document.querySelector = (q) => (q.includes("dialog") ? {} : null);
  assert.equal(b.win.CMTGerBib.podeAtualizar(), false);
});

test("curadoria antiga local não sobrescreve nem oculta julgados do catálogo público", async () => {
  const b = navegador([{ library: { paradigmasProprios: [{ id: "a", ementa: "x" }, { id: "b", tese: "t" }], paradigmasOcultos: ["b", "estatico-1"] }, revision: 1, canEditLibrary: false }]);
  await b.win.CMTGerBib.recarregar();
  await tick();
  assert.equal(JSON.stringify(b.win.CMTGerBib.paradigmasProprios()), '[]');
  assert.equal(JSON.stringify(b.win.CMTGerBib.paradigmasOcultos()), '[]');
});

test("Jurisprudência do apoio: biblioteca casada por assunto, ocultos e edições aplicados ao CMTCorresp", () => {
  assert.match(gerSrc, /function bibParadigmas\(\)/);
  assert.match(gerSrc, /\[r\.Assunto, r\.Tema, r\.Especificidades, r\.Classe\]/);
  assert.match(gerSrc, /proprio \|\| sc >= 2/);
  assert.match(gerSrc, /oc\.indexOf\(String\(o\.c\.id\)\) < 0/);
  assert.match(gerSrc, /ov = bibEdit\(x\.id\)/);
  assert.match(gerSrc, /data-sim="ementario"/);
  assert.doesNotMatch(gerSrc, /data-gr="juris-q"|api\.buscar\(termoJuris\)|Resultados da busca/);
  assert.match(html, /function buscar\(query\)/);
  assert.match(html, /buscar: buscar/);
  assert.match(gerSrc, /data-bsim/);
  assert.doesNotMatch(src, /MutationObserver/);
});

test("ementa mantém dispositivos e jurisprudência como citações textuais, sem variáveis no documento", () => {
  const ementa = html.slice(html.indexOf("  function emSegs()"), html.indexOf("  /* ═══ esqueleto do voto"));
  assert.match(ementa, /Dispositivos relevantes citados: '\s*\+\s*referenciasEmTexto\(F\.em\.leis, false\)/);
  assert.match(ementa, /Jurisprudência relevante citada: '\s*\+\s*referenciasEmTexto\(F\.em\.juris, true\)/);
  assert.doesNotMatch(ementa, /fld\('em\.(?:leis|juris)'/);
  assert.match(html, /inp\('em\.leis', 'Dispositivos citados'/);
  assert.match(html, /inp\('em\.juris', 'Jurisprudência citada'/);
});

test("fonte pública alimenta as três abas e o apoio sem depender da biblioteca interna", async () => {
  const b = navegador([], {
    source: { repository: "brndutra/trf3-muta-jurisprudencia", url: "https://github.com/brndutra/trf3-muta-jurisprudencia", branch: "main" },
    registros: [{ id: "A1", processo: "5000000", ementa: "Prévia", previa: true }],
    modelos: [{ id: "M1", nome: "Apelação", modelo: "Texto-base", blocos: [{ secao: "fundamentacao", texto: "Parágrafo do modelo público, com atribuição." }] }],
  });
  await b.win.CMTGerBib.recarregarFonte(); await tick();
  assert.deepEqual(Array.from(b.win.CMTGerBib.paradigmas(), r => r.id), ["A1"]);
  assert.deepEqual(Array.from(b.win.CMTGerBib.modelos(), r => r.id), ["M1"]);
  const pars = b.win.CMTGerBib.paragrafosCompartilhados();
  assert.equal(pars.length, 1);
  assert.equal(pars[0].fonteId, "M1");
  assert.match(pars[0].txt, /modelo público/);
  assert.equal(b.urls.filter(url => url === "/api/generator-library").length, 0);
  await b.win.CMTGerBib.recarregarFonte(); await tick();
  assert.equal(b.win.CMTGerBib.paragrafosCompartilhados().length, 1, "recarregar não duplica trechos");
  assert.equal(await b.win.CMTGerBib.publicarParagrafo({ txt: "Não publicar" }), false);
});

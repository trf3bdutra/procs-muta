import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import vm from 'node:vm';

const html = readFileSync(new URL('../../api-server/src/protected/gabcmt.html', import.meta.url), 'utf8');
const source = html.slice(html.indexOf("const CM3_PROFILE="), html.indexOf('let cm3Obs='));
const audienceSource = html.slice(html.indexOf('function forCM(notice,'), html.indexOf('  const isEnabled = category', html.indexOf('function forCM(notice,')));

function fixture() {
  let preferences = { production: false, personal: true, sessions: true };
  const log = [
    { msg: 'designação da equipe', at: '2026-11-03', category: 'production', audience: { profile: 'server:cm' } },
    { msg: 'prazo da sessão', at: '2026-11-03', category: 'sessions', audience: { profile: 'server:cm' } },
    { msg: 'falha crítica', at: '2026-11-03', type: 'err', category: 'critical', audience: { profile: 'server:cm' } },
    { msg: 'categoria desconhecida', at: '2026-11-03', category: 'unknown' },
    { msg: 'erro crítico de outra pessoa', type: 'err', category: 'critical', audience: { server: 'OUTRA PESSOA' } },
    { msg: 'CM mencionado em aviso geral', category: 'sessions' },
  ];
  const host = { _dock: 'calendar', _notifUnread: 7, notifLog: () => log };
  const context = {
    HOST: () => host, E: String, Date, Map, cm3On: () => true,
    window: {
      CMTNotificationPrefs: {
        classify: (_, type, options) => type === 'err' ? 'critical' : options.category,
        forCM: (notice, actualHost) => context.forCM(notice, actualHost),
        profilePreferences: (profile, actualHost) => {
          assert.equal(profile, 'server:cm'); assert.equal(actualHost, host); return preferences;
        },
        definitions: [{ key: 'sessions', label: 'Sessões' }, { key: 'production', label: 'Produção' }],
      },
      CMTNotices: { me: () => ({ name: 'CM' }), panelHTML: () => '<p>pendências do desembargador</p>' },
    },
  };
  vm.createContext(context);
  vm.runInContext(audienceSource + source, context);
  return { context, host, setPreferences: value => { preferences = value; } };
}

test('CM panel follows its own categories, includes critical and targeted notices, without dock side effects', () => {
  const { context, host, setPreferences } = fixture();
  let model = context.cm3Model();
  assert.match(model.html, /prazo da sessão/);
  assert.match(model.html, /falha crítica/);
  assert.match(model.html, /pendências do desembargador/);
  assert.doesNotMatch(model.html, /designação da equipe|categoria desconhecida/);
  assert.doesNotMatch(model.html, /erro crítico de outra pessoa|CM mencionado em aviso geral/);
  assert.equal(model.shown.length, 2);
  assert.equal(host._dock, 'calendar'); assert.equal(host._notifUnread, 7);
  setPreferences({ production: true, personal: false, sessions: false });
  model = context.cm3Model();
  assert.match(model.html, /designação da equipe/);
  assert.doesNotMatch(model.html, /prazo da sessão|pendências do desembargador/);
  assert.match(model.html, /falha crítica/);
  setPreferences(null);
  assert.equal(context.cm3Model().shown.length, 1);
});

test('recipient scope is explicit and survives viewing /cm as any account', () => {
  const { context, host } = fixture();
  host.team = { members: [{ id: 'judge', name: 'Desembargador', hierarchy: 'CM' }, { id: 'other', name: 'OUTRO' }] };
  for (const audience of [{ profile: 'server:cm' }, { server: 'CM' }, { memberId: 'cm-link' }, { memberId: 'judge' }]) {
    assert.equal(context.forCM({ audience }, host), true);
  }
  for (const notice of [{ msg: 'CM' }, { audience: { profile: 'role:assessoria' } }, { audience: { memberId: 'other' } }, { urgent: true }]) {
    assert.equal(context.forCM(notice, host), false);
  }
});

test('signature notices and the desk count linked urgency/decision only once, with explicit process labels', () => {
  const script = [...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].find(m => m[1].includes('if(window.CMTNotices)return;'))[1];
  const host = {
    team: { members: [] }, rows: [],
    decisoes: {
      monocraticas: [{ id: 'm1', processo: '26', status: 'Pronta para assinatura', linkedLimId: 'u1' }],
      liminares: [{ id: 'u1', processo: '26', status: 'Minuta pronta', linkedMonoId: 'm1' }, { id: 'u2', processo: '27', status: 'Minuta pronta' }],
    },
  };
  const context = {
    window: { PautaApp: host, PautaTeam: { isDesembargador: m => m.hierarchy === 'CM', isAssessoria: () => true } },
    document: { documentElement: { hasAttribute: () => true }, addEventListener() {} },
    localStorage: { getItem: () => null, setItem() {} }, setInterval() {}, setTimeout() {},
    URG_RANK: {}, Date,
  };
  vm.createContext(context);
  vm.runInContext(script, context);
  const signSource = html.slice(html.indexOf('function signItems('), html.indexOf('function signCardV56('));
  vm.runInContext(signSource, context);
  const notices = context.window.CMTNotices.items().filter(item => item.kind === 'sign');
  const desk = context.signItems(host, { today: () => '2026-11-03', date: v => v || '' });
  assert.equal(notices.length, 2);
  assert.equal(notices.length, desk.length);
  assert.equal(notices[0].text, 'Processo nº 26 · aguarda a sua assinatura');
  assert.equal(notices.filter(item => item.proc === '26').length, 1);
});

test('viewing /cm resolves CM preferences and targeted identity, restoring the viewer outside /cm', () => {
  let inCM = true;
  const sourceStart = html.indexOf('if(window.CMTNotices)return;');
  const me = html.slice(sourceStart).match(/function me\(\)\{[^\n]+/)[0];
  const effective = html.match(/function effectiveProfile\(host=window.PautaApp\)\{[^\n]+/)[0];
  const context = {
    document: { documentElement: { hasAttribute: () => inCM } },
    window: {}, H: () => ({ team: { members: [] } }), T: () => ({}),
    serverName: () => 'BRUNO', identity: () => 'bruno', roleProfile: () => 'role:administracao',
  };
  vm.createContext(context);
  vm.runInContext(`${me}\n${effective}`, context);
  assert.equal(context.me().name, 'CM');
  assert.equal(context.effectiveProfile(), 'server:cm');
  inCM = false;
  assert.equal(context.effectiveProfile(), 'server:bruno');
});

test('Em mesa renders actual signature and doubt counts without counting unrelated pending issues', () => {
  const start = html.indexOf('function mesa(host,P){');
  const source = html.slice(start, html.indexOf('\nfunction ', start + 1));
  const context = {
    cmMember: () => null, signItems: () => [{ x: { id: 'm1' }, lim: null, prazo: '' }],
    cmt2DeskDoubts: () => ({ mine: [], others: [{ id: 'q1' }] }),
    ST: { deskExpanded: true, doubtScope: 'cm', signArm: 0 }, Date,
    E: String, fmt: String, S: v => String(v || ''), cmt2Tip: () => '',
    CMT2_IC: { okk: '' }, IC: { down: '' }, signCard: () => 'Processo nº 26',
    issueCard: () => 'Dúvida', window: {},
  };
  vm.createContext(context); vm.runInContext(source, context);
  const rendered = context.mesa({}, { today: () => '2026-11-03' });
  assert.match(rendered, /Em mesa · 1/);
  assert.match(rendered, /Processo nº 26/);
  assert.match(rendered, /Dúvidas/);
  assert.doesNotMatch(rendered, /Pendências do CM/);
});

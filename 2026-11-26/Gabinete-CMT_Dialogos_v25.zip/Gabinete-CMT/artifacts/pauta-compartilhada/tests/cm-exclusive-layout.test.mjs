import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const css = readFileSync(new URL('../src/lib/cm-exclusive-layout.css', import.meta.url), 'utf8');
const page = readFileSync(new URL('../src/pages/shared-pauta.tsx', import.meta.url), 'utf8');
const rules = css.replace(/\/\*[\s\S]*?\*\//g, '').split('}').map((r) => r.trim()).filter((r) => r.includes('{'));

test('every /cm rule is scoped to the CM view', () => {
  for (const rule of rules) {
    const selector = rule.slice(rule.lastIndexOf('{') === rule.indexOf('{') ? 0 : rule.indexOf('{') + 1, rule.lastIndexOf('{')).trim();
    for (const part of selector.split(/,(?![^(]*\))/)) {
      assert.match(part, /body\.cmt-adv-open|html\[data-cm-route\]/, `unscoped selector: ${part}`);
    }
  }
});

test('hides shared sidebar, right rail and footer on /cm', () => {
  assert.match(css, /:is\(#alt-side,#cx-rrail\)\{display:none!important/);
  assert.match(css, /#pauta-global-dock \.gd-foot\{display:none!important/);
  assert.match(css, /#pauta-global-dock :is\(\.gd-panel,\.gd-overlay,\.gd-panel-stack\)\{display:none!important/);
});

test('CM view fills the viewport without outer shell offsets', () => {
  assert.match(css, /#cmt-adv#cmt-adv\{position:fixed!important;inset:0!important/);
  assert.match(css, /--pa-l:0px;--pa-r:0px;--pa-b:0px/);
});

test('style is installed on iframe load and route attribute is synced', () => {
  assert.match(page, /cm-exclusive-layout\.css\?inline/);
  assert.match(page, /cmt-cm-exclusive-layout/);
  assert.equal((page.match(/toggleAttribute\('data-cm-route', isCmRoute\(location\)\)/g) || []).length, 2);
  assert.doesNotMatch(css, /[\u{1F300}-\u{1FAFF}]/u);
});

const html = readFileSync(new URL('../../api-server/src/protected/gabcmt.html', import.meta.url), 'utf8');

test('CM shell separates the work panel, session view, and sticky notification rail', () => {
  assert.match(css, /#cmt-adv\.cm3\{--cm3-ground:#0a3542;/);
  assert.match(css, /\.cm3-shell\{grid-template-columns:clamp\(230px,22vw,310px\) minmax\(0,1fr\) clamp\(300px,24vw,360px\)!important\}/);
  assert.match(css, /#cmt-adv\.cm3 \.cm3-rail\{position:sticky;top:0;height:100%;overflow:auto/);
  assert.match(css, /@media\(min-width:901px\)/);
  assert.match(css, /\.cm3-main\{height:calc\(100% - 28px\);min-height:0;overflow:auto/);
  assert.match(html, /mainPane\.scrollTop=mainSc/);
  assert.match(css, /@media\(max-width:900px\)\{[\s\S]*\.cm3-shell\{grid-template-columns:minmax\(0,1fr\)!important\}/);
  assert.match(css, /@media\(max-width:900px\)\{[\s\S]*\.cm3-rail\{order:-1;position:static/);
});

test('CM template renders a distinct work sidebar and notification rail only on /cm', () => {
  assert.match(html, /function cm3On\(\)\{return document\.documentElement\.hasAttribute\('data-cm-route'\);\}/);
  assert.match(html, /el\.innerHTML=cm3\?`<div class="cm3-shell"><aside class="cm3-left" aria-label="Navegação e Mesa do CM">\$\{cm3DeskNav\(\)\}\$\{mesa\(host,P\)\}<\/aside><div class="cmt-adv-wrap cm3-main">\$\{body\}<\/div>\$\{cm3Rail\(host,sessions\)\}<\/div>`:`\$\{topbar\(host,sessions\)\}/);
  assert.match(html, /el\.id!=='cmt-adv'\|\|el\.classList\.contains\('cm3'\)\)return;/);
  const rail = html.slice(html.indexOf('function cm3Rail('), html.indexOf('function cm3Cal('));
  assert.doesNotMatch(rail, /data-adv-dlg|data-adv="bell"|data-adv="back"/);
  assert.doesNotMatch(rail, /data-adv-jump/);
  assert.match(html, /function cm3DeskNav\(\)[\s\S]*?data-adv-jump=/);
  assert.match(rail, /Sessões e avisos/);
});

test('/cm keeps internal navigation above the CM desk in the left work panel', () => {
  assert.match(html, /<aside class="cm3-left" aria-label="Navegação e Mesa do CM">\$\{cm3DeskNav\(\)\}\$\{mesa\(host,P\)\}<\/aside>/);
  assert.match(html, /class="cm3-nav-head"><b>Áreas da Mesa<\/b>/);
  assert.match(html, /<h2 id="cmt-adv-desk-h">Em mesa/);
  assert.match(html, /class="cm3-desk-overview" aria-label="Resumo da Mesa do CM"/);
  assert.match(html, /class="cm3-desk-quick" aria-labelledby="cm3-desk-actions-h"/);
  assert.match(html, /class="cm3-desk-section cm3-desk-sign"/);
  assert.match(html, /class="cm3-desk-section cm3-desk-doubts"/);
  assert.match(html, /data-adv-dlg="u" aria-haspopup="dialog" aria-controls="pauta-urgencias-dialog"/);
  assert.match(html, /data-adv="desk-doubts" aria-controls="cm3-doubts-h"/);
  assert.match(html, /data-adv-dlg="p" aria-haspopup="dialog" aria-controls="pauta-pendencias-dialog"/);
  assert.match(html, /id="cm3-doubts-h">Dúvidas/);
  assert.match(css, /\.cm3-left\{display:flex!important;flex-direction:column!important/);
  assert.match(css, /\.cm3-nav-head b\{color:#f0d48e/);
  assert.match(css, /\.cm3-desk-overview \.cmt2-desk-sum>span\{[^}]*background:#fff!important;color:#405d66/);
  assert.match(css, /@media\(max-width:1100px\)\{[\s\S]*?grid-template-columns:minmax\(210px,240px\) minmax\(0,1fr\) minmax\(270px,300px\)!important/);
  assert.match(css, /\.cm3-left \.cm3-desk-actions\{display:grid!important/);
  assert.match(html, /leftPane\.scrollTop=leftSc/);
  assert.match(html, /if\(a==='desk-doubts'\)\{ST\.deskExpanded=true;ST\.doubtScope='cm'/);
  assert.doesNotMatch(css, /cm3-left\{display:contents!important/);
});

test('/cm milestones are presented as a vertical list', () => {
  assert.match(css, /\.cm3-calmk \.cmt2-ms-row\{display:grid!important;grid-template-columns:minmax\(0,1fr\)!important/);
  assert.match(css, /\.cm3-calmk \.cmt2-ms\{display:grid!important;grid-template-columns:minmax\(0,1fr\) auto!important/);
});

test('calendar and notifications use real host data without opening the shared dock', () => {
  const cal = html.slice(html.indexOf('function cm3Cal('), html.indexOf('function cm3Click('));
  assert.match(cal, /\(host\.sessions\|\|\[\]\)\.filter/);
  assert.match(cal, /P\.date\(meta\[k\]\)/);
  assert.match(cal, /CMT2_MS\.forEach/);
  assert.match(html, /cm3CalMarcos\(cm3Cal\(host,P,sessions,m\),m\?cmt2Band\(host,m,P\):''\)/);
  assert.match(html, /document\.body\.classList\.remove\('cmt-adv-open'\);cm3Notif\(false\);/);
  const notifications = html.slice(html.indexOf("const CM3_PROFILE="), html.indexOf('function cmt2SecHead('));
  assert.match(notifications, /profilePreferences\(CM3_PROFILE,HOST\(\)\)/);
  assert.doesNotMatch(notifications, /_dock\s*=/);
  assert.doesNotMatch(notifications, /clearNotifs\(/);
  assert.match(notifications, /removeEventListener\('cmt:notification-preferences-changed'/);
});

function runCal(state, host, sessions, today = '2026-11-03') {
  const source = html.slice(html.indexOf('function cm3Cal('), html.indexOf('function cm3Click('));
  const context = {
    ST: state,
    CMT2_MS: [['prepStart', 'Preparação'], ['pecoDia', 'Peço-dia'], ['minutasDeadline', 'Minutas'], ['releaseDeadline', 'Liberação'], ['judgment', 'Sessão']],
    E: String, br: String, fmt: String, Date,
  };
  vm.createContext(context);
  vm.runInContext(source, context);
  const date = value => /^\d{2}\/\d{2}\/\d{4}$/.test(value || '')
    ? value.split('/').reverse().join('-') : value || '';
  return context.cm3Cal(host, { today: () => today, date }, sessions, null);
}

test('calendar draws one connected trace per session, several at once, and includes empty sessions', () => {
  const host = {
    sessions: ['13/11/2026', '20/11/2026', '04/12/2026'],
    sessionDetails: {
      '20/11/2026': { date: '2026-11-20', prepStart: '2026-11-10', minutasDeadline: '2026-11-16' },
      '04/12/2026': { date: '2026-12-04', prepStart: '2026-11-24' },
    },
  };
  const sessions = [
    { name: '13/11/2026', date: '2026-11-13', n: 5 },
    { name: '20/11/2026', date: '2026-11-20', n: 0 },
    { name: '04/12/2026', date: '2026-12-04', n: 0 },
  ];
  const state = { session: '20/11/2026' };
  const out = runCal(state, host, sessions);
  assert.match(out, /class="cm3-tr c\d is-sel"[^>]*data-s="20\/11\/2026"/);
  assert.match(out, /data-s="13\/11\/2026"/);
  assert.match(out, /data-s="04\/12\/2026"/);
  assert.match(out, /cm3-line[^"]*is-post/);
  assert.match(out, /cm3-mk k-minutasDeadline/);
  assert.match(out, /data-keep="1"/);
  assert.match(out, /aria-label="Sessão 20\/11\/2026: 10\/11 a 20\/11/);
  const colors = [...out.matchAll(/data-testid="button-cal-key-([^"]+)"/g)].map(x => x[1]);
  assert.deepEqual(colors.sort(), ['04/12/2026', '13/11/2026', '20/11/2026'].sort());
  const c1 = out.match(/cm3-key[^"]*" style="--tc:([^;"]+)"[^>]*data-s="20\/11\/2026"/)[1];
  state.cm3M = '2026-12';
  const dec = runCal(state, host, sessions);
  assert.match(dec, /cm3-line[^"]*is-pre/);
  const c2 = dec.match(/cm3-key[^"]*" style="--tc:([^;"]+)"[^>]*data-s="04\/12\/2026"/)[1];
  assert.notEqual(c1, c2);
  assert.doesNotMatch(dec, /data-s="13\/11\/2026"/);
});

test('/cm render keeps empty active sessions selectable and calendar picks keep the month', () => {
  assert.match(html, /const sessions=cm3On\(\)\?cm3Sessions\(host,P\):sessionsWithRecords\(host,P\);/);
  const fn = html.slice(html.indexOf('function cm3Sessions('), html.indexOf('function cm3Cal('));
  assert.doesNotMatch(fn, /filter\(o=>o\.n>0\)/);
  assert.match(html, /if\(b\.dataset\.keep\)ST\.cm3Ses=s;ST\.session=s;/);
});

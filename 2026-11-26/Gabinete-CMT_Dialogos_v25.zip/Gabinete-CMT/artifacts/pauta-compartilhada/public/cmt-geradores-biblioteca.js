/* ═══════════════════════════════════════════════════════════════════════
   v272 · Biblioteca dos Geradores
   Jurisprudência no padrão da Central: I · Precedentes (filtros, busca no índice ou no texto integral,
   card, leitura, citação) e II · Modelos (fase, espécie, resultado, texto-modelo, blocos). Sem links externos.
   Abas: Documento (rascunho do processo) e Jurisprudência (fonte pública somente leitura:
   GitHub brndutra/trf3-muta-jurisprudencia via backend same-origin
   /api/paradigmas/precedentes, /api/paradigmas/modelos, /api/paradigmas/inteiro-teor/:id).
   Modelos e parágrafos não têm aba própria: o banco de parágrafos (blocos dos modelos,
   Padrão Muta e pessoais) fica na aba Parágrafos do painel lateral do Documento, e as
   diretrizes na aba Diretrizes. Este módulo fornece a esse painel os parágrafos do acervo
   (paragrafosCompartilhados) e o Padrão Muta interno (/api/generator-library, edição só da
   Assessoria, nunca publicado: padraoAcao). Parágrafos pessoais: só neste navegador.
   ═══════════════════════════════════════════════════════════════════════ */
(function (root) {
  'use strict';

  /* ── lógica pura (testável em Node) ── */
  var VAZIA = function () { return { paragrafos: [], modelos: [], modelosOcultos: [], paradigmasProprios: [], paradigmasOcultos: [], padraoMuta: null }; };
  function arr(v) { return Array.isArray(v) ? v : []; }
  function normaliza(lib) {
    var b = lib && typeof lib === 'object' ? lib : {}, o = {};
    for (var k in b) if (Object.prototype.hasOwnProperty.call(b, k)) o[k] = b[k];
    o.paragrafos = arr(b.paragrafos).filter(function (p) { return p && p.id && typeof p.txt === 'string'; }).slice(0, 500);
    o.modelos = arr(b.modelos).filter(function (m) { return m && m.id; });
    o.modelosOcultos = arr(b.modelosOcultos).map(String);
    o.paradigmasProprios = arr(b.paradigmasProprios).filter(function (r) { return r && r.id; });
    o.paradigmasOcultos = arr(b.paradigmasOcultos).map(String);
    o.padraoMuta = b.padraoMuta && typeof b.padraoMuta === 'object' ? b.padraoMuta : null;
    return o;
  }
  /* estáticos + próprios; próprio com o mesmo id substitui o estático; ocultos saem da lista de uso */
  function mescla(estaticos, proprios, ocultos, comOcultos) {
    var oc = new Set(arr(ocultos).map(String)), mapa = new Map();
    arr(estaticos).forEach(function (x) { if (x && x.id != null) mapa.set(String(x.id), Object.assign({}, x, { _origem: 'acervo', _oculto: oc.has(String(x.id)) })); });
    arr(proprios).forEach(function (x) { if (x && x.id != null) mapa.set(String(x.id), Object.assign({}, x, { _origem: 'biblioteca', _oculto: oc.has(String(x.id)) })); });
    var out = Array.from(mapa.values());
    return comOcultos ? out : out.filter(function (x) { return !x._oculto; });
  }
  /* importação só acrescenta: ids já presentes nunca são sobrescritos */
  function acrescenta(atuais, novos) {
    var ids = new Set(arr(atuais).map(function (x) { return String(x.id); })), add = [];
    arr(novos).forEach(function (x) { if (x && x.id != null && !ids.has(String(x.id))) { ids.add(String(x.id)); add.push(x); } });
    return { lista: arr(atuais).concat(add), acrescentados: add.length };
  }
  function semAcento(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
  function filtra(lista, q, campos) {
    var ts = semAcento(q).split(/\s+/).filter(Boolean); if (!ts.length) return lista;
    return lista.filter(function (x) { var h = semAcento(campos.map(function (c) { var v = x[c]; return Array.isArray(v) ? v.join(' ') : v; }).join(' ')); return ts.every(function (t) { return h.indexOf(t) >= 0; }); });
  }
  function chaveDataJulgado(r) {
    r = r || {};
    var s = String(r.dataJulgamento || r.data_julgamento_iso || r.data_decisao_iso || r.d || '').trim();
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
    if (m) return m[1] + m[2] + m[3];
    m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(s);
    if (m) return m[3] + m[2] + m[1];
    var ano = String(r.ano || s).match(/^(19|20)\d{2}$/);
    return ano ? ano[0] + '0000' : '';
  }
  function anoJulgado(r) { var chave = chaveDataJulgado(r); return chave ? chave.slice(0, 4) : ''; }
  function ordenaJulgadosPorData(lista, ordem) {
    return arr(lista).slice().sort(function (a, b) {
      var da = chaveDataJulgado(a), db = chaveDataJulgado(b);
      if (da !== db) {
        if (!da) return 1;
        if (!db) return -1;
        return ordem === 'antigos' ? da.localeCompare(db) : db.localeCompare(da);
      }
      return 0;
    });
  }
  function classeChave(value) {
    var s = semAcento(value).replace(/[^a-z0-9]/g, '');
    var aliases = { apelacaocivel:'APCIV', apelacao:'APCIV', apciv:'APCIV', ac:'APCIV', agravodeinstrumento:'AI', ai:'AI', embargosdedeclaracao:'ED', edcl:'ED', ed:'ED', agravointerno:'AGINT', agint:'AGINT', agr:'AGINT', agravoregimental:'AGINT', mandadodeseguranca:'MS', ms:'MS' };
    return aliases[s] || String(value || '').trim().toUpperCase() || 'Não informada';
  }
  var META_CACHE = new WeakMap();
  function classifica(r) {
    r = r || {};
    if(META_CACHE.has(r))return META_CACHE.get(r);
    var t = semAcento(r.pronunciamento || r.tipo || r.t || '');
    var decisao = /acordao/.test(t) || t === 'a' ? 'Acórdão' : /monocr/.test(t) || t === 'm' ? 'Decisão monocrática' : /sentenca/.test(t) ? 'Sentença' : /despacho/.test(t) ? 'Despacho' : /interlocut/.test(t) ? 'Decisão interlocutória' : 'Não informado';
    var classes = r.classes && typeof r.classes === 'object' ? Object.keys(r.classes).map(classeChave) : [];
    if (!classes.length) classes = [classeChave(r.classeSigla || r.classe_sigla || r.classe || r.especie)];
    classes = Array.from(new Set(classes));
    var explicit = r.tipoJulgamento || r.tipo_julgamento || r.julgamentoTipo || '';
    var title = semAcento([explicit, r.especie, r.nome].filter(Boolean).join(' '));
    var abertura = semAcento(String(r.ementa || '').slice(0, 240));
    // Recurso interno não é a classe do processo. Só classifica quando há indicação na fonte.
    var julgamento = classeChave(explicit)==='ED' || /embargos (?:de|d[ae]) declaracao/.test(title) || classes.some(function (c) { return /^(ED|EDAC|EDAI|EDCL)$/.test(c); }) ? 'Embargos de declaração' :
      classeChave(explicit)==='AGINT' || /agravo (?:interno|regimental)/.test(title) || classes.some(function (c) { return /^(AGINT|AGREG|AGR)$/.test(c); }) ? 'Agravo interno / regimental' :
      /(?:1.? julgamento|primeiro julgamento|julgamento originario)/.test(semAcento(explicit)) ? '1º julgamento' : 'Não informado';
    // Abertura da ementa é apenas um indício identificado como tal, nunca o corpo completo.
    var indicio = '';
    if (julgamento === 'Não informado' && /^(?:ementa[.:\s-]*)?(?:(?:processual|civil|previdenciario|tributario|constitucional|administrativo)[.,\s]*){0,5}embargos de declaracao\b/.test(abertura)) { julgamento = 'Embargos de declaração'; indicio = 'Identificado na abertura da ementa'; }
    if (julgamento === 'Não informado' && /^(?:ementa[.:\s-]*)?(?:(?:processual|civil|previdenciario|tributario|constitucional|administrativo)[.,\s]*){0,5}agravo (?:interno|regimental)\b/.test(abertura)) { julgamento = 'Agravo interno / regimental'; indicio = 'Identificado na abertura da ementa'; }
    var meta={ decisao: decisao, classes: classes, julgamento: julgamento, indicio: indicio };META_CACHE.set(r,meta);return meta;
  }
  function passaMeta(c, filtros) {
    var f = filtros || {};
    return (!f.decisao || c.decisao === f.decisao) && (!f.classe || c.classes.indexOf(f.classe) >= 0) && (!f.julgamento || c.julgamento === f.julgamento);
  }
  function passaClassificacao(r, filtros) { return passaMeta(classifica(r), filtros); }
  function passaFiltrosJurisprudencia(r, filtros) {
    var f = filtros || {}, orgao = String(r && (r.orgao || r.orgao_julgador) || '').trim();
    return passaClassificacao(r, f) && (!f.ano || anoJulgado(r) === f.ano) && (!f.orgao || orgao === f.orgao);
  }
  function selecionaFontesParagrafos(lista,filtros,modeloId) {
    return lista.map(function(p){var origem=arr(p.fontes).find(function(f){return passaMeta(f.meta,filtros)&&(!modeloId||f.id===modeloId);});return origem?Object.assign({},p,{fonteId:origem.id,fonteNome:origem.nome,meta:origem.meta,rot:(p.sec?p.sec+' · ':'')+origem.nome}):null;}).filter(Boolean);
  }
  /* ── v272 · busca e apresentação no padrão da Central (Precedentes · Modelos) ── */
  var ACENTOS = { a: 'aáàâãä', e: 'eéèêë', i: 'iíìîï', o: 'oóòôõö', u: 'uúùûü', c: 'cç', n: 'nñ' };
  /* número de tema/súmula sem diferença de ponto: "1.102" e "1102" casam um com o outro */
  function rxTermo(t) {
    var b = semAcento(t).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
      .replace(/(\d)\\\.(?=\d{3}(?!\d))/g, '$1')
      .replace(/\d{4,}/g, function (n) { return n.replace(/(\d)(?=(\d{3})+$)/g, '$1\\.?'); })
      .replace(/[aeioucn]/g, function (c) { return '[' + ACENTOS[c] + ACENTOS[c].toUpperCase() + ']'; }).replace(/\s+/g, '\\s+');
    return new RegExp(b, 'i');
  }
  /* termos obrigatórios, "frase exata" e -exclusão */
  function parseConsulta(q) {
    var inc = [], exc = [], re = /(-?)"([^"]+)"|(-?)(\S+)/g, m, s = String(q == null ? '' : q).slice(0, 300);
    while ((m = re.exec(s)) && inc.length + exc.length < 16) { var neg = m[1] || m[3], t = (m[2] || m[4] || '').trim(); if (!t || t === '-') continue; (neg ? exc : inc).push(t); }
    return { inc: inc, exc: exc, rxInc: inc.map(rxTermo), rxExc: exc.map(rxTermo), vazia: !inc.length && !exc.length };
  }
  function casa(texto, c) {
    if (!c || c.vazia) return true;
    if (!texto) return !c.rxInc.length;
    for (var i = 0; i < c.rxExc.length; i++) if (c.rxExc[i].test(texto)) return false;
    for (var j = 0; j < c.rxInc.length; j++) if (!c.rxInc[j].test(texto)) return false;
    return true;
  }
  function escH(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  /* recebe HTML já escapado */
  function realca(html, c) {
    if (!c || !c.inc || !c.inc.length) return html;
    var src = c.inc.map(function (t) { return rxTermo(escH(t)).source; }).join('|');
    try { return html.replace(new RegExp('(' + src + ')', 'gi'), '<mark>$1</mark>'); } catch (_) { return html; }
  }
  function trecho(texto, c, larg) {
    larg = larg || 160; if (!texto || !c || !c.rxInc.length) return '';
    var m = c.rxInc[0].exec(texto); if (!m) return '';
    var i = Math.max(0, m.index - larg), f = Math.min(texto.length, m.index + m[0].length + larg);
    return (i ? '…' : '') + texto.slice(i, f).replace(/\s+/g, ' ') + (f < texto.length ? '…' : '');
  }
  function fmtData(d) { d = String(d || ''); var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(d); return m ? m[3] + '/' + m[2] + '/' + m[1] : (d || '—'); }
  /* a ementa do PJe vem com cabeçalho (tribunal, endereço, partes e advogados): começa depois da linha "Ementa" */
  function limpaEmenta(e) {
    e = String(e || ''); if (!e) return '';
    var m = e.match(/^\s*E\s?M\s?E\s?N\s?T\s?A\s*[:.]?\s*$/im);
    if (m) return e.slice(m.index + m[0].length).trim();
    if (/^\s*PODER JUDICI/i.test(e)) { var k = e.search(/\n\s*\n\s*[A-ZÁÉÍÓÚÂÊÔÃÕÇ][A-ZÁÉÍÓÚÂÊÔÃÕÇ ,.\-]{12,}\./); if (k > 0) return e.slice(k).trim(); }
    return e.trim();
  }
  function relatorPA(r) { return /relator para o ac/i.test(String(r && (r.atuacao || r.a) || '')); }
  function tipoAM(r) { r = r || {}; return r.tipo === 'M' || r.t === 'M' || /monocr/i.test(String(r.pronunciamento || '')) ? 'M' : 'A'; }
  function resumoResultado(r) {
    var s = String(r || '').toLowerCase();
    var m = [['não conhec', 'não conhecido'], ['prejudicad', 'prejudicado'], ['parcial provimento', 'parcial provimento'], ['parcialmente provid', 'parcial provimento'], ['negou provimento', 'desprovido'], ['negar provimento', 'desprovido'], ['nego provimento', 'desprovido'], ['nego-lhe', 'desprovido'], ['deu provimento', 'provido'], ['dar provimento', 'provido'], ['dou provimento', 'provido'], ['rejeit', 'rejeitados'], ['acolh', 'acolhidos'], ['homolog', 'homologação'], ['extin', 'extinção'], ['indefer', 'indeferido'], ['defiro', 'deferido'], ['defer', 'deferido']];
    for (var i = 0; i < m.length; i++) if (s.indexOf(m[i][0]) >= 0) return m[i][1];
    return '';
  }
  function siglaOrgao(o) { o = String(o || ''); if (!o) return 'órgão n/i'; if (/Mato Grosso do Sul/.test(o)) return 'TRMS'; return o.replace(' Turma', 'ª T').replace('ªª', 'ª').replace(' Seção', 'ª S').replace('Órgão Especial', 'OE').replace('Vice-Presidência', 'VP').replace('Presidência', 'PRES'); }
  function classeOrgao(o) { o = String(o || ''); if (!o) return 'dash'; if (/Mato Grosso do Sul/.test(o)) return 'oms'; if (/^3ª Turma/.test(o)) return 'o3'; if (/^1ª Turma/.test(o)) return 'o1'; return 'ooutro'; }
  /* "assunto" do card: as primeiras frases da ementa (acórdão) ou a primeira frase do relatório (monocrática) */
  function assuntoDe(r) {
    var e = limpaEmenta(r && r.ementa).replace(/^…/, '');
    if (tipoAM(r) === 'A') { var m = e.match(/^((?:[^.]{2,90}\.\s*){1,3})/); return (m ? m[1] : e).trim(); }
    e = e.replace(/^\s*(?:vistos(?:\s+etc)?\.?|decis[aã]o\.?)\s*/i, '');
    return e.split(/(?<=\.)\s/)[0];
  }
  function textoIndice(r) { return [r.processo, r.classeSigla, r.classe, r.orgao, r.ementa, r.resultado, fmtData(r.dataJulgamento), r.assunto, Array.isArray(r.temas) ? r.temas.join(' ') : r.temas,
    /* julgados dos últimos 24 meses: ementa completa, temas, súmulas e citações (servidor: /api/paradigmas/enriquecidos) */
    r.ementaRica, arr(r.temasCitados).map(function (t) { return 'Tema ' + t; }).join(' '), arr(r.sumulasCitadas).map(function (t) { return 'Súmula ' + t; }).join(' '), r.dispositivosCitados, r.jurisprudenciaCitada].filter(Boolean).join(' '); }
  /* citação no formato da Central (votos do gabinete): classe, número, relatoria, publicação e ementa */
  function citacao(r) {
    r = r || {};
    var rel = /JUIZ/i.test(r.relator || '') && /CONVOCAD/i.test(r.relator || '') ? 'Rel. Juiz Conv. CARLOS MUTA' : relatorPA(r) ? 'Rel. p/ acórdão Des. Fed. CARLOS MUTA' : 'Rel. Des. Fed. CARLOS MUTA';
    var v = String(r.veiculo || '').trim(), d = String(r.dataPublicacao || '').trim(), M = tipoAM(r) === 'M', pub;
    if (/^\d{4}-\d{2}-\d{2}/.test(d)) d = fmtData(d);
    if (/intima/i.test(v) && d) pub = 'intimação via sistema em ' + d;
    else if (v && d) pub = (v.replace(/\s*Judicial\s*\d*/i, '').replace(/^e\s*-\s*/, 'e-').trim() + ' ' + d).trim();
    else pub = (M ? 'decidido em ' : 'julgado em ') + fmtData(r.dataJulgamento);
    var cab = [r.classeSigla, r.processo].filter(Boolean).join(' ') + ', ' + rel + ', ' + (M ? 'decisão monocrática, ' : '') + pub;
    var em = !M && r.previa === false ? limpaEmenta(r.ementa).replace(/\s*\n\s*/g, ' ').trim() : '';
    return em ? cab + ': "' + em + '"' : cab;
  }
  /* ── v272 · subassuntos: os rótulos do enunciado da ementa ("APOSENTADORIA POR IDADE RURAL. SEGURADA ESPECIAL. …") ──
     matéria  → entra na aderência dos Similares e no filtro "Subassunto";
     proced   → tipo de ação ou de recurso (execução fiscal, cumprimento de sentença, MS…);
     acessorias → honorários, consectários, vícios, coisa julgada…; ramo, classe e resultado saem. */
  var SUB_STOP = { de: 1, da: 1, do: 1, das: 1, dos: 1, e: 1, em: 1, no: 1, na: 1, nos: 1, nas: 1, por: 1, para: 1, a: 1, o: 1, as: 1, os: 1, ao: 1, aos: 1, com: 1, sem: 1, ou: 1, ate: 1, pela: 1, pelo: 1 };
  /* chave normalizada: sem acento, pontuação e palavras vazias; plural e gênero aproximados ("segurada/segurado especial") */
  function chaveSub(s) {
    return semAcento(s).replace(/\([^)]*\)/g, ' ').replace(/[^a-z0-9%,]+/g, ' ').trim().split(/\s+/).filter(function (w) { return w && !SUB_STOP[w]; })
      .map(function (w) { if (/^\d/.test(w)) return w; if (w.length > 4) w = w.replace(/(oes|aes|ais|eis|ns|es|s)$/, function (m) { return { oes: 'ao', aes: 'ao', ais: 'al', eis: 'el', ns: 'm', es: '', s: '' }[m]; }); return w.length > 3 ? w.replace(/[ao]$/, '') : w; }).join(' ');
  }
  var RX_RAMO = /^(?:direito\s+)?(?:(?:processual\s+)?(?:civil|penal|previdenciario|tributario|administrativo|constitucional|ambiental|assistencial|economico|financeiro|militar|internacional|do consumidor|privado|publico|empresarial|eleitoral|agrario|sanitario|do trabalho|da saude|a educacao|aduaneiro|urbanistico|regulatorio|sancionador|minerario|portuario|bancario|securitario|registral|notarial|indigenista|educacional)(?:\s*(?:,|e)\s*)?)+$/;
  var RX_CLASSE = /^(?:apelac[ao][eo]?s?(?:\s+civ(?:el|eis))?|apelacoes|remessa (?:necessaria|oficial)|reexame necessario|apelacao e remessa (?:necessaria|oficial)|apelacao e reexame necessario|agravo (?:de instrumento|interno|regimental|legal)|embargos de declaracao|recurso adesivo|recursos?|apelac[ao]o (?:da parte autora|do inss|da uniao|das partes)|apelacoes (?:das partes|civeis)|e?\s*recurso adesivo|agravo inominado|agravo (?:interno|legal) em [a-z ]+)$/;
  var RX_RESULT = /^(?:(?:apelac[ao]o|apelacoes|recursos?|remessa(?: necessaria| oficial)?|agravo(?: de instrumento| interno)?|embargos(?: de declaracao)?|pedido|sentenca|ordem|seguranca|tutela)\s+)?(?:(?:parcialmente\s+)?(?:provid[ao]s?|desprovid[ao]s?|improvid[ao]s?|acolhid[ao]s?|rejeitad[ao]s?|prejudicad[ao]s?|mantid[ao]s?|reformad[ao]s?|confirmad[ao]s?|anulad[ao]s?|concedid[ao]s?|denegad[ao]s?|nao conhecid[ao]s?|conhecid[ao]s? em parte|extint[ao]s?)|(?:parcial\s+)?(?:provimento|desprovimento|improvimento|rejeicao|acolhimento|nao conhecimento|manutencao|reforma|anulacao|prejudicialidade)(?: (?:da|do) (?:sentenca|recurso|apelacao))?|sentenca (?:mantida|reformada|confirmada|anulada)|recursos? (?:provid|desprovid)[a-z]*)(?:\s+(?:em parte|parcialmente))?$/;
  var RX_PROCED = /^(?:acao civil publica|acao popular|acao rescisoria|acao (?:ordinaria|declaratoria|anulatoria|monitoria|de cobranca|indenizatoria|revisional)|mandado de seguranca(?: coletivo| individual)?|execucao fiscal|embargos (?:a|de) execucao(?: fiscal| de sentenca| de titulo judicial)?|embargos de terceiro|excecao de pre.?executividade|cumprimento (?:individual )?de sentenca(?: coletiva| contra a fazenda publica)?|cumprimento de sentenca proferida em acao coletiva|execucao (?:de sentenca|individual|provisoria|contra a fazenda publica|de titulo judicial|de titulo extrajudicial)|suspensao de (?:liminar|seguranca)(?: e de sentenca)?|tutela (?:de urgencia|antecipada|provisoria|cautelar)|liminar|incidente de [a-z ]+|conflito de competencia|habeas corpus|habeas data|acao de improbidade administrativa|interdito proibitorio|juizo de retratacao|retratacao)$/;
  var RX_ACESS = /honorari|sucumbencia|consectari|correcao monetaria|juros|atualizac[ao]o monetaria|manual de calculos|selic|vicios?\b|omiss[ao]|contradic|obscuridade|erro material|prequestion|rediscuss|coisa julgada|litispendencia|cerceamento|nulidade|ilegitimidade|legitimidade|interesse de agir|perda (?:superveniente )?d[eo] objeto|gratuidade|justica gratuita|custas|multa (?:diaria|cominatoria|processual)|astreintes|efeito suspensivo|inversao|ec 136|emenda constitucional 136|correcao de oficio|dialeticidade|inovacao recursal|preclusao|competencia|dissociad|extincao (?:do processo|sem)|sem (?:resolucao|exame|julgamento) d[eo] merito|tempestividade|intempestividade|deserc|desistencia|sentenca extra|ultra petita|citra petita|reexame de prova|fundamentacao|tese|tema \d|carater infringente|deficiencia instrutoria|instrucao probatoria|prova pericial|artigo 5(?:35|57)|art\.? 5(?:35|57)|efeitos infringentes/;
  var RX_GEN = /^(?:(?:nao\s+)?(?:requisitos?|pressupostos?)(?: legais)? (?:nao )?(?:preenchid|atendid|comprovad|demonstrad)[a-z]*|ausencia de (?:requisitos?|pressupostos?|comprovacao|prova)|inaplicabilidade|aplicabilidade|inexistencia|existencia|possibilidade|impossibilidade|cabimento|descabimento|inadmissibilidade|admissibilidade|legalidade|ilegalidade|precedentes?|jurisprudencia|tese|caso concreto|situacao (?:dos autos|concreta)|demais (?:alegacoes|questoes)|inviabilidade|viabilidade|inocorrencia|ocorrencia|validade|invalidade|incidencia|nao incidencia|constitucionalidade|inconstitucionalidade|prazo|jurisprudencia (?:consolidada|dominante|pacifica|do stj|do stf)|arts?|art|mérito|merito|recurso desprovido|recurso provido|precedente[s]? do (?:stf|stj))$/;
  /* normas e precedentes citados no enunciado ("ARTIGO 16 DA LEI 7.347/1985", "SÚMULA 150/STF", "EC 136/2025") */
  var RX_NORMA = /^(?:artigos?|arts?\.?|lei(?:s| complementar)?|decreto(?:-lei)?|medida provisoria|mp|ec|emenda constitucional|sumula(?: vinculante)?|tema|resolucao|portaria|instrucao normativa|in|ctn|cpc|cf|cc|clt)\b[\s\S]*\d/;
  function classificaSub(rot) {
    var n = semAcento(rot).replace(/[^a-z0-9%,./ ]+/g, ' ').replace(/\s+/g, ' ').trim();
    if (!n || n.length < 4) return '';
    if (RX_RAMO.test(n) || RX_CLASSE.test(n) || RX_RESULT.test(n) || RX_GEN.test(n)) return '';
    if (RX_NORMA.test(n)) return 'normas';
    if (RX_PROCED.test(n)) return 'proced';
    if (RX_ACESS.test(n)) return 'acessorias';
    return 'materia';
  }
  /* texto: ementa (prévia do índice ou completa); truncado: a prévia corta no meio, o último rótulo pode estar incompleto */
  function subassuntos(texto, truncado) {
    var t = String(texto || '').replace(/^\s*PODER JUDICI[\s\S]*?\n\s*Ementa\s*\n/i, '');
    var k = t.search(/\n|\bI\.\s*CASO EM EXAME|\s1\.\s+[A-Z]/i); var cab = (k > 0 ? t.slice(0, k) : t).trim();
    var out = { materia: [], proced: [], acessorias: [], normas: [] }, vis = {};
    if (!/^[^a-z]{12,}/.test(cab.slice(0, 60))) return out; /* enunciado em caixa alta; monocráticas não têm */
    var partes = cab.replace(/…\s*$/, '').split(/\.\s+|\.$|;\s+/).map(function (x) { return x.replace(/^[\s\-–—:]+|[\s\-–—:]+$/g, '').trim(); }).filter(Boolean);
    if (truncado && partes.length > 1 && !/\.\s*$/.test(cab.replace(/…\s*$/, ''))) partes.pop();
    partes.forEach(function (rot) {
      if (rot.length > 160) return;
      var tipo = classificaSub(rot), ch = chaveSub(rot); if (!tipo || !ch || vis[ch]) return; vis[ch] = 1;
      out[tipo].push({ rot: rotuloSub(rot), k: ch });
    });
    return out;
  }
  /* "APOSENTADORIA POR IDADE RURAL" → "Aposentadoria por idade rural" (siglas e números mantidos) */
  function rotuloSub(rot) {
    var s = String(rot).trim(); if (/[a-z]/.test(s)) return s;
    var m = s.toLowerCase().replace(/(^|\s)([a-zà-ÿ])/, function (x, a, b) { return a + b.toUpperCase(); });
    return m.replace(/\b(re|resp|are|adi|adc|adpf|inss|ec|cpc|ctn|cf|stf|stj|trf3?|bpc|loas|fgts|cef|funai|ibama|incra|icms|pis|cofins|irpf|irpj|ipi|csll|anatel|anvisa|sus|siape|pje|rmi|ctps|cnis|ppp|ltcat|mpf|oab|crm|crea|ufms|ufgd|ifms|pasep|pis\/pasep|tnu|tr|ipca|inpc|selic|csl|iss|iptu|itr|cide|sat|rat|fap|incra|sebrae|sesc|senai|bacenjud|sisbajud|renajud|cnpj|cpf|dna)\b/gi, function (x) { return x.toUpperCase(); });
  }
  var PURO = { normaliza: normaliza, mescla: mescla, acrescenta: acrescenta, filtra: filtra, semAcento: semAcento, VAZIA: VAZIA, classifica: classifica, classeChave: classeChave, passaClassificacao: passaClassificacao, passaFiltrosJurisprudencia: passaFiltrosJurisprudencia, selecionaFontesParagrafos:selecionaFontesParagrafos, ordenaJulgadosPorData: ordenaJulgadosPorData,
    parseConsulta: parseConsulta, casa: casa, realca: realca, trecho: trecho, fmtData: fmtData, limpaEmenta: limpaEmenta, citacao: citacao, resumoResultado: resumoResultado, siglaOrgao: siglaOrgao, classeOrgao: classeOrgao, assuntoDe: assuntoDe, textoIndice: textoIndice, tipoAM: tipoAM, relatorPA: relatorPA, escH: escH,
    subassuntos: subassuntos, chaveSub: chaveSub, classificaSub: classificaSub };
  if (typeof module !== 'undefined' && module.exports) { module.exports = PURO; }
  if (!root || !root.document) return;

  /* ── navegador ── */
  var W = root, D = W.document;
  if (W.__cmtGerBib) return; W.__cmtGerBib = true;
  var API = '/api/generator-library';
  var REPO = { repository: 'brndutra/trf3-muta-jurisprudencia', branch: '', url: 'https://github.com/brndutra/trf3-muta-jurisprudencia' };
  var CACHE_MS = 5 * 60 * 1000;
  var ST = {
    /* interno (Padrão Muta, Assessoria) — carregado só quando necessário */
    lib: VAZIA(), rev: 0, can: false, carregado: false, erro: '', carregando: null,
    /* fonte pública canônica, somente leitura */
    est: { paradigmas: [], modelos: [], source: null, loaded: { paradigmas: false, modelos: false }, pending: null, erro: { paradigmas: '', modelos: '' }, em: 0 },
    /* registros completos (inteiro teor) por id */
    it: { cache: {}, pend: {}, erro: {} },
    aba: 'doc', fac: 'prec',
    sel: { paradigmas: '' }, salvando: false
  };
  var LS_PAR = 'acv_paragrafos';
  function E(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function avisa(msg, tipo) { try { W.PautaApp.notify(msg, tipo || 'info'); } catch (_) { try { console.info('[Biblioteca]', msg); } catch (__) {} } }
  function meusLocais() { try { return arr(JSON.parse(W.localStorage.getItem(LS_PAR) || '[]')); } catch (_) { return []; } }
  function fonte() { var s = ST.est.source || {}; return { repository: s.repository || REPO.repository, branch: s.branch || '', url: /^https:\/\/github\.com\//.test(String(s.url || '')) ? s.url : REPO.url }; }

  /* ── biblioteca interna (só Padrão Muta) ── */
  function chave() { return ST.rev + '|' + ST.can + '|' + (ST.erro ? 1 : 0); }
  function mudou(antes, carregadoAntes) { return !carregadoAntes || antes !== chave(); }
  function carrega(forca, silencioso) {
    if (ST.carregando && !forca) return ST.carregando;
    var antes = chave(), carregadoAntes = ST.carregado, padraoAntes = ST.lib.padraoMuta;
    ST.carregando = (async function () {
      try {
        var r = await fetch(API, { credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' } });
        var d = await r.json().catch(function () { return {}; });
        if (!r.ok) throw new Error(d.error || ('HTTP ' + r.status));
        ST.lib = normaliza(d.library); ST.rev = Number(d.revision) || 0; ST.can = d.canEditLibrary === true; ST.erro = ''; ST.carregado = true;
      } catch (e) { ST.erro = String(e && e.message || e); ST.can = false; ST.carregado = true; }
      finally { ST.carregando = null; }
      if (!mudou(antes, carregadoAntes)) return;
      avisaMudanca(JSON.stringify(padraoAntes) !== JSON.stringify(ST.lib.padraoMuta));
      if (!silencioso) pinta();
    })();
    return ST.carregando;
  }

  /* ── fonte pública: precedentes + modelos, deduplicada e com cache finito ── */
  async function jget(url) {
    var r = await fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' } });
    var d = await r.json().catch(function () { return null; });
    if (!r.ok || !d) throw new Error((d && d.error) || ('HTTP ' + r.status));
    return d;
  }
  function carregaEstaticos(forca) {
    var S = ST.est;
    if (S.pending) return S.pending;
    var fresco = S.loaded.paradigmas && S.loaded.modelos && !S.erro.paradigmas && !S.erro.modelos && (Date.now() - S.em) < CACHE_MS;
    if (fresco && !forca) return Promise.resolve();
    S.pending = (async function () {
      var res = await Promise.all([
        jget('/api/paradigmas/precedentes').then(function (j) { return { ok: j }; }, function (e) { return { e: e }; }),
        jget('/api/paradigmas/modelos').then(function (j) { return { ok: j }; }, function (e) { return { e: e }; })
      ]);
      var p = res[0], m = res[1];
      if (p.ok) { S.paradigmas = arr(p.ok.registros).filter(function (x) { return x && x.id != null; }); S.erro.paradigmas = ''; S.loaded.paradigmas = true; if (p.ok.source) S.source = p.ok.source; if (RICOS.carregado) aplicaRicos(); else carregaRicos(); }
      else S.erro.paradigmas = String(p.e && p.e.message || p.e);
      if (m.ok) { S.modelos = arr(m.ok.modelos).filter(function (x) { return x && x.id != null; }); S.erro.modelos = ''; S.loaded.modelos = true; if (m.ok.source && !S.source) S.source = m.ok.source; }
      else S.erro.modelos = String(m.e && m.e.message || m.e);
      S.em = Date.now(); S.pending = null;
      avisaMudanca(false);
      if (ST.aba !== 'doc') pinta();
    })();
    if (ST.aba !== 'doc') pinta();
    return S.pending;
  }
  /* julgados recentes enriquecidos: anexados aos registros do índice (mesmo objeto), sem travar a tela */
  var RICOS = { carregado: false, pend: null, m: new Map(), desde: '' };
  function carregaRicos() {
    if (RICOS.carregado) return Promise.resolve();
    if (RICOS.pend) return RICOS.pend;
    RICOS.pend = jget('/api/paradigmas/enriquecidos').then(function (d) {
      RICOS.m = new Map(arr(d.registros).map(function (x) { return [String(x.id), x]; })); RICOS.desde = String(d.desde || ''); RICOS.carregado = true; aplicaRicos();
    }).catch(function (e) { try { console.warn('[Biblioteca] enriquecidos', e); } catch (_) {} }).then(function () { RICOS.pend = null; });
    return RICOS.pend;
  }
  function aplicaRicos() {
    if (!RICOS.m.size) return;
    ST.est.paradigmas.forEach(function (r) { var x = RICOS.m.get(String(r.id)); if (!x) return; r.ementaRica = x.ementa || ''; r.temasCitados = arr(x.temas); r.sumulasCitadas = arr(x.sumulas); r.dispositivosCitados = x.dispositivos || ''; r.jurisprudenciaCitada = x.jurisprudencia || ''; });
    try { TI = new WeakMap(); SA = new WeakMap(); } catch (_) {}
    avisaMudanca(false);
    try { if (ST.aba !== 'doc' && ST.fac === 'prec') aplicaPrec(true); } catch (_) {}
  }
  /* registro completo de um paradigma: cache por id; a tela só usa o resultado do id selecionado */


  /* escrita interna (somente Padrão Muta): exige canEditLibrary e envia a biblioteca com a revisão base */
  async function grava(muta, ok) {
    if (!ST.can) { avisa('Biblioteca somente leitura: a edição é restrita à Assessoria.', 'warn'); return false; }
    if (ST.salvando) return false;
    var prox = normaliza(JSON.parse(JSON.stringify(ST.lib)));
    if (muta(prox) === false) return false;
    ST.salvando = true; pinta();
    try {
      var r = await fetch(API, { method: 'PUT', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ library: prox, baseRevision: ST.rev }) });
      var d = await r.json().catch(function () { return {}; });
      if (r.status === 409) { ST.salvando = false; await carrega(true); avisa('Outra pessoa alterou as diretrizes. Recarreguei a versão atual; refaça a alteração.', 'warn'); return false; }
      if (r.status === 403) { ST.can = false; throw new Error('sem permissão de edição (somente Assessoria)'); }
      if (!r.ok) throw new Error(d.error || ('HTTP ' + r.status));
      ST.lib = normaliza(d.library || prox); ST.rev = Number(d.revision != null ? d.revision : ST.rev + 1);
      if (typeof d.canEditLibrary === 'boolean') ST.can = d.canEditLibrary;
      if (ok) avisa(ok, 'ok');
      avisaMudanca(true);
      return true;
    } catch (e) { avisa('Não foi possível salvar: ' + (e && e.message || e), 'error'); return false; }
    finally { ST.salvando = false; pinta(); }
  }

  /* o Gerador (v269) escuta e repinta o apoio; detail.padrao pede repintar o documento */
  function avisaMudanca(padrao) { try { W.dispatchEvent(new CustomEvent('gerbib:changed', { detail: { revision: ST.rev, canEditLibrary: ST.can, padrao: !!padrao, fontePublica: true } })); } catch (_) {} }
  /* insere na lacuna ativa do Documento pelo próprio inserir() do Gerador (salva o rascunho do processo) */
  function insereNoDocumento(txt, rot) {
    var G = W.CMTGerador;
    if (!G || !G.inserir) { avisa('Abra o Gerador para inserir no documento.', 'warn'); return false; }
    var f = G.foco && G.foco();
    abre('doc');
    if (!f) { PEND = { txt: txt, rot: rot, processo: G.arg ? String(G.arg()) : '' }; avisa('Clique numa lacuna {{ }} do documento: "' + (rot || 'texto') + '" entra nela em seguida.', 'warn'); return false; }
    G.inserir(txt); return true;
  }
  var PEND = null;
  D.addEventListener('focusin', function (e) { if (!PEND) return; var t = e.target; if (!t || !t.closest || !t.closest('#cmt-ger .gr-paper') || t.dataset.f == null) return; var x = PEND; PEND = null; setTimeout(function () { try { var G=W.CMTGerador;if((G.arg?String(G.arg()):'')!==x.processo){avisa('A inserção foi cancelada porque o processo mudou. Escolha o trecho novamente.','warn');return;}if(G.foco())G.inserir(x.txt); } catch (err) { console.warn('[Biblioteca] inserir', err); } }, 30); });

  /* ── listas de uso: só a fonte pública ── */
  function paradigmas() { return ST.est.paradigmas.slice(); }
  function modelos() { return ST.est.modelos.slice(); }
  /* parágrafos distintos extraídos de modelo.blocos; chave estável = id do modelo + posição do bloco */
  var PGC = { em: -1, L: [] };
  function paragrafosPublicos() {
    if (PGC.em === ST.est.em) return PGC.L;
    var vistos = new Map(), L = [];
    ST.est.modelos.forEach(function (m) {
      arr(m.blocos).forEach(function (b, i) {
        var t = b && typeof b.texto === 'string' ? b.texto.trim() : ''; if (!t) return;
        var k = t.replace(/\s+/g, ' ').trim(), origem={id:String(m.id),nome:m.nome||String(m.id),meta:classifica(m)};
        if (vistos.has(k)) { var anterior=vistos.get(k);if(!anterior.fontes.some(function(f){return f.id===origem.id;}))anterior.fontes.push(origem);return; }
        var p={ id: 'pub:' + m.id + ':' + i, txt: t, rot: (b.secao ? b.secao + ' · ' : '') + (m.nome || m.id), sec: b.secao || '', uso: b.uso || '', fonteId: String(m.id), fonteNome: m.nome || String(m.id), fontes:[origem], _origem: 'publico' };
        vistos.set(k,p);L.push(p);
      });
    });
    PGC = { em: ST.est.em, L: L }; return L;
  }
  function pessoais() { return meusLocais().map(function (p) { return Object.assign({}, p, { _origem: 'pessoal' }); }); }
  function paragrafos() { return paragrafosPublicos().concat(pessoais()); }

  /* ── montagem ── */
  var ABAS = [
    ['doc', 'Documento', 'Rascunho do processo'],
    ['paradigmas', 'Jurisprudência', 'Precedentes · Modelos']
  ];
  /* pedidos antigos de modelos, parágrafos e Padrão Muta vão ao painel lateral do Documento */
  var APOIO = { minutas: 'par', modelo: 'mod', modelos: 'mod', paragrafos: 'par', paragrafo: 'par', padrao: 'rot' };
  var standaloneRoot = null, standaloneSuspended = null;
  function ger() { return standaloneRoot && standaloneRoot.isConnected ? standaloneRoot : D.getElementById('cmt-ger'); }
  function abrirEmentario(host, query) {
    if (!host || !host.isConnected) return false;
    if (standaloneRoot && standaloneRoot !== host) fecharEmentario();
    if (standaloneRoot !== host) {
      var original = D.getElementById('cmt-ger');
      standaloneSuspended = {
        root: original,
        nav: original && original.querySelector('#gbib-tabs'),
        panel: original && original.querySelector('#gbib'),
        aba: ST.aba,
        fac: ST.fac
      };
      if (standaloneSuspended.nav) standaloneSuspended.nav.remove();
      if (standaloneSuspended.panel) standaloneSuspended.panel.remove();
      standaloneRoot = host;
    }
    if (query != null && String(query).trim()) { J.pq = String(query).trim(); J.integral = null; J.montado = ''; }
    ST.aba = 'paradigmas';
    ST.fac = ST.fac === 'mod' ? 'mod' : 'prec';
    if (!host.querySelector('.gr-h')) return false;
    monta();
    var standaloneTabs = host.querySelector('#gbib-tabs');
    if (standaloneTabs) standaloneTabs.setAttribute('aria-label', 'Jurisprudência');
    carregaEstaticos(false);
    pinta();
    return true;
  }
  function fecharEmentario() {
    if (!standaloneRoot) return false;
    var host = standaloneRoot, nav = host.querySelector('#gbib-tabs'), panel = host.querySelector('#gbib');
    if (nav) nav.remove();
    if (panel) panel.remove();
    var saved = standaloneSuspended;
    standaloneRoot = null;
    standaloneSuspended = null;
    if (saved) {
      ST.aba = saved.aba || 'doc';
      ST.fac = saved.fac || 'prec';
      if (saved.root && saved.root.isConnected) {
        var heading = saved.root.querySelector('.gr-h');
        if (saved.nav) {
          if (heading) heading.insertAdjacentElement('afterend', saved.nav);
          else saved.root.prepend(saved.nav);
        }
        if (saved.panel) saved.root.appendChild(saved.panel);
        if (saved.panel) pinta();
      }
    }
    return true;
  }
  function monta() {
    var g = ger(); if (!g) return null;
    var h = g.querySelector('.gr-h'); if (!h) return null;
    var nav = g.querySelector('#gbib-tabs');
    var chavesAtuais = nav ? Array.from(nav.querySelectorAll('[data-gbib-aba]')).map(function (b) { return b.dataset.gbibAba; }) : [];
    var navAtual = ABAS.map(function (a) { return a[0]; });
    if (!nav || chavesAtuais.length !== navAtual.length || chavesAtuais.some(function (k, i) { return k !== navAtual[i]; })) {
      if (nav) nav.remove();
      nav = D.createElement('nav'); nav.id = 'gbib-tabs'; nav.className = 'gbib-tabs'; nav.setAttribute('role', 'tablist'); nav.setAttribute('aria-label', 'Áreas dos Geradores');
      nav.innerHTML = ABAS.map(function (a, i) {
        return (i === 1 ? '<span class="gbib-sep" aria-hidden="true">Apoio</span>' : '') + '<button type="button" role="tab" id="gbib-tab-' + a[0] + '" aria-controls="' + (a[0] === 'doc' ? '' : 'gbib') + '" data-gbib-aba="' + a[0] + '" data-testid="tab-geradores-' + a[0] + '"><b>' + a[1] + '</b><small>' + a[2] + '</small></button>'
          /* v272: Relatório · Voto · Ementa · Proclamação do Documento na mesma linha (o Gerador preenche: CMTGerador.abasDoc) */
          + (a[0] === 'doc' ? '<div class="gbib-doctabs" data-gbib-doctabs role="group" aria-label="Partes do documento"></div>' : '');
      }).join('');
      /* v272: Precedentes · Modelos na mesma linha de Documento · Jurisprudência */
      nav.insertAdjacentHTML('beforeend', '<div class="gbib-facs" data-gbib-facs role="tablist" aria-label="Bancos da jurisprudência" hidden>'
        + '<button type="button" role="tab" class="gbib-fac j" data-fac="prec" data-testid="tab-jurisprudencia-precedentes"><i>I</i><b>Precedentes</b><small data-ct="prec">—</small></button>'
        + '<button type="button" role="tab" class="gbib-fac m" data-fac="mod" data-testid="tab-jurisprudencia-modelos"><i>II</i><b>Modelos</b><small data-ct="mod">—</small></button></div>'
        );
      h.insertAdjacentElement('afterend', nav);
      try { if (W.CMTGerador && W.CMTGerador.abasDoc) W.CMTGerador.abasDoc(); } catch (_) {}
      nav.addEventListener('click', function (ev) {
        var b = ev.target.closest('[data-gbib-aba]'); if (b) { abre(b.dataset.gbibAba); return; }
        if (ev.target.closest('[data-gbib-doctabs] [data-tab]') && ST.aba !== 'doc') { abre('doc'); return; }
        var f = ev.target.closest('[data-fac]'); if (f) { if (ST.aba !== 'paradigmas') abre(f.dataset.fac === 'mod' ? 'modelos' : 'paradigmas'); else if (ST.fac !== f.dataset.fac) { ST.fac = f.dataset.fac; pinta(); } return; }
      });
      nav.addEventListener('keydown', function (ev) {
        if (standaloneRoot === g) return;
        if (!ev.target.closest || !ev.target.closest('[data-gbib-aba]')) return;
        var ks = ABAS.map(function (a) { return a[0]; }), i = ks.indexOf(ST.aba), n = -1;
        if (ev.key === 'ArrowRight') n = (i + 1) % ks.length; else if (ev.key === 'ArrowLeft') n = (i - 1 + ks.length) % ks.length; else if (ev.key === 'Home') n = 0; else if (ev.key === 'End') n = ks.length - 1;
        if (n < 0) return; ev.preventDefault(); abre(ks[n]); var b = nav.querySelector('[data-gbib-aba="' + ks[n] + '"]'); if (b) b.focus();
      });
    }
    if (!ABAS.some(function (a) { return a[0] === ST.aba; })) ST.aba = 'doc';
    var p = g.querySelector('#gbib');
    if (!p) {
      p = D.createElement('section'); p.id = 'gbib'; p.className = 'gbib gbj'; p.hidden = true; p.setAttribute('role', 'tabpanel'); g.appendChild(p);
      p.addEventListener('click', clique); p.addEventListener('input', digita); p.addEventListener('change', muda); p.addEventListener('keydown', tecla);
      p.addEventListener('scroll', rolagem, true);
    }
    return p;
  }
  /* abre('paradigmas', idDoPrecedente) · abre('modelos', idDoModelo) · abre('doc') */
  function abre(aba, sel) {
    var apoio = APOIO[aba] && !(aba === 'modelo' && sel) ? APOIO[aba] : '';
    if (aba === 'modelo' && sel) aba = 'modelos';
    ST.aba = apoio ? 'doc' : aba === 'paradigmas' || aba === 'modelos' ? 'paradigmas' : 'doc';
    if (aba === 'modelos') ST.fac = 'mod'; else if (aba === 'paradigmas') ST.fac = 'prec';
    var p = monta(); if (!p) return false;
    carregaEstaticos(false);
    pinta();
    if (sel && aba === 'paradigmas') abrePrec(String(sel));
    if (sel && aba === 'modelos') abreMod(String(sel));
    if (apoio) { try { W.CMTGerador.apoio(apoio); } catch (e) { console.warn('[Biblioteca] painel lateral', e); } }
    return true;
  }

  /* ══════════ estado da aba Jurisprudência (v272) ══════════ */
  var J = {
    pq: '', pf: { tipo: 'A', classe: '', orgao: '', ano1: '', ano2: '', conteudo: '', atuacao: '', ordem: 'recente', sub: '', subRot: '' }, anoRec: '', periodoIni: false,
    modo: 'indice', integral: null, buscando: false, prog: 0, progTxt: '',
    filt: [], mostrados: 0, abertos: new Set(), consulta: null,
    mq: '', mf: { fase: 'TRMS', tipo: '', esp: '', res: '', min: 10 }, mfilt: [], msel: '',
    montado: '', dados: -1, filtrosAbertos: false
  };
  var PAGINA = 120;
  var TI = new WeakMap(), SA = new WeakMap();
  /* subassuntos do julgado: ementa completa (últimos 2 anos) ou prévia do índice (último rótulo pode vir cortado) */
  function saDe(r) {
    if (!r) return { materia: [], proced: [], acessorias: [], normas: [] };
    var v = SA.get(r); if (v) return v;
    v = tipoAM(r) === 'A' ? (r.ementaRica ? subassuntos(r.ementaRica, false) : subassuntos(r.ementa, true)) : { materia: [], proced: [], acessorias: [], normas: [] };
    SA.set(r, v); return v;
  }
  function temSub(r, k) { var v = saDe(r); return ['materia', 'proced', 'acessorias', 'normas'].some(function (t) { return v[t].some(function (x) { return x.k === k; }); }); }
  function textoDe(r) { var t = TI.get(r); if (t == null) { t = textoIndice(r); TI.set(r, t); } return t; }
  var PORID = { em: -1, m: new Map() };
  function porId(id) {
    if (PORID.em !== ST.est.em) { PORID = { em: ST.est.em, m: new Map() }; ST.est.paradigmas.forEach(function (r) { PORID.m.set(String(r.id), r); }); }
    return PORID.m.get(String(id)) || null;
  }
  var MPOR = { em: -1, m: new Map() };
  function modPorId(id) {
    if (MPOR.em !== ST.est.em) { MPOR = { em: ST.est.em, m: new Map() }; ST.est.modelos.forEach(function (m) { MPOR.m.set(String(m.id), m); }); }
    return MPOR.m.get(String(id)) || null;
  }
  function conteudoDe(r) { return r.conteudo || (r.inteiroTeor ? 'integral' : ''); }
  function passaPrec(r) {
    var F = J.pf, t = tipoAM(r), ano = String(r.ano || String(r.dataJulgamento || '').slice(0, 4));
    if (F.tipo !== '*' && t !== F.tipo) return false;
    if (F.classe && String(r.classeSigla || '') !== F.classe) return false;
    if (F.orgao && (r.orgao || '(não informado)') !== F.orgao) return false;
    if (F.ano1 && ano < F.ano1) return false;
    if (F.ano2 && ano > F.ano2) return false;
    if (F.conteudo && conteudoDe(r) !== F.conteudo) return false;
    if (F.atuacao === 'relator' && relatorPA(r)) return false;
    if (F.atuacao === 'p' && !relatorPA(r)) return false;
    if (F.sub && !temSub(r, F.sub)) return false;
    return true;
  }
  function anos() { var s = new Set(); ST.est.paradigmas.forEach(function (r) { var a = String(r.ano || String(r.dataJulgamento || '').slice(0, 4)); if (/^\d{4}$/.test(a)) s.add(a); }); return Array.from(s).sort(); }
  function iniciaPeriodo() {
    if (J.periodoIni || !ST.est.loaded.paradigmas) return;
    var A = anos(); J.anoRec = A.length > 1 ? A[A.length - 2] : (A[0] || ''); J.pf.ano1 = J.anoRec; J.periodoIni = true;
  }
  function processoAtual() { try { var G = W.CMTGerador; var a = G && G.arg && G.arg(); return a ? String(a) : ''; } catch (_) { return ''; } }
  function vazio(t, s) { return '<div class="gbib-empty"><svg viewBox="0 0 48 48" aria-hidden="true"><rect x="9" y="7" width="30" height="36" rx="3"/><path d="M16 17h16M16 24h16M16 31h9"/></svg><b>' + E(t) + '</b><span>' + E(s) + '</span></div>'; }
  var ICO = {
    chev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>',
    cit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 7h4v4H7zM7 11c0 3-1 4-3 5M15 7h4v4h-4zM15 11c0 3-1 4-3 5"/></svg>',
    doc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/></svg>',
    lupa: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>'
  };
  var KROT = { integral: 'integral', apenas_acordao: 'ementa + acórdão', apenas_ementa: 'só ementa' };

  /* ══════════ card de precedente (compartilhado com o painel Similares do Documento) ══════════
     o.modo: 'lista' (aba Jurisprudência) ou 'compacto' (painel lateral); o.c: consulta para realce;
     o.hit: trecho do texto integral; o.aberto; o.sel; o.score/o.motivos (aderência); o.acoes: HTML dos botões do compacto */
  function cardPrec(r, o) {
    o = o || {}; var t = tipoAM(r), c = o.c, ass = assuntoDe(r), k = conteudoDe(r), res = resumoResultado(r.resultado), pa = relatorPA(r);
    var tags = '<span class="gbc-t org ' + classeOrgao(r.orgao) + '" title="' + E(r.orgao || 'Órgão julgador não informado') + '">' + E(siglaOrgao(r.orgao)) + '</span>'
      + '<span class="gbc-t" title="Ano">' + E(r.ano || String(r.dataJulgamento || '').slice(0, 4)) + '</span>'
      + (t === 'A' && k && k !== 'integral' ? '<span class="gbc-t dash" title="Texto disponível na base">' + E(KROT[k]) + '</span>' : '')
      + (pa ? '<span class="gbc-t pa" title="Muta como relator para o acórdão">rel. p/ acórdão</span>' : '')
      + (res ? '<span class="gbc-t res" title="' + E(r.resultado) + '">' + E(res) + '</span>' : '');
    var sa = saDe(r), subTags = sa.materia.slice(0, o.modo === 'compacto' ? 3 : 2).map(function (m) { return '<span class="gbc-t sub" title="Subassunto: ' + E(m.rot) + '">' + E(m.rot.length > 42 ? m.rot.slice(0, 40) + '…' : m.rot) + '</span>'; }).join('');
    if (o.modo === 'compacto') {
      return '<li class="gbc gbc-cp' + (o.aberto ? ' open' : '') + '" data-gbc="' + E(r.id) + '">'
        + '<div class="gbc-h"><span class="gbc-tp ' + t + '" title="' + (t === 'A' ? 'Acórdão' : 'Decisão monocrática') + '">' + t + '</span><span class="gbc-num">' + E(r.processo || r.id) + '</span><span class="gbc-sg">' + E(r.classeSigla || '') + '</span>'
        + (o.score != null ? '<em class="gbc-sc" title="' + E(o.scoreRot || 'aderência') + '">' + E(o.score) + '</em>' : o.proprio ? '<em class="gbc-sc pr">próprio</em>' : '')
        + '<span class="gbc-dt">' + fmtData(r.dataJulgamento) + '</span></div>'
        + '<div class="gbc-ass">' + realca(E(o.hit || ass || '(sem prévia)'), c) + '</div>'
        + '<div class="gbc-tags">' + tags + subTags + '</div>'
        + (o.motivos && o.motivos.length ? '<div class="gbc-mot">' + o.motivos.slice(0, 6).map(function (m) { return '<span>' + E(m) + '</span>'; }).join('') + '</div>' : '')
        + (o.aberto ? '<div class="gbc-x">' + realca(E(o.texto || r.ementa || '—'), c) + (r.resultado ? '<div class="gbc-note"><b>' + (t === 'A' ? 'Resultado' : 'Dispositivo') + ':</b> ' + realca(E(r.resultado), c) + '</div>' : '') + '</div>' : '')
        + (o.acoes ? '<div class="gbc-ac">' + o.acoes + '</div>' : '') + '</li>';
    }
    return '<li class="gbc' + (o.sel ? ' sel' : '') + (o.aberto ? ' open' : '') + '" data-id="' + E(r.id) + '">'
      + '<div class="gbc-row" data-gbj="abrir">'
      + '<div class="gbc-c0"><button type="button" class="gbc-chev" data-gbj="toggle" aria-expanded="' + !!o.aberto + '" aria-label="' + (o.aberto ? 'Recolher' : 'Expandir') + ' o card">' + ICO.chev + '</button><span class="gbc-tp ' + t + '" title="' + (t === 'A' ? 'Acórdão' : 'Decisão monocrática') + '">' + t + '</span></div>'
      + '<div class="gbc-c1"><span class="gbc-num">' + E(r.processo || r.id) + '</span><span class="gbc-sub" title="' + E(r.classe || '') + '">' + E([r.classeSigla, r.classe].filter(Boolean).join(' · ')) + '</span></div>'
      + '<div class="gbc-c2"><span class="gbc-assl" title="' + E(ass) + '">' + realca(E(ass || '(sem prévia)'), c) + '</span><div class="gbc-tags">' + tags + subTags + '</div></div>'
      + '<div class="gbc-c3"><span class="gbc-dt" title="' + (t === 'A' ? 'Julgado' : 'Decidido') + ' em">' + fmtData(r.dataJulgamento) + '</span><button type="button" class="gbc-ib" data-gbj="citar" title="Copiar citação" aria-label="Copiar citação">' + ICO.cit + '</button><button type="button" class="gbc-ib" data-gbj="abrir" title="Abrir o julgado" aria-label="Abrir o julgado">' + ICO.doc + '</button></div>'
      + '</div>'
      + (o.aberto ? '<div class="gbc-body"><div class="gbc-pnl"><div class="gbc-lb">' + (o.hit ? (o.hitRot ? E(o.hitRot) + '<span class="gbc-hint">últimos 2 anos</span>' : 'Ocorrência no texto integral<span class="gbc-hint">busca integral</span>') : t === 'A' ? 'Ementa · prévia' : 'Trecho inicial') + '</div><div class="gbc-tx">' + realca(E(o.hit || r.ementa || '—'), c) + '</div>'
        + (r.resultado ? '<div class="gbc-note"><b>' + (t === 'A' ? 'Resultado' : 'Dispositivo') + ':</b> ' + realca(E(r.resultado), c) + '</div>' : '') + '</div>'
        + '<div class="gbc-pnl"><div class="gbc-lb">Dados</div>'
        + [['Classe', r.classe || '—'], ['Órgão', r.orgao || 'não informado'], [t === 'A' ? 'Julgamento' : 'Decisão', fmtData(r.dataJulgamento)], ['Publicação', [r.veiculo, r.dataPublicacao].filter(Boolean).join(' · ') || '—'], ['Atuação', pa ? 'Relator para o acórdão' : 'Relator'], ['Registro', r.id]]
          .map(function (x) { return '<div class="gbc-pr"><span>' + x[0] + '</span><span>' + E(x[1]) + '</span></div>'; }).join('')
        + [['Subassuntos', sa.materia], ['Procedimento', sa.proced], ['Questões', sa.acessorias], ['Normas', sa.normas]].filter(function (x) { return x[1].length; }).map(function (x) { return '<div class="gbc-pr"><span>' + x[0] + '</span><span class="gbc-subs">' + x[1].map(function (m) { return '<button type="button" class="gbc-sb" data-gbj="sub" data-k="' + E(m.k) + '" data-rot="' + E(m.rot) + '" title="Filtrar por este subassunto">' + E(m.rot) + '</button>'; }).join('') + '</span></div>'; }).join('') + '</div>'
        + '<div class="gbc-foot"><button type="button" data-gbj="citar">' + ICO.cit + 'Copiar citação</button><button type="button" class="pri" data-gbj="abrir">' + ICO.doc + 'Abrir o julgado</button></div></div>' : '')
      + '</li>';
  }

  /* ══════════ pintura ══════════ */
  function pinta() {
    var g = ger(), p = g && g.querySelector('#gbib'); if (!p) return;
    g.querySelectorAll('[data-gbib-aba]').forEach(function (b) { var on = b.dataset.gbibAba === ST.aba; b.setAttribute('aria-selected', on ? 'true' : 'false'); b.tabIndex = on ? 0 : -1; b.classList.toggle('on', on); });
    var doc = ST.aba === 'doc'; p.hidden = doc; g.classList.toggle('gbib-on', !doc);
    g.querySelectorAll('[data-gbib-facs]').forEach(function (el) { el.hidden = doc; });
    g.querySelectorAll('[data-gbib-doctabs]').forEach(function (el) { el.hidden = !doc; });
    g.querySelectorAll('[data-fac]').forEach(function (b) { var on = b.dataset.fac === ST.fac; b.classList.toggle('on', on); b.setAttribute('aria-selected', on ? 'true' : 'false'); });
    if (doc) return;
    p.setAttribute('aria-labelledby', 'gbib-tab-' + ST.aba);
    iniciaPeriodo();
    var chaveMont = ST.fac + '|' + ST.est.paradigmas.length + '/' + ST.est.modelos.length + '|' + (ST.est.loaded.paradigmas ? 1 : 0) + (ST.est.loaded.modelos ? 1 : 0) + '|' + (ST.est.erro.paradigmas ? 1 : 0) + (ST.est.erro.modelos ? 1 : 0);
    if (J.montado !== chaveMont || !p.querySelector('[data-gbj-main]')) { montaFaceta(p); J.montado = chaveMont; }
    topo(ger());
  }
  function topo(g) {
    var S = ST.est, st = g && g.querySelector('.gbib-st'); if (!g) return;
    if (st) st.innerHTML = S.pending ? '<i class="warn"></i>Atualizando…' : (S.erro.paradigmas || S.erro.modelos) ? '<i class="err"></i>Fonte indisponível' : S.loaded.paradigmas ? '<i class="ok"></i>Conteúdo atualizado' : '<i></i>Carregando…';
    var a = g.querySelector('[data-ct="prec"]'), b = g.querySelector('[data-ct="mod"]');
    if (a) a.textContent = S.loaded.paradigmas ? S.paradigmas.length.toLocaleString('pt-BR') : '—';
    if (b) b.textContent = S.loaded.modelos ? S.modelos.length.toLocaleString('pt-BR') : '—';
  }
  /* o seletor de bancos e o status ficam na barra de abas; aqui só o aviso de falha */
  function cabecalho() {
    var er = ST.est.erro.paradigmas || ST.est.erro.modelos;
    return er ? '<div class="gbib-banner err" role="alert" data-testid="status-fonte-erro"><b>Não foi possível atualizar o conteúdo.</b>' + (ST.est.loaded.paradigmas ? ' A última consulta continua disponível.' : '') + ' <button type="button" data-gbib="fonte-recarregar" data-testid="button-fonte-tentar">Tentar de novo</button></div>' : '';
  }
  function montaFaceta(p) {
    var foco = D.activeElement && p.contains(D.activeElement) && D.activeElement.dataset.gbjQ ? D.activeElement.dataset.gbjQ : '';
    var html = cabecalho();
    if (ST.fac === 'mod') html += telaModelos(); else html += telaPrecedentes();
    p.innerHTML = html;
    if (ST.fac === 'mod') { if (ST.est.loaded.modelos) { aplicaModelos(); if (J.msel) abreMod(J.msel, true); } }
    else if (ST.est.loaded.paradigmas) { aplicaPrec(); if (ST.sel.paradigmas) abrePrec(ST.sel.paradigmas, true); }
    if (foco) { var i = p.querySelector('[data-gbj-q="' + foco + '"]'); if (i) { i.focus(); var v = i.value; try { i.setSelectionRange(v.length, v.length); } catch (_) {} } }
  }
  /* filtros sempre abertos na tela larga; no celular ficam recolhidos até o usuário abrir */
  function estreito() { try { return W.matchMedia('(max-width:1100px)').matches; } catch (_) { return false; } }
  function filtAttr() { return !estreito() || J.filtrosAbertos ? ' open' : ''; }
  function chips(grupo, ops, atual) { return '<div class="gbj-seg" data-gbj-chips="' + grupo + '">' + ops.map(function (o) { return '<button type="button" class="gbj-chip' + (o[0] === atual ? ' on' : '') + '" data-v="' + E(o[0]) + '"' + (o[2] ? ' title="' + E(o[2]) + '"' : '') + '>' + o[1] + '</button>'; }).join('') + '</div>'; }
  function esqueleto() { return '<div class="gbib-sk" aria-busy="true" data-testid="status-biblioteca-carregando"><i></i><i></i><i></i><i></i><i></i></div>'; }

  /* ══════════ I · Precedentes ══════════ */
  function telaPrecedentes() {
    var S = ST.est;
    if (!S.loaded.paradigmas) return '<div class="gbj-main sem-det"><div class="gbj-load">' + (S.erro.paradigmas ? vazio('Não foi possível carregar a jurisprudência', 'Use "Tentar de novo" acima.') : esqueleto()) + '</div></div>';
    var F = J.pf, A = anos(), opAno = function (v, ph) { return '<option value="">' + ph + '</option>' + A.slice().reverse().map(function (a) { return '<option' + (a === v ? ' selected' : '') + '>' + a + '</option>'; }).join(''); };
    var per = F.ano1 === J.anoRec && !F.ano2 ? 'recentes' : !F.ano1 && !F.ano2 ? 'todo' : '';
    var nAtivos = ['classe', 'orgao', 'conteudo', 'atuacao'].filter(function (k) { return F[k]; }).length + (per === 'recentes' ? 0 : 1);
    return '<div class="gbj-main' + (ST.sel.paradigmas ? '' : ' sem-det') + '" data-gbj-main="prec">'
      + '<details class="gbj-filtros"' + filtAttr() + ' data-gbj-filt><summary>Filtros' + (nAtivos ? ' <b>' + nAtivos + '</b>' : '') + '</summary><div class="gbj-fb">' + '<div class="gbj-atual"><button type="button" class="gbj-btn wide" data-gbib="fonte-recarregar" data-testid="button-fonte-recarregar">↻ Atualizar conteúdo</button><span class="gbib-st" role="status"></span></div>'
      + '<div class="gbj-grp"><span class="gbj-lbl">Tipo</span>' + chips('tipo', [['A', 'Acórdãos <b data-cta="A"></b>'], ['M', 'Monocráticas <b data-cta="M"></b>'], ['*', 'Todos']], F.tipo) + '</div>'
      + '<div class="gbj-grp"><label class="gbj-lbl" for="gbj-fsub">Subassunto <small>rótulos do enunciado da ementa</small></label>'
      + (F.sub ? '<div class="gbj-subsel"><span>' + E(F.subRot || F.sub) + '</span><button type="button" data-gbj="sub-x" aria-label="Remover o filtro de subassunto">×</button></div>' : '<input id="gbj-fsub" class="gbj-inp gbj-subq" list="gbj-sublist" data-gbj-subq placeholder="Digite e escolha — ex.: segurado especial" autocomplete="off"><datalist id="gbj-sublist"></datalist>')
      + '<div class="gbj-subs" data-gbj-subs></div></div>'
      + '<div class="gbj-grp"><label class="gbj-lbl" for="gbj-fclasse">Classe</label><select id="gbj-fclasse" class="gbj-inp" data-gbj-f="classe" data-testid="filter-gerador-classe"></select></div>'
      + '<div class="gbj-grp"><label class="gbj-lbl" for="gbj-forgao">Órgão julgador</label><select id="gbj-forgao" class="gbj-inp" data-gbj-f="orgao" data-testid="filter-gerador-orgao"></select></div>'
      + '<div class="gbj-grp"><span class="gbj-lbl">Período (ano)</span>' + chips('periodo', [['recentes', 'Mais recentes <b>' + (J.anoRec ? E(J.anoRec + '–' + A[A.length - 1]) : '') + '</b>', 'Ano atual e anterior — busca integral mais rápida'], ['todo', 'Todo o período', 'A busca integral lê todos os anos']], per)
      + '<div class="gbj-row2"><select class="gbj-inp" data-gbj-f="ano1" aria-label="Ano inicial" data-testid="filter-gerador-ano">' + opAno(F.ano1, 'de…') + '</select><select class="gbj-inp" data-gbj-f="ano2" aria-label="Ano final">' + opAno(F.ano2, 'até…') + '</select></div></div>'
      + '<div class="gbj-grp" data-gbj-soA' + (F.tipo === 'M' ? ' hidden' : '') + '><span class="gbj-lbl">Texto disponível</span>' + chips('conteudo', [['', 'Qualquer'], ['integral', 'Integral', 'Relatório, voto e acórdão'], ['apenas_acordao', 'Ementa + acórdão'], ['apenas_ementa', 'Só ementa']], F.conteudo) + '</div>'
      + '<div class="gbj-grp" data-gbj-soA' + (F.tipo === 'M' ? ' hidden' : '') + '><span class="gbj-lbl">Atuação</span>' + chips('atuacao', [['', 'Qualquer'], ['relator', 'Relator'], ['p', 'Relator p/ acórdão']], F.atuacao) + '</div>'
      + '<div class="gbj-grp"><label class="gbj-lbl" for="gbj-fordem">Ordenar</label><select id="gbj-fordem" class="gbj-inp" data-gbj-f="ordem" data-testid="select-ordem-jurisprudencia"><option value="recente"' + (F.ordem === 'recente' ? ' selected' : '') + '>Mais recentes primeiro</option><option value="antigo"' + (F.ordem === 'antigo' ? ' selected' : '') + '>Mais antigos primeiro</option><option value="processo"' + (F.ordem === 'processo' ? ' selected' : '') + '>Número do processo</option></select></div>'
      + '<button type="button" class="gbj-btn wide" data-gbj="limpar">Limpar filtros</button>'
      + '<hr class="gbj-hr"><span class="gbj-lbl">Distribuição no recorte</span><div class="gbj-histo" data-gbj-histo></div><div class="gbj-histoleg" data-gbj-histoleg></div>'
      + '</div></details>'
      + '<section class="gbj-lista"><div class="gbj-lbar"><div class="gbj-ftit j"><i>I</i>Precedentes <span>· decisões do gabinete — pesquise, leia, cite</span></div>'
      + '<label class="gbj-q">' + ICO.lupa + '<input type="search" data-gbj-q="prec" value="' + E(J.pq) + '" placeholder=\'Buscar — ex.: "perda superveniente" gratuidade -penal\' aria-label="Buscar precedentes" autocomplete="off" spellcheck="false" data-testid="input-busca-paradigmas"></label>'
      + '<div class="gbj-modo"><label><input type="radio" name="gbj-modo" value="indice"' + (J.modo === 'indice' ? ' checked' : '') + ' data-gbj-modo> Índice <span>(número, classe, ementa e resultado; nos últimos 2 anos também ementa completa, temas, súmulas e citações · instantâneo)</span></label><label><input type="radio" name="gbj-modo" value="integral"' + (J.modo === 'integral' ? ' checked' : '') + ' data-gbj-modo> Texto integral <span>(lê os anos do recorte)</span></label>'
      + '<button type="button" class="gbj-btn sm pri" data-gbj="buscar" data-testid="button-busca-integral"' + (J.buscando ? ' disabled' : '') + '>Buscar</button></div>'
      + '<div class="gbj-prog" data-gbj-prog' + (J.buscando ? '' : ' hidden') + '><i style="width:' + J.prog + '%"></i></div>'
      + '<div class="gbj-resumo"><span data-gbj-resumo>—</span><span class="gbj-meta" data-gbj-resumo2></span></div>'
      + '<p class="gbj-dica">Todos os termos precisam aparecer; use aspas para frase exata e - para excluir. Acentos e o ponto de milhar dos números (Tema 1.102 / 1102) não fazem diferença.</p></div>'
      + '<ul class="gbj-res" data-gbj-res data-testid="list-paradigmas"></ul></section>'
      + '<section class="gbj-det" data-gbj-det></section></div>';
  }
  function preencheSelects() {
    var p = ger() && ger().querySelector('#gbib'); if (!p) return;
    var F = J.pf, base = ST.est.paradigmas.filter(function (r) { return F.tipo === '*' || tipoAM(r) === F.tipo; }), cl = {}, og = {}, nomes = {}, ca = { A: 0, M: 0 };
    ST.est.paradigmas.forEach(function (r) { ca[tipoAM(r)]++; });
    base.forEach(function (r) { var k = r.classeSigla || '—'; cl[k] = (cl[k] || 0) + 1; if (!nomes[k]) nomes[k] = r.classe || ''; var o = r.orgao || '(não informado)'; og[o] = (og[o] || 0) + 1; });
    var ord = function (o) { return Object.keys(o).sort(function (a, b) { return o[b] - o[a]; }); };
    if (F.classe && !cl[F.classe]) F.classe = ''; if (F.orgao && !og[F.orgao]) F.orgao = '';
    var sc = p.querySelector('[data-gbj-f="classe"]'), so = p.querySelector('[data-gbj-f="orgao"]');
    if (sc) sc.innerHTML = '<option value="">Todas</option>' + ord(cl).map(function (k) { return '<option value="' + E(k) + '"' + (k === F.classe ? ' selected' : '') + '>' + E(k) + (nomes[k] ? ' — ' + E(nomes[k].toLowerCase().replace(/(^|\s)\S/g, function (x) { return x.toUpperCase(); }).replace(/\b(De|Da|Do|Das|Dos|E|Em)\b/g, function (x) { return x.toLowerCase(); })) : '') + ' (' + cl[k].toLocaleString('pt-BR') + ')</option>'; }).join('');
    if (so) so.innerHTML = '<option value="">Todos</option>' + ord(og).map(function (k) { return '<option value="' + E(k) + '"' + (k === F.orgao ? ' selected' : '') + '>' + E(k) + ' (' + og[k].toLocaleString('pt-BR') + ')</option>'; }).join('');
    p.querySelectorAll('[data-cta]').forEach(function (b) { b.textContent = (ca[b.dataset.cta] || 0).toLocaleString('pt-BR'); });
  }
  function aplicaPrec(semSelects) {
    var p = ger() && ger().querySelector('#gbib'), ul = p && p.querySelector('[data-gbj-res]'); if (!ul) return;
    if (!semSelects) preencheSelects();
    var c = parseConsulta(J.pq.trim()), I = J.integral, usarI = I && I.q === J.pq.trim(), pend = !c.vazia && !usarI && J.modo === 'integral';
    J.consulta = c.vazia || pend ? null : c;
    J.filt = ST.est.paradigmas.filter(function (r) { return passaPrec(r) && (c.vazia || pend || (usarI ? I.m.has(String(r.id)) : casa(textoDe(r), c))); });
    var o = J.pf.ordem, dk = function (r) { return String(r.dataJulgamento || ''); };
    J.filt.sort(o === 'antigo' ? function (a, b) { return dk(a).localeCompare(dk(b)); } : o === 'processo' ? function (a, b) { return String(a.processo || '').localeCompare(String(b.processo || '')); } : function (a, b) { return dk(b).localeCompare(dk(a)); });
    J.mostrados = 0; ul.innerHTML = ''; mais();
    var nA = 0; J.filt.forEach(function (r) { if (tipoAM(r) === 'A') nA++; });
    var rs = p.querySelector('[data-gbj-resumo]'), rs2 = p.querySelector('[data-gbj-resumo2]');
    if (rs) rs.innerHTML = '<b>' + J.filt.length.toLocaleString('pt-BR') + '</b> resultado' + (J.filt.length === 1 ? '' : 's') + (J.pf.tipo === '*' ? ' · ' + nA.toLocaleString('pt-BR') + ' acórdãos · ' + (J.filt.length - nA).toLocaleString('pt-BR') + ' monocráticas' : '');
    if (rs2) rs2.textContent = usarI ? 'texto integral · ' + I.anos + ' arquivo(s) anuais lidos' + (I.truncado ? ' · resultado parcial (refine)' : '') : pend ? 'pressione Buscar para pesquisar no texto integral' : c.vazia ? '' : 'busca no índice';
    histograma(); subsRecorte();
  }
  /* índice de matérias do recorte: os subassuntos mais frequentes, clicáveis */
  function subsRecorte() {
    var p = ger() && ger().querySelector('#gbib'), el = p && p.querySelector('[data-gbj-subs]'); if (!el) return;
    var cont = new Map(); J.filt.forEach(function (r) { saDe(r).materia.forEach(function (m) { var c = cont.get(m.k); if (c) c.n++; else cont.set(m.k, { n: 1, rot: m.rot }); }); });
    var top = Array.from(cont.entries()).filter(function (x) { return x[0] !== J.pf.sub; }).sort(function (a, b) { return b[1].n - a[1].n; }).slice(0, J.pf.sub ? 10 : 14);
    el.innerHTML = top.length ? '<span class="gbj-sublbl">' + (J.pf.sub ? 'Também presentes' : 'Mais frequentes no recorte') + '</span>' + top.map(function (x) { return '<button type="button" class="gbj-chip sub" data-gbj="sub" data-k="' + E(x[0]) + '" data-rot="' + E(x[1].rot) + '" title="' + x[1].n + ' julgado(s)">' + E(x[1].rot) + ' <b>' + x[1].n.toLocaleString('pt-BR') + '</b></button>'; }).join('') : '';
    var dl = p.querySelector('#gbj-sublist');
    if (dl && !dl.__ok) {
      var base = new Map(); ST.est.paradigmas.forEach(function (r) { if (J.pf.tipo !== '*' && tipoAM(r) !== J.pf.tipo) return; var v = saDe(r); v.materia.concat(v.proced, v.acessorias, v.normas).forEach(function (m) { var c = base.get(m.k); if (c) c.n++; else base.set(m.k, { n: 1, rot: m.rot }); }); });
      dl.innerHTML = Array.from(base.values()).filter(function (x) { return x.n >= 2; }).sort(function (a, b) { return b.n - a.n; }).slice(0, 600).map(function (x) { return '<option value="' + E(x.rot) + '">' + x.n + ' julgados</option>'; }).join('');
      dl.__ok = true;
    }
  }
  function mais() {
    var p = ger() && ger().querySelector('#gbib'), ul = p && p.querySelector('[data-gbj-res]'); if (!ul) return;
    var fim = Math.min(J.filt.length, J.mostrados + PAGINA), h = '', I = J.integral && J.integral.q === J.pq.trim() ? J.integral : null;
    for (var i = J.mostrados; i < fim; i++) { var r = J.filt[i], id = String(r.id); h += cardPrec(r, opCard(r)); }
    if (J.mostrados === 0 && !J.filt.length) h = '<li class="gbj-vz">' + (J.modo === 'indice' && J.consulta ? 'Nenhuma decisão no recorte. O índice cobre número, classe, prévia da ementa e resultado: experimente a busca no <b>texto integral</b> ou amplie os filtros.' : 'Nenhuma decisão no recorte. Amplie os filtros ou revise os termos.') + '</li>';
    var m = ul.querySelector('.gbj-mais'); if (m) m.remove();
    ul.insertAdjacentHTML('beforeend', h); J.mostrados = fim;
    if (J.mostrados < J.filt.length) ul.insertAdjacentHTML('beforeend', '<li class="gbj-mais"><button type="button" class="gbj-btn sm" data-gbj="mais">Mostrar mais ' + Math.min(PAGINA, J.filt.length - J.mostrados) + ' de ' + (J.filt.length - J.mostrados).toLocaleString('pt-BR') + '</button></li>');
  }
  /* opções do card na lista: trecho do texto integral, da ementa completa ou as citações, onde a busca casou */
  function opCard(r) {
    var id = String(r.id), I = J.integral && J.integral.q === J.pq.trim() ? J.integral : null, hit = I ? I.m.get(id) : '', rot = '';
    if (!hit && J.consulta && (r.ementaRica || arr(r.temasCitados).length) && !casa(r.ementa || '', J.consulta)) { hit = trecho(r.ementaRica || '', J.consulta); rot = 'Na ementa completa'; if (!hit) { hit = citadosDe(r); rot = 'Temas, súmulas e citações do julgado'; } }
    return { modo: 'lista', c: J.consulta, hit: hit, hitRot: rot, aberto: J.abertos.has(id), sel: ST.sel.paradigmas === id };
  }
  function citadosDe(r) { return [arr(r.temasCitados).length ? 'Temas: ' + arr(r.temasCitados).join(', ') : '', arr(r.sumulasCitadas).length ? 'Súmulas: ' + arr(r.sumulasCitadas).join(', ') : '', r.dispositivosCitados ? 'Dispositivos: ' + r.dispositivosCitados : '', r.jurisprudenciaCitada ? 'Jurisprudência: ' + r.jurisprudenciaCitada : ''].filter(Boolean).join(' · ').replace(/(\d+)\/(STF|STJ)/g, '$1/$2'); }
  function histograma() {
    var p = ger() && ger().querySelector('#gbib'), el = p && p.querySelector('[data-gbj-histo]'), lg = p && p.querySelector('[data-gbj-histoleg]'); if (!el) return;
    var cont = {}; J.filt.forEach(function (r) { var a = String(r.ano || String(r.dataJulgamento || '').slice(0, 4)); cont[a] = (cont[a] || 0) + 1; });
    var A = Object.keys(cont).filter(function (a) { return /^\d{4}$/.test(a); }).sort(); if (!A.length) { el.innerHTML = ''; lg.innerHTML = ''; return; }
    var a0 = +A[0], a1 = +A[A.length - 1], mx = Math.max.apply(null, A.map(function (a) { return cont[a]; })), h = '';
    for (var a = a0; a <= a1; a++) { var v = cont[a] || 0; h += '<button type="button" data-gbj="ano" data-v="' + a + '" title="' + a + ': ' + v.toLocaleString('pt-BR') + '" style="height:' + (v ? Math.max(4, v / mx * 100) : 4) + '%;opacity:' + (v ? .8 : .15) + '"></button>'; }
    el.innerHTML = h; lg.innerHTML = '<span>' + a0 + '</span><span>' + a1 + '</span>';
  }
  /* registro completo (ementa, partes, inteiro teor) do servidor, com cache por id */
  var INT = {};
  function inteiro(id) {
    id = String(id); var I = ST.it;
    if (I.cache[id]) return Promise.resolve(I.cache[id]);
    if (INT[id]) return INT[id];
    I.pend[id] = true; delete I.erro[id];
    INT[id] = jget('/api/paradigmas/inteiro-teor/' + encodeURIComponent(id)).then(function (d) {
      if (!d.registro || String(d.registro.id) !== id) throw new Error('registro não corresponde ao selecionado');
      if (Object.keys(I.cache).length >= 80) delete I.cache[Object.keys(I.cache)[0]];
      return (I.cache[id] = { registro: d.registro, inteiroTeor: typeof d.inteiroTeor === 'string' ? d.inteiroTeor : '' });
    }).catch(function (e) { I.erro[id] = String(e && e.message || e); throw e; })
      .finally(function () { delete I.pend[id]; delete INT[id]; });
    return INT[id];
  }
  function abrePrec(id, semRolar) {
    id = String(id); if (!ST.est.loaded.paradigmas) { ST.sel.paradigmas = id; return; }
    var x = porId(id), p = ger() && ger().querySelector('#gbib'); if (!p) return;
    if (ST.fac !== 'prec') { ST.fac = 'prec'; ST.sel.paradigmas = id; pinta(); return; }
    var Dt = p.querySelector('[data-gbj-det]'), mn = p.querySelector('[data-gbj-main]'); if (!Dt) return;
    ST.sel.paradigmas = id;
    if (!x) { Dt.innerHTML = '<div class="gbj-dbody"><div class="gbj-aviso err">Julgado não encontrado no índice.</div></div>'; mn.classList.remove('sem-det'); return; }
    mn.classList.remove('sem-det');
    p.querySelectorAll('.gbj-res li.sel').forEach(function (l) { l.classList.remove('sel'); });
    var li = p.querySelector('.gbj-res li[data-id="' + cssEsc(id) + '"]'); if (li) li.classList.add('sel');
    var full = ST.it.cache[id];
    Dt.innerHTML = detPrec(x, full);
    if (!semRolar) Dt.scrollTop = 0;
    if (!full) inteiro(id).then(function () { if (ST.sel.paradigmas === id && ST.fac === 'prec') { Dt.innerHTML = detPrec(x, ST.it.cache[id]); var mk = Dt.querySelector('.gbj-texto mark'); if (mk && J.consulta) setTimeout(function () { try { mk.scrollIntoView({ block: 'center' }); } catch (_) {} }, 60); } },
      function () { if (ST.sel.paradigmas === id && ST.fac === 'prec') Dt.innerHTML = detPrec(x, null); });
  }
  function cssEsc(s) { return String(s).replace(/["\\]/g, '\\$&'); }
  function detPrec(x, full) {
    var r = full ? full.registro : x, t = tipoAM(x), c = J.consulta, id = String(x.id), pa = relatorPA(r) || relatorPA(x);
    var em = full && t === 'A' ? limpaEmenta(r.ementa) : '', k = conteudoDe(r) || conteudoDe(x);
    var aviso = full && t === 'A' && k && k !== 'integral' ? '<div class="gbj-aviso">' + (k === 'apenas_ementa' ? 'A base pública do TRF3 oferece apenas a <b>ementa</b> deste acórdão.' : 'A base pública do TRF3 oferece apenas a <b>ementa e o parágrafo do acórdão</b>; relatório e voto não constam do texto disponibilizado.') + '</div>' : '';
    var estado = full ? '' : ST.it.pend[id] ? '<div class="gbj-aviso">Carregando o registro completo…</div>' : ST.it.erro[id] ? '<div class="gbj-aviso err" role="alert">Não foi possível obter o registro completo (' + E(ST.it.erro[id]) + '). Abaixo está a prévia do índice. <button type="button" class="gbj-btn sm" data-gbj="retry" data-id="' + E(id) + '" data-testid="button-paradigma-tentar">Tentar de novo</button></div>' : '';
    var pub = [r.veiculo || x.veiculo, r.dataPublicacao || x.dataPublicacao].filter(Boolean).join(' · ');
    var it = full && r.inteiroTeor ? String(full.inteiroTeor || '') : '';
    return '<div class="gbj-dhead"><div class="gbj-dtit"><span class="gbj-tag ' + t + '">' + (t === 'A' ? 'Acórdão' : 'Decisão monocrática') + '</span><span class="gbc-num big" data-testid="text-paradigma-titulo">' + E(x.processo || id) + '</span><span class="gbj-tag">' + E(x.classeSigla || '') + '</span>'
      + (full ? '<span class="gbj-tag ok" data-testid="status-registro-completo">registro completo</span>' : '') + '<button type="button" class="gbj-dx" data-gbj="fechar" title="Fechar (Esc)" aria-label="Fechar">×</button></div>'
      + '<div class="gbj-dmeta">' + [['Classe', r.classe || x.classe || '—'], ['Órgão julgador', r.orgao || x.orgao || 'não informado'], [t === 'A' ? 'Julgamento' : 'Decisão', fmtData(r.dataJulgamento || x.dataJulgamento)], ['Publicação', pub || '—'], ['Relator', (full && r.relator ? r.relator : 'Des. Fed. CARLOS MUTA') + (pa ? '\nMuta: relator para o acórdão' : '')], ['Registro', id]]
        .map(function (m) { return '<div><span>' + m[0] + '</span>' + E(m[1]).replace(/\n/g, '<br><em>').replace(/(<em>.*)$/, '$1</em>') + '</div>'; }).join('') + '</div>'
      + '<div class="gbj-dacts"><button type="button" class="gbj-btn sm pri" data-gbj="citar" data-id="' + E(id) + '" data-testid="button-paradigma-citar" title="Classe, número, relatoria, publicação e ementa">Copiar citação</button>'
      + '<button type="button" class="gbj-btn sm ponte" data-gbj="citar-doc" data-id="' + E(id) + '" title="Insere a citação na lacuna {{ }} selecionada do rascunho">Inserir citação no documento</button>'
      + (em ? '<button type="button" class="gbj-btn sm" data-gbj="copiar-ementa" data-id="' + E(id) + '" data-testid="button-paradigma-copiar">Copiar ementa</button>' : '')
      + (it ? '<button type="button" class="gbj-btn sm" data-gbj="copiar-teor" data-id="' + E(id) + '">Copiar inteiro teor</button>' : '') + '</div></div>'
      + '<div class="gbj-dbody">' + estado + aviso
      + (full && r.partes && r.partes.length ? '<h3 class="gbj-sec">Partes</h3><div class="gbj-partes">' + r.partes.map(function (q) { return '<b>' + E(q.polo) + '</b><span>' + E(q.nome) + '</span>'; }).join('') + '</div>' : '')
      + (em ? '<h3 class="gbj-sec">Ementa</h3><div class="gbj-box" data-testid="text-paradigma-ementa">' + realca(E(em), c) + '</div>' : !full && x.ementa ? '<h3 class="gbj-sec">' + (t === 'A' ? 'Ementa · prévia do índice' : 'Trecho inicial · prévia do índice') + '</h3><div class="gbj-box prev">' + realca(E(x.ementa), c) + '</div>' : '')
      + ((r.resultado || x.resultado) ? '<h3 class="gbj-sec">' + (t === 'A' ? 'Resultado' : 'Dispositivo') + '</h3><div class="gbj-box res">' + realca(E(r.resultado || x.resultado), c) + '</div>' : '')
      + (it ? '<h3 class="gbj-sec">Inteiro teor <small>' + it.length.toLocaleString('pt-BR') + ' caracteres</small></h3><div class="gbj-texto">' + realca(E(it), c) + '</div>' : '')
      + (full ? '<h3 class="gbj-sec">Rastreabilidade</h3><div class="gbj-hash">SHA-256 do inteiro teor: ' + E(r.sha256InteiroTeor || '— (sem inteiro teor)') + (r.sha256Ementa ? '<br>SHA-256 da ementa: ' + E(r.sha256Ementa) : '') + '<br>Arquivo: dados/' + (t === 'A' ? 'acordaos' : 'monocraticas') + '/' + E(x.ano) + '.json.gz' + (r.seq != null ? ' · posição ' + E(r.seq) : '') + '</div>'
        + '<p class="gbj-ajuda">Texto reproduzido da base pública de jurisprudência do TRF3, sem alteração de conteúdo. A versão oficial é o documento assinado no PJe e a publicação no diário.</p>' : '')
      + '</div>';
  }
  function fecharDet() {
    var p = ger() && ger().querySelector('#gbib'); if (!p) return;
    var mn = p.querySelector('[data-gbj-main]'); if (mn) mn.classList.add('sem-det');
    if (ST.fac === 'mod') { J.msel = ''; p.querySelectorAll('.gbj-res li.sel').forEach(function (l) { l.classList.remove('sel'); }); return; }
    ST.sel.paradigmas = ''; p.querySelectorAll('.gbj-res li.sel').forEach(function (l) { l.classList.remove('sel'); });
  }
  function citarId(id, noDoc) {
    return inteiro(id).then(function (f) { var t = citacao(f.registro); if (noDoc) insereNoDocumento(t, 'Citação'); else copia(t, 'Citação copiada.'); },
      function (e) { avisa('Não foi possível carregar o julgado: ' + (e && e.message || e), 'error'); });
  }
  /* busca no texto integral: um arquivo anual por chamada ao servidor, com progresso */
  function arquivosDoRecorte() {
    var s = new Set(); ST.est.paradigmas.forEach(function (r) { if (passaPrec(r) && (tipoAM(r) === 'M' || conteudoDe(r) !== 'apenas_ementa')) s.add((tipoAM(r) === 'A' ? 'acordaos/' : 'monocraticas/') + (r.ano || String(r.dataJulgamento || '').slice(0, 4))); });
    return Array.from(s).filter(function (a) { return /\/\d{4}$/.test(a); }).sort().reverse();
  }
  function progresso(pc, txt) {
    var p = ger() && ger().querySelector('#gbib'); if (!p) return; J.prog = pc;
    var b = p.querySelector('[data-gbj-prog]'); if (b) { b.hidden = !J.buscando; var i = b.firstChild; if (i) i.style.width = pc + '%'; }
    var r2 = p.querySelector('[data-gbj-resumo2]'); if (r2 && txt) r2.textContent = txt;
    var bt = p.querySelector('[data-gbj="buscar"]'); if (bt) bt.disabled = J.buscando;
  }
  async function buscarIntegral() {
    var q = J.pq.trim();
    if (J.modo === 'indice' || !q) { J.integral = null; aplicaPrec(true); return; }
    if (J.buscando) return;
    var c = parseConsulta(q); if (!c.rxInc.length) { avisa('Informe ao menos um termo positivo para a busca no texto integral.', 'warn'); return; }
    var arqs = arquivosDoRecorte(); if (!arqs.length) { J.integral = null; aplicaPrec(true); return; }
    if (arqs.length > 8 && !confirma('A busca no texto integral vai ler ' + arqs.length + ' arquivos anuais. Restrinja o período ou a classe para acelerar.\n\nContinuar?')) return;
    J.buscando = true; progresso(2, 'lendo ' + arqs[0].replace('/', ' · ') + '…');
    var m = new Map(), trunc = false;
    try {
      for (var i = 0; i < arqs.length; i++) {
        progresso(Math.max(2, i / arqs.length * 100), 'lendo ' + arqs[i].replace('/', ' · ') + ' (' + (i + 1) + '/' + arqs.length + ')…');
        var d = await jget('/api/paradigmas/busca-integral?arquivo=' + encodeURIComponent(arqs[i]) + '&q=' + encodeURIComponent(q));
        Object.keys(d.hits || {}).forEach(function (k) { m.set(String(k), d.hits[k]); }); if (d.truncado) trunc = true;
        if (J.pq.trim() !== q) return;
      }
      J.integral = { q: q, m: m, anos: arqs.length, truncado: trunc };
    } catch (e) { avisa('Falha na busca no texto integral: ' + (e && e.message || e), 'error'); }
    finally { J.buscando = false; progresso(100, ''); setTimeout(function () { progresso(0, ''); }, 300); }
    aplicaPrec(true);
  }

  /* ══════════ II · Modelos ══════════ */
  var FASES = { TRMS: 'TRMS', '1T': '1ª Turma', '3T': '3ª Turma' };
  function faseRot(f) {
    var a = '', b = ''; ST.est.modelos.forEach(function (m) { if (m.fase !== f || !m.periodo) return; var x = String(m.periodo[0] || '').slice(2, 4), y = String(m.periodo[1] || '').slice(2, 4); if (x && (!a || x < a)) a = x; if (y && (!b || y > b)) b = y; });
    return (FASES[f] || f) + (a ? ' ' + (a === b ? '20' + a : a + '–' + b) : '');
  }
  function modTxt(m) { if (m.__t == null) m.__t = [m.nome, m.tema, (m.palavras_chave || []).join(' '), m.especie, m.resultado, m.abertura, String(m.ementa_modelo || '').slice(0, 700), String(m.modelo || '').replace(/\[[^\]]*\]/g, ' ').slice(0, 6000)].join(' '); return m.__t; }
  function telaModelos() {
    var S = ST.est;
    if (!S.loaded.modelos) return '<div class="gbj-main sem-det"><div class="gbj-load">' + (S.erro.modelos ? vazio('Não foi possível carregar os modelos', 'Use "Tentar de novo" acima.') : esqueleto()) + '</div></div>';
    var F = J.mf, fases = Array.from(new Set(S.modelos.map(function (m) { return m.fase; }).filter(Boolean)));
    fases.sort(function (a, b) { return ['TRMS', '1T', '3T'].indexOf(a) - ['TRMS', '1T', '3T'].indexOf(b); });
    return '<div class="gbj-main m' + (J.msel ? '' : ' sem-det') + '" data-gbj-main="mod">'
      + '<details class="gbj-filtros"' + filtAttr() + ' data-gbj-filt><summary>Filtros</summary><div class="gbj-fb">' + '<div class="gbj-atual"><button type="button" class="gbj-btn wide" data-gbib="fonte-recarregar" data-testid="button-fonte-recarregar">↻ Atualizar conteúdo</button><span class="gbib-st" role="status"></span></div>'
      + '<div class="gbj-grp"><span class="gbj-lbl">Fase do gabinete</span>' + chips('fase', fases.map(function (f) { return [f, E(faseRot(f)), f === 'TRMS' ? 'Turma Regional de MS — padrão atual' : '']; }).concat([['', 'Todas']]), F.fase) + '</div>'
      + '<div class="gbj-grp"><span class="gbj-lbl">Tipo</span>' + chips('mtipo', [['', 'Ambos'], ['monocrática', 'Monocrática'], ['acórdão', 'Acórdão']], F.tipo) + '</div>'
      + '<div class="gbj-grp"><label class="gbj-lbl" for="gbj-mesp">Espécie</label><select id="gbj-mesp" class="gbj-inp" data-gbj-mf="esp"></select></div>'
      + '<div class="gbj-grp"><label class="gbj-lbl" for="gbj-mres">Resultado</label><select id="gbj-mres" class="gbj-inp" data-gbj-mf="res"></select></div>'
      + '<div class="gbj-grp"><label class="gbj-lbl" for="gbj-mmin">Uso mínimo</label><select id="gbj-mmin" class="gbj-inp" data-gbj-mf="min">' + [5, 10, 20, 50].map(function (n) { return '<option value="' + n + '"' + (F.min === n ? ' selected' : '') + '>' + n + '+ decisões</option>'; }).join('') + '</select></div>'
      + '<hr class="gbj-hr"><p class="gbj-ajuda"><b>Como os modelos foram extraídos.</b> Em cada fase, os parágrafos que o gabinete repete literalmente em várias decisões foram identificados; decisões que compartilham o mesmo conjunto desses blocos formam um modelo. O texto fixo vem da decisão mais típica do grupo (indicada na ficha); o que é próprio de cada caso aparece como <code>[campo]</code>.</p>'
      + '<p class="gbj-ajuda">Confira teses, temas e modulações vigentes antes de reutilizar um modelo antigo.</p>'
      + '</div></details>'
      + '<section class="gbj-lista"><div class="gbj-lbar"><div class="gbj-ftit m"><i>II</i>Modelos <span>· extraídos das decisões do gabinete — escolha, confira, aproveite no rascunho</span></div>'
      + '<label class="gbj-q">' + ICO.lupa + '<input type="search" data-gbj-q="mod" value="' + E(J.mq) + '" placeholder=\'Buscar modelos — ex.: deserção, "perda superveniente", BPC\' aria-label="Buscar modelos" autocomplete="off" spellcheck="false" data-testid="input-busca-modelos"></label>'
      + '<div class="gbj-resumo"><span data-gbj-mresumo>—</span><span class="gbj-meta" data-gbj-mresumo2></span></div></div>'
      + '<ul class="gbj-res" data-gbj-mres data-testid="list-modelos"></ul></section>'
      + '<section class="gbj-det" data-gbj-det></section></div>';
  }
  function preencheModSelects() {
    var p = ger() && ger().querySelector('#gbib'); if (!p) return;
    var F = J.mf, base = ST.est.modelos.filter(function (m) { return (!F.fase || m.fase === F.fase) && (!F.tipo || m.tipo === F.tipo); });
    var cnt = function (k) { return base.reduce(function (o, m) { var v = m[k] || '—'; o[v] = (o[v] || 0) + 1; return o; }, {}); };
    var op = function (o, v) { return Object.keys(o).sort(function (a, b) { return o[b] - o[a]; }).map(function (k) { return '<option value="' + E(k) + '"' + (k === v ? ' selected' : '') + '>' + E(k) + ' (' + o[k] + ')</option>'; }).join(''); };
    var ce = cnt('especie'), cr = cnt('resultado'); if (F.esp && !ce[F.esp]) F.esp = ''; if (F.res && !cr[F.res]) F.res = '';
    var se = p.querySelector('[data-gbj-mf="esp"]'), sr = p.querySelector('[data-gbj-mf="res"]');
    if (se) se.innerHTML = '<option value="">Todas</option>' + op(ce, F.esp);
    if (sr) sr.innerHTML = '<option value="">Todos</option>' + op(cr, F.res);
  }
  function aplicaModelos(semSelects) {
    var p = ger() && ger().querySelector('#gbib'), ul = p && p.querySelector('[data-gbj-mres]'); if (!ul) return;
    if (!semSelects) preencheModSelects();
    var F = J.mf, c = parseConsulta(J.mq.trim());
    J.mfilt = ST.est.modelos.filter(function (m) { return (!F.fase || m.fase === F.fase) && (!F.tipo || m.tipo === F.tipo) && (!F.esp || (m.especie || '—') === F.esp) && (!F.res || (m.resultado || '—') === F.res) && (Number(m.frequencia) || 0) >= F.min && (c.vazia || casa(modTxt(m), c)); })
      .sort(function (a, b) { return (b.frequencia || 0) - (a.frequencia || 0); });
    var tot = J.mfilt.reduce(function (s, m) { return s + (Number(m.frequencia) || 0); }, 0);
    var r1 = p.querySelector('[data-gbj-mresumo]'), r2 = p.querySelector('[data-gbj-mresumo2]');
    if (r1) r1.innerHTML = '<b>' + J.mfilt.length + '</b> modelo' + (J.mfilt.length === 1 ? '' : 's');
    if (r2) r2.textContent = 'cobrem ' + tot.toLocaleString('pt-BR') + ' decisões do banco';
    ul.innerHTML = J.mfilt.slice(0, 400).map(function (m) { return cardMod(m, c); }).join('') || '<li class="gbj-vz">Nenhum modelo no recorte. Reduza o “uso mínimo” ou mude a fase.</li>';
  }
  function cardMod(m, c) {
    var A = m.tipo === 'acórdão', per = m.periodo || [];
    return '<li class="gbc' + (String(m.id) === J.msel ? ' sel' : '') + '" data-mid="' + E(m.id) + '"><div class="gbc-row m" data-gbj="mabrir">'
      + '<div class="gbc-c0"><span class="gbc-tp ' + (A ? 'A' : 'M') + '" title="' + E(m.tipo || '') + '">' + (A ? 'A' : 'M') + '</span></div>'
      + '<div class="gbc-c1"><span class="gbc-num sans">' + E(m.frequencia || 0) + ' decisões</span><span class="gbc-sub">' + E(m.especie || '') + '</span></div>'
      + '<div class="gbc-c2"><span class="gbc-assl" title="' + E(m.nome || '') + '">' + realca(E(m.tema || (m.palavras_chave || []).join(' · ') || m.especie || m.nome || ''), c) + '</span>'
      + '<div class="gbc-tags"><span class="gbc-t org ' + (m.fase === 'TRMS' ? 'oms' : m.fase === '3T' ? 'o3' : 'o1') + '">' + E({ TRMS: 'TRMS', '1T': '1ª T', '3T': '3ª T' }[m.fase] || m.fase || '') + '</span>' + (m.resultado ? '<span class="gbc-t res">' + E(m.resultado) + '</span>' : '') + (per[0] ? '<span class="gbc-t">' + E(String(per[0]).slice(0, 4)) + '–' + E(String(per[1] || '').slice(0, 4)) + '</span>' : '') + (m.blocos_fixos ? '<span class="gbc-t dash">' + E(m.blocos_fixos) + ' blocos fixos</span>' : '') + '</div></div>'
      + '<div class="gbc-c3"><button type="button" class="gbc-ib" data-gbj="mcopiar" title="Copiar o texto-modelo" aria-label="Copiar o texto-modelo">' + ICO.doc + '</button></div></div></li>';
  }
  var SEC_ROT = { relatorio: 'Relatório', fundamentacao: 'Fundamentação', dispositivo: 'Dispositivo', ementa: 'Ementa' };
  function cpRender(s) { return E(s).replace(/\[[^\]\n]{1,80}\]/g, function (m) { return '<span class="gbj-cp">' + m + '</span>'; }); }
  function abreMod(id, semRolar) {
    id = String(id); if (!ST.est.loaded.modelos) { J.msel = id; return; }
    var m = modPorId(id), p = ger() && ger().querySelector('#gbib'); if (!p) return;
    if (ST.fac !== 'mod') { ST.fac = 'mod'; J.msel = id; pinta(); return; }
    var Dt = p.querySelector('[data-gbj-det]'), mn = p.querySelector('[data-gbj-main]'); if (!Dt || !m) return;
    J.msel = id; mn.classList.remove('sem-det');
    p.querySelectorAll('.gbj-res li').forEach(function (l) { l.classList.toggle('sel', l.dataset.mid === id); });
    var fonte = porId(m.fonte_modelo), per = m.periodo || [], c = parseConsulta(J.mq.trim());
    var blocos = Array.isArray(m.blocos) ? m.blocos.filter(function (b) { return b && b.texto; }) : [];
    var grupos = {}; blocos.forEach(function (b, i) { var k = b.secao || 'outros'; (grupos[k] = grupos[k] || []).push({ b: b, i: i }); });
    var ex = Array.isArray(m.exemplos) ? m.exemplos : [];
    Dt.innerHTML = '<div class="gbj-dhead"><div class="gbj-dtit"><span class="gbj-tag ' + (m.tipo === 'acórdão' ? 'A' : 'M') + '">' + (m.tipo === 'acórdão' ? 'Modelo de acórdão' : 'Modelo de monocrática') + '</span><span class="gbc-num big">' + E(m.id) + '</span><button type="button" class="gbj-dx" data-gbj="fechar" title="Fechar (Esc)" aria-label="Fechar">×</button></div>'
      + '<div class="gbj-mnome" data-testid="text-modelo-titulo">' + E(m.nome || '') + '</div>'
      + '<div class="gbj-meta">' + E(m.fase_nome || faseRot(m.fase)) + ' · ' + E(m.frequencia || 0) + ' decisões (' + fmtData(per[0]) + ' a ' + fmtData(per[1]) + ')' + (m.processo_modelo ? ' · texto-base <a href="#" data-gbj="ir-decisao" data-id="' + E(m.fonte_modelo) + '">' + E(m.processo_modelo) + '</a>' + (fonte ? ' (' + fmtData(fonte.dataJulgamento) + ')' : '') : '') + '</div>'
      + '<div class="gbj-dacts"><button type="button" class="gbj-btn sm pri" data-gbj="mcopiar" data-mid="' + E(m.id) + '">Copiar texto-modelo</button>' + (m.ementa_modelo ? '<button type="button" class="gbj-btn sm" data-gbj="mcopiar-ementa" data-mid="' + E(m.id) + '">Copiar ementa-modelo</button>' : '') + '<button type="button" class="gbj-btn sm ponte" data-gbj="mpar" title="Abre a aba Parágrafos do Documento agrupada por modelo">Parágrafos no Documento</button></div></div>'
      + '<div class="gbj-dbody">'
      + (m.ementa_modelo ? '<h3 class="gbj-sec">Ementa-modelo</h3><div class="gbj-box">' + realca(cpRender(m.ementa_modelo), c) + '</div>' : '')
      + '<h3 class="gbj-sec">Texto-modelo <small>campos próprios do caso entre [colchetes]</small></h3><div class="gbj-texto mod">' + realca(cpRender(m.modelo || ''), c) + '</div>'
      + (blocos.length ? '<h3 class="gbj-sec">Blocos <small>uso no grupo · inserir na lacuna {{ }} do rascunho</small></h3>' + ['relatorio', 'fundamentacao', 'dispositivo', 'ementa', 'outros'].filter(function (k) { return grupos[k]; }).map(function (k) {
          return '<div class="gbj-bgrp"><b>' + E(SEC_ROT[k] || 'Outros') + '</b>' + grupos[k].map(function (o) { var u = Math.round((Number(o.b.uso) || 0) * 100); return '<div class="gbj-bloco' + (o.b.fixo ? ' fixo' : '') + '"><div class="gbj-btx">' + realca(cpRender(o.b.texto), c) + '</div><div class="gbj-bac"><span title="presente em ' + u + '% das decisões do grupo">' + (o.b.fixo ? 'fixo · ' : '') + u + '%</span><button type="button" class="gbj-btn xs" data-gbj="bins" data-mid="' + E(m.id) + '" data-i="' + o.i + '">Inserir</button><button type="button" class="gbj-btn xs" data-gbj="bcop" data-mid="' + E(m.id) + '" data-i="' + o.i + '">Copiar</button></div></div>'; }).join('') + '</div>';
        }).join('') : '')
      + (ex.length ? '<h3 class="gbj-sec">Decisões que seguem o modelo <small>' + ex.length + '</small></h3><ul class="gbj-simlist">' + ex.map(function (i) { var x = porId(i); return x ? cardPrec(x, { modo: 'compacto', acoes: '<button type="button" class="gbj-btn xs" data-gbj="ir-decisao" data-id="' + E(x.id) + '">Abrir em Precedentes</button>' }) : ''; }).join('') + '</ul>' : '')
      + '</div>';
    if (!semRolar) Dt.scrollTop = 0;
  }

  /* ── formulários ── */
  function confirma(msg) { return W.confirm(msg); }
  function arquivoJSON(cb) {
    var i = D.createElement('input'); i.type = 'file'; i.accept = 'application/json,.json';
    i.onchange = function () { var f = i.files && i.files[0]; if (!f) return; f.text().then(function (t) { cb(JSON.parse(t)); }).catch(function (e) { avisa('Arquivo inválido: ' + e.message, 'error'); }); };
    i.click();
  }
  function copia(t, msg) {
    var ok = function () { avisa(msg || 'Copiado.', 'ok'); };
    try { W.navigator.clipboard.writeText(t).then(ok, function () { copiaAntiga(t) ? ok() : avisa('Não foi possível copiar.', 'warn'); }); }
    catch (_) { copiaAntiga(t) ? ok() : avisa('Não foi possível copiar.', 'warn'); }
  }
  function copiaAntiga(t) { try { var ta = D.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; D.body.appendChild(ta); ta.select(); var r = D.execCommand('copy'); ta.remove(); return r; } catch (_) { return false; } }

  function clique(ev) {
    var b = ev.target.closest('[data-gbib],[data-gbj]'), ch = ev.target.closest('[data-gbj-chips] .gbj-chip');
    if (ch) { chip(ch.parentElement.dataset.gbjChips, ch.dataset.v); return; }
    if (!b) return;
    var a = b.dataset.gbib || b.dataset.gbj, li = b.closest('li[data-id]'), id = b.dataset.id || (li && li.dataset.id), ml = b.closest('li[data-mid]'), mid = b.dataset.mid || (ml && ml.dataset.mid);
    if (a === 'voltar-doc') { abre('doc'); return; }
    if (a === 'fonte-recarregar') { carregaEstaticos(true); return; }
    if (a === 'fac') { if (ST.fac !== b.dataset.v) { ST.fac = b.dataset.v; pinta(); } return; }
    if (a === 'toggle' && id) { ev.stopPropagation(); J.abertos.has(id) ? J.abertos.delete(id) : J.abertos.add(id); var x = porId(id); if (x && li) li.outerHTML = cardPrec(x, opCard(x)); return; }
    if (a === 'citar' && id) { ev.stopPropagation(); citarId(id); return; }
    if (a === 'citar-doc' && id) { citarId(id, true); return; }
    if (a === 'abrir' && id) { abrePrec(id); return; }
    if (a === 'ir-decisao' && id) { ev.preventDefault(); if (!passaPrec(porId(id) || {})) { J.pf.tipo = tipoAM(porId(id) || {}); J.pf.ano1 = J.pf.ano2 = ''; J.pf.classe = J.pf.orgao = J.pf.conteudo = J.pf.atuacao = ''; } ST.sel.paradigmas = id; ST.fac = 'prec'; J.montado = ''; pinta(); return; }
    if (a === 'retry' && id) { delete ST.it.erro[id]; abrePrec(id, true); return; }
    if (a === 'fechar') { fecharDet(); return; }
    if (a === 'mais') { mais(); return; }
    if (a === 'buscar') { buscarIntegral(); return; }
    if (a === 'limpar') { J.pf = { tipo: J.pf.tipo, classe: '', orgao: '', ano1: J.anoRec, ano2: '', conteudo: '', atuacao: '', ordem: 'recente', sub: '', subRot: '' }; J.pq = ''; J.integral = null; J.montado = ''; pinta(); return; }
    if (a === 'sub') { J.pf.sub = b.dataset.k; J.pf.subRot = b.dataset.rot || ''; J.integral = null; J.montado = ''; pinta(); return; }
    if (a === 'sub-x') { J.pf.sub = J.pf.subRot = ''; J.integral = null; J.montado = ''; pinta(); return; }
    if (a === 'ano') { J.pf.ano1 = J.pf.ano2 = b.dataset.v; J.integral = null; J.montado = ''; pinta(); return; }
    if (a === 'copiar-ementa' && id) { inteiro(id).then(function (f) { copia(limpaEmenta(f.registro.ementa), 'Ementa copiada.'); }); return; }
    if (a === 'copiar-teor' && id) { inteiro(id).then(function (f) { copia(f.inteiroTeor, 'Inteiro teor copiado.'); }); return; }
    var m = mid && modPorId(mid);
    if (a === 'mabrir' && m) { abreMod(mid); return; }
    if (a === 'mcopiar' && m) { ev.stopPropagation(); copia(m.modelo || '', 'Texto-modelo copiado.'); return; }
    if (a === 'mcopiar-ementa' && m) { copia(m.ementa_modelo || '', 'Ementa-modelo copiada.'); return; }
    if ((a === 'bins' || a === 'bcop') && m) { var bl = (m.blocos || [])[+b.dataset.i]; if (!bl) return; if (a === 'bcop') copia(bl.texto, 'Bloco copiado.'); else insereNoDocumento(bl.texto, (SEC_ROT[bl.secao] || 'Bloco') + ' · ' + (m.nome || m.id)); return; }
    if (a === 'mpar') { abre('doc'); try { W.CMTGerador.apoio('par'); } catch (_) {} return; }
  }
  function chip(grupo, v) {
    if (grupo === 'tipo') { J.pf.tipo = v; if (v === 'M') J.pf.conteudo = J.pf.atuacao = ''; }
    else if (grupo === 'periodo') { J.pf.ano1 = v === 'recentes' ? J.anoRec : ''; J.pf.ano2 = ''; }
    else if (grupo === 'conteudo' || grupo === 'atuacao') J.pf[grupo] = v;
    else if (grupo === 'fase') { J.mf.fase = v; J.mf.esp = J.mf.res = ''; }
    else if (grupo === 'mtipo') { J.mf.tipo = v; J.mf.esp = J.mf.res = ''; }
    if (grupo === 'fase' || grupo === 'mtipo') { var s = ger().querySelector('[data-gbj-chips="' + grupo + '"]'); if (s) s.querySelectorAll('.gbj-chip').forEach(function (c) { c.classList.toggle('on', c.dataset.v === v); }); aplicaModelos(); return; }
    J.integral = null; J.montado = ''; pinta();
  }
  /* escritas internas do Padrão Muta (só Assessoria), acionadas pela aba Diretrizes do Gerador */
  function padraoAcao(a) {
    if (!ST.can) { avisa('Somente a Assessoria edita as diretrizes internas.', 'warn'); return false; }
    if (a === 'pm-importar') { arquivoJSON(function (j) { if (!j || !j.redacao || !arr(j.redacao.registros).length || !j.roteiros) { avisa('Arquivo incompleto: faltam registros de redação ou roteiros do Padrão Muta.', 'error'); return; } if (!confirma('Atualizar o Padrão Muta (' + (j.extraido_em || 'sem data') + ')? As diretrizes valerão para todo o gabinete.')) return; grava(function (L) { L.padraoMuta = j; }, 'Padrão Muta atualizado.'); }); return true; }
    if (a === 'pm-limpar') { if (confirma('Remover o Padrão Muta interno e voltar à versão embutida?')) grava(function (L) { L.padraoMuta = null; }, 'Voltou a valer o Padrão Muta embutido.'); return true; }
    return false;
  }
  var tQ = 0;
  function digita(ev) {
    var k = ev.target.dataset.gbjQ; if (!k) return;
    clearTimeout(tQ);
    if (k === 'prec') { J.pq = ev.target.value; if (J.modo === 'indice') tQ = setTimeout(function () { J.integral = null; aplicaPrec(true); }, 180); else aplicaPrec(true); }
    else { J.mq = ev.target.value; tQ = setTimeout(function () { aplicaModelos(true); }, 180); }
  }
  function muda(ev) {
    var t = ev.target;
    if (t.dataset.gbjModo != null) { J.modo = t.value === 'integral' ? 'integral' : 'indice'; if (J.modo === 'indice') J.integral = null; aplicaPrec(true); return; }
    if (t.dataset.gbjSubq != null) { var v = t.value.trim(); if (v) { J.pf.sub = chaveSub(v); J.pf.subRot = v; J.integral = null; J.montado = ''; setTimeout(pinta, 0); } return; }
    var f = t.dataset.gbjF; if (f) { J.pf[f] = t.value; if (f !== 'ordem') J.integral = null; if (f === 'ordem') aplicaPrec(true); else { J.montado = ''; pinta(); } return; }
    var mf = t.dataset.gbjMf; if (mf) { J.mf[mf] = mf === 'min' ? Number(t.value) || 5 : t.value; aplicaModelos(mf === 'esp' || mf === 'res'); }
  }
  function tecla(ev) {
    if (ev.key === 'Enter' && ev.target.dataset && ev.target.dataset.gbjQ === 'prec') { ev.preventDefault(); if (J.modo === 'integral') buscarIntegral(); else { J.integral = null; aplicaPrec(true); } }
    if (ev.key === 'Escape' && !ev.target.matches('input,select,textarea')) fecharDet();
  }
  function rolagem(ev) {
    var u = ev.target; if (!u || !u.matches || !u.matches('[data-gbj-res]')) return;
    if (u.scrollTop + u.clientHeight > u.scrollHeight - 300 && J.mostrados < J.filt.length) mais();
  }
  D.addEventListener('toggle', function (e) { var t = e.target; if (t && t.matches && t.matches('#gbib details[data-gbj-filt]') && estreito()) J.filtrosAbertos = t.open; }, true);

  /* busca do índice para outros painéis (Similares do Documento): mesma sintaxe e mesmos filtros de tipo */
  function buscarIndice(q, op) {
    op = op || {}; var c = parseConsulta(String(q || '').trim()); if (c.vazia) return { consulta: c, total: 0, itens: [] };
    if (!ST.est.loaded.paradigmas) { carregaEstaticos(false); return { consulta: c, total: 0, itens: [], carregando: true }; }
    var L = ST.est.paradigmas.filter(function (r) { return (!op.tipo || op.tipo === '*' || tipoAM(r) === op.tipo) && casa(textoDe(r), c); });
    L.sort(function (a, b) { return String(b.dataJulgamento || '').localeCompare(String(a.dataJulgamento || '')); });
    return { consulta: c, total: L.length, itens: L.slice(0, op.limite || 40) };
  }

  /* ── atalhos (CMTCentralIr) → abas dos Geradores ── */
  function ir(acao, dados) {
    dados = dados || {};
    var aba = acao === 'minuta' ? 'minutas' : acao === 'modelo' ? 'modelo' : acao === 'paragrafo' ? 'paragrafos' : acao === 'padrao' ? 'padrao' : 'paradigmas';
    var num = String(dados.numero || dados.processo || '').replace(/\D/g, '');
    var G = W.CMTGerador; if (!G) return false;
    try { if (!G.aberto() || (num && G.arg() !== num)) G.ir(num || G.arg() || ''); } catch (e) { console.warn('[Biblioteca] abrir Gerador', e); }
    var tenta = 0;
    (function vai() {
      if (abre(aba, aba === 'paradigmas' || aba === 'modelo' ? dados.id : '')) {
        if (!dados.id && num && aba === 'paradigmas') { J.pq = String(dados.numero || ''); J.pf.ano1 = J.pf.ano2 = ''; J.pf.tipo = '*'; J.montado = ''; pinta(); }
        return;
      }
      if (++tenta < 30) setTimeout(vai, 120);
    })();
    return true;
  }

  setInterval(function () {
    var box = D.querySelector('#cfg2-painel[data-painel="paradigmas"],#cfg2-painel[data-painel="minutas"]');
    if (box && !box.__gbib) { box.__gbib = 1; ir(box.dataset.painel === 'minutas' ? 'minuta' : 'decisao', {}); }
    var g = ger(); if (g && !g.hidden && !g.querySelector('#gbib-tabs')) { monta(); pinta(); }
    if (g && g.hidden && ST.aba !== 'doc') { ST.aba = 'doc'; pinta(); }
  }, 700);

  /* atualização segura: ao abrir o Gerador e a cada 20 s enquanto visível */
  function podeAtualizar() {
    var g = ger();
    if (g && g.contains && D.activeElement && g.contains(D.activeElement) &&
        D.activeElement.matches('input,textarea,[contenteditable="true"]')) return false;
    if (g && Array.from(g.querySelectorAll ? g.querySelectorAll('[data-gr="novo"],[data-gr="novo-rot"]') : []).some(function (el) { return String(el.value || '').trim(); })) return false;
    return !!(g && !g.hidden && D.visibilityState === 'visible' && !ST.salvando && !ST.carregando && !D.querySelector('dialog.gbib-dlg[open]'));
  }
  /* fonte pública respeita o cache de 5 min; interno só é consultado se já foi carregado (Padrão aberto ou Gerador pediu) */
  function atualiza() { if (!podeAtualizar()) return; carregaEstaticos(false); if (ST.carregado || ST.aba === 'padrao') carrega(false, true); }
  var gerVisivel = false;
  setInterval(function () { var g = ger(), vis = !!(g && !g.hidden); if (vis && !gerVisivel) atualiza(); gerVisivel = vis; }, 700);
  setInterval(atualiza, 20000);
  W.CMTGerBib = {
    ir: ir, abre: abre, abrirEmentario: abrirEmentario, fecharEmentario: fecharEmentario,
    recarregar: function () { return carrega(true); },
    recarregarFonte: function () { return carregaEstaticos(true); },
    podeEditar: function () { return ST.can === true; },
    estado: function () { return { revision: ST.rev, canEditLibrary: ST.can, aba: ST.aba, erro: ST.erro, fonte: fonte(), fonteErro: ST.est.erro, fonteCarregada: ST.est.loaded }; },
    paradigmas: function () { return paradigmas(); }, modelos: function () { return modelos(); }, paragrafos: paragrafos,
    paragrafosCompartilhados: function () { return paragrafosPublicos().slice(); },
    paradigmasProprios: function () { return []; },
    paradigmasOcultos: function () { return []; },
    podeAtualizar: function () { return podeAtualizar(); },
    inserir: insereNoDocumento,
    /* a fonte pública é somente leitura: nada é publicado a partir daqui */
    publicarParagrafo: function (p) { if (!ST.can) { avisa('Somente a Assessoria publica na biblioteca.', 'warn'); return Promise.resolve(false); } avisa('Guarde o trecho como parágrafo pessoal.', 'warn'); return Promise.resolve(false); },
    padraoMuta: function () { if (!ST.carregado && !ST.carregando) carrega(false, true); return ST.lib.padraoMuta; },
    padraoAcao: padraoAcao, puro: PURO,
    /* v272: busca e card compartilhados com o painel Similares do Documento */
    buscarIndice: buscarIndice, cardPrec: cardPrec, citacao: citacao, inteiro: inteiro,
    /* julgados do índice já com o enriquecimento dos últimos 24 meses (uma única carga para a página toda) */
    carregarJulgados: function () { return Promise.resolve(carregaEstaticos(false)).then(function () { return carregaRicos(); }).then(function () { if (!ST.est.loaded.paradigmas) throw new Error(ST.est.erro.paradigmas || 'jurisprudência indisponível'); return ST.est.paradigmas; }); },
    subassuntosDe: function (r) { return saDe(r); },
    enriquecidos: function () { return { carregado: RICOS.carregado, desde: RICOS.desde, total: RICOS.m.size }; }
  };
})(typeof window !== 'undefined' ? window : null);

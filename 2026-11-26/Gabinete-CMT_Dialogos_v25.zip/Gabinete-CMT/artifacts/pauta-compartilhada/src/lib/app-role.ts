export type AppRole = "equipe" | "editor" | "administracao";

export function canAccessGlobalSettings(role: AppRole | string | null | undefined): boolean {
  return role === "editor" || role === "administracao";
}

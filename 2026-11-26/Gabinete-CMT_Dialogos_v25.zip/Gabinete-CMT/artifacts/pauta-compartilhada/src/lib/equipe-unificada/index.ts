import css from './equipe-unificada.css?inline';
import grafismoSumarioUrl from './grafismo-sumario.svg?url';

/* Equipe unificada (Configurações > Equipe): quadro de orientação e apresentação do padrão
   "Designações e atribuições". Não clona controles: os botões acionam as subabas reais
   (.cfg2-subbar [data-cfg2]) e todo o conteúdo continua sendo o do PautaTeam. */

const VIEWS = ['srv', 'resp', 'tarefas', 'contas'] as const;
type View = (typeof VIEWS)[number];
const LABELS: Record<View, [string, string]> = {
  resp: ['Quem faz o quê', 'Matriz, regras de correção e servidor selecionado'],
  srv: ['Ficha completa', 'Todas as abas do perfil do servidor'],
  tarefas: ['Tarefas e subtarefas', 'Catálogo usado pela matriz de designações'],
  contas: ['Contas de acesso', 'Aprovação e vínculo de contas (Administração)'],
};
const ORDER: View[] = ['resp', 'srv', 'tarefas', 'contas'];

type Member = { archived?: boolean; functions?: unknown[]; minutaScopes?: unknown[]; absences?: unknown[] };
type FrameWin = Window & { PautaApp?: { team?: { members?: Member[] } }; __cmtEquipeUnificada?: () => void };

function esc(v: string) {
  return v.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c] as string);
}

export function installEquipeUnificada(doc: Document, win: Window): () => void {
  const w = win as FrameWin;
  w.__cmtEquipeUnificada?.();
  let style = doc.getElementById('cmt-equipe-unificada') as HTMLStyleElement | null;
  if (!style) {
    style = doc.createElement('style');
    style.id = 'cmt-equipe-unificada';
    doc.head.appendChild(style);
  }
  style.textContent = css;
  let railStyle = doc.getElementById('cmt-sidebar-grafismo') as HTMLStyleElement | null;
  if (!railStyle) {
    railStyle = doc.createElement('style');
    railStyle.id = 'cmt-sidebar-grafismo';
    doc.head.appendChild(railStyle);
  }
  const graphic = `url("${grafismoSumarioUrl}")`;
  railStyle.textContent = `
    html.alt-on #alt-side {
      background-image: ${graphic} !important;
      background-position: center top !important;
      background-size: 100% auto !important;
      background-repeat: repeat-y !important;
    }
    @media (min-width: 1100px) {
      html.alt-on.cmtx-rr-on.cmtx-rr-min #cx-rrail {
        isolation: isolate;
      }
      html.alt-on.cmtx-rr-on.cmtx-rr-min #cx-rrail::before {
        content: "";
        position: absolute;
        inset: 0;
        z-index: 0;
        pointer-events: none;
        background: ${graphic} center top / 100% auto repeat-y;
      }
      html.alt-on.cmtx-rr-on.cmtx-rr-min #cx-rrail > :is(.rr-top, .rr-slot, .rr-foot) {
        position: relative;
        z-index: 1;
      }
      html.alt-on.cmtx-rr-on.cmtx-rr-min #cx-rrail :is(.rr-top, .rr-foot) {
        background: transparent !important;
      }
      html.alt-on.cmtx-rr-on.cmtx-rr-min #cx-rrail #v2-rr-mintag {
        z-index: 2;
      }
    }
  `;

  const root = doc.documentElement;
  let frame = 0;
  let lastHtml = '';

  const current = (): View | '' => {
    const v = root.dataset.cfgcV || '';
    return (VIEWS as readonly string[]).includes(v) ? (v as View) : '';
  };

  const summary = () => {
    const members = (w.PautaApp?.team?.members || []).filter((m) => m && !m.archived);
    const semFuncao = members.filter((m) => !m.functions?.length).length;
    const semVinculo = members.filter((m) => !m.minutaScopes?.length).length;
    return { total: members.length, semFuncao, semVinculo };
  };

  const sync = () => {
    frame = 0;
    const view = current();
    const existing = doc.getElementById('eqx-strip');
    root.toggleAttribute('data-eqx', !!view);
    if (!view) { existing?.remove(); lastHtml = ''; return; }
    const bar = doc.querySelector<HTMLElement>('.cfg2-subbar');
    if (!bar || !bar.parentElement) return;
    const available = new Set(Array.from(bar.querySelectorAll<HTMLElement>('[data-cfg2]')).map((b) => b.dataset.cfg2 || ''));
    const s = summary();
    const tabs = ORDER.filter((v) => available.has(v)).map((v) =>
      `<button type="button" class="eqx-tab" data-eqx-go="${v}" aria-current="${v === view ? 'page' : 'false'}"><b>${esc(LABELS[v][0])}</b><small>${esc(LABELS[v][1])}</small></button>`,
    ).join('');
    const html =
      `<div class="eqx-head"><div><span class="eqx-k">Designações e atribuições</span><h2>${esc(LABELS[view][0])}</h2></div>` +
      `<dl class="eqx-stats"><div><dt>Servidores</dt><dd>${s.total}</dd></div>` +
      `<div class="${s.semFuncao ? 'is-warn' : ''}"><dt>Sem atribuição</dt><dd>${s.semFuncao}</dd></div>` +
      `<div class="${s.semVinculo ? 'is-warn' : ''}"><dt>Sem vínculo de minuta</dt><dd>${s.semVinculo}</dd></div></dl></div>` +
      `<nav class="eqx-tabs" aria-label="Áreas da equipe">${tabs}</nav>`;
    let strip = existing;
    if (!strip) {
      strip = doc.createElement('section');
      strip.id = 'eqx-strip';
      strip.setAttribute('aria-label', 'Equipe: designações e atribuições');
    }
    if (strip.previousElementSibling !== bar) bar.insertAdjacentElement('afterend', strip);
    if (html !== lastHtml) { strip.innerHTML = html; lastHtml = html; }
  };
  const schedule = () => { if (!frame) frame = win.requestAnimationFrame(sync); };

  const onClick = (e: Event) => {
    const t = e.target instanceof (win as unknown as { Element: typeof Element }).Element ? (e.target as Element) : null;
    const go = t?.closest<HTMLElement>('#eqx-strip [data-eqx-go]');
    if (!go) return;
    e.preventDefault();
    const target = doc.querySelector<HTMLElement>(`.cfg2-subbar [data-cfg2="${go.dataset.eqxGo}"]`);
    target?.click();
    schedule();
  };
  doc.addEventListener('click', onClick);

  const attrObs = new MutationObserver(schedule);
  attrObs.observe(root, { attributes: true, attributeFilter: ['data-cfgc-v'] });
  /* Narrow: só filhos diretos do corpo das Configurações e da área de conteúdo (sem subtree). */
  const listObs = new MutationObserver((records) => {
    if (records.every((r) => Array.from(r.addedNodes).concat(Array.from(r.removedNodes)).every((n) => (n as Element).id === 'eqx-strip'))) return;
    schedule();
  });
  const watch = () => {
    listObs.disconnect();
    const content = doc.getElementById('app-content');
    if (content) listObs.observe(content, { childList: true });
    const bar = doc.querySelector('.cfg2-subbar');
    if (bar?.parentElement) listObs.observe(bar.parentElement, { childList: true });
  };
  watch();
  const outer = new MutationObserver(() => { watch(); schedule(); });
  outer.observe(root, { attributes: true, attributeFilter: ['data-cfgc-v'] });
  schedule();

  const cleanup = () => {
    attrObs.disconnect(); listObs.disconnect(); outer.disconnect();
    if (frame) win.cancelAnimationFrame(frame);
    doc.removeEventListener('click', onClick);
    doc.getElementById('eqx-strip')?.remove();
    root.removeAttribute('data-eqx');
    if (w.__cmtEquipeUnificada === cleanup) delete w.__cmtEquipeUnificada;
  };
  w.__cmtEquipeUnificada = cleanup;
  return cleanup;
}

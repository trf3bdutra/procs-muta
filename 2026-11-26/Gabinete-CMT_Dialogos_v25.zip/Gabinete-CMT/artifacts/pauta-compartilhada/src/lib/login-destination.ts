const DEFAULT_LOGIN_PATH = "/gabinete";
const DEFAULT_APP_PATHS = new Set(["/", "/gabinete", "/cm", "/cmt", "/ass"]);

export function resolveLoginDestination(search: string, origin: string): string {
  const candidate = new URLSearchParams(search).get("next");
  if (!candidate || !candidate.startsWith("/") || candidate.startsWith("//") || candidate.includes("\\")) {
    return DEFAULT_LOGIN_PATH;
  }

  try {
    const baseOrigin = new URL(origin).origin;
    const target = new URL(candidate, baseOrigin);
    if (
      target.origin !== baseOrigin ||
      target.pathname === "/sign-in" ||
      target.pathname.startsWith("/api/")
    ) {
      return DEFAULT_LOGIN_PATH;
    }

    const normalizedPath = target.pathname.replace(/\/+$/, "") || "/";
    if (normalizedPath === "/servidor") {
      return `/serv-user${target.search}${target.hash}`;
    }
    if (DEFAULT_APP_PATHS.has(normalizedPath)) return DEFAULT_LOGIN_PATH;

    return `${target.pathname}${target.search}${target.hash}`;
  } catch {
    return DEFAULT_LOGIN_PATH;
  }
}

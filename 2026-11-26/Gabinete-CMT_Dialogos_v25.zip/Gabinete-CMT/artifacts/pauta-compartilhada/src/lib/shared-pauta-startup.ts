type StartupOptions<TApp, TSnapshot> = {
  isHtmlReady: () => boolean;
  getApp: () => TApp | null | undefined;
  isAppLoading: (app: TApp) => boolean;
  areScriptsReady: () => boolean;
  isSnapshotFetching: () => boolean;
  getSnapshot: () => TSnapshot | null | undefined;
  onReady: (app: TApp, snapshot: TSnapshot) => void;
  onTimeout?: () => void;
  intervalMs?: number;
  timeoutMs?: number;
};

type AdvancedView = {
  open?: () => void;
  close?: (options?: { notify?: boolean }) => void;
};

export type EmbeddedGabCmtRouteState = {
  pagina?: string;
  area?: string;
  rota?: string;
};

export type EmbeddedGabCmtRouter = {
  ir?: (route: string) => unknown;
  atual?: () => EmbeddedGabCmtRouteState | null | undefined;
};

function routePath(location: string): string {
  return (location.split(/[?#]/, 1)[0].replace(/\/+$/, '') || '/').toLowerCase();
}

/**
 * Map the public URLs to the page names understood by GabCMT's own router.
 * Cada página tem a sua rota: /pauta (Pauta de Julgamento), /mono (Controle de
 * Monocráticas) e /serv-user (Campo do Servidor). Sessões e marcos são
 * configurados em Configurações Globais, sem página independente.
 * As antigas páginas Ementário, Protocolo e Repositório foram retiradas.
 */
export function gabCmtRouteForLocation(location: string): string | null {
  const path = routePath(location);
  const routes: Record<string, string> = {
    '/gabinete': 'pauta',
    '/pauta': 'pauta',
    '/mono': 'decisoes',
    '/tria': 'triagem',
    // Endereços antigos continuam resolvendo, para links salvos não quebrarem.
    '/controle-de-pauta': 'pauta',
    '/controle-de-decisoes': 'decisoes',
    '/filter': 'triagem',
    '/triagem': 'triagem',
    '/serv-user': 'servidor',
  };
  if (routes[path]) return routes[path];
  return null;
}

/** Cada página do GabCMT tem a sua URL própria no shell. */
export function locationForGabCmtPage(pageValue: unknown, routeValue: unknown): string | null {
  const page = String(pageValue ?? '').toLowerCase();
  if (page === 'pauta') return '/pauta';
  if (page === 'decisoes' || page === 'decisao' || page === 'mono') return '/mono';
  if (page === 'configuracoes' || page === 'configuração'
    || page === 'configuracoes-globais') return '/gabinete';
  if (page === 'triagem') return '/tria';
  if (page === 'session' || page === 'sessions' || page === 'sessoes' || page === 'sessoes-e-marcos') return null;
  if (page === 'servidor' || page === 'srv') return '/serv-user';
  void routeValue;
  return null;
}

/** Translate the embedded router's page event into a public URL, avoiding duplicate history entries. */
export function shellPathForEmbeddedPage(pageValue: unknown, currentLocation = ''): string | null {
  // /cm is an independent view. While it is open, the iframe may still emit
  // stale page events from the underlying Pauta; only its explicit close event
  // may change the public URL.
  if (['/cm', '/cmt'].includes(routePath(currentLocation))) return null;
  const page = String(pageValue ?? '').toLowerCase();
  if (page === 'configuracoes' || page === 'configuração' || page === 'configuracoes-globais') return null;
  const target = locationForGabCmtPage(page, '');
  if (!target || routePath(currentLocation) === target) return null;
  return target;
}

/** Translate legacy iframe route events without exposing its internal root as the login landing page. */
export function shellPathForEmbeddedRoute(pathValue: unknown, currentLocation = ''): string | null {
  if (typeof pathValue !== 'string') return null;
  // The underlying Gabinete keeps emitting its route while the exclusive CM
  // view is open. Only an explicit CM close action may leave that page.
  if (['/cm', '/cmt'].includes(routePath(currentLocation))
    && pathValue !== '/cm' && pathValue !== '/cmt') return null;
  const paths: Record<string, string> = {
    '/': '/gabinete',
    '/padrao': '/gabinete',
    '/pauta': '/pauta',
    '/mono': '/mono',
    // O GabCMT ainda emite os endereços antigos; eles chegam às rotas novas.
    '/controle-de-pauta': '/pauta',
    '/controle-de-decisoes': '/mono',
    '/decisoes': '/mono',
    '/tria': '/tria',
    '/filter': '/tria',
    '/triagem': '/tria',
    '/servidor': '/serv-user',
    '/cmt': '/cm',
    '/cm': '/cm',
  };
  return paths[pathValue] ?? null;
}

/* /cm (antes /cmt) is the advanced CM view; as demais páginas usam o roteador interno do GabCMT. */
export function applySharedPautaRoute(
  location: string,
  isReady: boolean,
  advanced?: AdvancedView | null,
  padrao?: AdvancedView | null,
  embeddedRouter?: EmbeddedGabCmtRouter | null,
): boolean {
  if (!isReady) return false;
  const path = routePath(location);
  if (path === '/cm' || path === '/cmt') {
    padrao?.close?.({ notify: false });
    advanced?.open?.();
    return true;
  } else if (path === '/padrao') {
    advanced?.close?.();
    padrao?.open?.();
    return true;
  } else {
    advanced?.close?.();
    padrao?.close?.({ notify: false });
  }

  const targetRoute = gabCmtRouteForLocation(location);
  if (!targetRoute) return false;
  const targetPage = targetRoute.split('/')[0];
  const current = embeddedRouter?.atual?.();
  const currentRoute = String(current?.rota ?? '').replace(/^#\/?/, '');
  const sameRoute = current?.pagina?.toLowerCase() === targetPage
    && (targetPage === 'configuracoes' ? currentRoute === targetRoute : true);
  if (sameRoute) return true;
  if (!embeddedRouter?.ir) return false;
  return embeddedRouter.ir(targetRoute) !== false;
}

export function waitForSharedPautaStartup<TApp, TSnapshot>({
  isHtmlReady,
  getApp,
  isAppLoading,
  areScriptsReady,
  isSnapshotFetching,
  getSnapshot,
  onReady,
  onTimeout,
  intervalMs = 80,
  timeoutMs = 45_000,
}: StartupOptions<TApp, TSnapshot>) {
  let completed = false;
  let cancelled = false;
  let poll: ReturnType<typeof setInterval> | undefined;
  let timeout: ReturnType<typeof setTimeout> | undefined;

  const check = () => {
    if (cancelled || completed || !isHtmlReady() || isSnapshotFetching()) return;
    const app = getApp();
    const snapshot = getSnapshot();
    if (!app || isAppLoading(app) || !areScriptsReady() || snapshot == null) return;

    completed = true;
    if (poll) clearInterval(poll);
    if (timeout) clearTimeout(timeout);
    onReady(app, snapshot);
  };

  const expire = () => {
    if (cancelled || completed) return;
    completed = true;
    if (poll) clearInterval(poll);
    onTimeout?.();
  };

  check();
  if (!completed) {
    poll = setInterval(check, intervalMs);
    timeout = setTimeout(expire, timeoutMs);
  }

  return () => {
    cancelled = true;
    if (poll) clearInterval(poll);
    if (timeout) clearTimeout(timeout);
  };
}
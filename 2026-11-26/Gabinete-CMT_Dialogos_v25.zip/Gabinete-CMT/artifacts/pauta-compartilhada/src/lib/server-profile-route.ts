export function profilePathForLoggedInServer(name: string, currentServer?: string | null): string | null {
  const fold = (value: string) =>
    value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toLocaleUpperCase("pt-BR");
  const requested = fold(name);
  const authenticated = fold(currentServer ?? "");
  return requested && authenticated && requested === authenticated ? "/serv-user" : null;
}

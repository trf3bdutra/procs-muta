const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

export function isAcervoStatisticsStale(
  sourceUpdatedAt: string | Date,
  now = Date.now(),
): boolean {
  const updatedAt = sourceUpdatedAt instanceof Date
    ? sourceUpdatedAt.getTime()
    : Date.parse(sourceUpdatedAt);
  return Number.isFinite(updatedAt) && now - updatedAt > SEVEN_DAYS_MS;
}

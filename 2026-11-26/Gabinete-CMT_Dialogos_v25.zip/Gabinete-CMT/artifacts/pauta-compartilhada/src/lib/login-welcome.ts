import { useEffect, useLayoutEffect, useRef, useState } from "react";

const STORAGE_KEY = "cmt.login-welcome-pending.v1";
const WELCOME_DURATION_MS = 1_200;
let inMemoryPendingUserId: string | null = null;

export function markLoginWelcomePending(userId: string): void {
  inMemoryPendingUserId = userId;
  try {
    sessionStorage.setItem(STORAGE_KEY, userId);
  } catch {
    // A blocked sessionStorage must not interrupt successful authentication.
  }
}

export function clearLoginWelcomePending(): void {
  inMemoryPendingUserId = null;
  try {
    sessionStorage.removeItem(STORAGE_KEY);
  } catch {
    // The server session remains authoritative.
  }
}

function consumeLoginWelcomePending(userId: string): boolean {
  const memoryUserId = inMemoryPendingUserId;
  inMemoryPendingUserId = null;
  try {
    const pendingUserId = sessionStorage.getItem(STORAGE_KEY);
    sessionStorage.removeItem(STORAGE_KEY);
    return pendingUserId === userId || memoryUserId === userId;
  } catch {
    return memoryUserId === userId;
  }
}

/** Consumes the one-shot welcome only after the authenticated identity is confirmed. */
export function useLoginWelcome(authReady: boolean, userId?: string | null): boolean {
  const [visible, setVisible] = useState(false);
  const consumedUser = useRef<string | null>(null);

  useLayoutEffect(() => {
    if (!userId) {
      consumedUser.current = null;
      return;
    }
    if (!authReady || consumedUser.current === userId) return;
    consumedUser.current = userId;
    if (consumeLoginWelcomePending(userId)) setVisible(true);
  }, [authReady, userId]);

  useEffect(() => {
    if (!visible) return;
    const timer = window.setTimeout(() => setVisible(false), WELCOME_DURATION_MS);
    return () => window.clearTimeout(timer);
  }, [visible]);

  return visible;
}

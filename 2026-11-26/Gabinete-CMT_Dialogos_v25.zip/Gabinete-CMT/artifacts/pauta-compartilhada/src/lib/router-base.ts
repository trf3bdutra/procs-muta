export function normalizeRouterBase(baseUrl: string): string {
  return baseUrl.replace(/\/$/, '');
}

export type ProcessStatus =
  | 'pendente'
  | 'feito'
  | 'corrigido'
  | 'liberado'
  | 'adiado'
  | 'retirado'
  | 'julgado';

export type ProcessField = {
  label: string;
  value: string;
};

export type AdvancedProcess = {
  id: string;
  processNumber: string;
  item: string;
  status: ProcessStatus;
  statusLabel: string;
  responsible: string;
  corrector: string;
  fields: ProcessField[];
};

export type SessionStats = {
  total: number;
  pending: number;
  done: number;
  corrected: number;
  released: number;
  postponed: number;
  withdrawn: number;
  judged: number;
};

export type AdvancedSession = {
  name: string;
  date: string;
  prepStart: string;
  minutasDeadline: string;
  releaseDeadline: string;
  gabinete: string;
  stats: SessionStats;
  processes: AdvancedProcess[];
};

export type StaffProductivity = {
  id: string;
  name: string;
  hierarchy: string;
  assignedMinutas: number;
  pendingMinutas: number;
  completedMinutas: number;
  manualMinutas: number;
  assignedCorrections: number;
  pendingCorrections: number;
  completedCorrections: number;
  completedPendencies: number;
  totalMinutas: number;
};

export type ProductivityFilters = {
  session?: string;
  fromDate?: string;
  toDate?: string;
};

export type AdvancedAnalytics = {
  totalProcesses: number;
  activeSessionCount: number;
  sessions: AdvancedSession[];
  productivitySessions: string[];
  productivity: StaffProductivity[];
};

type JsonRecord = Record<string, unknown>;

const STATUS_LABELS: Record<ProcessStatus, string> = {
  pendente: 'Pendente',
  feito: 'Feito',
  corrigido: 'Corrigido',
  liberado: 'Liberado',
  adiado: 'Adiado',
  retirado: 'Retirado',
  julgado: 'Julgado',
};

function record(value: unknown): JsonRecord {
  return value && typeof value === 'object' && !Array.isArray(value)
    ? value as JsonRecord
    : {};
}

function array(value: unknown): unknown[] {
  return Array.isArray(value) ? value : [];
}

function text(value: unknown): string {
  if (value === null || value === undefined) return '';
  if (typeof value === 'boolean') return value ? 'Sim' : 'Não';
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value).trim();
}

function hasValue(value: unknown): boolean {
  return value !== null && value !== undefined && String(value).trim() !== '';
}

function isYes(value: unknown): boolean {
  if (value === true || value === 1) return true;
  return ['sim', 's', 'yes', 'true', '1', 'x', 'ok', 'liberado', 'corrigido']
    .includes(text(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase());
}

function isCompletedFlag(value: unknown): boolean {
  return isYes(value) || dateStamp(value) !== null;
}

function digits(value: unknown): string {
  return text(value).replace(/\D/g, '');
}

function nameKey(value: unknown): string {
  return text(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}

function dateStamp(value: unknown): number | null {
  const raw = text(value);
  const iso = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
  const br = raw.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  const parts = iso
    ? [Number(iso[1]), Number(iso[2]), Number(iso[3])]
    : br
      ? [Number(br[3]), Number(br[2]), Number(br[1])]
      : null;
  if (!parts) return null;
  const [year, month, day] = parts;
  const stamp = Date.UTC(year, month - 1, day);
  const check = new Date(stamp);
  return check.getUTCFullYear() === year && check.getUTCMonth() === month - 1 &&
    check.getUTCDate() === day ? stamp : null;
}

function sessionEntries(row: JsonRecord): JsonRecord[] {
  const entries = array(row._pautaEntries).map(record).filter((entry) => text(entry.session));
  if (entries.length) return entries;
  const destination = text(row['Sessão Destino']);
  return destination ? [{ session: destination, closed: false }] : [];
}

function sessionProcessRows(state: JsonRecord, session: string): Array<{
  row: JsonRecord;
  work: JsonRecord;
  entry: JsonRecord;
  processNumber: string;
}> {
  const preferences = record(state.pautaPreferences);
  const officialLists = record(preferences.jsonSessionLists);
  const permitted = new Set(array(officialLists[session]).map(digits).filter(Boolean));
  if (!permitted.size) return [];

  const matched = array(state.rows).flatMap((rawRow) => {
    const row = record(rawRow);
    const processNumber = text(row.Processo);
    if (!permitted.has(digits(processNumber))) return [];
    const entry = sessionEntries(row).find((item) => text(item.session) === session);
    if (!entry) return [];
    const work = entry.closed && entry.work && typeof entry.work === 'object'
      ? { ...row, ...record(entry.work) }
      : row;
    return [{ row, work, entry, processNumber }];
  });

  const position = new Map(array(officialLists[session]).map((value, index) => [digits(value), index]));
  return matched.sort((left, right) => {
    const leftItem = text(left.entry.item || left.work['Item (Pauta de Julgamento)']);
    const rightItem = text(right.entry.item || right.work['Item (Pauta de Julgamento)']);
    if (leftItem && rightItem) {
      const byItem = leftItem.localeCompare(rightItem, 'pt-BR', { numeric: true });
      if (byItem) return byItem;
    } else if (leftItem !== rightItem) {
      return leftItem ? -1 : 1;
    }
    return (position.get(digits(left.processNumber)) ?? Number.POSITIVE_INFINITY) -
      (position.get(digits(right.processNumber)) ?? Number.POSITIVE_INFINITY);
  });
}

function getProcessStatus(work: JsonRecord): ProcessStatus {
  const hearing = nameKey(work['Status de Julgamento'] || work.JULGAMENTO);
  if (hearing.includes('adiad')) return 'adiado';
  if (hearing.includes('retirad')) return 'retirado';
  if (hearing.includes('julgad')) return 'julgado';
  if (isCompletedFlag(work.LIBERADO)) return 'liberado';
  if (isCompletedFlag(work.CORRIGIDO)) return 'corrigido';
  if (hasValue(work.MINUTADO)) return 'feito';
  return 'pendente';
}

function processFields(row: JsonRecord, work: JsonRecord, entry: JsonRecord, order: string[]): ProcessField[] {
  const merged = { ...row, ...work };
  const keys = [...new Set([...order, ...Object.keys(merged)])];
  const fields = keys
    .filter((key) => key && !key.startsWith('_') && key !== 'Processo')
    .map((key) => ({ label: key, value: text(merged[key]) }))
    .filter((field) => field.value);
  const item = text(entry.item || work['Item (Pauta de Julgamento)']);
  if (item && !fields.some((field) => field.label === 'Item (Pauta de Julgamento)')) {
    fields.unshift({ label: 'Item (Pauta de Julgamento)', value: item });
  }
  return fields;
}

function summarizeProcesses(processes: AdvancedProcess[]): SessionStats {
  const counts: SessionStats = {
    total: processes.length,
    pending: 0,
    done: 0,
    corrected: 0,
    released: 0,
    postponed: 0,
    withdrawn: 0,
    judged: 0,
  };
  for (const process of processes) {
    if (process.status === 'pendente') counts.pending += 1;
    else if (process.status === 'feito') counts.done += 1;
    else if (process.status === 'corrigido') counts.corrected += 1;
    else if (process.status === 'liberado') counts.released += 1;
    else if (process.status === 'adiado') counts.postponed += 1;
    else if (process.status === 'retirado') counts.withdrawn += 1;
    else if (process.status === 'julgado') counts.judged += 1;
  }
  return counts;
}

function asProcess(row: JsonRecord, work: JsonRecord, entry: JsonRecord, order: string[], session: string, index: number): AdvancedProcess {
  const status = getProcessStatus(work);
  return {
    id: `${session}|${digits(row.Processo)}|${index}`,
    processNumber: text(row.Processo),
    item: text(entry.item || work['Item (Pauta de Julgamento)']),
    status,
    statusLabel: STATUS_LABELS[status],
    responsible: text(work.SERVIDOR) || 'Sem servidor',
    corrector: text(work.CORRETOR) || 'Sem corretor',
    fields: processFields(row, work, entry, order),
  };
}

function personMatches(value: unknown, member: JsonRecord): boolean {
  const needle = nameKey(value);
  if (!needle) return false;
  return [member.name, ...array(member.aliases)].some((candidate) => nameKey(candidate) === needle);
}

function inReferencePeriod(value: unknown, fromDate: string, toDate: string): boolean {
  if (!fromDate && !toDate) return true;
  const stamp = dateStamp(value);
  if (stamp === null) return false;
  const from = dateStamp(fromDate);
  const to = dateStamp(toDate);
  return (from === null || stamp >= from) && (to === null || stamp <= to);
}

function dailyCount(member: JsonRecord, fromDate: string, toDate: string): number {
  return array(member.daily).reduce<number>((sum, raw) => {
    const entry = record(raw);
    const count = Number(entry.count);
    return Number.isFinite(count) && count > 0 &&
      inReferencePeriod(entry.date, fromDate, toDate) ? sum + count : sum;
  }, 0);
}

function minuteAuthorMatches(work: JsonRecord, member: JsonRecord): boolean {
  if (hasValue(work._minutadoMemberId)) {
    return hasValue(member.id) && String(work._minutadoMemberId) === String(member.id);
  }
  return personMatches(work._minutadoBy || work.SERVIDOR, member);
}

export function buildAdvancedAnalytics(
  value: unknown,
  productivityFilters: ProductivityFilters = {},
): AdvancedAnalytics {
  const state = record(value);
  const details = record(state.sessionDetails);
  const sourceColumns = array(state.sourceColumns).map(text);
  const sessionNames = array(state.sessions).map(text).filter(Boolean);
  const activeNames = sessionNames.filter((name) => !record(record(details[name]).archive).saved);
  const activeSessions = activeNames
    .map((name) => {
      const meta = record(details[name]);
      const date = text(meta.date) || name;
      const rows = sessionProcessRows(state, name);
      const processes = rows.map((item, index) => asProcess(
        item.row, item.work, item.entry, sourceColumns, name, index,
      ));
      return {
        name,
        date,
        prepStart: text(meta.prepStart),
        minutasDeadline: text(meta.minutasDeadline),
        releaseDeadline: text(meta.releaseDeadline),
        gabinete: text(meta.gabinete),
        stats: summarizeProcesses(processes),
        processes,
        stamp: dateStamp(meta.date) ?? dateStamp(name) ?? Number.POSITIVE_INFINITY,
      };
    })
    .sort((left, right) => left.stamp - right.stamp || left.name.localeCompare(right.name, 'pt-BR'))
    .map(({ stamp: _stamp, ...session }) => session);

  const allSessionNames = sessionNames;
  const productivitySessionNames = productivityFilters.session
    ? allSessionNames.filter((name) => name === productivityFilters.session)
    : allSessionNames;
  const productivityProcesses = productivitySessionNames.flatMap((name) => sessionProcessRows(state, name).map((item, index) => ({
    process: asProcess(item.row, item.work, item.entry, sourceColumns, name, index),
    work: item.work,
  })));
  const fromDate = text(productivityFilters.fromDate);
  const toDate = text(productivityFilters.toDate);
  const team = record(state.team);
  const members = array(team.members).map(record);
  const pendingCompletions = array(team.pendingCompletions).map(record);
  const productivity = members
    .filter((member) => text(member.name))
    .map((member, index) => {
      const assigned = productivityProcesses.filter((item) => personMatches(item.process.responsible, member));
      const assignedCorrections = productivityProcesses.filter((item) => personMatches(item.process.corrector, member));
      const authoredMinutas = productivityProcesses.filter((item) =>
        minuteAuthorMatches(item.work, member) && hasValue(item.work.MINUTADO) &&
        inReferencePeriod(item.work.MINUTADO, fromDate, toDate),
      ).length;
      const assignedCompletedMinutas = assigned.filter((item) => hasValue(item.work.MINUTADO)).length;
      const allCompletedCorrections = assignedCorrections.filter((item) =>
        isCompletedFlag(item.work.CORRIGIDO) || isCompletedFlag(item.work.LIBERADO),
      ).length;
      const completedCorrections = assignedCorrections.filter((item) =>
        (isCompletedFlag(item.work.CORRIGIDO) && inReferencePeriod(item.work.CORRIGIDO, fromDate, toDate)) ||
        (isCompletedFlag(item.work.LIBERADO) && inReferencePeriod(item.work.LIBERADO, fromDate, toDate)),
      ).length;
      const manualMinutas = dailyCount(member, fromDate, toDate);
      const completedPendencies = pendingCompletions.filter((completion) =>
        ((member.id !== undefined && String(completion.memberId) === String(member.id)) ||
          (!hasValue(member.id) && nameKey(completion.memberName) === nameKey(member.name))) &&
        inReferencePeriod(completion.date || completion.at, fromDate, toDate),
      ).length;
      return {
        id: `${nameKey(member.name)}-${index}`,
        name: text(member.name).toLocaleUpperCase('pt-BR'),
        hierarchy: text(member.hierarchy || member.role || member.level || member.type) || 'Sem hierarquia',
        assignedMinutas: assigned.length,
        pendingMinutas: Math.max(0, assigned.length - assignedCompletedMinutas),
        completedMinutas: authoredMinutas,
        manualMinutas,
        assignedCorrections: assignedCorrections.length,
        pendingCorrections: Math.max(0, assignedCorrections.length - allCompletedCorrections),
        completedCorrections,
        completedPendencies,
        totalMinutas: authoredMinutas + manualMinutas,
      };
    })
    .sort((left, right) =>
      right.totalMinutas - left.totalMinutas ||
      right.completedCorrections - left.completedCorrections ||
      right.completedPendencies - left.completedPendencies ||
      left.name.localeCompare(right.name, 'pt-BR'),
    );

  const sessions = activeSessions;
  return {
    totalProcesses: sessions.reduce((total, session) => total + session.stats.total, 0),
    activeSessionCount: sessions.length,
    sessions,
    productivitySessions: allSessionNames,
    productivity,
  };
}

export function statusLabel(status: ProcessStatus): string {
  return STATUS_LABELS[status];
}

declare const __PAUTA_BUILD__: string;

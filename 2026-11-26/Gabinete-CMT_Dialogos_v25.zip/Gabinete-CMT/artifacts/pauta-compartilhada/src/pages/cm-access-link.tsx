import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Check, Copy, ExternalLink, LoaderCircle, ShieldCheck } from "lucide-react";

export default function CmAccessLinkPage() {
  const [link, setLink] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(true);
  const [copied, setCopied] = useState(false);

  const loadLink = useCallback(async () => {
    setBusy(true);
    setError("");
    setCopied(false);
    try {
      const base = import.meta.env.BASE_URL.replace(/\/$/, "");
      const response = await fetch(`${base}/api/auth/cm-access-link`, {
        credentials: "same-origin",
        cache: "no-store",
      });
      const result = await response.json().catch(() => ({})) as { path?: string; error?: string };
      if (!response.ok || !result.path?.startsWith("/cm#access=")) {
        throw new Error(result.error || "Não foi possível gerar o link do CM.");
      }
      setLink(`${window.location.origin}${result.path}`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível carregar o link.");
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => { void loadLink(); }, [loadLink]);

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
    } catch {
      setError("O navegador bloqueou a cópia automática. Selecione e copie o link manualmente.");
    }
  };

  return (
    <main className="min-h-screen bg-slate-100 px-4 py-10 text-slate-900">
      <div className="mx-auto max-w-2xl">
        <Button variant="ghost" className="mb-4" onClick={() => { window.location.assign("/gabinete"); }}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Voltar ao Gabinete
        </Button>
        <Card className="border-slate-200 shadow-lg">
          <CardHeader>
            <div className="mb-2 flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-900 text-white">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <CardTitle>Acesso exclusivo à Mesa do CM</CardTitle>
            <CardDescription>
              Gere o link de entrada do Desembargador sem criar uma conta individual. A Administração é a única que pode visualizar este link.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-lg border border-amber-300 bg-amber-50 p-4 text-sm leading-6 text-amber-950">
              Quem possuir o link poderá abrir a Mesa do CM e realizar as ações próprias dela, mas não terá acesso de Administração.
              Trate-o como uma credencial e não o envie em grupos ou canais públicos.
            </div>
            {busy ? (
              <div className="flex items-center gap-2 py-3 text-sm text-slate-600" role="status">
                <LoaderCircle className="h-4 w-4 animate-spin" /> Preparando o link seguro…
              </div>
            ) : error ? (
              <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-800" role="alert">{error}</div>
            ) : (
              <div className="space-y-2">
                <label htmlFor="cm-access-link" className="text-sm font-medium">Link secreto atual</label>
                <input
                  id="cm-access-link"
                  readOnly
                  value={link}
                  onFocus={(event) => event.currentTarget.select()}
                  className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 font-mono text-xs"
                />
                <div className="flex flex-wrap gap-2">
                  <Button onClick={() => void copyLink()}>
                    {copied ? <Check className="mr-2 h-4 w-4" /> : <Copy className="mr-2 h-4 w-4" />}
                    {copied ? "Copiado" : "Copiar link"}
                  </Button>
                  <Button variant="outline" onClick={() => window.open(link, "_blank", "noopener,noreferrer")}>
                    <ExternalLink className="mr-2 h-4 w-4" /> Abrir Mesa do CM
                  </Button>
                </div>
              </div>
            )}
            <div className="border-t pt-4 text-sm leading-6 text-slate-600">
              O link não expira no servidor e só muda quando você troca o segredo. Se o navegador remover a sessão,
              basta abrir novamente o mesmo link. Para revogar o link e as sessões CM, substitua
              <code className="mx-1 rounded bg-slate-100 px-1.5 py-0.5 text-xs">CM_ACCESS_LINK_SECRET</code>
              em Secrets. Um novo segredo gera um novo link.
            </div>
            {!busy && error && (
              <Button variant="outline" onClick={() => void loadLink()}>Tentar novamente</Button>
            )}
          </CardContent>
        </Card>
      </div>
    </main>
  );
}

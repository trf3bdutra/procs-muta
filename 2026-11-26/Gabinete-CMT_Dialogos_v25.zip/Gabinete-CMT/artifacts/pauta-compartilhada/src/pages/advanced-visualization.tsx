import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  getGetAcervoCentralQueryKey,
  useGetAcervoCentral,
  useGetPauta,
} from '@workspace/api-client-react';
import { useLocation } from 'wouter';
import { buildAdvancedAnalytics, type ProductivityFilters } from '@/lib/advanced-analytics';
import AdvancedVisualizationView from '@/pages/advanced-visualization-view';

export default function AdvancedVisualization() {
  const queryClient = useQueryClient();
  const pautaQuery = useGetPauta();
  const cmtQuery = useGetAcervoCentral(undefined, {
    query: {
      queryKey: getGetAcervoCentralQueryKey(),
      staleTime: 60_000,
      refetchInterval: 60_000,
      retry: 1,
      refetchOnWindowFocus: true,
    },
  });
  const cmtRefreshQuery = useGetAcervoCentral({ refresh: 'true' }, {
    query: {
      queryKey: getGetAcervoCentralQueryKey({ refresh: 'true' }),
      enabled: false,
      staleTime: 0,
      retry: 1,
      refetchOnWindowFocus: false,
    },
  });
  const [, setLocation] = useLocation();
  const [productivityFilters, setProductivityFilters] = useState<ProductivityFilters>({});
  const refetchRef = useRef(pautaQuery.refetch);
  refetchRef.current = pautaQuery.refetch;
  const refresh = useCallback(() => {
    void pautaQuery.refetch();
  }, [pautaQuery.refetch]);
  const goBack = useCallback(() => setLocation('/'), [setLocation]);
  const refreshCmt = useCallback(async () => {
    const result = await cmtRefreshQuery.refetch();
    if (result.data) {
      queryClient.setQueryData(getGetAcervoCentralQueryKey(), result.data);
    }
  }, [cmtRefreshQuery.refetch, queryClient]);
  const latestCmtError = cmtRefreshQuery.errorUpdatedAt > cmtQuery.dataUpdatedAt
    ? cmtRefreshQuery.error
    : cmtQuery.isError
      ? cmtQuery.error
      : null;
  const cmtError = latestCmtError
    ? latestCmtError instanceof Error
      ? latestCmtError.message
      : 'Não foi possível consultar as estatísticas do Acervo deste app.'
    : null;

  const revision = pautaQuery.data?.revision ?? 0;
  const hasSnapshot = Boolean(pautaQuery.data);
  const analytics = useMemo(
    () => buildAdvancedAnalytics(pautaQuery.data?.state, productivityFilters),
    [pautaQuery.data?.state, productivityFilters],
  );

  useEffect(() => {
    const previousTitle = document.title;
    document.title = 'Visualização avançada · Pauta de Julgamento';
    return () => { document.title = previousTitle; };
  }, []);

  useEffect(() => {
    if (!hasSnapshot) return;
    const base = new URL(import.meta.env.BASE_URL, window.location.origin);
    const eventsUrl = new URL('api/pauta/events', base);
    eventsUrl.searchParams.set('after', String(revision));
    const events = new EventSource(eventsUrl);
    let refreshTimer: ReturnType<typeof setTimeout> | undefined;
    events.onmessage = () => {
      if (refreshTimer) clearTimeout(refreshTimer);
      refreshTimer = setTimeout(() => {
        void refetchRef.current();
      }, 180);
    };
    return () => {
      if (refreshTimer) clearTimeout(refreshTimer);
      events.close();
    };
  }, [hasSnapshot]);

  return (
    <AdvancedVisualizationView
      data={analytics}
      isLoading={pautaQuery.isLoading}
      isFetching={pautaQuery.isFetching}
      error={pautaQuery.isError
        ? pautaQuery.error instanceof Error
          ? pautaQuery.error.message
          : 'Não foi possível carregar os dados compartilhados.'
        : null}
      cmtData={cmtQuery.data}
      cmtIsLoading={cmtQuery.isLoading}
      cmtIsFetching={cmtQuery.isFetching || cmtRefreshQuery.isFetching}
      cmtError={cmtError}
      onCmtRefresh={refreshCmt}
      onRefresh={refresh}
      onBack={goBack}
      productivityFilters={productivityFilters}
      onProductivityFiltersChange={setProductivityFilters}
    />
  );
}

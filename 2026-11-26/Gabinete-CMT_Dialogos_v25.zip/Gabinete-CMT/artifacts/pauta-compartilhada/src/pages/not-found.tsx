import { Card, CardContent } from '@/components/ui/card';
import { AlertCircle, ArrowLeft } from 'lucide-react';
import { Link } from 'wouter';

export default function NotFound() {
  return (
    <main className="flex min-h-screen w-full items-center justify-center bg-slate-50 px-4 py-8">
      <Card className="w-full max-w-md border-slate-200 shadow-sm">
        <CardContent className="pt-6">
          <div className="mb-4 flex items-center gap-3">
            <AlertCircle
              aria-hidden="true"
              className="h-8 w-8 shrink-0 text-rose-600"
            />
            <div>
              <p className="text-sm font-semibold uppercase tracking-wide text-slate-500">
                Erro 404
              </p>
              <h1 className="text-2xl font-bold text-slate-900">
                Página não encontrada
              </h1>
            </div>
          </div>

          <p className="mb-6 text-sm leading-6 text-slate-600">
            O endereço que você acessou não corresponde a uma página do
            Gabinete CMT. Confira o link ou volte para a pauta compartilhada.
          </p>

          <Link
            href="/"
            className="inline-flex min-h-10 items-center justify-center gap-2 rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-slate-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500 focus-visible:ring-offset-2"
          >
            <ArrowLeft aria-hidden="true" className="h-4 w-4" />
            Voltar para a pauta
          </Link>
        </CardContent>
      </Card>
    </main>
  );
}

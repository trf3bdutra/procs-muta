import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import type {
  AcervoCategoryCount,
  AcervoCentralStatistics,
} from '@workspace/api-client-react';
import { isAcervoStatisticsStale } from '../lib/acervo-staleness';
import {
  ArrowLeft,
  CalendarDays,
  ChevronDown,
  ChevronRight,
  Clock3,
  Download,
  FileText,
  Moon,
  Printer,
  RefreshCw,
  Sun,
  UsersRound,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type {
  AdvancedAnalytics,
  AdvancedProcess,
  AdvancedSession,
  ProcessStatus,
  ProductivityFilters,
  StaffProductivity,
} from '@/lib/advanced-analytics';

type AdvancedVisualizationViewProps = {
  data: AdvancedAnalytics;
  isLoading: boolean;
  isFetching: boolean;
  error: string | null;
  cmtData: AcervoCentralStatistics | undefined;
  cmtIsLoading: boolean;
  cmtIsFetching: boolean;
  cmtError: string | null;
  onCmtRefresh: () => void;
  onRefresh: () => void;
  onBack: () => void;
  productivityFilters: ProductivityFilters;
  onProductivityFiltersChange: (filters: ProductivityFilters) => void;
};

const CHART_COLORS = {
  blue: '#416d8c',
  teal: '#398d87',
  gold: '#b68b45',
  slate: '#71849a',
  red: '#b8645c',
};

const STATUS_SERIES: Array<{ key: keyof AdvancedSession['stats']; label: string; color: string }> = [
  { key: 'pending', label: 'Pendentes', color: CHART_COLORS.gold },
  { key: 'done', label: 'Minutados', color: CHART_COLORS.blue },
  { key: 'corrected', label: 'Corrigidos', color: CHART_COLORS.teal },
  { key: 'released', label: 'Liberados', color: CHART_COLORS.slate },
  { key: 'postponed', label: 'Adiados', color: CHART_COLORS.red },
  { key: 'withdrawn', label: 'Retirados', color: '#927b9a' },
  { key: 'judged', label: 'Julgados', color: '#72926c' },
];

const REFRESH_INTERVALS = [
  { label: '5 minutos', value: 5 * 60 * 1000 },
  { label: '15 minutos', value: 15 * 60 * 1000 },
  { label: '1 hora', value: 60 * 60 * 1000 },
  { label: '24 horas', value: 24 * 60 * 60 * 1000 },
];

const numberFormat = new Intl.NumberFormat('pt-BR');

function escapeCsv(value: unknown): string {
  const text = String(value ?? '');
  return `"${text.replaceAll('"', '""')}"`;
}

function downloadCsv(filename: string, headers: string[], rows: unknown[][]) {
  const content = [headers, ...rows].map((row) => row.map(escapeCsv).join(';')).join('\r\n');
  const blob = new Blob(['\uFEFF', content], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function formatNumber(value: number) {
  return numberFormat.format(value);
}

function Kpi({
  label,
  value,
  detail,
  loading,
}: {
  label: string;
  value: number;
  detail: string;
  loading: boolean;
}) {
  return (
    <Card className="border-card-border shadow-none">
      <CardContent className="p-4 sm:p-5">
        <p className="text-sm text-muted-foreground">{label}</p>
        <p className="mt-1 font-mono text-[26px] font-semibold tracking-tight text-primary">
          {loading ? '—' : formatNumber(value)}
        </p>
        <p className="mt-1 text-xs text-muted-foreground">{detail}</p>
      </CardContent>
    </Card>
  );
}

function AcervoBreakdown({
  title,
  items,
}: {
  title: string;
  items: AcervoCategoryCount[];
}) {
  return (
    <div>
      <h3 className="text-xs font-semibold text-foreground">{title}</h3>
      {items.length ? (
        <ul className="mt-2 max-h-56 space-y-1.5 overflow-y-auto pr-1">
          {items.map((item) => (
            <li key={item.category} className="flex items-start justify-between gap-3 text-xs">
              <span className="min-w-0 break-words text-muted-foreground">{item.category}</span>
              <span className="shrink-0 font-mono font-medium tabular-nums">{formatNumber(item.count)}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="mt-2 text-xs text-muted-foreground">Nenhuma categoria informada pela fonte.</p>
      )}
    </div>
  );
}

function formatAcervoDate(value: Date | string) {
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime())
    ? 'Data não informada pela fonte'
    : new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short' }).format(date);
}

function ChartExportButton({
  label,
  onClick,
}: {
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={`Baixar CSV: ${label}`}
      title={`Baixar CSV: ${label}`}
      className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-background px-2.5 text-xs font-medium text-muted-foreground transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring print:hidden"
    >
      <Download className="h-3.5 w-3.5" aria-hidden="true" />
      <span>CSV</span>
    </button>
  );
}

function SessionProcessRow({
  process,
  expanded,
  onToggle,
}: {
  process: AdvancedProcess;
  expanded: boolean;
  onToggle: () => void;
}) {
  return (
    <div className="border-t border-border/70 first:border-t-0">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={expanded}
        aria-label={`${expanded ? 'Recolher' : 'Expandir'} detalhes do processo ${process.processNumber}`}
        className="grid min-h-12 w-full grid-cols-[20px_minmax(100px,1.25fr)_minmax(90px,0.8fr)_minmax(100px,1fr)_auto] items-center gap-2 px-3 text-left transition-colors hover:bg-muted/55 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring sm:grid-cols-[22px_minmax(150px,1.2fr)_minmax(110px,0.8fr)_minmax(140px,1fr)_auto] sm:gap-3 sm:px-4"
      >
        {expanded ? (
          <ChevronDown className="h-4 w-4 text-primary" aria-hidden="true" />
        ) : (
          <ChevronRight className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
        )}
        <span className="truncate font-mono text-[13px] font-semibold text-foreground" title={process.processNumber}>
          {process.processNumber}
        </span>
        <span className="truncate text-xs text-muted-foreground sm:text-sm" title={process.item}>
          {process.item || 'Sem item informado'}
        </span>
        <span className="truncate text-xs text-muted-foreground sm:text-sm" title={process.responsible}>
          {process.responsible}
        </span>
        <span className={`whitespace-nowrap rounded-full px-2 py-1 text-[11px] font-semibold ${statusClass(process.status)}`}>
          {process.statusLabel}
        </span>
      </button>
      {expanded && (
        <dl className="grid grid-cols-1 gap-x-5 gap-y-3 bg-muted/35 px-5 py-4 pl-10 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Responsável" value={process.responsible} />
          <Field label="Corretor" value={process.corrector} />
          {process.fields.map((field, index) => (
            <Field key={`${process.id}-${field.label}-${index}`} label={field.label} value={field.value} />
          ))}
          {process.fields.length === 0 && (
            <p className="col-span-full text-sm text-muted-foreground">Não há outros campos informados para este processo.</p>
          )}
        </dl>
      )}
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <dt className="mb-0.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</dt>
      <dd className="break-words text-sm text-foreground">{value || '—'}</dd>
    </div>
  );
}

function statusClass(status: ProcessStatus): string {
  switch (status) {
    case 'pendente':
      return 'bg-amber-100 text-amber-900 dark:bg-amber-950/70 dark:text-amber-200';
    case 'feito':
      return 'bg-sky-100 text-sky-900 dark:bg-sky-950/70 dark:text-sky-200';
    case 'corrigido':
    case 'liberado':
      return 'bg-teal-100 text-teal-900 dark:bg-teal-950/70 dark:text-teal-200';
    case 'adiado':
      return 'bg-orange-100 text-orange-900 dark:bg-orange-950/70 dark:text-orange-200';
    case 'retirado':
      return 'bg-slate-200 text-slate-800 dark:bg-slate-800 dark:text-slate-200';
    case 'julgado':
      return 'bg-emerald-100 text-emerald-900 dark:bg-emerald-950/70 dark:text-emerald-200';
  }
}

function SessionCard({
  session,
  expandedProcessId,
  onExpand,
}: {
  session: AdvancedSession;
  expandedProcessId: string | null;
  onExpand: (id: string) => void;
}) {
  return (
    <Card className="overflow-hidden border-card-border shadow-none">
      <CardHeader className="gap-4 border-b border-border/70 bg-muted/20 px-4 py-4 sm:px-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <CardTitle className="text-base">{session.name}</CardTitle>
              <span className="rounded-full border border-border bg-background px-2 py-0.5 font-mono text-[11px] text-muted-foreground">
                {formatNumber(session.stats.total)} processos
              </span>
            </div>
            <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5"><CalendarDays className="h-3.5 w-3.5" />{session.date || 'Data não informada'}</span>
              {session.gabinete && <span className="inline-flex items-center gap-1.5"><UsersRound className="h-3.5 w-3.5" />{session.gabinete}</span>}
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 xl:grid-cols-7">
          {[
            ['Pendentes', session.stats.pending],
            ['Minutados', session.stats.done],
            ['Corrigidos', session.stats.corrected],
            ['Liberados', session.stats.released],
            ['Adiados', session.stats.postponed],
            ['Retirados', session.stats.withdrawn],
            ['Julgados', session.stats.judged],
          ].map(([label, value]) => (
            <div key={label} className="rounded-md border border-border/70 bg-card px-2.5 py-2">
              <p className="text-[11px] text-muted-foreground">{label}</p>
              <p className="mt-0.5 font-mono text-sm font-semibold">{formatNumber(Number(value))}</p>
            </div>
          ))}
        </div>
        <div className="flex flex-wrap gap-x-5 gap-y-2 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1.5"><Clock3 className="h-3.5 w-3.5" />Início da preparação: {session.prepStart || '—'}</span>
          <span>Prazo das minutas: {session.minutasDeadline || '—'}</span>
          <span>Prazo de liberação: {session.releaseDeadline || '—'}</span>
        </div>
      </CardHeader>
      <div className="border-b border-border/70 bg-muted/45 px-3 py-2 sm:px-4">
        <div className="grid grid-cols-[20px_minmax(100px,1.25fr)_minmax(90px,0.8fr)_minmax(100px,1fr)_auto] gap-2 text-[10px] font-semibold uppercase tracking-[0.08em] text-muted-foreground sm:grid-cols-[22px_minmax(150px,1.2fr)_minmax(110px,0.8fr)_minmax(140px,1fr)_auto] sm:gap-3">
          <span aria-hidden="true" />
          <span>Processo</span>
          <span>Item</span>
          <span>Responsável</span>
          <span>Situação</span>
        </div>
      </div>
      {session.processes.length > 0 ? (
        <div>
          {session.processes.map((process) => (
            <SessionProcessRow
              key={process.id}
              process={process}
              expanded={expandedProcessId === process.id}
              onToggle={() => onExpand(process.id)}
            />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center px-5 py-9 text-center">
          <FileText className="mb-2 h-6 w-6 text-muted-foreground/70" aria-hidden="true" />
          <p className="text-sm font-medium">Esta sessão ainda não tem processos relacionados.</p>
          <p className="mt-1 text-xs text-muted-foreground">Quando houver processos vinculados, eles aparecerão nesta lista.</p>
        </div>
      )}
    </Card>
  );
}

function ProductivityTable({ rows }: { rows: StaffProductivity[] }) {
  if (!rows.length) {
    return (
      <div className="flex flex-col items-center px-5 py-12 text-center">
        <UsersRound className="mb-3 h-7 w-7 text-muted-foreground/70" aria-hidden="true" />
        <h3 className="text-sm font-semibold">Nenhum servidor cadastrado para exibição</h3>
        <p className="mt-1 max-w-md text-sm text-muted-foreground">A produtividade será apresentada aqui para todos os integrantes registrados, inclusive assessoria.</p>
      </div>
    );
  }
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[900px] border-collapse text-left">
        <thead>
          <tr className="border-b border-border bg-muted/40 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
            <th scope="col" className="px-4 py-3">Servidor / hierarquia</th>
            <th scope="col" className="px-3 py-3 text-right">Minutas atribuídas</th>
            <th scope="col" className="px-3 py-3 text-right">Pendentes</th>
            <th scope="col" className="px-3 py-3 text-right">Concluídas</th>
            <th scope="col" className="px-3 py-3 text-right">Manuais</th>
            <th scope="col" className="px-3 py-3 text-right">Correções atribuídas</th>
            <th scope="col" className="px-3 py-3 text-right">Correções pendentes</th>
            <th scope="col" className="px-3 py-3 text-right">Correções concluídas</th>
            <th scope="col" className="px-4 py-3 text-right">Pendências concluídas</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((person) => (
            <tr key={person.id} className="border-b border-border/60 last:border-0 hover:bg-muted/25">
              <th scope="row" className="px-4 py-3 text-left font-medium">
                <div className="text-sm text-foreground">{person.name}</div>
                <div className="mt-0.5 text-xs font-normal text-muted-foreground">{person.hierarchy}</div>
              </th>
              <NumericCell value={person.assignedMinutas} />
              <NumericCell value={person.pendingMinutas} />
              <NumericCell value={person.completedMinutas} />
              <NumericCell value={person.manualMinutas} />
              <NumericCell value={person.assignedCorrections} />
              <NumericCell value={person.pendingCorrections} />
              <NumericCell value={person.completedCorrections} />
              <NumericCell value={person.completedPendencies} end />
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function NumericCell({ value, end = false }: { value: number; end?: boolean }) {
  return (
    <td className={`px-3 py-3 text-right font-mono text-sm ${end ? 'pr-4' : ''}`}>
      {formatNumber(value)}
    </td>
  );
}

export function AdvancedVisualizationView({
  data,
  isLoading,
  isFetching,
  error,
  cmtData,
  cmtIsLoading,
  cmtIsFetching,
  cmtError,
  onCmtRefresh,
  onRefresh,
  onBack,
  productivityFilters,
  onProductivityFiltersChange,
}: AdvancedVisualizationViewProps) {
  const [isDark, setIsDark] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [intervalMs, setIntervalMs] = useState(REFRESH_INTERVALS[0].value);
  const [refreshMenuOpen, setRefreshMenuOpen] = useState(false);
  const [isSpinning, setIsSpinning] = useState(false);
  const [expandedProcessId, setExpandedProcessId] = useState<string | null>(null);
  const refreshMenuRef = useRef<HTMLDivElement>(null);
  const loading = isLoading || isFetching;
  const cmtLoading = cmtIsLoading && !cmtData;
  const cmtDataIsStale = cmtData
    ? isAcervoStatisticsStale(cmtData.sourceUpdatedAt)
    : false;
  const cmtStatusLabel = cmtLoading
    ? 'Consultando'
    : cmtError
      ? (cmtData ? 'Falha ao atualizar' : 'Indisponível')
      : cmtDataIsStale
        ? 'Dados desatualizados'
      : cmtIsFetching
        ? 'Atualizando'
        : cmtData
          ? 'Conectado'
          : 'Indisponível';
  const cmtStatusColor = cmtError || cmtDataIsStale
    ? 'bg-amber-600'
    : cmtLoading || (cmtIsFetching && !cmtData)
      ? 'bg-blue-600'
      : cmtData
        ? 'bg-emerald-600'
        : 'bg-amber-600';

  const sessionChartData = useMemo(
    () => data.sessions.map((session) => ({
      sessao: session.name,
      ...Object.fromEntries(STATUS_SERIES.map(({ key }) => [key, session.stats[key]])),
    })),
    [data.sessions],
  );
  const productivityChartData = useMemo(
    () => data.productivity.map((staff) => ({
      servidor: staff.name,
      hierarquia: staff.hierarchy,
      minutasConcluidas: staff.completedMinutas,
      minutasManuais: staff.manualMinutas,
      correcoesConcluidas: staff.completedCorrections,
      totalMinutas: staff.totalMinutas,
    })),
    [data.productivity],
  );

  useEffect(() => {
    if (loading) {
      setIsSpinning(true);
      return;
    }
    const timeout = window.setTimeout(() => setIsSpinning(false), 600);
    return () => window.clearTimeout(timeout);
  }, [loading]);

  useEffect(() => {
    if (!autoRefresh) return;
    const timer = window.setInterval(onRefresh, intervalMs);
    return () => window.clearInterval(timer);
  }, [autoRefresh, intervalMs, onRefresh]);

  useEffect(() => {
    function dismissMenu(event: MouseEvent) {
      if (refreshMenuRef.current && !refreshMenuRef.current.contains(event.target as Node)) {
        setRefreshMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', dismissMenu);
    return () => document.removeEventListener('mousedown', dismissMenu);
  }, []);

  const chartGridColor = isDark ? 'rgba(255,255,255,0.09)' : '#dce4e9';
  const chartTickColor = isDark ? '#b8c3cb' : '#607283';
  const chartTooltipStyle = {
    backgroundColor: isDark ? '#23323e' : '#fffefa',
    border: `1px solid ${isDark ? '#465866' : '#d5dfe5'}`,
    borderRadius: 7,
    color: isDark ? '#eef3f6' : '#253644',
    fontSize: 12,
  };

  function exportSessionChart() {
    downloadCsv(
      'situacao-das-sessoes.csv',
      ['Sessão', ...STATUS_SERIES.map((item) => item.label), 'Total'],
      data.sessions.map((session) => [
        session.name,
        ...STATUS_SERIES.map(({ key }) => session.stats[key]),
        session.stats.total,
      ]),
    );
  }

  function exportProductivityChart() {
    downloadCsv(
      'produtividade-da-equipe.csv',
      ['Servidor', 'Hierarquia', 'Minutas concluídas', 'Minutas manuais', 'Correções concluídas', 'Total de minutas'],
      data.productivity.map((staff) => [
        staff.name,
        staff.hierarchy,
        staff.completedMinutas,
        staff.manualMinutas,
        staff.completedCorrections,
        staff.totalMinutas,
      ]),
    );
  }

  return (
    <div className={isDark ? 'dark' : ''}>
      <main className="min-h-[100dvh] bg-background px-4 py-5 text-foreground transition-colors sm:px-6 lg:px-8">
        <div className="mx-auto max-w-[1480px]">
          <header className="mb-6 flex flex-wrap items-start justify-between gap-4 border-b border-border/70 pb-5">
            <div className="flex min-w-0 items-start gap-3">
              <button
                type="button"
                onClick={onBack}
                aria-label="Voltar à Pauta de Julgamento"
                className="mt-1 inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-md border border-border bg-card text-muted-foreground transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring print:hidden"
              >
                <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              </button>
              <div>
                <p className="mb-1 text-[11px] font-semibold uppercase tracking-[0.16em] text-primary">Pauta de Julgamento · visão operacional</p>
                <h1 className="text-2xl font-semibold tracking-tight sm:text-[30px]">Visualização avançada</h1>
                <p className="mt-1.5 max-w-2xl text-sm text-muted-foreground">Acompanhamento compartilhado de sessões, tramitação e produção da equipe.</p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2 print:hidden">
              <div className="relative" ref={refreshMenuRef}>
                <div className="flex h-9 items-center overflow-hidden rounded-md border border-border bg-card text-sm text-foreground">
                  <button
                    type="button"
                    onClick={onRefresh}
                    disabled={loading}
                    className="inline-flex h-full items-center gap-2 px-3 transition-colors hover:bg-muted disabled:opacity-50"
                    aria-label="Atualizar dados da pauta"
                  >
                    <RefreshCw className={`h-3.5 w-3.5 ${isSpinning ? 'animate-spin' : ''}`} aria-hidden="true" />
                    <span>Atualizar</span>
                  </button>
                  <span className="h-5 w-px bg-border" aria-hidden="true" />
                  <button
                    type="button"
                    onClick={() => setRefreshMenuOpen((open) => !open)}
                    aria-label="Opções de atualização automática"
                    aria-expanded={refreshMenuOpen}
                    className="inline-flex h-full items-center px-2.5 text-muted-foreground transition-colors hover:bg-muted"
                  >
                    <ChevronDown className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>
                {refreshMenuOpen && (
                  <div className="absolute right-0 z-20 mt-2 w-60 rounded-lg border border-border bg-popover p-2 text-popover-foreground shadow-lg">
                    <button
                      type="button"
                      role="switch"
                      aria-checked={autoRefresh}
                      onClick={() => setAutoRefresh((enabled) => !enabled)}
                      className="flex w-full items-center justify-between rounded-md px-2.5 py-2 text-left text-sm hover:bg-muted"
                    >
                      <span>Atualização automática</span>
                      <span className={`rounded-full px-2 py-0.5 text-xs ${autoRefresh ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
                        {autoRefresh ? 'Ligada' : 'Desligada'}
                      </span>
                    </button>
                    <div className="my-1 border-t border-border" />
                    <p className="px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Intervalo mínimo de 5 min</p>
                    {REFRESH_INTERVALS.map((option) => (
                      <button
                        key={option.value}
                        type="button"
                        onClick={() => setIntervalMs(option.value)}
                        className="flex w-full items-center justify-between rounded-md px-2.5 py-2 text-sm hover:bg-muted"
                      >
                        <span>{option.label}</span>
                        {intervalMs === option.value && <span className="text-primary" aria-label="Selecionado">✓</span>}
                      </button>
                    ))}
                    <p className="px-2.5 pb-1 pt-2 text-[11px] leading-relaxed text-muted-foreground">A pauta e as estatísticas do Acervo deste app são atualizadas a partir dos dados locais.</p>
                  </div>
                )}
              </div>
              <button
                type="button"
                onClick={() => window.print()}
                disabled={loading}
                aria-label="Imprimir ou salvar como PDF"
                title="Imprimir ou salvar como PDF"
                className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-border bg-card text-muted-foreground transition-colors hover:bg-muted disabled:opacity-50"
              >
                <Printer className="h-4 w-4" aria-hidden="true" />
              </button>
              <button
                type="button"
                onClick={() => setIsDark((value) => !value)}
                aria-label={isDark ? 'Ativar tema claro' : 'Ativar tema escuro'}
                title={isDark ? 'Ativar tema claro' : 'Ativar tema escuro'}
                className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-border bg-card text-muted-foreground transition-colors hover:bg-muted"
              >
                {isDark ? <Sun className="h-4 w-4" aria-hidden="true" /> : <Moon className="h-4 w-4" aria-hidden="true" />}
              </button>
            </div>
          </header>

          {error && (
            <section role="alert" className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3">
              <div>
                <p className="text-sm font-semibold text-destructive">Não foi possível atualizar os dados</p>
                <p className="mt-0.5 text-sm text-muted-foreground">{error}</p>
              </div>
              <button type="button" onClick={onRefresh} className="rounded-md border border-border bg-card px-3 py-2 text-sm font-medium hover:bg-muted">Tentar novamente</button>
            </section>
          )}

          <section aria-labelledby="acervo-title" className="mb-5">
            <Card className="overflow-hidden border-card-border shadow-none">
              <div className="grid md:grid-cols-[minmax(220px,0.8fr)_minmax(0,2fr)]">
                <div className="border-b border-border bg-primary/[0.055] p-5 md:border-b-0 md:border-r">
                  <div className="flex items-center gap-2">
                    <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-primary/10 text-primary"><FileText className="h-4 w-4" aria-hidden="true" /></span>
                    <div>
                      <p className="text-[10px] font-semibold uppercase tracking-[0.15em] text-muted-foreground">ACERVO DO APP</p>
                      <h2 id="acervo-title" className="text-sm font-semibold">Acervo do Gabinete</h2>
                    </div>
                  </div>
                  <div className="mt-5 flex items-center gap-2">
                    <span className={`h-2 w-2 rounded-full ${cmtStatusColor}`} aria-hidden="true" />
                    <span className="text-sm font-semibold">{cmtStatusLabel}</span>
                  </div>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    {cmtError
                      ? cmtError
                      : 'Fonte: banco de dados deste app. As estatísticas são calculadas no servidor; os registros individuais não são enviados ao navegador.'}
                  </p>
                </div>
                <div className="flex min-h-[140px] flex-col p-5">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">Estatísticas do acervo</p>
                    <button
                      type="button"
                      onClick={onCmtRefresh}
                      disabled={cmtIsFetching}
                      className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-background px-2.5 text-xs font-medium text-muted-foreground transition-colors hover:bg-muted disabled:cursor-wait disabled:opacity-50 print:hidden"
                      aria-label="Atualizar estatísticas do Acervo"
                    >
                      <RefreshCw className={`h-3.5 w-3.5 ${cmtIsFetching ? 'animate-spin' : ''}`} aria-hidden="true" />
                      <span>{cmtIsFetching ? 'Atualizando' : 'Atualizar'}</span>
                    </button>
                  </div>
                  {cmtLoading ? null : cmtData ? (
                    <div className="mt-4">
                      <div className="flex flex-wrap items-end justify-between gap-x-5 gap-y-2">
                        <div>
                          <p className="text-xs text-muted-foreground">Processos no acervo</p>
                          <p className="font-mono text-[26px] font-semibold tracking-tight text-primary">{formatNumber(cmtData.total)}</p>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Consulta local realizada em {formatAcervoDate(cmtData.sourceUpdatedAt)}
                        </p>
                      </div>
                      <div className="mt-4 grid gap-5 border-t border-border pt-4 sm:grid-cols-2">
                        <AcervoBreakdown title="Por classe" items={cmtData.byClass} />
                        <AcervoBreakdown title="Por seção competente" items={cmtData.bySection} />
                      </div>
                      {cmtError && (
                        <p role="status" className="mt-3 text-xs text-amber-700 dark:text-amber-400">
                          A atualização mais recente falhou. Os números acima são da última resposta válida da fonte.
                        </p>
                      )}
                      {cmtDataIsStale && (
                        <p role="status" className="mt-3 rounded-md border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-sm text-amber-800 dark:text-amber-300">
                          Acervo desatualizado: a data da fonte ultrapassa o limite de 7 dias. Os totais e a data acima são os valores informados pela fonte; não foram estimados.
                        </p>
                      )}
                    </div>
                  ) : cmtError ? (
                    <div role="alert" className="mt-4 rounded-md border border-destructive/30 bg-destructive/5 p-3">
                      <p className="text-sm text-destructive">{cmtError}</p>
                      <p className="mt-1 text-xs text-muted-foreground">Nenhum valor foi estimado ou substituído por dados de demonstração.</p>
                      <button
                        type="button"
                        onClick={onCmtRefresh}
                        disabled={cmtIsFetching}
                        className="mt-3 rounded-md border border-border bg-card px-3 py-1.5 text-xs font-medium hover:bg-muted disabled:opacity-50"
                      >
                        Tentar novamente
                      </button>
                    </div>
                  ) : (
                    <p className="mt-4 text-sm text-muted-foreground">Não há estatísticas do Acervo deste app disponíveis para exibir.</p>
                  )}
                </div>
              </div>
            </Card>
          </section>

          <section aria-label="Resumo das pautas" className="mb-5 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <Kpi label="Processos em pauta" value={data.totalProcesses} detail="Total nas sessões ativas" loading={loading} />
            <Kpi label="Sessões ativas" value={data.activeSessionCount} detail="Sessões em acompanhamento" loading={loading} />
            <Kpi label="Servidores registrados" value={data.productivity.length} detail="Inclui toda a equipe cadastrada" loading={loading} />
            <Kpi label="Processos pendentes" value={data.sessions.reduce((sum, session) => sum + session.stats.pending, 0)} detail="Somatório das sessões ativas" loading={loading} />
          </section>

          <section aria-label="Indicadores das sessões" className="mb-5 grid grid-cols-1 gap-4 xl:grid-cols-2">
            <Card className="border-card-border shadow-none">
              <CardHeader className="flex-row items-center justify-between gap-3 space-y-0 px-4 pb-2 pt-4 sm:px-5">
                <div>
                  <CardTitle className="text-base">Situação dos processos por sessão</CardTitle>
                  <p className="mt-1 text-xs text-muted-foreground">Distribuição dos estados registrados em cada pauta ativa.</p>
                </div>
                {!loading && sessionChartData.length > 0 && <ChartExportButton label="situação dos processos por sessão" onClick={exportSessionChart} />}
              </CardHeader>
              <CardContent className="px-2 pb-4 pt-3 sm:px-4">
                {loading ? null : sessionChartData.length ? (
                  <>
                    <div className="h-[300px] min-w-0" role="img" aria-label="Gráfico de barras empilhadas com a quantidade de processos por situação em cada sessão">
                      <ResponsiveContainer width="100%" height="100%" debounce={0}>
                        <BarChart data={sessionChartData} margin={{ top: 8, right: 12, left: -18, bottom: 36 }}>
                          <CartesianGrid stroke={chartGridColor} strokeDasharray="3 3" vertical={false} />
                          <XAxis dataKey="sessao" tick={{ fontSize: 11, fill: chartTickColor }} stroke={chartTickColor} angle={-24} textAnchor="end" interval={0} height={55} />
                          <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: chartTickColor }} stroke={chartTickColor} />
                          <Tooltip contentStyle={chartTooltipStyle} cursor={{ fill: 'rgba(80,100,115,0.08)', stroke: 'none' }} formatter={(value: number, name: string) => [formatNumber(value), name]} />
                          {STATUS_SERIES.map((item) => (
                            <Bar key={item.key} dataKey={item.key} name={item.label} stackId="situacao" fill={item.color} isAnimationActive={false} />
                          ))}
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="mt-1 flex flex-wrap gap-x-4 gap-y-2 px-2">
                      {STATUS_SERIES.map((item) => (
                        <span key={item.key} className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground">
                          <span className="h-2 w-2 rounded-sm" style={{ backgroundColor: item.color }} aria-hidden="true" />{item.label}
                        </span>
                      ))}
                    </div>
                  </>
                ) : <EmptyChart text="Não há sessões ativas para comparar." />}
              </CardContent>
            </Card>
            <Card className="border-card-border shadow-none">
              <CardHeader className="flex-row items-center justify-between gap-3 space-y-0 px-4 pb-2 pt-4 sm:px-5">
                <div>
                  <CardTitle className="text-base">Produção registrada por servidor</CardTitle>
                <p className="mt-1 text-xs text-muted-foreground">Minutas concluídas e manuais no período selecionado, para toda a equipe.</p>
                </div>
                {!loading && productivityChartData.length > 0 && <ChartExportButton label="produção registrada por servidor" onClick={exportProductivityChart} />}
              </CardHeader>
              <CardContent className="px-2 pb-4 pt-3 sm:px-4">
                {loading ? null : productivityChartData.length ? (
                  <>
                    <div
                      className="min-w-0"
                      style={{ height: Math.max(280, Math.min(760, productivityChartData.length * 38)) }}
                      role="img"
                      aria-label={`Gráfico horizontal de produção de ${productivityChartData.length} servidores cadastrados`}
                    >
                      <ResponsiveContainer width="100%" height="100%" debounce={0}>
                        <BarChart data={productivityChartData} layout="vertical" margin={{ top: 6, right: 16, left: 8, bottom: 4 }}>
                          <CartesianGrid stroke={chartGridColor} strokeDasharray="3 3" horizontal={false} />
                          <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11, fill: chartTickColor }} stroke={chartTickColor} />
                          <YAxis type="category" dataKey="servidor" width={112} tick={{ fontSize: 10, fill: chartTickColor }} stroke={chartTickColor} />
                          <Tooltip contentStyle={chartTooltipStyle} cursor={{ fill: 'rgba(80,100,115,0.08)', stroke: 'none' }} formatter={(value: number, name: string) => [formatNumber(value), name]} />
                          <Bar dataKey="minutasConcluidas" name="Minutas concluídas" stackId="minutas" fill={CHART_COLORS.blue} isAnimationActive={false} />
                          <Bar dataKey="minutasManuais" name="Minutas manuais" stackId="minutas" fill={CHART_COLORS.teal} isAnimationActive={false} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="mt-1 flex flex-wrap gap-4 px-2">
                      <span className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground"><span className="h-2 w-2 rounded-sm" style={{ backgroundColor: CHART_COLORS.blue }} aria-hidden="true" />Minutas concluídas</span>
                      <span className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground"><span className="h-2 w-2 rounded-sm" style={{ backgroundColor: CHART_COLORS.teal }} aria-hidden="true" />Minutas manuais</span>
                    </div>
                  </>
                ) : <EmptyChart text="Não há registros de produtividade da equipe." />}
              </CardContent>
            </Card>
          </section>

          <section aria-labelledby="sessions-heading" className="mb-5">
            <div className="mb-3 flex flex-wrap items-end justify-between gap-2">
              <div>
                <h2 id="sessions-heading" className="text-lg font-semibold tracking-tight">Sessões ativas</h2>
                <p className="mt-1 text-sm text-muted-foreground">Cada processo permanece em uma linha compacta. Selecione uma linha para consultar todos os campos recebidos.</p>
              </div>
              <span className="font-mono text-xs text-muted-foreground">{formatNumber(data.activeSessionCount)} sessões · {formatNumber(data.totalProcesses)} processos</span>
            </div>
            {loading ? null : data.sessions.length ? (
              <div className="space-y-3">
                {data.sessions.map((session) => (
                  <SessionCard
                    key={`${session.name}-${session.date}`}
                    session={session}
                    expandedProcessId={expandedProcessId}
                    onExpand={(id) => setExpandedProcessId((current) => current === id ? null : id)}
                  />
                ))}
              </div>
            ) : (
              <Card className="border-card-border shadow-none">
                <CardContent className="flex flex-col items-center px-5 py-12 text-center">
                  <CalendarDays className="mb-3 h-7 w-7 text-muted-foreground/70" aria-hidden="true" />
                  <h3 className="text-sm font-semibold">Nenhuma sessão ativa</h3>
                  <p className="mt-1 max-w-md text-sm text-muted-foreground">Quando uma pauta estiver ativa, suas estatísticas e processos aparecerão aqui.</p>
                </CardContent>
              </Card>
            )}
          </section>

          <section aria-labelledby="productivity-heading" className="pb-8">
            <div className="mb-3 flex flex-wrap items-end justify-between gap-2">
              <div>
                <h2 id="productivity-heading" className="text-lg font-semibold tracking-tight">Produtividade da equipe</h2>
                <p className="mt-1 text-sm text-muted-foreground">Totais por servidor, incluindo assessoria, com filtros de sessão e período.</p>
              </div>
              {!loading && data.productivity.length > 0 && (
                <button
                  type="button"
                  onClick={() => downloadCsv(
                    'produtividade-completa-da-equipe.csv',
                     ['Servidor', 'Hierarquia', 'Minutas atribuídas', 'Minutas pendentes', 'Minutas concluídas', 'Minutas manuais', 'Correções atribuídas', 'Correções pendentes', 'Correções concluídas', 'Pendências concluídas', 'Total de minutas'],
                    data.productivity.map((row) => [
                      row.name, row.hierarchy, row.assignedMinutas, row.pendingMinutas, row.completedMinutas,
                       row.manualMinutas, row.assignedCorrections, row.pendingCorrections, row.completedCorrections,
                       row.completedPendencies, row.totalMinutas,
                    ]),
                  )}
                  className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-card px-2.5 text-xs font-medium text-muted-foreground transition-colors hover:bg-muted print:hidden"
                  aria-label="Baixar produtividade completa em CSV"
                >
                  <Download className="h-3.5 w-3.5" aria-hidden="true" />Exportar tabela CSV
                </button>
              )}
            </div>
            <div className="mb-3 rounded-lg border border-border/70 bg-muted/20 p-3">
              <div className="flex flex-wrap items-end gap-3">
                <label className="grid gap-1 text-xs font-medium text-muted-foreground" htmlFor="productivity-session">
                  Sessão
                  <select
                    id="productivity-session"
                    value={productivityFilters.session || ''}
                    onChange={(event) => onProductivityFiltersChange({
                      ...productivityFilters,
                      session: event.target.value || undefined,
                    })}
                    className="h-9 min-w-[190px] rounded-md border border-input bg-background px-3 text-sm font-normal text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <option value="">Todas as sessões registradas</option>
                    {data.productivitySessions.map((session) => (
                      <option key={session} value={session}>{session}</option>
                    ))}
                  </select>
                </label>
                <label className="grid gap-1 text-xs font-medium text-muted-foreground" htmlFor="productivity-from">
                  De
                  <input
                    id="productivity-from"
                    type="date"
                    value={productivityFilters.fromDate || ''}
                    onChange={(event) => onProductivityFiltersChange({
                      ...productivityFilters,
                      fromDate: event.target.value || undefined,
                    })}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm font-normal text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  />
                </label>
                <label className="grid gap-1 text-xs font-medium text-muted-foreground" htmlFor="productivity-to">
                  Até
                  <input
                    id="productivity-to"
                    type="date"
                    value={productivityFilters.toDate || ''}
                    onChange={(event) => onProductivityFiltersChange({
                      ...productivityFilters,
                      toDate: event.target.value || undefined,
                    })}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm font-normal text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  />
                </label>
                {(productivityFilters.session || productivityFilters.fromDate || productivityFilters.toDate) && (
                  <button
                    type="button"
                    onClick={() => onProductivityFiltersChange({})}
                    className="h-9 rounded-md border border-border bg-card px-3 text-xs font-medium text-muted-foreground hover:bg-muted"
                  >
                    Limpar filtros
                  </button>
                )}
              </div>
              <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                A sessão limita as atribuições. O período limita minutas pela data registrada em MINUTADO, correções com data explícita, minutas manuais e conclusões de pendências. Atribuições e pendências mostram o estado completo da sessão.
              </p>
            </div>
            <Card className="overflow-hidden border-card-border shadow-none">
              {!loading && <ProductivityTable rows={data.productivity} />}
            </Card>
          </section>
        </div>
      </main>
    </div>
  );
}

function EmptyChart({ text }: { text: string }) {
  return (
    <div className="flex h-[280px] flex-col items-center justify-center px-5 text-center">
      <FileText className="mb-2 h-6 w-6 text-muted-foreground/70" aria-hidden="true" />
      <p className="text-sm font-medium">{text}</p>
      <p className="mt-1 text-xs text-muted-foreground">Os gráficos serão preenchidos com os dados disponíveis da pauta.</p>
    </div>
  );
}

export default AdvancedVisualizationView;

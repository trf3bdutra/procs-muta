import { useCallback, useEffect, useRef, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  getGetPautaQueryKey,
  useGetPauta,
  useSavePauta,
} from '@workspace/api-client-react';
import { useAppAuth, type AppSession } from '@/components/app-access-gate';
import { useLocation } from 'wouter';
import { applySharedPautaRoute, shellPathForEmbeddedPage, shellPathForEmbeddedRoute, waitForSharedPautaStartup } from '@/lib/shared-pauta-startup';
import { profilePathForLoggedInServer } from '@/lib/server-profile-route';
import cmExclusiveLayoutCss from '@/lib/cm-exclusive-layout.css?inline';
import { GabineteLoader } from '@/components/loading';
import { useLoginWelcome } from '@/lib/login-welcome';
import { installEquipeUnificada } from '@/lib/equipe-unificada';
import { canAccessGlobalSettings } from '@/lib/app-role';

/** A Mesa do CM é acessível pelo link secreto do Desembargador e pela Administração. */

/* saudação da abertura da Mesa pelo link do Desembargador: "Boa tarde, Dr. Carlos Muta!" */
const CM_SALUTATION = 'Dr. Carlos Muta';
const CM_INFO = 'Preparando a Mesa: assinaturas pendentes, dúvidas da equipe e urgências.';
function canOpenCmt(
  currentSession: AppSession | null,
  frameWindow?: (Window & { CMTConfigPagina?: { pode?: () => boolean } }) | null,
): boolean {
  if (!currentSession) return false;
  if (currentSession.userId === "cm-link" && currentSession.server === "CM") return true;
  return canAccessGlobalSettings(currentSession.role);
}

function currentUserProfilePath(name: string, currentSession: AppSession | null): string | null {
  const currentServer = currentSession?.server || (currentSession?.role === 'equipe' ? currentSession.name : '');
  return profilePathForLoggedInServer(name, currentServer);
}

const pautaBuildId =
  typeof __PAUTA_BUILD__ === 'string' ? __PAUTA_BUILD__ : Date.now().toString(36);

type SnapshotState = Record<string, unknown>;
type PautaConflict = {
  path: (string | number)[];
  localExists: boolean;
  localValue?: unknown;
  remoteExists: boolean;
  remoteValue?: unknown;
};
type PautaSnapshot = {
  revision: number;
  state: SnapshotState;
  conflicts?: PautaConflict[];
};
type PautaDelta = {
  kind: 'delta'; revision: number; baseRevision: number;
  fields: SnapshotState; removed: string[];
  rowChanges?: { index: number; value: unknown }[];
};
function isDelta(value: unknown): value is PautaDelta {
  return !!value && typeof value === 'object' && (value as PautaDelta).kind === 'delta';
}
function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}
function normalizePautaSnapshot(value: unknown): PautaSnapshot | null {
  let current = value;
  let revision = 0;
  for (let depth = 0; depth < 5; depth += 1) {
    if (typeof current === 'string') {
      try {
        current = JSON.parse(current) as unknown;
        continue;
      } catch {
        return null;
      }
    }
    if (!isRecord(current)) return null;
    if (typeof current.revision === 'number' && Number.isInteger(current.revision)) {
      revision = current.revision;
    }
    if (Array.isArray(current.rows)) {
      return { revision, state: current as SnapshotState };
    }
    if (isRecord(current.state)) current = current.state;
    else if (isRecord(current.data)) current = current.data;
    else if (isRecord(current.snapshot)) current = current.snapshot;
    else return null;
  }
  return null;
}
function applyDelta(base: SnapshotState, delta: PautaDelta): SnapshotState {
  const state = { ...base, ...delta.fields };
  delta.removed.forEach(key => { delete state[key]; });
  if (delta.rowChanges) {
    if (!Array.isArray(base.rows)) throw new Error('Missing row base');
    const rows = [...base.rows];
    for (const change of delta.rowChanges) {
      if (change.index < 0 || change.index >= rows.length) throw new Error('Invalid row index');
      rows[change.index] = change.value;
    }
    state.rows = rows;
  }
  return state;
}
type PautaWindowApp = {
  snapshot: () => SnapshotState | string;
  restoreSnapshot: (state: SnapshotState) => void;
  renderShell: () => void;
  saveDB: () => Promise<boolean>;
  saveDeb: () => void;
  /** Versão da vista: invalida os caches da lista, da busca e dos painéis a cada alteração. */
  _pautaViewVersion?: number;
  loadDB?: (user?: boolean) => Promise<unknown>;
  clearData?: () => Promise<unknown>;
  notify?: (
    message: string,
    kind?: string,
    options?: { category?: 'save' | 'files' | 'validation' | 'team' | 'agentmail' | 'personal' | 'critical'; countUnread?: boolean; urgent?: boolean },
  ) => void;
  updateStatus: () => void;
  storageStatus?: string;
  sharedRevision?: number;
  sharedState?: SnapshotState;
  pautaPreferences?: Record<string, unknown>;
  _dirty?: boolean;
  _loading?: boolean;
};
function appSnapshotState(app: Pick<PautaWindowApp, 'snapshot'>): SnapshotState | null {
  return normalizePautaSnapshot(app.snapshot())?.state ?? null;
}

type PresenceSummary = {
  count: number;
  people: { who: string; count: number }[];
  unidentified: number;
};

declare global {
  interface Window {
    PautaApp?: PautaWindowApp;
    PautaPresence?: { set: (data: PresenceSummary | null) => void };
  }
}

const PRESENCE_PIN_KEY = 'pauta.footer-pinned-server.v1';
const PRESENCE_CLIENT_KEY = 'pauta.presence-client.v1';

/* Random id per browser tab, so several connections of the same tab count once. */
function presenceClientId(): string {
  const fresh = () => `tab_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
  try {
    const stored = window.sessionStorage.getItem(PRESENCE_CLIENT_KEY);
    if (stored && /^[\w-]{6,64}$/.test(stored)) return stored;
    const id = fresh();
    window.sessionStorage.setItem(PRESENCE_CLIENT_KEY, id);
    return id;
  } catch {
    return fresh();
  }
}

/* The server marked with the footer star in this browser (stored by the HTML app). */
function presenceWho(): string {
  try {
    const identity = JSON.parse(window.sessionStorage.getItem('cmt:sessao') || 'null') as
      | { servidor?: unknown; nome?: unknown }
      | null;
    if (identity) {
      const authenticatedName =
        typeof identity.servidor === 'string' && identity.servidor.trim()
          ? identity.servidor.trim()
          : typeof identity.nome === 'string'
            ? identity.nome.trim()
            : '';
      if (authenticatedName) return authenticatedName.slice(0, 80);
    }
  } catch {
    // Fall back to the browser's saved footer selection if the auth record is unavailable.
  }
  try {
    const value: unknown = JSON.parse(window.localStorage.getItem(PRESENCE_PIN_KEY) || '[]');
    return Array.isArray(value) && typeof value[0] === 'string' ? value[0].trim().slice(0, 80) : '';
  } catch {
    return '';
  }
}

function isPresenceSummary(value: unknown): value is PresenceSummary {
  return isRecord(value) && typeof value.count === 'number' && Array.isArray(value.people);
}

function equal(a: unknown, b: unknown): boolean {
  if (Object.is(a, b)) return true;
  if (Array.isArray(a) && Array.isArray(b)) {
    return a.length === b.length && a.every((item, index) => equal(item, b[index]));
  }
  if (!a || !b || typeof a !== 'object' || typeof b !== 'object') return false;
  const left = a as Record<string, unknown>;
  const right = b as Record<string, unknown>;
  const keys = Object.keys(left);
  if (keys.length !== Object.keys(right).length) return false;
  return keys.every((key) =>
    Object.prototype.hasOwnProperty.call(right, key) && equal(left[key], right[key]),
  );
}

function changed(value: unknown, base: unknown) {
  return !equal(value, base);
}

function setPathValue<T>(state: T, path: (string | number)[], value: unknown, exists: boolean): T {
  if (path.length === 0 || !state || typeof state !== 'object') return state;
  const result = structuredClone(state);
  let parent: unknown = result;
  for (const segment of path.slice(0, -1)) {
    if (!parent || typeof parent !== 'object') return result;
    parent = (parent as Record<string | number, unknown>)[segment];
  }
  if (!parent || typeof parent !== 'object') return result;
  const key = path[path.length - 1];
  const container = parent as Record<string | number, unknown>;
  if (Array.isArray(parent) && typeof key === 'number' && !exists) {
    parent.splice(key, 1);
  } else if (exists) {
    container[key] = value;
  } else {
    delete container[key];
  }
  return result;
}

function describeValue(value: unknown, exists: boolean) {
  if (!exists) return 'Campo removido';
  if (typeof value === 'string') return value || '(vazio)';
  const serialized = JSON.stringify(value);
  return serialized === undefined ? '(vazio)' : serialized;
}

function describePath(path: (string | number)[]) {
  return path.reduce<string>((label, segment) => {
    if (typeof segment === 'number') return `${label}[${segment}]`;
    return label ? `${label}.${segment}` : segment;
  }, '') || 'Pauta';
}

function identity(item: unknown): string | null {
  if (!item || typeof item !== 'object' || Array.isArray(item)) return null;
  const record = item as Record<string, unknown>;
  const processId = record.Processo ?? record.id ?? record.ID ?? record.idProcesso ?? record.processId ??
    record.numeroProcesso ?? record['Número do Processo'] ?? record['Nº Processo'] ??
    record['PROCESSO'];
  if (processId === undefined || processId === null) return null;
  if (record.Processo !== undefined || record['PROCESSO'] !== undefined) {
    const entries = Array.isArray(record._pautaEntries) ? record._pautaEntries : [];
    const sessions = entries
      .map((entry) => entry && typeof entry === 'object'
        ? (entry as Record<string, unknown>).session
        : null)
      .filter((session): session is string => typeof session === 'string' && session.length > 0);
    const destination = record['Sessão Destino'];
    if (typeof destination === 'string' && destination) sessions.push(destination);
    const scope = [...new Set(sessions)].sort();
    return `process:${String(processId)}:${JSON.stringify(scope)}`;
  }
  return String(processId);
}

function mergeThreeWay(base: unknown, local: unknown, remote: unknown): unknown {
  if (!changed(local, base)) return remote;
  if (!changed(remote, base)) return local;
  if (
    base && local && remote &&
    typeof base === 'object' && typeof local === 'object' && typeof remote === 'object' &&
    !Array.isArray(base) && !Array.isArray(local) && !Array.isArray(remote)
  ) {
    const b = base as Record<string, unknown>;
    const l = local as Record<string, unknown>;
    const r = remote as Record<string, unknown>;
    const result: Record<string, unknown> = {};
    for (const key of new Set([...Object.keys(b), ...Object.keys(l), ...Object.keys(r)])) {
      if (!(key in l) && !(key in r)) continue;
      result[key] = mergeThreeWay(b[key], l[key], r[key]);
    }
    return result;
  }
  if (Array.isArray(base) && Array.isArray(local) && Array.isArray(remote)) {
    const keyed = [...base, ...local, ...remote].every((item) => identity(item) !== null);
    if (keyed) {
      const baseMap = new Map(base.map((item) => [identity(item)!, item]));
      const localMap = new Map(local.map((item) => [identity(item)!, item]));
      const remoteMap = new Map(remote.map((item) => [identity(item)!, item]));
      // Dois cartões com a mesma identidade (mesmo processo na mesma sessão) colapsariam no Map
      // e um deles sumiria da tela. Nesse caso não há casamento seguro por chave.
      const duplicated =
        baseMap.size !== base.length || localMap.size !== local.length || remoteMap.size !== remote.length;
      if (!duplicated) {
        const order = [...new Set([...remoteMap.keys(), ...localMap.keys()])];
        return order.flatMap((key) => {
          const b = baseMap.get(key);
          const l = localMap.get(key);
          const r = remoteMap.get(key);
          if (l === undefined && b !== undefined && equal(r, b)) return [];
          if (r === undefined && b !== undefined && equal(l, b)) return [];
          if (l === undefined) return r === undefined ? [] : [r];
          if (r === undefined) return [l];
          return [mergeThreeWay(b, l, r)];
        });
      }
    }
    if (base.length === local.length && base.length === remote.length) {
      return base.map((item, index) => mergeThreeWay(item, local[index], remote[index]));
    }
  }
  return local;
}

function isEditableTarget(target: EventTarget | null) {
  if (!(target instanceof HTMLElement)) return false;
  return target.matches('input, textarea, select, [contenteditable="true"]');
}

/** Nome de cada página, na aba do navegador e no título do iframe. */
const PAGE_TITLES: Record<string, string> = {
  '/configuracoes-globais': 'Configurações Globais',
  '/tria': 'Triagem',
  '/serv-user': 'Campo do Servidor',
  '/mono': 'Controle de Monocráticas',
  '/ementario': 'Ementário',
  '/repositorio': 'Repositório',
  '/repertorio': 'Repositório',
  '/protocolo': 'Protocolo',
  '/diretrizes-e-fluxos': 'Protocolo',
};

function pageTitle(pathname: string): string {
  return `${PAGE_TITLES[pathname] ?? 'Pauta de Julgamento'} — GabCMT`;
}

function isCmRoute(location: string): boolean {
  const path = location.split(/[?#]/, 1)[0].replace(/\/+$/, '');
  return path === '/cm' || path === '/cmt';
}

export default function SharedPauta() {
  const { session, ready: authReady, refreshSession, logout } = useAppAuth();
  const loginWelcome = useLoginWelcome(authReady, session?.userId);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [location, setLocation] = useLocation();
  const pathname = location.split(/[?#]/, 1)[0].replace(/\/+$/, "").toLowerCase();
  const triageWorkspace = pathname === "/tria";
  const globalSettingsPage = pathname === "/configuracoes-globais" || pathname.startsWith("/configuracoes-globais/");
  const settingsReturnLocationRef = useRef("/gabinete");
  const settingsPageDialogOpenRef = useRef(false);
  const [htmlReady, setHtmlReady] = useState(false);
  const [cmReady, setCmReady] = useState(false);
  const [moduleError, setModuleError] = useState(false);
  const [frameAttempt, setFrameAttempt] = useState(0);
  const frameRecoveryRef = useRef(0);
  const [connected, setConnected] = useState(false);
  const [initializing, setInitializing] = useState(true);
  const [authTimedOut, setAuthTimedOut] = useState(false);
  const [startupTimedOut, setStartupTimedOut] = useState(false);
  const [recoveryBusy, setRecoveryBusy] = useState(false);
  const [logoutBusy, setLogoutBusy] = useState(false);
  const [logoutError, setLogoutError] = useState('');
  const [snapshotError, setSnapshotError] = useState(false);
  const [connectionError, setConnectionError] = useState(false);
  const [conflicts, setConflicts] = useState<PautaConflict[]>([]);
  const queryClient = useQueryClient();
  const activeUserRef = useRef<string | null>(session?.userId ?? null);
  // Sessão atual para os ouvintes de mensagem do iframe, sem recriá-los a cada atualização.
  const sessionRef = useRef<AppSession | null>(session ?? null);
  sessionRef.current = session ?? null;
  activeUserRef.current = session?.userId ?? null;
  const pautaQuery = useGetPauta({
    query: { queryKey: getGetPautaQueryKey(), enabled: authReady && !!session },
  });
  // This controller owns retries and pending edits. Do not let React Query
  // silently pause its mutation based on navigator.onLine as well.
  const saveMutation = useSavePauta({ mutation: { networkMode: 'always', retry: false } });
  const saveMutationRef = useRef(saveMutation.mutate);
  saveMutationRef.current = saveMutation.mutate;
  const queryRefetchRef = useRef(pautaQuery.refetch);
  queryRefetchRef.current = pautaQuery.refetch;
  const revisionRef = useRef(0);
  const remoteStateRef = useRef<SnapshotState | null>(null);
  const pendingRemoteRef = useRef<PautaSnapshot | null>(null);
  const initializedRef = useRef(false);
  const enhancementsReadyRef = useRef(false);
  const connectedRef = useRef(false);
  const editingRef = useRef(false);
  const suppressSaveRef = useRef(false);
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const inflightRef = useRef(false);
  const saveFailuresRef = useRef(0);
  const needsSaveRef = useRef(false);
  const conflictsRef = useRef<PautaConflict[]>([]);
  const waitersRef = useRef<Array<(ok: boolean) => void>>([]);
  const pumpRef = useRef<() => void>(() => undefined);
  const presenceClientRef = useRef<string>('');
  const presenceRef = useRef<PresenceSummary | null>(null);
  const roleObserverRef = useRef<MutationObserver | null>(null);
  const pendingLoginServerPinRef = useRef<string | null>(null);
  const loggingOutRef = useRef(false);
  const startupDeadlineRef = useRef<{ userId: string; deadline: number } | null>(null);

  const loaderError = pautaQuery.isError || snapshotError || moduleError || authTimedOut || startupTimedOut;
  const cmRoute = isCmRoute(location);
  const cmLoading = cmRoute && !cmReady;
  /* acesso pelo link do Desembargador: saudação própria na abertura da Mesa */
  const loaderVisible = !authReady || (!!session && (initializing || loaderError || cmLoading)) || (!session && moduleError) || loginWelcome;
  const startupMessage = authTimedOut
    ? 'Não foi possível confirmar seu acesso em 45 segundos.'
    : startupTimedOut
      ? 'A abertura do Gabinete ultrapassou 45 segundos.'
    : !authReady
    ? 'Confirmando seu acesso…'
    : !htmlReady
      ? 'Abrindo a interface do Gabinete…'
      : pautaQuery.isFetching
        ? 'Buscando a pauta compartilhada…'
        : initializing
          ? 'Preparando os processos e os dados da equipe…'
          : 'Concluindo a abertura do Gabinete…';

  useEffect(() => {
    if (authReady || authTimedOut) return;
    const timer = window.setTimeout(() => setAuthTimedOut(true), 45_000);
    return () => window.clearTimeout(timer);
  }, [authReady, authTimedOut]);

  useEffect(() => {
    if (session) return;
    startupDeadlineRef.current = null;
    initializedRef.current = false;
    enhancementsReadyRef.current = false;
    revisionRef.current = 0;
    remoteStateRef.current = null;
    pendingRemoteRef.current = null;
    connectedRef.current = false;
    editingRef.current = false;
    needsSaveRef.current = false;
    presenceRef.current = null;
    roleObserverRef.current?.disconnect();
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = null;
    waitersRef.current.splice(0).forEach((resolve) => resolve(false));
    setConnected(false);
    setInitializing(true);
    setAuthTimedOut(false);
    setStartupTimedOut(false);
    setHtmlReady(false);
    setSnapshotError(false);
    setModuleError(false);
    setConnectionError(false);
    setRecoveryBusy(false);
    setLogoutError('');
    setConflicts([]);
  }, [session]);
  if (!presenceClientRef.current) presenceClientRef.current = presenceClientId();

  useEffect(() => () => {
    activeUserRef.current = null;
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    waitersRef.current.splice(0).forEach((resolve) => resolve(false));
    roleObserverRef.current?.disconnect();
  }, []);

  const pushPresence = useCallback((summary: PresenceSummary | null) => {
    presenceRef.current = summary;
    try {
      iframeRef.current?.contentWindow?.PautaPresence?.set(summary);
    } catch {
      /* the HTML may still be loading; the summary is applied after hydration */
    }
  }, []);

  const applyAuthToFrame = useCallback((currentSession: AppSession) => {
    const frameDocument = iframeRef.current?.contentDocument;
    const frameWindow = iframeRef.current?.contentWindow as
      | (Window & {
          CMT_AUTH_SESSION?: AppSession;
          __cmtPublicProfilePathFor?: (name: string) => string | null;
        })
      | null;
    if (!frameDocument || !frameWindow) return;

    roleObserverRef.current?.disconnect();
    frameWindow.__cmtPublicProfilePathFor = (name) =>
      currentUserProfilePath(name, currentSession);
    const legacyIdentity = {
      nome: currentSession.name,
      servidor: currentSession.server ?? '',
      papel: currentSession.role === 'equipe' ? 'servidor' : 'admin',
    };
    try {
      frameDocument.documentElement.dataset.appRole = currentSession.role;
      frameWindow.sessionStorage.setItem('cmt:sessao', JSON.stringify(legacyIdentity));
      frameWindow.CMT_AUTH_SESSION = currentSession;
    } catch {
      // The API session cookie remains authoritative if iframe storage is unavailable.
    }
    const routesReady = frameDocument.createEvent('Event');
    routesReady.initEvent('cmt:public-profile-routes-ready', false, false);
    frameDocument.dispatchEvent(routesReady);

    const removalControls = frameDocument.querySelectorAll<HTMLElement>(
      '[data-hub="remove-processes"], [data-hub-form="remove-processes"]',
    );
    if (currentSession.role === 'equipe') {
      let roleStyle = frameDocument.getElementById('cmt-app-role-restrictions');
      if (!roleStyle) {
        roleStyle = frameDocument.createElement('style');
        roleStyle.id = 'cmt-app-role-restrictions';
        roleStyle.textContent = `
          [data-app-role="equipe"] [data-hub="remove-processes"],
          [data-app-role="equipe"] [data-hub-form="remove-processes"] {
            display: none !important;
          }
        `;
        frameDocument.head.appendChild(roleStyle);
      }
      const hideProcessRemoval = () => {
        removalControls.forEach((element) => {
          element.setAttribute('aria-hidden', 'true');
          element.style.setProperty('display', 'none', 'important');
        });
        frameDocument
          .querySelectorAll<HTMLElement>('[data-hub="remove-processes"], [data-hub-form="remove-processes"]')
          .forEach((element) => {
            element.setAttribute('aria-hidden', 'true');
            element.style.setProperty('display', 'none', 'important');
          });
      };
      hideProcessRemoval();
      // Uma passada por quadro: o app troca muitos nós ao mudar de página ou abrir painéis,
      // e varrer o documento a cada mutação travava a interface do perfil Equipe.
      let removalFrame = 0;
      const hideProcessRemovalSoon = () => {
        if (removalFrame) return;
        removalFrame = frameWindow.requestAnimationFrame(() => {
          removalFrame = 0;
          hideProcessRemoval();
        });
      };
      roleObserverRef.current = new MutationObserver(hideProcessRemovalSoon);
      if (frameDocument.body) {
        roleObserverRef.current.observe(frameDocument.body, { childList: true, subtree: true });
      }
    } else {
      removalControls.forEach((element) => {
        element.removeAttribute('aria-hidden');
        element.style.removeProperty('display');
      });
      // Contas de acesso ficam em Configurações Globais › Equipe › Contas de acesso. O botão Sair da barra
      // lateral (cmtx-logout, criado pelo próprio app) vale para todos, inclusive Administração.
      frameDocument.querySelectorAll('[data-account-admin]').forEach((element) => element.remove());
    }
  }, []);

  useEffect(() => {
    if (session && htmlReady) applyAuthToFrame(session);
  }, [session, htmlReady, applyAuthToFrame]);

  const logoutSafely = useCallback(async () => {
    if (loggingOutRef.current) return;
    loggingOutRef.current = true;
    setLogoutBusy(true);
    setLogoutError('');
    const app = iframeRef.current?.contentWindow?.PautaApp;
    try {
      const persistedState = remoteStateRef.current;
      let hasUnpersistedChanges = false;
      if (app) {
        if (persistedState !== null) {
          try {
            const currentState = appSnapshotState(app);
            hasUnpersistedChanges =
              editingRef.current || !currentState || !equal(currentState, persistedState);
          } catch {
            hasUnpersistedChanges = true;
          }
        } else {
          hasUnpersistedChanges =
            app._dirty || !!saveTimerRef.current || inflightRef.current;
        }
      }

      if (app && hasUnpersistedChanges) {
        let timer: ReturnType<typeof setTimeout> | undefined;
        const saved = await Promise.race([
          app.saveDB(),
          new Promise<never>((_, reject) => {
            timer = setTimeout(
              () => reject(new Error('O salvamento ainda não terminou. Aguarde e tente sair novamente.')),
              12_000,
            );
          }),
        ]).finally(() => clearTimeout(timer));
        if (!saved) throw new Error('Não foi possível salvar as alterações. A sessão continua aberta.');
      } else if (app) {
        if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
        saveTimerRef.current = null;
        needsSaveRef.current = false;
        app._dirty = false;
      }
      await logout();
      setLocation('/', { replace: true });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Não foi possível sair. Tente novamente.';
      setLogoutError(message);
      throw error;
    } finally {
      loggingOutRef.current = false;
      setLogoutBusy(false);
    }
  }, [logout, setLocation]);

  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      if (
        event.origin !== window.location.origin ||
        event.source !== iframeRef.current?.contentWindow
      ) return;
      const frameWindow = iframeRef.current?.contentWindow as
        | (Window & { CMTConfigPagina?: { pode?: () => boolean } })
        | null;
      if (event.data?.type === 'pauta:workspace-navigation') {
        if (event.data.page !== 'triagem') return;
        const target = '/tria';
        if (window.location.pathname !== target) setLocation(target);
      } else if (event.data?.type === 'pauta:open-global-settings') {
        if (!canAccessGlobalSettings(sessionRef.current?.role)) return;
        const current = location || '/gabinete';
        if (!globalSettingsPage) settingsReturnLocationRef.current = current;
        setLocation('/configuracoes-globais');
      } else if (event.data?.type === 'pauta:close-global-settings') {
        setLocation(settingsReturnLocationRef.current || '/gabinete', { replace: true });
      } else if (event.data?.type === 'pauta:open-advanced-visualization') {
        if (canOpenCmt(sessionRef.current, frameWindow)) setLocation('/cm');
      } else if (event.data?.type === 'pauta:close-advanced-visualization') {
        setLocation('/gabinete');
      } else if (
        event.data?.tipo === 'cmt:page' &&
        typeof event.data.pagina === 'string'
      ) {
        if (globalSettingsPage) return;
        const target = shellPathForEmbeddedPage(event.data.pagina, window.location.pathname);
        if (target) setLocation(target);
      } else if (
        event.data?.tipo === 'cmt:route' &&
        typeof event.data.path === 'string'
      ) {
        if (globalSettingsPage) return;
        const target = shellPathForEmbeddedRoute(event.data.path, window.location.pathname);
        if (!target) return;
        if (target === '/cm' && !canOpenCmt(sessionRef.current, frameWindow)) return;
        setLocation(target);
      } else if (event.data?.tipo === 'cmt:auth-required') {
        void refreshSession();
      } else if (event.data?.tipo === 'cmt:logout') {
        const app = iframeRef.current?.contentWindow?.PautaApp;
        void logoutSafely().catch((error) => {
          const button = iframeRef.current?.contentDocument?.querySelector<HTMLButtonElement>('.cmtx-logout');
          if (button) button.disabled = false;
          app?.notify?.(error instanceof Error ? error.message : 'Não foi possível sair. Tente novamente.', 'err');
        });
      }
    };
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, [location, globalSettingsPage, setLocation, refreshSession, logoutSafely]);

  useEffect(() => {
    setCmReady(false);
    if (!htmlReady || initializing) return;
    type RouteView = { open: () => void; close: (options?: { notify?: boolean }) => void };
    const frameWindow = iframeRef.current?.contentWindow as
      | (Window & {
        CMTAdvanced?: RouteView;
        CMTConfigPagina?: { pode?: () => boolean };
        CMTRotas?: { ir?: (route: string) => unknown; atual?: () => { pagina?: string; area?: string; rota?: string } | null };
        CMTAppDialogs?: {
          canOpenSettings?: () => boolean;
          openSettings?: (options?: { page?: boolean }) => boolean;
          closeSettings?: (options?: { fromRoute?: boolean }) => void;
        };
      })
      | undefined;
    if (!globalSettingsPage && settingsPageDialogOpenRef.current) {
      frameWindow?.CMTAppDialogs?.closeSettings?.({ fromRoute: true });
      settingsPageDialogOpenRef.current = false;
    }
    // /cmt digitado ou vindo do histórico por quem não é da Assessoria volta para a página inicial.
    if (location === '/cmt' && !canOpenCmt(session, frameWindow)) {
      setLocation('/', { replace: true });
      return;
    }
    iframeRef.current?.contentDocument?.documentElement.toggleAttribute('data-cm-route', isCmRoute(location));
    if (!globalSettingsPage && new URLSearchParams(location.split('?')[1] || '').get('perfil') === '1') {
      const profile = frameWindow as (typeof frameWindow & { CMTProfileDialog?: { open: () => boolean } });
      if (profile?.CMTProfileDialog?.open()) setLocation('/gabinete', { replace: true });
    }
    if (!globalSettingsPage) {
      applySharedPautaRoute(
        location, true, frameWindow?.CMTAdvanced, null, frameWindow?.CMTRotas,
      );
    }
    if (globalSettingsPage) {
      if (!canAccessGlobalSettings(session?.role) || !frameWindow?.CMTAppDialogs?.canOpenSettings?.()) {
        setLocation('/gabinete', { replace: true });
        return;
      }
      settingsPageDialogOpenRef.current =
        frameWindow.CMTAppDialogs.openSettings?.({ page: true }) === true;
      return;
    }
    if (!isCmRoute(location)) return;
    // Do not expose the underlying Gabinete while the CM builds its own view.
    const deadline = performance.now() + 20_000;
    let timer: ReturnType<typeof setTimeout>;
    let paint = 0;
    let reveal = 0;
    const check = () => {
      const doc = iframeRef.current?.contentDocument;
      const root = doc?.getElementById('cmt-adv');
      if (root && !root.hidden && doc?.body.classList.contains('cmt-adv-open')
        && root.querySelector('.cm3-rail, .cm3-brand, .cmt2-top, .cmt-adv-top')) {
        paint = requestAnimationFrame(() => {
          reveal = requestAnimationFrame(() => setCmReady(true));
        });
      } else if (performance.now() >= deadline) {
        setModuleError(true);
      } else {
        timer = setTimeout(check, 100);
      }
    };
    check();
    return () => {
      clearTimeout(timer);
      cancelAnimationFrame(paint);
      cancelAnimationFrame(reveal);
    };
  }, [htmlReady, initializing, location, session, globalSettingsPage, setLocation]);

  useEffect(() => {
    if (!triageWorkspace || !htmlReady || initializing) return;
    iframeRef.current?.contentWindow?.postMessage({
      type: 'pauta:workspace-state',
      page: 'triagem',
    }, window.location.origin);
  }, [htmlReady, initializing, pathname, triageWorkspace]);

  useEffect(() => {
    const previousTitle = document.title;
    document.title = pageTitle(pathname);
    return () => { document.title = previousTitle; };
  }, [pathname]);

  const setAppStatus = useCallback((text: string) => {
    const app = iframeRef.current?.contentWindow?.PautaApp;
    if (!app) return;
    app.storageStatus = text;
    app.updateStatus();
  }, []);

  const hydrate = useCallback((snapshot: PautaSnapshot) => {
    const app = iframeRef.current?.contentWindow?.PautaApp;
    const normalized = normalizePautaSnapshot(snapshot);
    if (!app || !normalized) return;
    suppressSaveRef.current = true;
    try {
      app.restoreSnapshot(normalized.state);
      app.renderShell();
      revisionRef.current = normalized.revision;
      remoteStateRef.current = normalized.state;
      app.sharedRevision = normalized.revision;
      app.sharedState = normalized.state;
      iframeRef.current?.contentDocument?.documentElement.classList.remove('pauta-booting');
      pendingRemoteRef.current = null;
      app._dirty = false;
      setSnapshotError(false);
      setAppStatus(connectedRef.current ? 'Conectado · pauta sincronizada' : 'Pauta sincronizada · reconectando');
      if (presenceRef.current) iframeRef.current?.contentWindow?.PautaPresence?.set(presenceRef.current);
    } finally {
      window.setTimeout(() => { suppressSaveRef.current = false; }, 0);
    }
  }, [setAppStatus]);

  const postPresence = useCallback(() => {
    if (!session) return;
    void fetch('/api/pauta/presence', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ client: presenceClientRef.current, who: presenceWho() }),
    }).then(async (response) => {
      if (!response.ok) return;
      const summary: unknown = await response.json().catch(() => null);
      if (isPresenceSummary(summary)) pushPresence(summary);
    }).catch(() => undefined);
  }, [pushPresence, session]);

  useEffect(() => {
    const server = pendingLoginServerPinRef.current;
    if (!server || !session || (session.role !== 'equipe' && session.role !== 'editor') || !htmlReady || initializing || !initializedRef.current) {
      return;
    }

    let attempts = 0;
    let timer: number | undefined;
    const normalizeName = (name: string) =>
      name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLocaleUpperCase('pt-BR');
    const pinSelectedServer = () => {
      if (pendingLoginServerPinRef.current !== server) return;
      const frameDocument = iframeRef.current?.contentDocument;
      const star = Array.from(
        frameDocument?.querySelectorAll<HTMLButtonElement>('[data-action="dock-pin"]') ?? [],
      ).find((button) => normalizeName(button.dataset.server || '') === normalizeName(server));

      if (star) {
        if (star.getAttribute('aria-pressed') !== 'true') star.click();
        pendingLoginServerPinRef.current = null;
        if (star.getAttribute('aria-pressed') === 'true') postPresence();
        return;
      }
      if (attempts++ < 50) timer = window.setTimeout(pinSelectedServer, 100);
    };

    pinSelectedServer();
    return () => {
      if (timer) window.clearTimeout(timer);
    };
  }, [htmlReady, initializing, postPresence, session]);

  useEffect(() => {
    // The star is chosen inside the iframe; its localStorage write reaches this window as a storage event.
    const onStorage = (event: StorageEvent) => {
      if (event.key === PRESENCE_PIN_KEY) postPresence();
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, [postPresence]);

  const applyRemote = useCallback((snapshot: PautaSnapshot) => {
    if (!initializedRef.current || snapshot.revision <= revisionRef.current) return;
    const app = iframeRef.current?.contentWindow?.PautaApp;
    const dialogOpen = !!iframeRef.current?.contentDocument?.querySelector('dialog[open]');
    if (!app || editingRef.current || dialogOpen || conflictsRef.current.length > 0) {
      pendingRemoteRef.current = snapshot;
      return;
    }
    if (inflightRef.current) {
      pendingRemoteRef.current = snapshot;
      return;
    }
    const local = appSnapshotState(app);
    const hasLocalEdits = app._dirty || !local || !equal(local, remoteStateRef.current);
    if (hasLocalEdits) {
      pendingRemoteRef.current = snapshot;
      needsSaveRef.current = true;
      pumpRef.current();
      return;
    }
    hydrate(snapshot);
  }, [hydrate]);

  const requestSave = useCallback(() => {
    const app = iframeRef.current?.contentWindow?.PautaApp;
    if (!app || !initializedRef.current || suppressSaveRef.current) return Promise.resolve(false);
    if (saveTimerRef.current) {
      clearTimeout(saveTimerRef.current);
      saveTimerRef.current = null;
    }
    return new Promise<boolean>((resolve) => {
      waitersRef.current.push(resolve);
      needsSaveRef.current = true;
      pumpRef.current();
    });
  }, []);

  pumpRef.current = () => {
    if (!session?.userId || activeUserRef.current !== session.userId) return;
    if (inflightRef.current || conflictsRef.current.length > 0 || !needsSaveRef.current) return;
    const app = iframeRef.current?.contentWindow?.PautaApp;
    const baseState = remoteStateRef.current;
    if (!app || !baseState) return;
    const state = appSnapshotState(app);
    if (!state) {
      needsSaveRef.current = false;
      app._dirty = true;
      setAppStatus('Não foi possível ler a pauta para salvar.');
      waitersRef.current.splice(0).forEach((resolve) => resolve(false));
      return;
    }
    if (equal(state, baseState)) {
      needsSaveRef.current = false;
      app._dirty = false;
      setAppStatus(connectedRef.current ? 'Conectado · pauta sincronizada' : 'Pauta sincronizada · reconectando');
      waitersRef.current.splice(0).forEach((resolve) => resolve(true));
      return;
    }
    needsSaveRef.current = false;
    inflightRef.current = true;
    app._dirty = true;
    setAppStatus('Salvando alterações compartilhadas…');
    saveMutationRef.current(
      { data: { baseRevision: revisionRef.current, baseState, state } },
      {
        onSuccess: (saved) => {
          if (activeUserRef.current !== session.userId) return;
          const liveApp = iframeRef.current?.contentWindow?.PautaApp;
          const current = liveApp ? appSnapshotState(liveApp) : null;
          const reconciled = current
            // Only edits made after this request began remain local. Changes
            // already submitted must accept the server's canonical response.
            ? mergeThreeWay(state, current, saved.state) as SnapshotState
            : saved.state;
          revisionRef.current = saved.revision;
          remoteStateRef.current = saved.state;
          if (pendingRemoteRef.current && pendingRemoteRef.current.revision <= saved.revision) {
            pendingRemoteRef.current = null;
          }
          if (liveApp) {
            liveApp.sharedRevision = saved.revision;
            liveApp.sharedState = saved.state;
            if (!equal(current, reconciled)) {
              suppressSaveRef.current = true;
              try {
                liveApp.restoreSnapshot(reconciled);
                if (!editingRef.current) liveApp.renderShell();
              } finally {
                window.setTimeout(() => { suppressSaveRef.current = false; }, 0);
              }
            }
          }
          queryClient.setQueryData(getGetPautaQueryKey(), saved);
          inflightRef.current = false;
          saveFailuresRef.current = 0;
          const foundConflicts =
            (saved as typeof saved & { conflicts?: PautaConflict[] }).conflicts ?? [];
          if (foundConflicts.length > 0) {
            conflictsRef.current = foundConflicts;
            setConflicts(foundConflicts);
            needsSaveRef.current = false;
            if (liveApp) liveApp._dirty = true;
            setAppStatus('Conflito de edição · escolha qual valor manter');
            return;
          }
          needsSaveRef.current = !equal(reconciled, saved.state);
          if (liveApp) liveApp._dirty = needsSaveRef.current;
          const newerRemote = pendingRemoteRef.current;
          if (newerRemote && newerRemote.revision > saved.revision) {
            pendingRemoteRef.current = null;
            applyRemote(newerRemote);
            return;
          }
          if (needsSaveRef.current) {
            setAppStatus('Salvando alterações compartilhadas…');
            pumpRef.current();
          } else {
            setAppStatus(connectedRef.current ? 'Conectado · pauta sincronizada' : 'Salvo · reconectando');
            waitersRef.current.splice(0).forEach((resolve) => resolve(true));
          }
        },
        onError: () => {
          if (activeUserRef.current !== session.userId) return;
          inflightRef.current = false;
          needsSaveRef.current = true;
          setAppStatus('Falha ao sincronizar · alterações mantidas nesta tela');
          waitersRef.current.splice(0).forEach((resolve) => resolve(false));
          // Espera crescente (1,5 s, 3 s, 6 s… até 30 s) para não martelar o servidor fora do ar.
          saveFailuresRef.current += 1;
          const delay = Math.min(30_000, 1500 * 2 ** (saveFailuresRef.current - 1));
          window.setTimeout(() => {
            void queryRefetchRef.current().then((result) => {
              if (result.data) applyRemote(result.data);
              // Saving uses HTTP and must recover even while the event stream
              // is reconnecting; the pump already checks identity and in-flight work.
              pumpRef.current();
            });
          }, delay);
        },
      },
    );
  };

  const resolveConflict = (conflict: PautaConflict, keep: 'local' | 'remote') => {
    const app = iframeRef.current?.contentWindow?.PautaApp;
    if (!app) return;
    if (keep === 'remote') {
      const currentState = appSnapshotState(app);
      if (!currentState) return;
      const updated = setPathValue(
        currentState,
        conflict.path,
        conflict.remoteValue,
        conflict.remoteExists,
      );
      suppressSaveRef.current = true;
      try {
        app.restoreSnapshot(updated);
        app.renderShell();
      } finally {
        window.setTimeout(() => { suppressSaveRef.current = false; }, 0);
      }
    }
    const remaining = conflictsRef.current.filter((item) => item !== conflict);
    conflictsRef.current = remaining;
    setConflicts(remaining);
    if (remaining.length === 0) {
      const currentState = appSnapshotState(app);
      app._dirty = !currentState || !equal(currentState, remoteStateRef.current);
      needsSaveRef.current = app._dirty;
      const pending = pendingRemoteRef.current;
      if (pending && pending.revision > revisionRef.current) {
        pendingRemoteRef.current = null;
        applyRemote(pending);
        return;
      }
      pendingRemoteRef.current = null;
      if (needsSaveRef.current) {
        setAppStatus('Salvando valor escolhido e alterações mescladas…');
        pumpRef.current();
      } else {
        setAppStatus(connectedRef.current ? 'Conectado · pauta sincronizada' : 'Salvo · reconectando');
        waitersRef.current.splice(0).forEach((resolve) => resolve(true));
      }
    }
  };

  const flushPendingRemote = useCallback(() => {
    editingRef.current = false;
    if (conflictsRef.current.length > 0) return;
    const pending = pendingRemoteRef.current;
    if (!pending) {
      const app = iframeRef.current?.contentWindow?.PautaApp;
      if (app?._dirty) void requestSave();
      return;
    }
    const app = iframeRef.current?.contentWindow?.PautaApp;
    if (!app) return;
    const local = appSnapshotState(app);
    pendingRemoteRef.current = null;
    const hasLocalEdits = app._dirty || !local || !equal(local, remoteStateRef.current);
    if (hasLocalEdits) {
      needsSaveRef.current = true;
      pumpRef.current();
      return;
    }
    hydrate(pending);
  }, [hydrate, requestSave]);

  useEffect(() => {
    if (!authReady || !session || initializedRef.current || startupTimedOut) return;
    const now = window.performance.now();
    if (startupDeadlineRef.current?.userId !== session.userId) {
      startupDeadlineRef.current = { userId: session.userId, deadline: now + 45_000 };
    }
    const remainingMs = Math.max(1, startupDeadlineRef.current.deadline - now);
    return waitForSharedPautaStartup({
      isHtmlReady: () => htmlReady,
      getApp: () => iframeRef.current?.contentWindow?.PautaApp,
      isAppLoading: (app) => !!app._loading,
      areScriptsReady: () => enhancementsReadyRef.current,
      isSnapshotFetching: () => pautaQuery.isFetching,
      getSnapshot: () => pautaQuery.data,
      timeoutMs: remainingMs,
      onTimeout: () => setStartupTimedOut(true),
      onReady: (app, response) => {
        startupDeadlineRef.current = null;
        const snapshot = normalizePautaSnapshot(response);
        if (!snapshot) {
          setSnapshotError(true);
          return;
        }
        app.saveDB = requestSave;
        app.saveDeb = () => {
          if (suppressSaveRef.current) return;
          // Cada alteração local invalida os cálculos em cache da lista e da Ordem do dia.
          app._pautaViewVersion = (app._pautaViewVersion ?? 0) + 1;
          app._dirty = true;
          setAppStatus('Alterações pendentes · compartilhamento ativo');
          if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
          saveTimerRef.current = setTimeout(() => { void requestSave(); }, 400);
        };
        app.loadDB = async (user = false) => {
          const result = await queryRefetchRef.current();
          if (result.data) {
            hydrate(result.data);
            if (user) app.notify?.('Pauta compartilhada atualizada.', 'ok', { category: 'save' });
            return result.data;
          }
          return undefined;
        };
        if (app.clearData) {
          const clearLocalData = app.clearData.bind(app);
          app.clearData = async () => {
            await clearLocalData();
            await requestSave();
          };
        }
        remoteStateRef.current = snapshot.state;
        revisionRef.current = snapshot.revision;
        suppressSaveRef.current = true;
        app.restoreSnapshot(snapshot.state);
        app.renderShell();
        iframeRef.current?.contentDocument?.documentElement.classList.remove('pauta-booting');
        app.sharedRevision = snapshot.revision;
        app.sharedState = snapshot.state;
        app._dirty = false;
        initializedRef.current = true;
        setSnapshotError(false);
        setInitializing(false);
        setAppStatus(connectedRef.current ? 'Conectado · pauta sincronizada' : 'Conectando à pauta compartilhada…');
        window.setTimeout(() => { suppressSaveRef.current = false; }, 0);
      },
    });
  }, [authReady, session, htmlReady, pautaQuery.data, pautaQuery.isFetching, startupTimedOut, requestSave, setAppStatus, hydrate]);

  useEffect(() => {
    if (!initializedRef.current) return;
    const frame = iframeRef.current;
    const doc = frame?.contentDocument;
    if (!doc) return;
    const onFocusIn = (event: FocusEvent) => {
      if (isEditableTarget(event.target)) editingRef.current = true;
    };
    const onFocusOut = (event: FocusEvent) => {
      if (!isEditableTarget(event.target)) return;
      window.setTimeout(() => {
        const active = doc.activeElement;
        editingRef.current = isEditableTarget(active);
        if (!editingRef.current) flushPendingRemote();
      }, 0);
    };
    doc.addEventListener('focusin', onFocusIn);
    doc.addEventListener('focusout', onFocusOut);
    return () => {
      doc.removeEventListener('focusin', onFocusIn);
      doc.removeEventListener('focusout', onFocusOut);
    };
  }, [flushPendingRemote, initializing]);

  useEffect(() => {
    if (!initializedRef.current) return;
    let source: EventSource | null = null;
    let stopped = false;
    let rehydrating = false;
    let queuedSnapshot: PautaSnapshot | null = null;
    let queuedSnapshotTimer: ReturnType<typeof setTimeout> | null = null;
    const flushQueuedSnapshot = () => {
      queuedSnapshotTimer = null;
      const snapshot = queuedSnapshot;
      queuedSnapshot = null;
      if (snapshot) applyRemote(snapshot);
    };
    const queueSnapshot = (snapshot: PautaSnapshot) => {
      if (!queuedSnapshot || snapshot.revision > queuedSnapshot.revision) {
        queuedSnapshot = snapshot;
      }
      // A short coalescing window avoids restoring and repainting the whole
      // embedded app once per event when a burst changes several processes.
      if (queuedSnapshotTimer === null) {
        queuedSnapshotTimer = setTimeout(flushQueuedSnapshot, 120);
      }
    };
    const discardQueuedSnapshot = () => {
      queuedSnapshot = null;
      if (queuedSnapshotTimer !== null) clearTimeout(queuedSnapshotTimer);
      queuedSnapshotTimer = null;
    };
    const connect = () => {
      if (stopped) return;
      source?.close();
      const presenceQuery = `&client=${encodeURIComponent(presenceClientRef.current)}&who=${encodeURIComponent(presenceWho())}`;
      source = new EventSource(`/api/pauta/events?after=${revisionRef.current}${presenceQuery}`);
      source.addEventListener('access-revoked', () => {
        source?.close();
        void refreshSession();
      });
      source.addEventListener('presence', (event) => {
        try {
          const summary: unknown = JSON.parse((event as MessageEvent<string>).data);
          if (isPresenceSummary(summary)) pushPresence(summary);
        } catch {
          /* ignore malformed presence events */
        }
      });
      source.addEventListener('gabnet', (event) => {
        try {
          const payload: unknown = JSON.parse((event as MessageEvent<string>).data);
          if (isRecord(payload) && typeof payload.revision === 'number' && isRecord(payload.game)) {
            const pending = pendingRemoteRef.current;
            const baseRevision = pending?.revision ?? revisionRef.current;
            const baseState = pending?.state ?? remoteStateRef.current;
            if (baseState && payload.revision === baseRevision + 1) {
              const preferences = isRecord(baseState.pautaPreferences) ? baseState.pautaPreferences : {};
              const nextState = {
                ...baseState,
                pautaPreferences: { ...preferences, gabnetGame: payload.game },
              };
              if (pending) {
                pendingRemoteRef.current = { revision: payload.revision, state: nextState };
              } else {
                remoteStateRef.current = nextState;
                revisionRef.current = payload.revision;
                const app = iframeRef.current?.contentWindow?.PautaApp;
                if (app) {
                  app.pautaPreferences ??= {};
                  app.pautaPreferences.gabnetGame = payload.game;
                  app.sharedRevision = payload.revision;
                  app.sharedState = nextState;
                }
              }
            } else if (payload.revision > baseRevision) {
              void queryRefetchRef.current().then((result) => {
                if (result.data) applyRemote(result.data);
              });
            }
          }
        } catch {
          /* ignore malformed GAB-NET events */
        }
      });
      source.onopen = () => {
        connectedRef.current = true;
        setConnected(true);
        setConnectionError(false);
        setAppStatus('Conectado · pauta sincronizada');
        // EventSource reconnects with its original URL; refresh the starred server after every (re)connection.
        postPresence();
        if (rehydrating) {
          rehydrating = false;
          void queryRefetchRef.current().then((result) => {
            if (result.data) applyRemote(result.data);
          });
        }
      };
      source.onmessage = (event) => {
        try {
          const candidate: unknown = JSON.parse(event.data);
          if (isDelta(candidate)) {
            const buffered = queuedSnapshot;
            const pending = pendingRemoteRef.current;
            const knownRevision = Math.max(
              revisionRef.current,
              buffered?.revision ?? 0,
              pending?.revision ?? 0,
            );
            if (candidate.revision <= knownRevision) return;
            // Pending and buffered events may have advanced the base beyond the displayed revision.
            const bufferedBase = buffered && buffered.revision === candidate.baseRevision
              ? buffered : null;
            const pendingBase = pending && pending.revision === candidate.baseRevision
              ? pending : null;
            const base = bufferedBase?.state ?? pendingBase?.state ?? remoteStateRef.current;
            const baseRevision = bufferedBase?.revision ?? pendingBase?.revision ?? revisionRef.current;
            if (!base || candidate.baseRevision !== baseRevision) {
              discardQueuedSnapshot();
              void queryRefetchRef.current().then(result => { if (result.data) applyRemote(result.data); });
              return;
            }
            queueSnapshot({ revision: candidate.revision, state: applyDelta(base, candidate) });
          } else if (candidate && typeof candidate === 'object' &&
            typeof (candidate as PautaSnapshot).revision === 'number' &&
            (candidate as PautaSnapshot).state) {
            const snapshot = candidate as PautaSnapshot;
            if (snapshot.revision > Math.max(
              revisionRef.current,
              queuedSnapshot?.revision ?? 0,
              pendingRemoteRef.current?.revision ?? 0,
            )) {
              queueSnapshot(snapshot);
            }
          } else {
            discardQueuedSnapshot();
            void queryRefetchRef.current().then(result => { if (result.data) applyRemote(result.data); });
          }
        } catch {
          discardQueuedSnapshot();
          void queryRefetchRef.current().then((result) => { if (result.data) applyRemote(result.data); });
        }
      };
      source.onerror = () => {
        connectedRef.current = false;
        setConnected(false);
        setConnectionError(true);
        rehydrating = true;
        const app = iframeRef.current?.contentWindow?.PautaApp;
        if (app) setAppStatus('Conexão interrompida · tentando reconectar');
        pushPresence(null);
        void queryRefetchRef.current().then((result) => {
          if (result.data) applyRemote(result.data);
        });
        // O navegador só reconecta sozinho em quedas de rede; se o servidor responder com erro
        // (502/503 num deploy, por exemplo) o EventSource fica CLOSED para sempre.
        if (source?.readyState === EventSource.CLOSED && !stopped) {
          if (reconnectTimer) clearTimeout(reconnectTimer);
          reconnectTimer = setTimeout(connect, 3000);
        }
      };
    };
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
    connect();
    return () => {
      stopped = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      discardQueuedSnapshot();
      source?.close();
    };
  }, [applyRemote, initializing, postPresence, pushPresence, setAppStatus]);

  useEffect(() => {
    const doc = iframeRef.current?.contentDocument;
    if (!doc || !initializedRef.current) return;
    const onClose = () => window.requestAnimationFrame(() => {
      if (!doc.querySelector('dialog[open]')) flushPendingRemote();
    });
    doc.addEventListener('close', onClose, true);
    return () => doc.removeEventListener('close', onClose, true);
  }, [initializing, flushPendingRemote]);

  useEffect(() => () => {
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
  }, []);

  const retry = () => {
    if (recoveryBusy) return;
    setRecoveryBusy(true);
    startupDeadlineRef.current = session
      ? { userId: session.userId, deadline: window.performance.now() + 45_000 }
      : null;
    setAuthTimedOut(false);
    setStartupTimedOut(false);
    if (!session) {
      setModuleError(false);
      setHtmlReady(false);
      setFrameAttempt((attempt) => attempt + 1);
      void refreshSession().finally(() => setRecoveryBusy(false));
      return;
    }
    frameRecoveryRef.current = 0;
    setConnectionError(false);
    setSnapshotError(false);
    setModuleError(false);
    setInitializing(true);
    setHtmlReady(false);
    enhancementsReadyRef.current = false;
    setFrameAttempt((attempt) => attempt + 1);
    void Promise.allSettled([refreshSession(), pautaQuery.refetch()])
      .finally(() => setRecoveryBusy(false));
  };

  const iframeVisible = authReady && (
    !session || (htmlReady && !initializing && !snapshotError && !moduleError && !startupTimedOut && !pautaQuery.isError && !cmLoading)
  );

  return (
    <main className="shared-pauta" data-testid="shared-pauta">
      {authReady && session && (
        <iframe
          ref={iframeRef}
          className="pauta-original-frame"
          key={`shared-pauta:${session.userId}:${triageWorkspace ? "filter" : "gabinete"}`}
          src={`/api/app/${triageWorkspace ? "filter" : "gabcmt"}?v=${pautaBuildId}&shared=1&boot=${frameAttempt}`}
          title={pageTitle(pathname)}
          onLoad={() => {
          setHtmlReady(false);
          setModuleError(false);
          enhancementsReadyRef.current = false;
          roleObserverRef.current?.disconnect();
          if (!session) return;
          const frameDocument = iframeRef.current?.contentDocument;
          const frameWindow = iframeRef.current?.contentWindow as
            | (Window & {
                __cmtModulesReady?: boolean;
                __cmtModulesError?: boolean;
                CMT_AUTH_SESSION?: AppSession;
                __cmtPublicProfilePathFor?: (name: string) => string | null;
              })
            | null;
          if (!frameDocument || !frameWindow) {
            setModuleError(true);
            return;
          }
          // A restart or rotating cookie can load a 401/502 document into an
          // iframe. Revalidate once instead of waiting forever for absent scripts.
          if (!frameWindow.CMT_AUTH_SESSION?.authenticated ||
              frameWindow.CMT_AUTH_SESSION.userId !== session.userId) {
            if (frameRecoveryRef.current >= 1) { setModuleError(true); return; }
            frameRecoveryRef.current += 1;
            void refreshSession().then((approved) => {
              if (approved?.userId === activeUserRef.current) setFrameAttempt((attempt) => attempt + 1);
            });
            return;
          }
          applyAuthToFrame(session);
          // /cm presentation only: exclusive viewport, no shared sidebar/footer/rail.
          let cmLayoutStyle = frameDocument.getElementById('cmt-cm-exclusive-layout') as HTMLStyleElement | null;
          if (!cmLayoutStyle) {
            cmLayoutStyle = frameDocument.createElement('style');
            cmLayoutStyle.id = 'cmt-cm-exclusive-layout';
            frameDocument.head.appendChild(cmLayoutStyle);
          }
          cmLayoutStyle.textContent = cmExclusiveLayoutCss;
          frameDocument.documentElement.toggleAttribute('data-cm-route', isCmRoute(location));
          let tabLayoutStyle = frameDocument.getElementById('cmt-tab-layout-parity') as HTMLStyleElement | null;
          if (!tabLayoutStyle) {
            tabLayoutStyle = frameDocument.createElement('style');
            tabLayoutStyle.id = 'cmt-tab-layout-parity';
            frameDocument.head.appendChild(tabLayoutStyle);
          }
          tabLayoutStyle.textContent = `
            html.alt-on .app-main {
              --cmt-tab-page-min-height: max(0px, calc(100dvh - var(--dock-h, 58px) - 112px));
            }
            html.alt-on .app-main > #app-content,
            html.alt-on .app-main > #cmtx-view,
            html.alt-on .app-main #controle-pauta-root,
            html.alt-on .app-main #pauta-decisions-root,
            html.alt-on .app-main #pauta-decisions-root .dec-area,
            html.alt-on .app-main #controle-pauta-root .pc-pauta {
              box-sizing: border-box !important;
              width: 100% !important;
              max-width: 100% !important;
              min-width: 0 !important;
              min-height: var(--cmt-tab-page-min-height) !important;
            }
            html.alt-on .app-main > #app-content,
            html.alt-on .app-main > #cmtx-view {
              margin-right: 0 !important;
              align-self: stretch !important;
            }
            html.alt-on.cmtx-view-on .app-main > #cmtx-view {
              flex: 1 1 auto !important;
            }
            @media (max-width: 680px) {
              html.alt-on .app-main {
                --cmt-tab-page-min-height: max(0px, calc(100dvh - var(--dock-h, 58px) - 88px));
              }
            }
          `;
          frameDocument.getElementById('cmt-server-profile-settings-format')?.remove();
          installEquipeUnificada(frameDocument, frameWindow);
          // Profile launchers are owned by CMTProfileDialog inside the frame.
          let attempts = 0;
          const waitForEmbeddedModules = () => {
            if (frameWindow.__cmtModulesError) {
              setModuleError(true);
              return;
            }
            if (frameWindow.__cmtModulesReady) {
              frameRecoveryRef.current = 0;
              enhancementsReadyRef.current = true;
              setHtmlReady(true);
              return;
            }
            attempts += 1;
            if (attempts >= 225) {
              setModuleError(true);
              return;
            }
            window.setTimeout(waitForEmbeddedModules, 40);
          };
          waitForEmbeddedModules();
          }}
          style={{ visibility: iframeVisible ? 'visible' : 'hidden' }}
          data-testid="pauta-original-frame"
        />
      )}
      {conflicts.length > 0 && (
        <div className="pauta-conflict-overlay">
          <section className="pauta-conflict-panel" role="alert" aria-live="assertive" data-testid="pauta-conflict-panel">
            <h2>Conflito de edição</h2>
            <p>Duas pessoas alteraram o mesmo campo. Escolha qual valor deve ser mantido em cada item.</p>
            <ul>
              {conflicts.map((conflict, index) => (
                <li key={`${describePath(conflict.path)}-${index}`} data-testid="pauta-conflict">
                  <strong>{describePath(conflict.path)}</strong>
                  <div className="pauta-conflict-values">
                    <div>
                      <span>Seu valor</span>
                      <p>{describeValue(conflict.localValue, conflict.localExists)}</p>
                      <button type="button" onClick={() => resolveConflict(conflict, 'local')}>
                        Manter meu valor
                      </button>
                    </div>
                    <div>
                      <span>Valor remoto</span>
                      <p>{describeValue(conflict.remoteValue, conflict.remoteExists)}</p>
                      <button type="button" onClick={() => resolveConflict(conflict, 'remote')}>
                        Usar valor remoto
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </section>
        </div>
      )}
      {loaderVisible && (
        <GabineteLoader
          variant="fullscreen"
          cover
          userName={session?.name}
          salutation={cmRoute ? CM_SALUTATION : undefined}
          welcome={cmRoute ? true : loginWelcome}
          welcomeText={cmRoute ? CM_INFO : undefined}
          className={cmRoute ? 'cmt-loader--cm' : undefined}
          error={loaderError}
          stage={pautaQuery.isError
            ? 'Não foi possível carregar a pauta compartilhada.'
            : moduleError
              ? (cmRoute ? 'Não foi possível preparar a Mesa do Desembargador. Tente novamente.' : 'Não foi possível preparar a interface atual do Gabinete CMT.')
              : snapshotError
                ? 'O servidor respondeu, mas a lista de processos veio em um formato inesperado.'
                : cmRoute
                  ? (!authReady ? 'Confirmando seu acesso exclusivo…'
                    : !htmlReady ? 'Carregando a Mesa do Desembargador…'
                    : initializing ? 'Sincronizando os processos e os avisos…'
                    : 'Preparando a Mesa do Desembargador…')
                  : startupMessage}
        >
          {/* na Mesa do CM as opções só aparecem se a abertura falhar */}
          {(!cmRoute || loaderError) && <>
          <button
            type="button"
            onClick={retry}
            disabled={recoveryBusy}
            data-testid="retry-shared-pauta"
          >
            {recoveryBusy ? 'Verificando acesso…' : 'Verificar acesso'}
          </button>
          <button
            type="button"
            className="cmt-loader__secondary"
            onClick={() => { void logoutSafely().catch(() => undefined); }}
            disabled={logoutBusy}
            data-testid="logout-from-loader"
          >
            {logoutBusy ? 'Encerrando sessão…' : session ? 'Sair e voltar ao login' : 'Voltar ao login'}
          </button>
          </>}
          {logoutError && <p className="cmt-loader__action-error" role="alert">{logoutError}</p>}
        </GabineteLoader>
      )}
      {!initializing && connectionError && (
        <span className="pauta-connection-note" role="status" data-testid="connection-status">
          Reconectando à pauta compartilhada
        </span>
      )}
    </main>
  );
}
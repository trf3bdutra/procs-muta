import { useEffect, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import AppAccessGate, { useAppAuth } from '@/components/app-access-gate';
import { MembershipNotice, SignInPage, safeNextPath } from '@/components/account-access-pages';
import { GabineteLoader } from '@/components/loading';
import NotFound from '@/pages/not-found';
import SharedPauta from '@/pages/shared-pauta';
import CmAccessLinkPage from '@/pages/cm-access-link';
import { normalizeRouterBase } from '@/lib/router-base';
import { canAccessGlobalSettings } from '@/lib/app-role';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  return (
    <AppAccessGate>
      <AuthenticatedHome />
    </AppAccessGate>
  );
}

function AuthenticatedHome() {
  const { session, ready, signedIn, status, email, message, cmAccessError, refreshSession, logout } = useAppAuth();
  const [location, navigate] = useLocation();
  const pathname = location.split(/[?#]/, 1)[0];
  useEffect(() => {
    if (!ready) return;
    if (session && pathname === '/cm-link' && !canAccessGlobalSettings(session.role)) {
      navigate('/gabinete', { replace: true });
      return;
    }
    if (session && pathname === '/') {
      navigate('/gabinete', { replace: true });
      return;
    }
    if (session && pathname === '/sign-in') {
      navigate(safeNextPath(), { replace: true });
      return;
    }
    if (!session && !signedIn && pathname !== '/sign-in' && !(pathname === '/cm' && cmAccessError)) {
      const next = `${window.location.pathname}${window.location.search}${window.location.hash}`;
      navigate(`/sign-in?next=${encodeURIComponent(next)}`, { replace: true });
    }
  }, [ready, session, signedIn, pathname, location, navigate, cmAccessError]);
  if (!ready) return <GabineteLoader variant="fullscreen" welcome={false} stage="Confirmando seu acesso…" />;
  if (!session) {
    if (!signedIn) {
      if (pathname === '/cm' && cmAccessError) {
        return (
          <main className="flex min-h-screen items-center justify-center bg-slate-100 p-6">
            <section className="max-w-lg rounded-xl border bg-white p-6 shadow-lg">
              <h1 className="text-lg font-semibold text-slate-900">Link de acesso indisponível</h1>
              <p className="mt-2 text-sm leading-6 text-slate-600">{cmAccessError}</p>
              <a className="mt-5 inline-flex rounded-md bg-emerald-900 px-4 py-2 text-sm font-medium text-white" href="/sign-in">
                Ir para o login
              </a>
            </section>
          </main>
        );
      }
      return pathname === '/sign-in'
        ? <SignInPage />
        : <GabineteLoader variant="fullscreen" welcome={false} stage="Abrindo o acesso do Gabinete…" />;
    }
    return (
      <MembershipNotice
        status={status}
        email={email}
        message={message}
        onRetry={() => { void refreshSession(); }}
        onSignOut={logout}
      />
    );
  }
  if (pathname === '/' || pathname === '/sign-in') {
    return <GabineteLoader variant="fullscreen" welcome={false} userName={session.name} stage="Abrindo o destino solicitado…" />;
  }
  if (pathname === '/cm-link') {
    return canAccessGlobalSettings(session.role) ? <CmAccessLinkPage /> : <GabineteLoader variant="fullscreen" welcome={false} stage="Abrindo o Gabinete…" />;
  }
  if (pathname === '/configuracoes-globais' || pathname.startsWith('/configuracoes-globais/')) {
    return canAccessGlobalSettings(session.role) ? <SharedPauta /> : <RestrictedSettingsPage />;
  }
  return <SharedPauta />;
}

function RestrictedSettingsPage() {
  const [, navigate] = useLocation();
  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-100 p-6">
      <section role="alert" className="max-w-lg rounded-xl border bg-white p-7 shadow-lg">
        <p className="text-xs font-bold uppercase tracking-[0.16em] text-amber-700">Área restrita</p>
        <h1 className="mt-2 text-xl font-semibold text-slate-900">Configurações Globais</h1>
        <p className="mt-2 text-sm leading-6 text-slate-600">Acesso restrito à Administração e ao perfil Editor.</p>
        <button
          type="button"
          className="mt-5 rounded-md bg-emerald-900 px-4 py-2 text-sm font-medium text-white"
          onClick={() => navigate('/gabinete', { replace: true })}
        >
          Voltar ao Gabinete
        </button>
      </section>
    </main>
  );
}

function SignIn() {
  return (
    <AppAccessGate>
      <AuthenticatedHome />
    </AppAccessGate>
  );
}

const RESERVED_TOP_LEVEL_ROUTES = new Set([
  '', 'sign-in', 'gabinete', 'filter', 'tria', 'triagem', 'sessions', 'session', 'cm', 'ass', 'cm-link', 'cmt', 'ementario', 'gerador', 'padrao', 'accounts', 'api', 'acervo-app',
  'visualizacao-avancada', 'servidor', 'serv-user', 'pauta', 'mono',
  'repositorio', 'repertorio', 'protocolo', 'diretrizes', 'diretrizes-e-fluxos',
  'conformidade', 'jurisprudencia', 'precedentes', 'controle-de-pauta',
  'controle-de-decisoes', 'controle-de-triagem', 'configuracoes-globais',
]);

function LegacyServerRoute() {
  const [location, navigate] = useLocation();
  const segment = location.split('?')[0].replace(/^\/+|\/+$/g, '').toLowerCase();
  const isReserved = RESERVED_TOP_LEVEL_ROUTES.has(segment);

  useEffect(() => {
    if (isReserved) return;
    if (/^[a-z0-9][a-z0-9._-]{0,63}$/.test(segment)) {
      navigate('/gabinete?perfil=1', { replace: true });
    } else {
      navigate('/gabinete', { replace: true });
    }
  }, [isReserved, navigate, segment]);

  if (segment === 'servidor') return <NotFound />;
  if (isReserved) return <Home />;
  return <main role="status" style={{ padding: 24 }}>Atualizando o endereço do perfil do servidor…</main>;
}

/** /cmt era o endereço da Mesa do CM; agora é /cm. Links e favoritos antigos chegam ao novo sem nova entrada no histórico. */
function LegacyCmRedirect() {
  const [, navigate] = useLocation();
  useEffect(() => { navigate('/cm', { replace: true }); }, [navigate]);
  return <GabineteLoader variant="fullscreen" welcome={false} stage="Abrindo a Mesa do CM…" />;
}

function LegacyCommandRedirect() {
  const [, navigate] = useLocation();
  useEffect(() => { navigate('/gabinete', { replace: true }); }, [navigate]);
  return <GabineteLoader variant="fullscreen" welcome={false} stage="Abrindo o Gabinete…" />;
}

/** Old inner-page URLs now enter the single Gabinete shell. */
function LegacyGabinetePageRedirect() {
  const [, navigate] = useLocation();
  useEffect(() => { navigate('/gabinete', { replace: true }); }, [navigate]);
  return <GabineteLoader variant="fullscreen" welcome={false} stage="Abrindo o Gabinete…" />;
}

function LegacyTriagemRedirect() {
  const [, navigate] = useLocation();
  useEffect(() => { navigate('/tria', { replace: true }); }, [navigate]);
  return <GabineteLoader variant="fullscreen" welcome={false} stage="Abrindo a Triagem…" />;
}

/** /controle-de-pauta era o endereço da Pauta de Julgamento; agora é /pauta. */
function LegacyPautaRedirect() {
  const [, navigate] = useLocation();
  useEffect(() => { navigate('/pauta', { replace: true }); }, [navigate]);
  return <GabineteLoader variant="fullscreen" welcome={false} stage="Abrindo a Pauta de Julgamento…" />;
}

/** /controle-de-decisoes era o endereço do Controle de Monocráticas; agora é /mono. */
function LegacyMonoRedirect() {
  const [, navigate] = useLocation();
  useEffect(() => { navigate('/mono', { replace: true }); }, [navigate]);
  return <GabineteLoader variant="fullscreen" welcome={false} stage="Abrindo o Controle de Monocráticas…" />;
}

function LegacyServerProfileRedirect() {
  const [, navigate] = useLocation();
  useEffect(() => { navigate('/gabinete?perfil=1', { replace: true }); }, [navigate]);
  return <GabineteLoader variant="fullscreen" welcome={false} stage="Abrindo a página do servidor…" />;
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/sign-in" component={SignIn} />
        <Route path="/" component={Home} />
        <Route path="/gabinete" component={Home} />
        {/* Uma rota por página do Gabinete. */}
        <Route path="/pauta" component={Home} />
        <Route path="/mono" component={Home} />
        <Route path="/session" component={LegacyGabinetePageRedirect} />
        {/* Endereços antigos seguem válidos e levam às rotas novas. */}
        <Route path="/controle-de-pauta" component={LegacyPautaRedirect} />
        <Route path="/controle-de-decisoes" component={LegacyMonoRedirect} />
        <Route path="/tria" component={Home} />
        <Route path="/triagem" component={LegacyTriagemRedirect} />
        <Route path="/sessions" component={LegacyGabinetePageRedirect} />
        <Route path="/filter" component={LegacyTriagemRedirect} />
        {/* As antigas páginas de apoio foram retiradas; links antigos voltam ao Gabinete. */}
        <Route path="/ementario" component={LegacyGabinetePageRedirect} />
        <Route path="/repositorio" component={LegacyGabinetePageRedirect} />
        <Route path="/protocolo" component={LegacyGabinetePageRedirect} />
        <Route path="/repertorio" component={LegacyGabinetePageRedirect} />
        <Route path="/diretrizes" component={LegacyGabinetePageRedirect} />
        <Route path="/diretrizes-e-fluxos" component={LegacyGabinetePageRedirect} />
        <Route path="/conformidade" component={LegacyGabinetePageRedirect} />
        <Route path="/jurisprudencia" component={LegacyGabinetePageRedirect} />
        <Route path="/precedentes" component={LegacyGabinetePageRedirect} />
        {/* The Generator is now a Mesa face; old standalone links return to the Gabinete shell. */}
        <Route path="/gerador/:processo" component={LegacyGabinetePageRedirect} />
        <Route path="/gerador" component={LegacyGabinetePageRedirect} />
        <Route path="/cm" component={Home} />
        <Route path="/ass" component={LegacyGabinetePageRedirect} />
        <Route path="/cm-link" component={Home} />
        <Route path="/cmt" component={LegacyCmRedirect} />
        {/* Legacy inner-page URLs normalize to the single Gabinete page. */}
        <Route path="/controle-de-triagem" component={LegacyTriagemRedirect} />
        <Route path="/configuracoes-globais" component={Home} />
        <Route path="/configuracoes-globais/:area" component={Home} />
        <Route path="/serv-user" component={LegacyServerProfileRedirect} />
        {/* /servidor is an alias; the authenticated server page lives at /serv-user. */}
        <Route path="/servidor" component={LegacyServerProfileRedirect} />
        <Route path="/padrao" component={NotFound} />
        <Route path="/command" component={LegacyCommandRedirect} />
        <Route path="/command/" component={LegacyCommandRedirect} />
        <Route path="/comando-:tab" component={LegacyCommandRedirect} />
        {/* Links antigos de perfis levam à página nativa do usuário autenticado. */}
        <Route path="/serv-:serverSlug" component={LegacyServerRoute} />
        <Route path="/:serverSlug" component={LegacyServerRoute} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={normalizeRouterBase(import.meta.env.BASE_URL)}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { Link, useLocation } from "wouter";
import { useAppAuth } from "./app-access-gate";
import { resolveLoginDestination } from "@/lib/login-destination";
import { LogIn, RefreshCw, LogOut } from "lucide-react";
import { markLoginWelcomePending } from "@/lib/login-welcome";
import {
  ACCESS_COPY, AccessCard, AccessHeading, AccessPanel, AccessShell, AccountLine, BrandLockup, INSTITUTION, NO_PUBLIC_SIGNUP,
  PREPARING, SESSION_ACTIONS, SIGN_IN, extraMessage, serverColor, type AccessStatus,
} from "./access";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

export function safeNextPath(): string {
  return resolveLoginDestination(window.location.search, window.location.origin);
}

function LocalSignIn() {
  const [, navigate] = useLocation();
  const { refreshSession } = useAppAuth();
  const [servers, setServers] = useState<string[]>([]);
  const [choice, setChoice] = useState("");
  const [optionsLoaded, setOptionsLoaded] = useState(false);
  const [optionsError, setOptionsError] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => {
    let active = true;
    fetch(`${basePath}/api/auth/login-options`, { credentials: "same-origin", cache: "no-store" })
      .then((response) => {
        if (!response.ok) throw new Error(SIGN_IN.optionsFailed);
        return response.json() as Promise<{ servers: string[] }>;
      })
      .then((data) => {
        if (!active) return;
        if (!Array.isArray(data.servers)) throw new Error(SIGN_IN.badList);
        setServers(data.servers.filter((name) => typeof name === "string"));
        setOptionsLoaded(true);
      })
      .catch(() => {
        if (!active) return;
        setOptionsError(SIGN_IN.loadFailed);
        setOptionsLoaded(true);
      });
    return () => { active = false; };
  }, []);
  return <form className="local-sign-in" onSubmit={async (event) => {
    event.preventDefault(); setError("");
    if (!choice) { setError(SIGN_IN.pickServer); return; }
    if (!password) { setError(SIGN_IN.typePassword); return; }
    setBusy(true);
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 15_000);
    try {
      const response = await fetch(`${basePath}/api/auth/login`, {
        method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role: "equipe", server: choice, password }),
        signal: controller.signal,
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || SIGN_IN.failed);
      const session = await refreshSession();
      if (!session) throw new Error(SIGN_IN.sessionUnconfirmed);
      markLoginWelcomePending(session.userId);
      navigate(safeNextPath());
    } catch (e) {
      const error = e as { name?: string; message?: string };
      setError(error.name === "AbortError" ? SIGN_IN.timeout : error.message || SIGN_IN.failed);
    } finally {
      window.clearTimeout(timeout);
      setPassword(""); setBusy(false);
    }
  }}>
    <fieldset className="local-server-fieldset">
      <legend>Selecione seu servidor</legend>
      <div className="local-server-grid" role="group" aria-label="Servidor">
        {servers.map((name, index) => {
          const initials = name.slice(0, 2).toUpperCase();
          return <button key={name} type="button" title={name} className={`local-server-choice${choice === name ? " selected" : ""}`}
            aria-label={`Selecionar ${name}`} aria-pressed={choice === name}
            onClick={() => { setChoice(name); setError(""); }} disabled={busy}>
            <span className="local-server-dot" aria-hidden="true" style={{ backgroundColor: serverColor(index) }}>{initials}</span>
            <span className="local-server-name">{name}</span>
          </button>;
        })}
      </div>
      {optionsLoaded && servers.length === 0 && <p className="local-sign-in-hint">{SIGN_IN.noServers}</p>}
      {optionsError && <p className="local-sign-in-hint" role="status">{optionsError}</p>}
    </fieldset>
    <label htmlFor="account-password">Senha</label>
    <input id="account-password" type="password" aria-label="Senha do servidor selecionado" placeholder="Digite sua senha"
      autoComplete="current-password" maxLength={1024} value={password} onChange={(e) => setPassword(e.target.value)} disabled={busy} />
    {error && <p role="alert" aria-live="assertive" className="local-sign-in-error">{error}</p>}
    <button type="submit" disabled={busy}>{busy ? SIGN_IN.submitting : SIGN_IN.submit}</button>
    <small>{SIGN_IN.footnote}</small>
  </form>;
}

/** Login: a página auth-login.html continua no iframe, e o formulário entra nela por portal. */
export function SignInPage() {
  const [mountNode, setMountNode] = useState<HTMLElement | null>(null);
  const attachSignIn = (frame: HTMLIFrameElement | null) => {
    const target = frame?.contentDocument?.getElementById("cmtx-sign-in-mount");
    if (target) setMountNode(target);
  };
  useEffect(() => {
    const subtitle = mountNode?.ownerDocument.getElementById("hav-s");
    if (subtitle) subtitle.textContent = SIGN_IN.hint;
  }, [mountNode]);
  return (
    <main className="cmt-access cmt-existing-login">
      <iframe
        className="cmt-existing-login-frame"
        src={`${basePath}/auth-login.html`}
        title={SIGN_IN.frameTitle}
        onLoad={(event) => attachSignIn(event.currentTarget)}
      />
      {mountNode && createPortal(<LocalSignIn />, mountNode)}
    </main>
  );
}

/** Abertura do app: conferindo a sessão, com tentativa e saída quando algo falha. */
export function AccessPendingPage({
  message = PREPARING.defaultMessage,
  errorMessage,
  onRetry,
  retrying = false,
  onLogout,
}: {
  message?: string;
  errorMessage?: string;
  onRetry?: () => void;
  retrying?: boolean;
  onLogout?: () => Promise<void>;
}) {
  const [loggingOut, setLoggingOut] = useState(false);
  const [logoutError, setLogoutError] = useState("");
  const endSession = async () => {
    if (!onLogout || loggingOut) return;
    setLoggingOut(true);
    setLogoutError("");
    try {
      await onLogout();
    } catch (error) {
      setLoggingOut(false);
      setLogoutError(error instanceof Error && error.message ? error.message : SESSION_ACTIONS.endFailed);
    }
  };
  return (
    <AccessShell ground="loading" className="cmt-access-pending">
      <AccessCard className="cmt-pending-card" aria-labelledby="pending-title">
        <div className="cmt-pending-mark" aria-hidden="true"><span /></div>
        <p className="cmt-access-kicker">{PREPARING.kicker}</p>
        <h1 className="cmt-h" id="pending-title">{PREPARING.title}</h1>
        <p className="cmt-p cmt-pending-message" role="status" aria-live="polite">{message}</p>
        {errorMessage && <div className="cmt-err" role="alert" data-testid="startup-error">{errorMessage}</div>}
        {(onRetry || onLogout) && (
          <div className="cmt-actions">
            {onRetry && (
              <button type="button" className="cmt-btn primary" onClick={onRetry} disabled={retrying} data-testid="retry-shared-pauta">
                <RefreshCw size={16} aria-hidden="true" />
                {retrying ? PREPARING.retrying : PREPARING.retry}
              </button>
            )}
            {onLogout && (
              <button type="button" className="cmt-btn ghost" onClick={() => void endSession()} disabled={loggingOut} data-testid="button-pending-sign-out">
                <LogOut size={16} aria-hidden="true" />{loggingOut ? SESSION_ACTIONS.ending : SESSION_ACTIONS.endSession}
              </button>
            )}
          </div>
        )}
        {logoutError && <p role="alert" className="cmt-err cmt-logout-error">{logoutError}</p>}
      </AccessCard>
    </AccessShell>
  );
}

/** Página para quem procura se cadastrar: não há cadastro público. */
export function ActivationPage() {
  return (
    <AccessShell ground="login">
      <AccessCard data-testid="status-no-public-signup" aria-labelledby="activation-title">
        <BrandLockup subtitle={INSTITUTION.productTagline} />
        <AccessHeading copy={NO_PUBLIC_SIGNUP} titleId="activation-title" />
        <div className="cmt-actions">
          <Link href="/sign-in" className="cmt-btn primary" data-testid="link-back-login"><LogIn size={16} aria-hidden="true" />{SESSION_ACTIONS.backToLogin}</Link>
        </div>
      </AccessCard>
    </AccessShell>
  );
}

type NoticeProps = {
  status: AccessStatus;
  email?: string;
  message?: string;
  onRetry: () => void;
  onSignOut: () => Promise<void>;
};

/** Conta conferida, mas sem acesso liberado (pendente, não autorizada, desativada, e-mail ou falha). */
export function MembershipNotice({ status, email, message, onRetry, onSignOut }: NoticeProps) {
  const extra = extraMessage(status, message);
  const [loggingOut, setLoggingOut] = useState(false);
  const [logoutError, setLogoutError] = useState("");
  const endSession = async () => {
    if (loggingOut) return;
    setLoggingOut(true);
    setLogoutError("");
    try {
      await onSignOut();
    } catch (error) {
      setLogoutError(error instanceof Error && error.message ? error.message : SESSION_ACTIONS.endFailed);
    } finally {
      setLoggingOut(false);
    }
  };
  return (
    <AccessShell ground="notice" className="cmt-access-membership">
      <AccessPanel className="cmt-membership-card" role="status" data-testid={`status-membership-${status}`} aria-labelledby="membership-title">
        <AccessHeading copy={ACCESS_COPY[status]} titleId="membership-title" />
        {email && <AccountLine value={email} data-testid="text-email" />}
        {extra && <div className="cmt-err" role={status === "error" ? "alert" : "note"} data-testid="text-membership-message">{extra}</div>}
        <div className="cmt-actions">
          <button type="button" className="cmt-btn primary" onClick={onRetry} data-testid="button-retry"><RefreshCw size={16} aria-hidden="true" />{SESSION_ACTIONS.verify}</button>
          <button type="button" className="cmt-btn ghost" onClick={() => void endSession()} disabled={loggingOut} data-testid="button-sign-out">
            <LogOut size={16} aria-hidden="true" />{loggingOut ? SESSION_ACTIONS.ending : SESSION_ACTIONS.endSession}
          </button>
        </div>
        {logoutError && <p role="alert" className="cmt-err cmt-logout-error">{logoutError}</p>}
      </AccessPanel>
    </AccessShell>
  );
}

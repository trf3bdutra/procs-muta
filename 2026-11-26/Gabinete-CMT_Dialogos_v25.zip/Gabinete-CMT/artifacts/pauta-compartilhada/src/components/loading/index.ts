export { GabineteLoader } from "./GabineteLoader";
export type { GabineteLoaderProps, LoaderVariant } from "./GabineteLoader";

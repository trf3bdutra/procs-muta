import { useId, type ReactNode } from 'react';
import { BRAND_ASSETS, INSTITUTION } from '../access/brand';
import '../access/tokens.css';
import './gabinete-loader.css';

/** Único sistema de carregamento do Gabinete CMT.
 *  fullscreen = abertura do app · overlay = operação que bloqueia · inline = região de conteúdo. */
export type LoaderVariant = 'fullscreen' | 'overlay' | 'inline';

export interface GabineteLoaderProps {
  variant?: LoaderVariant;
  /** Etapa real da operação em curso (a única informação confiável da tela). */
  stage?: string;
  /** Detalhe opcional abaixo da etapa. */
  detail?: string;
  /** Nome da sessão autenticada; a saudação usa só o primeiro nome. Nunca fixo no componente. */
  userName?: string | null;
  /** Mensagem de boas-vindas da tela cheia. */
  welcome?: boolean;
  /** Tratamento completo na saudação ("Boa tarde, Dr. Carlos Muta!"), em lugar do primeiro nome da sessão. */
  salutation?: string;
  /** Texto próprio sob a saudação, em lugar da frase de boas-vindas do login. */
  welcomeText?: string;
  /** Título específico de uma área, em lugar da saudação de entrada. */
  heading?: string;
  /** 0–100 quando houver progresso real; sem ele, a barra é indeterminada. */
  progress?: number;
  /** Estado de erro: sem barra nem frases; a etapa vira a mensagem do problema. */
  error?: boolean;
  /** Ocupa só o contêiner posicionado em que está (em vez da janela inteira). */
  cover?: boolean;
  /** Outro logotipo. Um logotipo escuro sobre fundo claro recebe o filtro que recorta o fundo e tinge de ouro. */
  logoSrc?: string;
  className?: string;
  /** Ações (por exemplo, tentar de novo ou sair), mostradas abaixo da barra. */
  children?: ReactNode;
}

const DEFAULT_LOGO = BRAND_ASSETS.starGold;

function greeting() {
  const hour = new Date().getHours();
  return hour < 12 ? 'Bom dia' : hour < 18 ? 'Boa tarde' : 'Boa noite';
}

export function GabineteLoader({
  variant = 'fullscreen',
  stage = 'Preparando os processos e os dados da equipe…',
  detail,
  userName,
  welcome = true,
  salutation,
  welcomeText,
  heading,
  progress,
  error = false,
  cover = false,
  logoSrc = DEFAULT_LOGO,
  className = '',
  children,
}: GabineteLoaderProps) {
  const filterId = useId().replace(/:/g, '');
  const full = variant === 'fullscreen';
  const known = typeof progress === 'number' && Number.isFinite(progress);
  const value = known ? Math.min(100, Math.max(0, progress as number)) : undefined;
  const customLogo = logoSrc !== DEFAULT_LOGO;
  const name = typeof userName === 'string' ? userName.trim().split(/\s+/)[0] ?? '' : '';
  const classes = [
    'cmt-loader',
    `cmt-loader--${variant}`,
    cover ? 'cmt-loader--cover' : '',
    error ? 'is-error' : '',
    className,
  ].filter(Boolean).join(' ');

  return (
    <div className={classes} role="status" aria-live="polite" aria-busy={!error}>
      {variant !== 'inline' && customLogo && !full && (
        <svg className="cmt-loader__defs" aria-hidden="true" focusable="false" width="0" height="0">
          <filter id={filterId} colorInterpolationFilters="sRGB">
            <feColorMatrix type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  -0.3333 -0.3333 -0.3333 1 0" />
            <feComponentTransfer result="key">
              <feFuncA type="linear" slope="22" intercept="-1.05" />
            </feComponentTransfer>
            <feFlood floodColor="#e6d3a8" result="tint" />
            <feComposite in="tint" in2="key" operator="in" />
          </filter>
        </svg>
      )}
      <section className="cmt-loader__content">
        {variant !== 'inline' && (customLogo ? (
          <img
            className="cmt-loader__logo"
            src={logoSrc}
            alt="Logotipo do Gabinete CMT"
            style={!full ? { filter: `url(#${filterId}) drop-shadow(0 5px 18px rgba(0,0,0,.2))` } : undefined}
          />
        ) : (
          /* Estrela dourada com brilho que passa e ondas que se abrem em volta (cor nos tokens). */
          <span className="cmt-loader__mark" role="img" aria-label="Logotipo do Gabinete CMT"><span className="cmt-loader__star" /></span>
        ))}
        {full && (
          <>
            <p className="cmt-loader__identity">{INSTITUTION.office}</p>
            <p className="cmt-loader__greeting">
              {heading || (salutation
                ? <>{greeting()}, <em>{salutation}!</em></>
                : <>{greeting()}{name ? <>, <em>{name}.</em></> : '.'}</>)}
            </p>
            {welcome && !error && (
              <p className="cmt-loader__welcome">{welcomeText || 'Que bom ter você aqui. A Turma estava esperando por você.'}</p>
            )}
          </>
        )}
        {!error && (
          <div
            className={`cmt-loader__track${known ? ' cmt-loader__track--determinate' : ''}`}
            role={known ? 'progressbar' : undefined}
            aria-valuemin={known ? 0 : undefined}
            aria-valuemax={known ? 100 : undefined}
            aria-valuenow={value}
            aria-label={known ? 'Progresso da operação' : undefined}
            aria-hidden={known ? undefined : true}
          >
            <div className="cmt-loader__progress" style={known ? { width: `${value}%` } : undefined} />
          </div>
        )}
        <p className="cmt-loader__stage">{stage}</p>
        {detail && <p className="cmt-loader__detail">{detail}</p>}
        {children && <div className="cmt-loader__actions">{children}</div>}
      </section>
    </div>
  );
}

export default GabineteLoader;

import type { HTMLAttributes, ImgHTMLAttributes, ReactNode } from "react";
import { BRAND_ASSETS, INSTITUTION } from "./brand";
import { SESSION_ACTIONS, type AccessCopy, type BadgeTone } from "./copy";
import "./tokens.css";
import "./access.css";

/* Gabinete CMT — moldura e peças comuns das telas de acesso. */

/** Imagem de marca que some em silêncio se o arquivo não carregar (em vez do ícone de imagem quebrada). */
export function BrandImage(props: ImgHTMLAttributes<HTMLImageElement>) {
  return <img alt="" {...props} onError={(event) => { event.currentTarget.style.visibility = "hidden"; props.onError?.(event); }} />;
}

/** Faixa fina no topo e, à direita, a estrela com o nome do Gabinete. */
export function AccessMasthead() {
  return (
    <div className="cmt-access-top">
      <div className="cmt-access-strip" aria-hidden="true" />
      <header className="cmt-access-header">
        <span className="cmt-brand-mark" aria-hidden="true" />
        <strong>{INSTITUTION.product}</strong>
      </header>
    </div>
  );
}

/** Rodapé institucional: símbolo da Justiça Federal, Tribunal e Turma. */
export function AccessFooter() {
  const label = `${INSTITUTION.justice} · ${INSTITUTION.courtName.join(" ")} · ${INSTITUTION.unitFull.join(" ")}`;
  return (
    <footer className="cmt-access-footer">
      <div className="cmt-access-signature" role="img" aria-label={label}>
        <BrandImage src={BRAND_ASSETS.jfSymbol} />
        <span className="cmt-court">{INSTITUTION.courtFooter[0]}<br />{INSTITUTION.courtFooter[1]}</span>
        <i aria-hidden="true" />
        <span className="cmt-unit">{INSTITUTION.unitFull[0]}<br />{INSTITUTION.unitFull[1]}</span>
      </div>
    </footer>
  );
}

/** Estrela monumental, anéis de contorno e trama do símbolo, atrás de todo o conteúdo. */
export function AccessBackdrop() {
  return (
    <div className="cmt-access-backdrop" aria-hidden="true">
      <div className="cmt-access-backdrop__contour" />
      <span className="cmt-access-backdrop__ring" />
      <span className="cmt-access-backdrop__ring" />
      <span className="cmt-access-backdrop__mark" />
    </div>
  );
}

/** Variante do fundo: a luz muda de lugar e o verde cede ao azul aos poucos. */
export type AccessGround = "login" | "loading" | "notice";

type ShellProps = HTMLAttributes<HTMLElement> & { align?: "center" | "start"; ground?: AccessGround; children: ReactNode };

/** Fundo com sobreposições, cabeçalho, área central e rodapé institucional. */
export function AccessShell({ align = "center", ground = "notice", className = "", children, ...rest }: ShellProps) {
  const classes = ["cmt-access", `cmt-access--${ground}`, align === "start" ? "cmt-access--start" : "", className].filter(Boolean).join(" ");
  return (
    <main className={classes} {...rest}>
      <AccessBackdrop />
      <AccessMasthead />
      <div className="cmt-access-main">{children}</div>
      <AccessFooter />
    </main>
  );
}

type CardProps = HTMLAttributes<HTMLElement> & { wide?: boolean; children: ReactNode };

/** Cartão branco e plano. */
export function AccessCard({ wide = false, className = "", children, ...rest }: CardProps) {
  const classes = ["cmt-access-card", wide ? "cmt-access-card--wide" : "", className].filter(Boolean).join(" ");
  return <section className={classes} {...rest}>{children}</section>;
}

type BadgeProps = HTMLAttributes<HTMLSpanElement> & { tone: BadgeTone; icon?: ReactNode; children: ReactNode };

export function StatusBadge({ tone, icon, className = "", children, ...rest }: BadgeProps) {
  return <span className={`cmt-badge cmt-badge--${tone} ${className}`.trim()} {...rest}>{icon}{children}</span>;
}

/** Conteúdo pousado direto sobre o fundo, sem cartão (avisos de conta e erros). */
export function AccessPanel({ className = "", children, ...rest }: HTMLAttributes<HTMLElement> & { children: ReactNode }) {
  return <section className={`cmt-access-panel ${className}`.trim()} {...rest}>{children}</section>;
}

/** Sobrelinha com traço, título com destaque dourado e texto de um estado, a partir do registro de textos. */
export function AccessHeading({ copy, titleId }: { copy: Pick<AccessCopy, "tone" | "badge" | "title" | "highlight" | "text">; titleId: string }) {
  return (
    <>
      <p className={`cmt-overline cmt-overline--${copy.tone}`}><span aria-hidden="true" />{copy.badge}</p>
      <h1 className="cmt-display" id={titleId}>
        {copy.title}{copy.highlight && <> <em>{copy.highlight}</em></>}
      </h1>
      <p className="cmt-lead">{copy.text}</p>
    </>
  );
}

/** Nome do produto com o logotipo, para cartões que não têm o cabeçalho institucional por perto. */
export function BrandLockup({ subtitle, className = "" }: { subtitle: string; className?: string }) {
  return (
    <div className={`cmt-brand ${className}`.trim()}>
      <BrandImage src={BRAND_ASSETS.cmtSeal} />
      <div><b>{INSTITUTION.product}</b><small>{subtitle}</small></div>
    </div>
  );
}

export function AccountLine({ value, ...rest }: HTMLAttributes<HTMLParagraphElement> & { value: string }) {
  return <p className="cmt-account-email" {...rest}><span>{SESSION_ACTIONS.account}</span><strong>{value}</strong></p>;
}

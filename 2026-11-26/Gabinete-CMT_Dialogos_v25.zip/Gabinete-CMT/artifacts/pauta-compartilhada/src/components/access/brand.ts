/* Gabinete CMT — identidade: nomes institucionais, imagens e cores dos servidores.
   Nenhum componente escreve esses textos ou caminhos por conta própria. */

import jfSignature from "./assets/jf-assinatura-horizontal-negativo.svg";
import jfSymbol from "./assets/jf-simbolo-negativo.svg";
import cmtSeal from "./assets/selo-verde.svg";
import starGold from "./assets/estrela-ouro.svg";
import starBrand from "./assets/estrela-marca.svg";

/** Grafismos oficiais (pacote Gabinete_CMT_grafismos), importados pelo Vite:
 *  um arquivo ausente quebra o build em vez de aparecer quebrado na tela. */
export const BRAND_ASSETS = {
  /** Assinatura horizontal da Justiça Federal, versão negativa (Manual de Identidade Visual da JF). */
  jfSignature,
  /** Símbolo da Justiça Federal em branco (versão negativa), usado no rodapé sobre o fundo escuro. */
  jfSymbol,
  /** Selo verde do Gabinete CMT: estrela sobre a trama. */
  cmtSeal,
  /** Estrela do símbolo. No cabeçalho e no fundo ela serve de máscara (a cor vem dos tokens);
   *  no carregamento ainda aparece como imagem. */
  starGold,
  /** Estrela em degradê verde-menta → azul-céu: a logo como aparece nas telas. */
  starBrand,
} as const;

export const INSTITUTION = {
  justice: "JUSTIÇA FEDERAL",
  court: "TRF3",
  courtName: ["Tribunal Regional Federal", "da 3ª Região"] as const,
  /** Quebra usada no rodapé: "Tribunal Regional / Federal da 3ª Região". */
  courtFooter: ["Tribunal Regional", "Federal da 3ª Região"] as const,
  /** Turma por extenso, em duas linhas no rodapé. */
  unitFull: ["Turma Regional de", "Mato Grosso do Sul"] as const,
  product: "Gabinete CMT",
  productTagline: "Pauta compartilhada",
  unit: "Turma Regional · MS",
  office: "Gabinete do Des. Fed. Carlos Muta",
} as const;

/** Cores das iniciais dos servidores, na ordem da lista. */
export const SERVER_COLORS = [
  "#2f5d8a", "#1f7a6d", "#7457ad", "#b0761f", "#3b8f80", "#c25e7a",
  "#4f7fc4", "#5a9e5a", "#d9822b", "#8b6cc9", "#6b8389",
] as const;

export function serverColor(index: number): string {
  return SERVER_COLORS[index % SERVER_COLORS.length];
}

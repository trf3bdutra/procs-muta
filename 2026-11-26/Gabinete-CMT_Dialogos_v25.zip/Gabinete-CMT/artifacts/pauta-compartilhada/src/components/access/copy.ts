import { AlertTriangle, Clock, KeyRound, MailWarning, ShieldOff, UserX, type LucideIcon } from "lucide-react";

/* Gabinete CMT — todos os textos das telas de acesso num lugar só. */

export type AccessStatus = "pending" | "unregistered" | "disabled" | "unverified" | "error";
export type BadgeTone = "warn" | "danger" | "ok" | "info";

/** title + highlight formam o título; highlight sai em destaque dourado ("Não foi possível <em>verificar seu acesso.</em>"). */
export type AccessCopy = { Icon: LucideIcon; tone: BadgeTone; badge: string; title: string; highlight?: string; text: string };

export const ACCESS_COPY: Record<AccessStatus, AccessCopy> = {
  /* As contas são criadas pela Administração já com servidor; "pending" só sobra quando a conta ficou sem servidor. */
  pending: {
    Icon: Clock, tone: "warn", badge: "Sem servidor vinculado", title: "Sua conta ainda não tem", highlight: "servidor vinculado.",
    text: "O responsável pelo gabinete precisa vincular sua conta a um servidor antes de liberar a pauta.",
  },
  unregistered: {
    Icon: UserX, tone: "danger", badge: "Conta não encontrada", title: "Esta conta não está", highlight: "cadastrada.",
    text: "As contas são criadas pelo responsável pelo gabinete. Peça a ele o seu cadastro.",
  },
  disabled: {
    Icon: ShieldOff, tone: "danger", badge: "Acesso desativado", title: "O acesso desta conta está", highlight: "desativado.",
    text: "Esta conta não tem mais acesso à pauta compartilhada. Se acredita que houve engano, fale com a Administração do gabinete.",
  },
  /* Herdado do login por e-mail; com contas locais não deve ocorrer, mas o servidor ainda pode devolver o código. */
  unverified: {
    Icon: MailWarning, tone: "warn", badge: "Conta não confirmada", title: "Não foi possível", highlight: "confirmar sua conta.",
    text: "Fale com o responsável pelo gabinete para revisar o cadastro da sua conta.",
  },
  error: {
    Icon: AlertTriangle, tone: "danger", badge: "Falha na verificação", title: "Não foi possível", highlight: "verificar seu acesso.",
    text: "Houve um problema ao consultar a sua conta. Tente novamente em instantes; se persistir, fale com o responsável pelo gabinete.",
  },
};

/** Página sem cadastro público. */
export const NO_PUBLIC_SIGNUP: AccessCopy = {
  Icon: KeyRound, tone: "info", badge: "Acesso autorizado", title: "Não há", highlight: "cadastro público.",
  text: "As contas são criadas exclusivamente pelo responsável pelo gabinete. As senhas são configuradas nos Secrets do projeto. Se precisar de acesso, solicite o cadastro ao responsável.",
};

/** Abertura do app enquanto a sessão é conferida. */
export const PREPARING = {
  kicker: "Acesso ao gabinete",
  title: "Preparando seu espaço de trabalho",
  defaultMessage: "Conferindo seu acesso ao Gabinete…",
  retry: "Tentar novamente",
  retrying: "Tentando novamente…",
} as const;

export const SIGN_IN = {
  frameTitle: "Entrar no Gabinete CMT",
  hint: "Selecione seu acesso acima e digite sua senha.",
  pickServer: "Selecione seu servidor.",
  typePassword: "Digite sua senha.",
  submit: "Entrar no Gabinete",
  submitting: "Entrando…",
  footnote: "Acesso exclusivo para contas cadastradas pelo responsável.",
  noServers: "Nenhum servidor com conta ativa vinculada.",
  loadFailed: "Não foi possível carregar a lista de servidores. Atualize a página e tente novamente.",
  badList: "A lista de servidores veio em formato inválido.",
  optionsFailed: "Não foi possível carregar as opções de acesso.",
  failed: "Não foi possível entrar.",
  sessionUnconfirmed: "A senha foi aceita, mas não foi possível confirmar sua sessão. Tente novamente.",
  timeout: "O servidor demorou para responder. Verifique a conexão e tente novamente.",
} as const;

export const SESSION_ACTIONS = {
  verify: "Tentar novamente",
  signOut: "Sair",
  endSession: "Encerrar sessão",
  ending: "Encerrando sessão…",
  endFailed: "Não foi possível encerrar a sessão. Tente novamente.",
  backToLogin: "Voltar ao login",
  account: "Conta",
} as const;

/** Mensagem do navegador quando a verificação falha sem resposta útil do servidor. */
export const ACCESS_FALLBACK_MESSAGE = "Não foi possível confirmar seu acesso. Tente novamente.";

/* Mensagens que só repetem o texto padrão do estado. As do servidor espelham account-auth.ts. */
const REDUNDANT_MESSAGES = [
  ACCESS_FALLBACK_MESSAGE,
  "Não foi possível verificar seu acesso agora. Tente novamente.",
  "Sua conta aguarda vínculo com um servidor.",
  "Seu acesso foi desativado pela Administração.",
];

const normalize = (value: string) => value.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/gi, " ").trim().toLowerCase();
const redundant = new Set(REDUNDANT_MESSAGES.map(normalize));

/** Título completo (texto + destaque), para comparações e leitores de tela. */
export function fullTitle(copy: Pick<AccessCopy, "title" | "highlight">): string {
  return copy.highlight ? `${copy.title} ${copy.highlight}` : copy.title;
}

/** Devolve a mensagem só quando ela acrescenta algo ao que o estado já diz. */
export function extraMessage(status: AccessStatus, message?: string): string | undefined {
  if (!message?.trim()) return undefined;
  const key = normalize(message);
  const copy = ACCESS_COPY[status];
  if (redundant.has(key) || key === normalize(copy.text) || key === normalize(fullTitle(copy))) return undefined;
  return message;
}

/** Rótulos da administração de contas. */
export const MEMBERSHIP_STATUS: Record<"pending" | "active" | "disabled", { label: string; tone: BadgeTone; group: string }> = {
  pending: { label: "Sem servidor", tone: "warn", group: "Sem servidor vinculado" },
  active: { label: "Ativa", tone: "ok", group: "Contas ativas" },
  disabled: { label: "Desativada", tone: "danger", group: "Desativadas" },
};

/** Tela de erro geral (ErrorBoundary). */
export const APP_ERROR = {
  tone: "danger" as BadgeTone,
  badge: "Erro inesperado",
  title: "Algo deu errado",
  highlight: "nesta parte do app.",
  text: "O restante do Gabinete continua funcionando. Tente novamente; se o problema persistir, recarregue a página.",
  retry: "Tentar novamente",
} as const;

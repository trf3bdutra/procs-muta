import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { getMyAccount, getAppSession as readAppSession } from "@workspace/api-client-react";
import { ACCESS_FALLBACK_MESSAGE } from "./access/copy";
import { clearLoginWelcomePending } from "@/lib/login-welcome";

export type AppSession = { authenticated: true; userId: string; role: "equipe" | "editor" | "administracao"; name: string; server?: string };
type AccessState = "pending" | "disabled" | "unverified" | "unregistered" | "error";
type AppAuthContextValue = {
  session: AppSession | null; ready: boolean; signedIn: boolean; status: AccessState;
  email?: string; message?: string; cmAccessError?: string;
  refreshSession: () => Promise<AppSession | null>; logout: () => Promise<void>;
};
const AppAuthContext = createContext<AppAuthContextValue | null>(null);
export function useAppAuth() {
  const context = useContext(AppAuthContext);
  if (!context) throw new Error("useAppAuth must be used inside AppAccessGate");
  return context;
}
export default function AppAccessGate({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const [session, setSession] = useState<AppSession | null>(null);
  const [signedIn, setSignedIn] = useState(false);
  const [ready, setReady] = useState(false);
  const [status, setStatus] = useState<AccessState>("pending");
  const [message, setMessage] = useState<string>();
  const [cmAccessError, setCmAccessError] = useState<string>();
  const [email, setEmail] = useState<string>();
  const generation = useRef(0);
  const pending = useRef<AbortController | null>(null);
  const revoke = useCallback(() => {
    try { sessionStorage.removeItem("cmt:sessao"); sessionStorage.removeItem("cmt:user-id"); } catch { /* Storage can be blocked. */ }
    clearLoginWelcomePending();
    window.dispatchEvent(new Event("cmt:access-revoked"));
    queryClient.clear(); setSession(null);
  }, [queryClient]);
  const refreshSession = useCallback(async (): Promise<AppSession | null> => {
    pending.current?.abort();
    const controller = new AbortController();
    pending.current = controller;
    const current = ++generation.current;
    const timeout = window.setTimeout(() => controller.abort(), 12_000);
    try {
      const appBase = import.meta.env.BASE_URL.replace(/\/$/, "");
      const currentPath = window.location.pathname.startsWith(appBase)
        ? window.location.pathname.slice(appBase.length) || "/"
        : window.location.pathname;
      const authApi = `${appBase}/api/auth`;
      if (currentPath === "/cm") {
        const hash = window.location.hash.replace(/^#/, "");
        const accessToken = new URLSearchParams(hash).get("access");
        if (hash.startsWith("access=")) {
          setCmAccessError(undefined);
          const exchange = await fetch(`${authApi}/cm-access/exchange`, {
            method: "POST",
            credentials: "same-origin",
            cache: "no-store",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ token: accessToken }),
            signal: controller.signal,
          });
          const result = await exchange.json().catch(() => ({})) as { error?: string };
          window.history.replaceState(null, "", `${window.location.pathname}${window.location.search}`);
          if (current !== generation.current) return null;
          if (!exchange.ok) {
            revoke();
            setSignedIn(false);
            setEmail(undefined);
            setStatus("error");
            setMessage(undefined);
            setCmAccessError(result.error || "Este link do CM é inválido ou foi revogado. Peça um novo link à Administração.");
            return null;
          }
        }

      }

      let account: Awaited<ReturnType<typeof getMyAccount>>;
      try {
        account = await getMyAccount({ signal: controller.signal, credentials: "same-origin", cache: "no-store" });
      } catch (error) {
        const value = error as { status?: number };
        // The signed CM cookie is valid throughout the app, not only on /cm.
        // Local accounts still take precedence when one is signed in.
        if (value.status === 401) {
          const cmResponse = await fetch(`${authApi}/cm-session`, {
            credentials: "same-origin", cache: "no-store", signal: controller.signal,
          });
          if (cmResponse.ok) {
            const data = await cmResponse.json() as AppSession;
            if (current !== generation.current) return null;
            if (data.authenticated !== true || data.userId !== "cm-link" || data.role !== "equipe" || data.server !== "CM") {
              throw new Error("A sessão exclusiva do CM não é válida.");
            }
            try {
              const previousUser = sessionStorage.getItem("cmt:user-id");
              if (previousUser && previousUser !== data.userId) {
                queryClient.clear();
                window.dispatchEvent(new Event("cmt:access-revoked"));
              }
              sessionStorage.setItem("cmt:sessao", JSON.stringify({ nome: data.name, servidor: "CM", papel: "servidor" }));
              sessionStorage.setItem("cmt:user-id", data.userId);
              if (previousUser !== data.userId) localStorage.setItem("pauta.footer-pinned-server.v1", JSON.stringify(["CM"]));
            } catch { /* O cookie HttpOnly continua sendo a fonte autoritativa. */ }
            setSignedIn(true);
            setEmail(undefined);
            setStatus("pending");
            setMessage(undefined);
            setCmAccessError(undefined);
            setSession((previous) => previous?.userId === data.userId && previous.server === "CM" ? previous : data);
            return data;
          }
          if (cmResponse.status === 401 && sessionStorage.getItem("cmt:user-id") === "cm-link") {
            setCmAccessError("A sessão do CM foi removida ou revogada. Abra novamente o link secreto salvo.");
          }
        }
        throw error;
      }
      if (current !== generation.current) return null;
      setSignedIn(true); setEmail(account.email);
      if (account.status !== "active") {
        revoke(); setStatus(account.status); setMessage(undefined); return null;
      }
      const data = await readAppSession({ signal: controller.signal, credentials: "same-origin", cache: "no-store" });
      if (current !== generation.current) return null;
      if (data.userId !== account.userId || data.authenticated !== true) throw new Error("A resposta de acesso não é válida.");
      const approved = data as AppSession;
      try {
        const previousUser = sessionStorage.getItem("cmt:user-id");
        if (previousUser && previousUser !== approved.userId) { queryClient.clear(); window.dispatchEvent(new Event("cmt:access-revoked")); }
        sessionStorage.setItem("cmt:sessao", JSON.stringify({ nome: approved.name, servidor: approved.server ?? "", papel: approved.role === "equipe" ? "servidor" : "admin" }));
        sessionStorage.setItem("cmt:user-id", approved.userId);
        if (previousUser !== approved.userId) {
          if (approved.server) localStorage.setItem("pauta.footer-pinned-server.v1", JSON.stringify([approved.server]));
          else localStorage.removeItem("pauta.footer-pinned-server.v1");
        }
      } catch { /* Server membership remains authoritative. */ }
      setSession((previous) => previous?.userId === approved.userId && previous.role === approved.role &&
        previous.server === approved.server ? previous : approved);
      setMessage(undefined);
      setCmAccessError(undefined);
      return approved;
    } catch (error) {
      if (current !== generation.current) return null;
      const value = error as { status?: number; data?: { code?: string; error?: string } };
      const code = value.data?.code;
      revoke();
      if (value.status === 401) { setSignedIn(false); setEmail(undefined); }
      setStatus(code === "pending" || code === "disabled" || code === "unregistered" ? code : "error");
      setMessage(value.data?.error || ACCESS_FALLBACK_MESSAGE);
      return null;
    } finally {
      window.clearTimeout(timeout);
      if (current === generation.current) setReady(true);
    }
  }, [revoke, queryClient]);
  useEffect(() => {
    void refreshSession();
    const timer = window.setInterval(() => { if (!document.hidden) void refreshSession(); }, 20_000);
    const refresh = () => { if (!document.hidden) void refreshSession(); };
    window.addEventListener("focus", refresh);
    document.addEventListener("visibilitychange", refresh);
    window.addEventListener("cmt:membership-changed", refresh);
    return () => {
      clearInterval(timer); pending.current?.abort(); ++generation.current;
      window.removeEventListener("focus", refresh); document.removeEventListener("visibilitychange", refresh);
      window.removeEventListener("cmt:membership-changed", refresh);
    };
  }, [refreshSession]);
  const logout = useCallback(async () => {
    ++generation.current; pending.current?.abort();
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 12_000);
    let response: Response;
    try {
      response = await fetch(`${import.meta.env.BASE_URL.replace(/\/$/, "")}/api/auth/logout`, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: "{}",
        signal: controller.signal,
      });
    } catch {
      throw new Error("Não foi possível encerrar a sessão. Verifique a conexão e tente novamente.");
    } finally {
      window.clearTimeout(timeout);
    }
    if (!response.ok) throw new Error("Não foi possível encerrar a sessão. Tente novamente.");
    revoke(); setSignedIn(false); setEmail(undefined); setReady(true);
    window.location.assign(import.meta.env.BASE_URL);
  }, [revoke]);
  return <AppAuthContext.Provider value={{ session, signedIn, ready, status, email, message, cmAccessError, refreshSession, logout }}>
    {children}
  </AppAuthContext.Provider>;
}

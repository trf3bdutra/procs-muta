import { useState } from "react";
import { Link } from "wouter";
import { useAppAuth } from "./app-access-gate";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Check, Ban, Save, RefreshCw } from "lucide-react";
import {
  useListAccountMemberships,
  useChangeAccountMembership,
  getListAccountMembershipsQueryKey,
  type AccountMembership,
} from "@workspace/api-client-react";
import { AccessCard, AccessShell, BrandLockup, MEMBERSHIP_STATUS, StatusBadge } from "./access";

type Status = AccountMembership["status"];
type Role = AccountMembership["role"];


function errText(e: unknown): string {
  const any = e as { status?: number; data?: { error?: string; message?: string }; message?: string };
  const detail = any?.data?.error || any?.data?.message;
  if (any?.status === 409) return detail || "Este servidor já está vinculado a outra conta ativa.";
  if (any?.status === 403) return detail || "Somente a Administração pode alterar contas.";
  if (any?.status === 400 || any?.status === 422) return detail || "Dados inválidos. Revise função e servidor.";
  return detail || any?.message || "Não foi possível salvar a alteração.";
}

function Row({ m, roster, isMe }: { m: AccountMembership; roster: string[]; isMe: boolean }) {
  const qc = useQueryClient();
  const change = useChangeAccountMembership();
  const [role, setRole] = useState<Role>(m.role);
  const [server, setServer] = useState<string>(m.server ?? "");
  const [adminAccess, setAdminAccess] = useState<boolean>(m.role === "equipe" && m.adminAccess);
  const [error, setError] = useState<string | null>(null);
  const busy = change.isPending;
  const nextAdminAccess = role === "administracao" || (role === "equipe" && adminAccess);
  const dirty = role !== m.role || (server || null) !== (m.server ?? null) || nextAdminAccess !== m.adminAccess;

  async function submit(status: Status) {
    setError(null);
    if (status === "active" && (role === "equipe" || role === "editor") && !server) {
      setError("Selecione o servidor do quadro para ativar esta conta.");
      return;
    }
    try {
      await change.mutateAsync({ userId: m.userId, data: { status, role, server: role === "administracao" ? null : server || null, adminAccess: role === "equipe" ? adminAccess : false } });
      await qc.invalidateQueries({ queryKey: getListAccountMembershipsQueryKey() });
      if (isMe) window.dispatchEvent(new Event("cmt:membership-changed"));
    } catch (e) {
      setError(errText(e));
    }
  }

  const id = m.userId;
  return (
    <div className={`cmt-row${isMe ? " me" : ""}`} data-testid={`row-account-${id}`}>
      <div className="who">
        <b>{m.name || "Sem nome"}{isMe ? " (você)" : ""}</b>
        <span>{m.email}</span>
      </div>
      <StatusBadge tone={MEMBERSHIP_STATUS[m.status].tone} data-testid={`status-account-${id}`}>{MEMBERSHIP_STATUS[m.status].label}</StatusBadge>
      <select value={role} disabled={isMe || busy} onChange={(e) => {
        const nextRole = e.target.value as Role;
        setRole(nextRole);
        if (nextRole === "administracao") { setServer(""); setAdminAccess(false); }
        if (nextRole === "editor") setAdminAccess(false);
      }} aria-label="Função" data-testid={`select-role-${id}`}>
        <option value="equipe">Equipe</option>
        <option value="editor" disabled={m.server !== "BRUNO" && role !== "editor"}>Editor</option>
        <option value="administracao">Administração</option>
      </select>
      <select value={server} disabled={isMe || busy || role === "administracao" || role === "editor"} onChange={(e) => setServer(e.target.value)} aria-label="Servidor" data-testid={`select-server-${id}`}>
        <option value="">{role === "equipe" || role === "editor" ? "Selecione o servidor" : "Sem servidor"}</option>
        {roster.map((r) => <option key={r} value={r}>{r}</option>)}
        {m.server && !roster.includes(m.server) && <option value={m.server}>{m.server}</option>}
      </select>
      {m.server === "BRUNO" && role === "equipe" && <label
        className="cmt-admin-access"
        title="Com a senha da Administração, este servidor pode entrar com permissões administrativas."
      >
        <input
          type="checkbox"
          checked={nextAdminAccess}
          disabled={isMe || busy}
          onChange={(event) => setAdminAccess(event.target.checked)}
          data-testid={`checkbox-admin-access-${id}`}
        />
        Acesso adicional da Administração
      </label>}
      <div className="btns">
        {isMe ? <span className="mine">Sua conta</span> : <>
          {m.status !== "active" && <button className="cmt-btn ok sm" disabled={busy} onClick={() => submit("active")} data-testid={`button-approve-${id}`}><Check size={14} />Ativar</button>}
          {m.status === "active" && dirty && <button className="cmt-btn primary sm" disabled={busy} onClick={() => submit("active")} data-testid={`button-save-${id}`}><Save size={14} />Salvar</button>}
          {m.status !== "disabled" && <button className="cmt-btn danger sm" disabled={busy} onClick={() => submit("disabled")} data-testid={`button-disable-${id}`}><Ban size={14} />Desativar</button>}
        </>}
      </div>
      {busy && <div className="rowerr busy">Salvando...</div>}
      {error && <div className="rowerr" role="alert" data-testid={`text-error-${id}`}>{error}</div>}
    </div>
  );
}

export default function AdminAccounts() {
  const { session } = useAppAuth();
  const q = useListAccountMemberships({ query: { refetchInterval: 15000, queryKey: getListAccountMembershipsQueryKey() } });
  const members = q.data?.members ?? [];
  const roster = q.data?.roster ?? [];
  const groups: [Status, string][] = (["pending", "active", "disabled"] as const).map((st) => [st, MEMBERSHIP_STATUS[st].group]);

  return (
    <AccessShell align="start" ground="login">
      <AccessCard wide>
        <div className="cmt-top">
          <div>
            <BrandLockup subtitle="Administração de contas" />
              <p className="cmt-p" style={{ marginBottom: 0 }}>Vincule servidores, conceda o perfil Editor somente a BRUNO, altere funções e desative acessos.</p>
          </div>
          <Link href="/gabinete" className="cmt-btn ghost sm" data-testid="link-back-gabinete"><ArrowLeft size={14} />Voltar ao gabinete</Link>
        </div>

        {q.isError && (
          <div className="cmt-err" style={{ marginTop: "1.25rem" }} role="alert">
            {errText(q.error)}{" "}
            <button className="cmt-btn ghost sm" onClick={() => q.refetch()} data-testid="button-retry-list"><RefreshCw size={14} />Tentar novamente</button>
          </div>
        )}
        {q.data && members.length === 0 && <p className="cmt-note">Nenhuma conta registrada até o momento.</p>}
        {q.data && groups.map(([st, label]) => {
          const list = members.filter((m) => m.status === st);
          if (!list.length) return null;
          return (
            <div key={st}>
              <div className="cmt-sec">{label} · {list.length}</div>
              <div className="cmt-table">
                {list.map((m) => <Row key={`${m.userId}-${m.status}-${m.role}-${m.server ?? ""}`} m={m} roster={roster} isMe={m.userId === session?.userId} />)}
              </div>
            </div>
          );
        })}
      </AccessCard>
    </AccessShell>
  );
}

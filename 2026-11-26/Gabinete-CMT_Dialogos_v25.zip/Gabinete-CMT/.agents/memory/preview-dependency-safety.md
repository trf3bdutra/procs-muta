---
name: Preview dependency safety
description: Security rationale for preferring native file discovery in the Canvas preview.
---

Keep preview file discovery on Node's built-in APIs unless an external dependency offers a necessary capability and its full dependency tree is safe.

**Why:** The security remediation found no patched upstream release of `braces`; even the latest `fast-glob` and `micromatch` still pulled it in. Native globbing removed this exposure without adding a replacement package.

**How to apply:** Before adding globbing libraries back to preview tooling, check their transitive dependencies against current advisories rather than assuming the latest parent release is safe. Preserve private-file exclusions and file-only discovery.

## Keep the mockup host independent from the product shell

The mockup sandbox must render `/preview/{group}/{component}` directly from its generated component registry. Do not make its entry depend on the product app's routes, pages, or providers.

**Why:** stale product-shell imports can break every canvas preview even when the isolated component itself builds correctly.

**How to apply:** Keep the sandbox entry focused on path-based component loading; use its registry and report a local preview error when a target cannot be resolved.

---
name: Criação de contas individuais
description: Quem pode criar contas de acesso ao Gabinete CMT
---

O usuário determinou: “QUERO QUE SÓ EU POR AQUI POSSA CRIAR CONTAS”.

**Why:** o usuário quer controlar a criação de contas pelo projeto/conversa, não por cadastro público ou por outros usuários no app.

**How to apply:** não oferecer cadastro público ou criação de contas no app. Somente provisionar ou convidar pessoas por solicitação explícita do proprietário neste projeto; não inventar destinatários, senhas ou permissões.

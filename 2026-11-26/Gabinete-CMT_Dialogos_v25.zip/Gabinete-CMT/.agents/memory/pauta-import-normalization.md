---
name: Pauta import normalization
description: Canonical subject handling, competent-section inference, and procedural subtype tags for imported process records.
---

For process imports, resolve subject-code values through the shared Assuntos catalog and store the corresponding text in `Assunto` or `Tema`. Normalize primary and alternate subject fields into `Assunto`, and infer `Seção competente` from the catalog or existing subject rules when possible. If exact matching fails, a related-name match is safe only when it resolves unambiguously to one section; otherwise use `A conferir`. Procedural labels such as ED and Agravo Interno belong in `Etiquetas`, not as the substantive matter.

When a record contains only ED and has no underlying matter to infer a section, use `Assunto = Embargos de Declaração`, keep the `ED` tag, and set `Seção competente = A conferir`.

**Why:** the user asked for imports to avoid leaving subjects and competent sections blank or displaying numeric catalog codes, and chose this fallback for ED-only records.

**How to apply:** normalize and validate all imported rows before saving. If the source lacks the underlying subject or the catalog points to conflicting sections, do not invent a section; mark it for review.

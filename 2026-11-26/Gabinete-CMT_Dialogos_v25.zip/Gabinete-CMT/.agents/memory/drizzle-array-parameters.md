---
name: Drizzle array parameters
description: Safe SQL patterns for list filters in PostgreSQL queries built with Drizzle.
---

Do not interpolate a JavaScript array directly into a PostgreSQL `ANY(...::type[])` expression through a Drizzle `sql` template. Drizzle expands it into multiple placeholders inside parentheses, which is a tuple/record expression rather than one PostgreSQL array parameter.

**Why:** A live `/api/pauta` save failed while syncing a list of process numbers to the Acervo because the generated `ANY(($1, $2, ...)::text[])` SQL was invalid.

**How to apply:** For a nonempty list, use a parameterized `IN (${sql.join(items.map((item) => sql`${item}`), sql`, `)})` clause, or explicitly bind a true array using a driver-compatible array parameter. Inspect generated SQL and parameters with `PgDialect.sqlToQuery` when changing this pattern.

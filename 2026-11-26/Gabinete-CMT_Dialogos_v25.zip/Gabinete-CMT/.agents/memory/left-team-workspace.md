---
name: Prontuário, Pendências e área de trabalho
description: Layout da Pauta de Julgamento, notificações laterais e Pendências no rodapé central.
---

O Prontuário fica como painel lateral esquerdo dentro do espaço principal da Pauta de Julgamento. Ações ficam integradas ao cabeçalho; não recriar a faixa flutuante nem um título grande “Em foco”. O Prontuário não aparece na Triagem nem no painel lateral direito.

Na Pauta, o Prontuário fica sempre visível e fixo na coluna de trabalho, sem botão ou estado de recolhimento. Mesmo sem processo selecionado ou durante o carregamento, preserve a moldura e mostre uma mensagem de estado; não selecione automaticamente o primeiro processo.

**Why:** o usuário pediu que a ausência do painel não dependesse de clique, foco do processo ou ordem de carregamento.

**How to apply:** mantenha ficha e Gerador sincronizados pelo fluxo existente, reconcilie a visibilidade por eventos e redimensionamento e não introduza polling ou observadores globais. Em telas estreitas, empilhe a lista e o painel sem recolher o Prontuário.

A moldura lateral interna esquerda da Pauta, abaixo dos filtros, passa a conter todo o Prontuário e seu Gerador expansível, com altura ampliada até o rodapé. Não é uma segunda fila de urgências.

**Why:** o usuário substituiu a regra anterior de deixar a moldura vazia: pediu aumentar sua altura e mover para ela todo o Prontuário, inclusive o Gerador.

**How to apply:** use os mesmos campos, seleção e rascunhos, sem clonar o Prontuário ou o Gerador. Preserve formulários em edição quando a lista se redesenhar. O painel pertence somente à Pauta e não deve deslocar cabeçalhos ou filtros.

Meu dia fica na base da barra esquerda, com Entregas do dia abaixo, reunindo as entregas gerais de todos os servidores. Acima deles ficam Notificações e Calendário; Pendências foi separada e abre para cima a partir do rodapé central visível. Para a organização desses painéis, siga `acompanhamento-paineis.md`. Ao abrir Pendências, preserve os filtros Todas/Minhas/Assessoria/Com processo/Atrasadas e as ações Nova pendência/Fechar na primeira faixa. Preserve a gestão em `/sessions` e os dias sem expediente usados no cálculo de prazos. Urgências ficam na fila completa do Controle de Monocráticas, sem o diálogo separado “Painel de pedidos e tutelas”, e os botões Urgências e Organograma saíram em definitivo do painel lateral esquerdo. Solicitações fica como aba do diálogo Configurações Globais, sem página própria em /ass. Minha equipe não integra o painel de Pendências.

**Why:** o usuário separou Pendências do Centro Operacional, mantendo-a no rodapé central; nas páginas sem rodapé, “daí n precisa”.

**How to apply:** mantenha Notificações acima de Meu dia, com tópicos expansíveis, lista detalhada real e Calendário oficial; não use o seletor Por tipo/Tudo. Pendências não é uma aba desse painel e só deve abrir onde houver rodapé central. Ao minimizar Notificações, remova a lista nativa do DOM para que novos avisos voltem a contar como não lidos. Preserve a gestão de sessões/eventos, as configurações de expediente e a fila de urgências. Não restaure /ass; mantenha Solicitações em Configurações Globais.

Na Pauta de Julgamento, o Prontuário permanece disponível no painel interno esquerdo, sem modo ou botão “Mesa de trabalho”. Se nenhum processo estiver em foco, mostre o estado vazio, sem selecionar o primeiro processo. “Meus”, ao lado de Meta/Metas, filtra os processos vinculados ao usuário autenticado, sem abrir ou fechar o Prontuário; corretores usam suas designações de correção.

**Why:** o usuário pediu excluir o botão de modo Mesa de trabalho e criar “Meus” ao lado de Metas para filtrar os processos vinculados ao usuário.

**How to apply:** preserve um foco existente, mas não selecione processos automaticamente. A identificação de “Meus” vem da sessão autenticada, nunca de um servidor fixado ou escolhido para consulta; desligar o filtro restaura a lista sem alterar a seleção em lote. Não recrie o seletor antigo nem um botão de modo Mesa. Na Pauta, não ofereça recolhimento do Prontuário.

Ao alternar para outra aba das Configurações Globais, mantenha Solicitações no slot oculto; devolva o painel ao corpo do documento somente ao fechar o diálogo.

**Why:** mover o painel para fora do diálogo durante uma troca de aba pode perder o estado e impedir que a mesma lista reapareça ao voltar.

**How to apply:** teste Solicitações → outra aba → Solicitações, além dos fechamentos por Esc e ×. Preserve o nó e seus filtros durante a alternância.

Ementário, Protocolo e Repositório não têm páginas nem diálogos standalone e não devem voltar à seção APOIO. O Ementário continua disponível integrado ao Gerador e ao painel `/cm`; não recrie seu diálogo antigo. Configurações Globais tem botão único no trilho direito, dentro da faixa ADM e só para a Administração. Pendências pertence ao rodapé central, não à barra esquerda.

**Why:** o usuário removeu as páginas/diálogos standalone de Ementário, Protocolo e Repositório, mantendo apenas as integrações do Ementário; Configurações Globais fica no trilho direito e Pendências foi separada para o rodapé central.

**How to apply:** mantenha o acesso embutido ao Ementário nas superfícies existentes e suas permissões; não recrie a seção APOIO com essas páginas, o dock do Ementário no trilho, seu acesso sob a marca nem o diálogo antigo de Pendências.

Na barra esquerda, use a referência de crachá enviada pelo usuário: identificação da Justiça Federal no topo, foto/nome/grupo ao centro, indicadores reais e faixa rosa fechando o cartão com situação e marca do Gabinete. Essa referência substitui a disposição anterior com a marca fora do crachá. No modo minimizado, a foto, sua moldura e a marca devem caber dentro da largura da barra. Não exiba a marca do TRF3 nem a contagem de pessoas online na base do trilho direito; mantenha Configurações Globais e um único botão de Controle de Sessões no grupo inferior, com o mesmo estilo circular; ambos ficam ocultos para membros da equipe. Notificações e Calendário ficam acima de Meu dia; Pendências fica no rodapé central. Preserve o crachá e o botão de encerrar sessão sem sobreposição ao recolher ou ampliar a barra; com a barra recolhida, encerrar sessão não aparece. Não restaure o mini-calendário na barra. Na página Campo do Servidor, o perfil deve ocupar um banner horizontal, com foto, identidade e dados existentes, encerrado pela faixa rosa; adapte-o em telas menores sem excluir campos ou edição.

**Why:** o usuário forneceu novas referências visuais para o crachá e o banner do Campo do Servidor, com a marca dentro da faixa rosa; os dados devem continuar vindo do app, não dos números ilustrativos das imagens.

**How to apply:** deixe a faixa rosa como última linha do crachá, com a marca dentro dela quando expandido; no modo compacto, use o slot de marca que cabe na barra, sem “Menu”. Limite foto/moldura ao espaço interno disponível. Mantenha o banner do servidor exclusivo dessa página, preservando campos e edição. Deixe a barra sem calendário operacional; na direita, use botões circulares iguais para Configurações Globais e Controle de Sessões, sem duplicar Sessões e mantendo ambos ocultos para membros da equipe.

Na barra esquerda minimizada, não exiba os ícones de Meu dia e Entregas do dia; mantenha Notificações e fixe a marca do Gabinete no último espaço da barra. No crachá expandido, mostre a contagem real de pessoas online junto à identificação da Justiça Federal.

**Why:** o usuário pediu retirar os dois atalhos que falham no estado minimizado, reposicionar a marca e incluir presença no crachá aberto.

**How to apply:** o estado compacto oculta os controles de Meu dia/Entregas sem remover seus dados nem alterar a versão expandida. Calcule a presença a partir da mesma lista online usada pelo app e mantenha a ação existente da marca.

No modo expandido, a navegação começa logo após o crachá, sem um vão vazio; a lateral escurece gradualmente até a base. Notificações e os resumos de Meu dia/Entregas ficam agrupados visualmente no rodapé da barra.

**Why:** o usuário pediu eliminar o espaço sob o crachá, aplicar um degradê vertical e integrar os campos diários à base da lateral.

**How to apply:** não deixe o corpo da navegação crescer para empurrar os resumos; mantenha o degradê no fundo da barra e a rolagem confinada aos conteúdos dos painéis diários.

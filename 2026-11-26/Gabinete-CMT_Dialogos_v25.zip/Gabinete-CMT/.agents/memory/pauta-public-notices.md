---
name: Public dashboard notices
description: Keep shared dashboard and public notification text free of admin-directed configuration instructions.
---

Do not show administrator-directed configuration instructions in the shared “Ordem do Dia” panel or public notifications. When shared configuration is missing, use a neutral status description rather than telling the administrator what to change.

**Why:** the user explicitly requested that public shared surfaces not carry admin-directed notices such as instructions to set the minutes deadline.

**How to apply:** keep actionable setup guidance inside settings and phrase missing-data states in shared panels and notifications factually.

---
name: Embedded XLSX source
description: How the shared pauta page avoids parsing a malformed inline SheetJS export template.
---

Treat the compressed XLSX payload in the page's resource block as the executable source of truth. Keep the legacy inline copy non-executable: injected interface CSS inside SheetJS's HTML export template can break JavaScript parsing, while the compressed library remains valid and is loaded by the existing asynchronous fallback.

**Why:** the inline and compressed copies diverged; restoring inline execution reintroduced a browser syntax error and could slow panel startup.

**How to apply:** when changing embedded XLSX or export HTML, validate the decompressed resource and preserve the lazy fallback. Do not reactivate the legacy inline block without regenerating and syntax-checking it.

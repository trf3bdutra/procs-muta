---
name: Pauta collaboration access
description: Product scope and collaboration access preference for the process docket app.
---

Keep this app visually and behaviorally close to the supplied original, including its existing process fields and workflows. Anyone with the link can edit shared process cards without an account; only Configurações Globais require the shared password.

**Why:** the user wants permanent, simultaneous shared editing without accounts, and explicitly requested a password gate for Configurações Globais.

**How to apply:** keep process editing open to link holders. Protect only the Global Settings entry point with the server-verified shared password; do not add account login or expand the gate unless requested.

## Fixed server roster

Use the configured server roster as the only source for process assignments. Free-text or imported names must not create server profiles; create profiles only through Global Settings. Keep legacy assignments visible but out of the selectable roster until someone explicitly remaps them.

**Why:** the user chose a fixed roster and said server assignment should select from its options rather than create profiles from entered names.

**How to apply:** populate all assignment selectors from active team profiles, validate bulk assignment against that list, and preserve unmatched historical values without guessing who they should map to.

## Public profile photos

Keep team profile photos editable through a public HTTP(S) image URL in the shared profile data; do not require sign-in or store image bytes for this field.

**Why:** the app must remain open to everyone with the shared link, and the existing team photo editor already uses public image URLs.

**How to apply:** reuse the shared profile photo field and save path. If direct device-file uploads are requested, revisit storage and access requirements before changing this approach.

## Public Crachá appearance

Use the supplied badge reference for the public Crachá dialog only. Keep its existing fields, shared editing, and interactions intact, and leave the rest of the app's appearance unchanged.

**Why:** the user explicitly requested a Crachá-only restyle based on the attachment without changing functionality or the surrounding app.

**How to apply:** scope future visual changes to the public profile dialog and preserve its current data and event hooks.

Each process card belongs exclusively to one session. Identical process numbers in different sessions represent independent records; edits and deletions in one session must not affect another.

**Why:** the user clarified that cards with the same process number in different sessions do not communicate and must be treated independently.

**How to apply:** scope process identity, shared-state merges (including stale concurrent snapshots), session imports, edits, and deletions by session as well as process number in both client and API paths.

## Sessions are registered before process imports

Cadastre primeiro a sessão e seus marcos. A importação de pauta pelo PDF só deve aceitar sessões futuras já cadastradas e sem processos. Na lista geral, exiba sessões ativas e inativas juntas, ordenadas por data: futuras mais próximas primeiro, depois as demais futuras, e passadas no final com destaque visual reduzido.

**Why:** the user explicitly stated that sessions will be registered before their processes are added and asked for the nearest sessions first, including inactive sessions.

**How to apply:** keep the session-management list and session selectors in the same date order after loads, imports, and edits; do not create a session as a side effect of importing its process list.

## Session backups and session-bound Pendencias

Manage sessions and milestones only in Configurações Globais; `/session` and `/sessions` redirect to the Gabinete and have no standalone page or navigation buttons. In the session settings, provide a per-session JSON backup containing the session details, milestones, process order, and full linked process data. Import merges by default; replacing is an explicit action scoped to that session, preserving other sessions. A Pendência created from a process associated with a session should inherit that session, remain editable, and be searchable/filterable by session.

**Why:** the user asked to retire the individual Sessions page, keep session configuration in Global Settings, make complete session backups importable there, and associate Pendências with the process's session automatically.

**How to apply:** keep the session backup and import controls in Global Settings, never recreate `/sessions` navigation, and infer the issue's session from the selected process's official session entry while allowing a deliberate session selection in the editor.

## Public team calendar

Keep the team calendar read-only and derive its entries from the shared session, work-calendar, team, and docket data. Show absence type, person, and dates, but not free-text absence notes. Badge absence requests stay pending until confirmed; pending requests do not affect availability or appear as absences in the calendar.

**Why:** the user asked for a public calendar of cabinet events, milestones, and absences, with absence requests reviewed before confirmation. Deriving entries avoids a second source of truth; omitting free-text notes reduces accidental exposure in an app accessible by link.

**How to apply:** update calendar rendering when shared records change, and keep new event creation or editing in the existing controls unless the user asks otherwise. Materialize a request as an absence only after confirmation.

Show milestones for every registered session, not just the selected one. Keep each session's milestone color consistent, connect its dates across the calendar, place Peço-dia first in the milestone sequence, and show day intervals between adjacent milestones. In calendar day cards, use a process icon for Peço-dia, a clearly recognizable gavel with a distinct head, handle, and striking base for judgment, a completion icon for delivery of minutes, and a document-release icon for vote release.

**Why:** the user explicitly requested an all-session public calendar with connected, session-colored milestones and the exact icon for each key date type; they later clarified that the judgment icon must visibly read as a hammer.

**How to apply:** preserve this icon mapping in the public calendar, make the gavel silhouette immediately recognizable at its displayed size, and keep milestone ordering and session colors consistent across the calendar, main dashboard, and selected-session editor.

## Assignment specialties

Every assignment can have catalog specialties, whether or not that assignment is active for a server. A server profile can select catalog specialties and add independent specialties that are visually distinct from linked ones.

**Why:** the user asked for assignment specialties to be available across the team and for unlinked profile specialties to remain distinguishable.

**How to apply:** keep catalog specialties shared across profiles, profile selections tied to their assignment, and independent specialties editable on the individual profile.

## Personal footer server pin

The footer server star is a per-browser preference that persists until that browser unpins the server. Do not sync this selection through shared team data. Make it available for every server in the all-server list, even without process assignments, because any server may need pinned-recipient notifications.

**Why:** the user explicitly requested an individual browser pin and clarified that unassigned servers still use the app to receive targeted notifications.

**How to apply:** expose the same pin action on every all-server row; store it in browser-local storage, exclude it from shared snapshots, and initialize a browser without an existing local choice as unpinned rather than copying a shared snapshot value.

## Footer notifications

Keep the notification bell in its footer pill. Public notifications that report completed vote or monocratic drafts remain in the shared dashboard and notification history, but do not increment the bell's unread count. The Pendências action no longer lives in the footer: it belongs to the main navigation, in the dialog group, and must not be duplicated in the footer.

**Why:** the user moved Pendências to the navigation as a standardized dialog and asked to avoid duplicated controls; they also distinguished public completion notices from badge-counting unread notifications.

**How to apply:** keep the footer bell pill without a Pendências button; open Pendências only from the navigation button (`data-pnd="open"`). Preserve shared delivery and history for completion notices while excluding them from the unread counter.

## Notification preferences and batching

Notification categories are configured only in Global Settings, with defaults by role/profile and individual overrides. Errors and urgent notices stay enabled. A burst of equivalent notices for different processes should appear as one notification with the affected process list.

**Why:** the user asked to remove preference controls from the notifications panel, manage defaults centrally for each login/profile, and reduce repeated notices during multi-process updates.

**How to apply:** resolve the active authenticated profile before reading preferences; keep the category controls in Global Settings; never suppress critical errors or urgency; group equivalent process notices and preserve the process references in the grouped entry.

## Review and release ownership

The CM releases a minuta, but setting it as released must not change the assigned reviewer.

**Why:** the user clarified that release is done by the CM and explicitly asked that marking release preserve the reviewer name.

**How to apply:** keep the release flag separate from the reviewer assignment; release may complete the review checklist but must preserve the current reviewer value.

## Single main navigation

Brand the app as Gabinete CMT and keep one primary navigation, split into two groups separated by a subtle divider: the tabs Pauta de Julgamento (first/default) and Controle de Monocráticas (Monocráticas archive and production), followed by the Urgências, Pendências, and Calendário dialog actions. These three actions are not tabs. In `mainNav` the buttons are icon-only, each with `aria-label` and `title`; no text label is rendered. Remove the duplicate text-only tab selector from the header; When scrolling collapses the header, keep the same navigation as a minimal icon pill with accessible names/tooltips. Both tab headers use the overline “GABINETE · GESTÃO DO TRABALHO” above “Gabinete CMT” and mark the active tab. A fixed top band (`#cmt-appbar`, like the footer) holds title, navigation pill and the Configurações gear; past 56 px of scroll it collapses (`cmt-appbar-compact`). All navigation markup, rendering, icons, and compact-on-scroll behavior belong in `pauta-original.html`; the compact navigation shown while scrolling is the same element.

**Why:** the user renamed the app Gabinete CMT, asked for two main areas and one shared header label across both, and explicitly requested removal of the duplicate text tab selector while retaining labeled icon navigation and the existing team dialogs.

**How to apply:** keep the two labels and their existing underlying views; do not reintroduce a Urgências tab or a footer Pendências button. The left sidebar navigation is a separate register (`NAV`, sections PRODUÇÃO and APOIO) and is not governed by this section. Preserve the shared dialog chrome, keyboard/outside-click close behavior, and the layout bounds that keep dialogs between the navigation and footer.

## Embedded modules

`pauta-pending-migration.js`, `pauta-enhancements.js` and `pauta-decision-import.js` are embedded in `pauta-original.html` (JSON blocks marked with `data-pauta-*` and executed once at page load, in that order). The shared shell never loads external copies: it waits for `window.__cmtModulesReady`, set by the HTML after the embedded modules run. Edit these modules only inside `pauta-original.html`; post-render adjustments must run in the same frame (microtask), never in a later animation frame, to avoid flicker.

**Why:** the external scripts were re-patching the rendered dashboard one frame late, causing duplicated/competing layouts and visible flicker.

**How to apply:** do not restore the external `.js` files in `public/`; keep Panorama, session counts and statistics rendered by the core (`window.CMTPanorama`, `window.CMTSessionCounts`, `window.CMTStats`).

## Pending issue actors

Use the server pinned in the current browser as the actor for pending-issue activity. If no server is pinned, require an explicit server selection before completion. Assessoria completions count toward internal productivity; only Assessoria can choose to add the completion to personal history.

**Why:** the user chose browser-pinned identity for pendency updates and asked for Assessoria-specific productivity and personal-history handling.

**How to apply:** keep actor identity local to each browser, record Assessoria completions separately, and show the personal-history option only for Assessoria.

Restore legacy pending issues deterministically. Migration must preserve existing activities and assignments without manufacturing dates, activity events, notification events, or productivity completions.

**Why:** loading the same old shared state again must not make it look edited or count the migration as user work.

**How to apply:** keep legacy normalization side-effect-free and stable across repeated restores; only explicit user actions create notifications and productivity records.

## Class statistics

In “Por classe,” count ED and Agravo Interno as separate subdivisions, excluded from the totals of other judicial classes.

**Why:** the user explicitly requested these categories be shown separately without inflating another class's count.

**How to apply:** classify from the judicial class label or procedural tags and keep both special counts distinct in dashboard statistics and exports.

## Process list and subclassification tags

In list mode, expanding one process must leave other records compact until the global view toggle is used. Recognized procedural labels such as Embargos, Agravos, and Mandado de Segurança are grouped as subclassification tags without rewriting their stored text.

**Why:** the user requested per-process expansion and separate routing of procedural labels.

**How to apply:** keep row expansion separate from the global view preference, and derive subclassification from labels while preserving the editable original tags.

## Server roster management

Add servers through team settings only. Display server names in uppercase in settings and the footer. Deleting a profile archives its team-specific data, preserves existing process-card names, and must not let roster sync reactivate it.

**Why:** the user explicitly requested settings-only server registration, uppercase names in those views, and profile deletion that preserves historical data and process assignments without restoring the profile to the active roster.

**How to apply:** keep manual creation in the settings form, archive a complete profile snapshot in shared state, retain a shared deletion marker for roster synchronization, and leave historical card fields untouched.

## Advanced visualization

The Visualização avançada is an internal page of `pauta-original.html` (`window.CMTAdvanced`, `#cmt-adv`), opened from Configurações › Visualização avançada or by the `/cmt` route. It shows one session at a time through a single session selector that lists only non-archived sessions with processes on the official docket (same order as the main selector), and starts on the session selected in the Painel. It reuses the Controle de Pauta look with the Calendário público chrome and gives access to the real Urgências, Pendências and Calendário dialogs (the same nav buttons). Clicking a process opens its card in the Painel de Controle.

At `/cmt` it is the CM's page (“Mesa do CM”), in this order: (1) **Mesa do CM** — monocráticas “Pronta para assinatura” (urgências first, with medida/pedido, tipo, assunto/tema, partes, síntese do responsável, nota de revisão, who drafted and reviewed, prazo) with Assinar / Devolver (note → back to revisão, or to the responsável when there is no revisor) / Abrir; tutelas with “Minuta pronta” and no monocrática; and open pendências whose Responsáveis include the CM, with a devolutiva field (“Devolver” records it as the CM, removes the CM and notifies whoever opened it; “Registrar e manter” keeps it on the desk). (2) The session block with its own selector, then hero, indicators, list, side and charts; the 1º julgamento / ED pills use `window.CMTSessionTally` (same facets as the Sessão de referência card). (3) **Produtividade do gabinete** for one day (today by default, ‹ › and date picker, CSV): every Equipe member, then the Assessoria (CM excluded); each row shows that day's items as chips (minuta with process, session and item; monocrática; despacho; diligência; pendência resolvida; produção complementar; for the Assessoria also correções and revisões) and expands to the day's detail only — no history. Correction day = last “Correção/Revisão concluída / Liberado” history entry (Cuiabá day); pendências resolvidas come from `completed` activities.

**Why:** the user asked for the advanced page to replicate the original docket merged with the public calendar, with a single session panel instead of one panel per session, and with the calendar, pendencies and urgencies dialogs available there.

**How to apply:** keep `/` and `/cmt` rendering the same `SharedPauta` instance (no iframe reload); the iframe posts `pauta:open-advanced-visualization` / `pauta:close-advanced-visualization` and the route only follows. Do not reintroduce the separate React advanced page or `advanced-analytics.ts`, and never show estimated CMT (Monitor de Tramitação) numbers while its API is not connected.

On `/cm`, keep the **Mesa do CM** in the blue left-side panel, with internal section navigation above it. The work panel contains signature items, urgent actions, and doubts assigned to the CM; its doubt scope can expand to all unresolved cabinet doubts. Its buttons must reuse the existing urgency and team-wide Pendências dialogs rather than creating duplicate workflows. Keep the right rail for session selection and CM notifications only.

**Why:** the user identified the empty left panel as the correct home for the CM workbench and asked that the page navigation sit above it, while the right side remains dedicated to sessions and notifications.

**How to apply:** keep the CM desk and its default doubt list scoped to the CM assignment; preserve the toggle to all unresolved cabinet doubts and do not narrow the shared team dialog. Keep the three page regions independently scrollable on desktop and stack them accessibly on mobile.

## First-judgment classification

In the Painel de Controle’s session-reference card, count every process as “1º julgamento” except Embargos de Declaração and Agravo Interno. Its clickable pill must filter the same “Demais classes” set. Keep this card rule distinct from the editable/imported “Pendente de 1º julgamento” field and its independent facet unless the user broadens the scope.

**Why:** the user clarified that the session-reference card should treat all processes other than ED and Agravo Interno as first judgments.

**How to apply:** use the existing procedural-subclass facet (which checks tags, class and resource type) for the card count and its click target. Do not change the underlying field or its separate filter without an explicit request.

## TXT import · Outras peças

A document sent to “Outras peças” in the inteiro-teor import is recorded with its document name (PJe “Tipo — Descrição”, without repetition) as tipo “Outro” + Especifique, never as “Juntada de documento”. The name is editable in both dialog steps and persists while the dialog is open (also when going back to the document list); re-importing the same document shows “já consta” or, if renamed, a conflict that renames the existing piece instead of duplicating it. Only the name and the ID are stored.

**Why:** the user wanted the selected document's name filled in Outras peças and the name typed in the dialog to persist.

**How to apply:** keep `otherPieceName`, `occTipo` and the rename-on-conflict logic in the embedded module; do not store document text.

## Footer item search

The footer “Item” search always refers to the docket of the session on screen (the Painel's session, or the Visualização avançada's session when it is open) and matches the card's “Item” field (`Item (Pauta de Julgamento)`, falling back to the session entry item). It works with the virtualized list, offers the session's items as suggestions, warns when the item does not exist or is duplicated, and clears filters (with a notice) when the card is hidden by them.

**Why:** the user required the item search to always relate to the session listing on screen and to integrate with the card's item number field.

**How to apply:** keep the lookup data-driven (session rows), never DOM-only; navigation goes through `CMTCharts.goToProcess`.

## Manual saving of card edits

Edits made in process cards (everything that goes through the Painel's `Page.save`) are not saved automatically: they stay pending with an “Alterações não salvas” bar (Salvar / Descartar, Ctrl+S), an amber mark on the edited card and a warning before leaving the page. Automatic saves from other modules (pendências, equipe, calendário, imports) still happen and carry the pending card edits along. While card edits are pending, the shared shell holds remote updates and merges them on the next save instead of auto-saving.

**Why:** the user asked that card edits not be saved automatically, to avoid the panel freezing, with a clear unsaved-changes indicator.

**How to apply:** keep the contract `__cmtManualPending` / `__cmtRemoteWaiting` between `pauta-original.html` and `shared-pauta.tsx`; do not reintroduce per-edit saves for cards.

## Item in process mentions

Every notification (toast and bell log) that mentions a session process number appends its item in parentheses — “5005972-43.2024.4.03.6000 (item 1)” — using the session on screen first. Already-indicated items are not duplicated.

## Footer search mode

The footer search toggles between “Item” and “Processo” (preference per browser). Process mode accepts the full number with or without punctuation or a fragment of at least 4 digits, always within the session on screen.

## Representation (power of attorney) from the TXT import

The inteiro-teor import locates every document named Procuração/Substabelecimento and pre-selects only those confirmed as the appellant's (grantor = appellant, or filed by the same lawyer who filed the appeal; a power of attorney of the opposing party is rejected). Each one becomes a row of Representação in the operational panel: ID, signature date written in the document (never the PJe filing date), validity (“Válida” when signed up to 2 years ago, otherwise “A verificar”) and a minimal “NAME (OAB/UF nº)” line. When the scan has no text, the date stays empty for manual entry and the lawyers come from the appeal, flagged as such. `ID da Procuração` stays synced with the rows.

## Operational panel layout

Regularidade: Tempestividade/Preparo and Impedimento/Padronização in two columns; Representação and Mídias in full-width rows below. Parecer e outras peças: Outras peças is a scrollable list, one record per line. The tempestividade note is the tooltip of the “i” icon (exact text set by the user).

## Procedural deadlines (MS)

Deadline counting follows the Turma Regional de Mato Grosso do Sul (TRF3): no 9 de julho (SP); 11/10 (creation of MS, no business at JFMS) is excluded. In Configurações › calendar, days not counted for CPC deadlines show “§”, and any added date can be flagged “Não contabilizada para fins processuais” (`workCalendar.labels[date].semPrazo`), which the tempestividade calculation honours.

## MPF required from process data

Elderly, minor/incapable, indigenous, quilombola, mandado de segurança, ACP, ação popular, improbidade and agrarian-reform expropriation cases (detected in assunto, tema, partes, classe, etiquetas; public-body names like FUNAI/INCRA alone do not count) make the MPF opinion required. An explicit choice by the server (including “Não se aplica”) always prevails; nothing is written automatically.

## Settings › edit process information

The selected session in Configurações has an expandable editor: search by process number or item (several per line or comma-separated), pick any card field and value, review current values and apply to the selected processes. Saved immediately (like other settings) with a history entry per process.

## Statistics layout

Top row: Assuntos CNJ e temas (height-limited, Lista or Mosaico view; subtopic temas as chips identical to “Outros temas”) with a side column of Classes processuais, Evolução temporal (daily) and Acumulado (area). Bottom row: “Servidores” (Processos por servidor | Produtividade por servidor) and “Situação e pendências” (Situação dos processos | Pendências por categoria).

## Free search and footer locator

The free search of the Painel de Controle never filters while typing (each keystroke used to redraw the whole list): typing only keeps a draft (with an “↵ Enter adiciona à pesquisa” hint). Enter or “+ Termo” ADDS the term as a chip, so several different terms can be combined; with two or more terms a chip toggles “Todos os termos (E)” / “Qualquer termo (OU)”. Digit-only terms (4+) also match process numbers without punctuation. Esc clears the draft. Redraws keep the focus and caret in the field. The footer locator searches the session on screen (or the Visualização avançada session) by item or by process number (full, with or without punctuation, or at least 4 digits); hidden cards clear the filters with a notice; the ↑ button returns to the top.

When the free search is scoped to Item (or all fields), comma-separated item numbers and ranges such as `2, 4-6` match exact docket item numbers. When scoped to Processo, comma-separated process numbers match the corresponding session cards.

**Why:** the user requested a compact way to filter session cards by multiple process numbers or item ranges.

**How to apply:** preserve exact item matching for ranges, process-number list matching, and the existing Enter-to-add-search-chip behavior.

## Card balance and visual identity

Process card (main row), three balanced columns: Processo (identification · Observações filling the gap · Especificidades) | Acompanhamento ([Elaboração / Intercorrências] beside [Revisão / Etiquetas e Histórico], two equal-height columns) | Julgamento (Voto filling · Sessões at the base). Painel operacional, three columns of the same height: Regularidade (Tempestividade + Preparo | Impedimento + Representação; with procurações, Representação takes a full row; Mídias in its own row) | Sentença e recursos | Parecer, outras peças and Padronização da minuta. The public calendar dialog's graphite and gold (tokens --cal-*) appear as counterpoint to the white areas: Controle de Pauta title band, Avisos, active buttons (Filtros, + Termo, Painel operacional open), card-head icons and section kickers. The Sessão de referência tile keeps its original light look (the dark version was rejected). The statistics panel (“Análises da sessão”) follows the calendar dialog entirely: graphite background, gold kicker, session title, legend-style clickable indicators and a gold/blue/green palette (the Visualização avançada keeps its own palette).

## Replacing the embedded HTML snapshot

When replacing `pauta-original.html` with an attached snapshot, reconcile newer merged behavior before considering the replacement complete. The page can still render while its embedded module loader has lost behavior required by newer tests and persistence paths.

**Why:** an older snapshot omitted the post-merge hook that records all completed pendencies for productivity, while the preview continued to load.

**How to apply:** inspect recent source changes and run the full artifact tests after any snapshot replacement; reapply compatible runtime hooks and update assertions only when the current markup is structurally different but behavior is intact.

## People: CM, Assessoria and Equipe

Three names, used everywhere in the UI: **CM** (the desembargador; hierarchy “CM”, also recognised by the member named CM or a legacy “Desembargador…” hierarchy), **Assessoria** (CJ1–CJ3, plus the CM) and **Equipe** (“Membro do Time” and FC3/FC4 — FC is never Assessoria). CJ/FC codes are never shown: the interface shows only the group (`PautaTeam.groupLabel`); the ficha has a “Grupo” select (Equipe | Assessoria | CM) that keeps a compatible stored code (FC stays FC within Equipe, CJ stays CJ within Assessoria, otherwise Membro do Time / CJ1) so the roster data is preserved. Never write “desembargador” in new UI text; pre-existing catalogue wording about other desembargadores stays.

- Assessoria is outside the standard productivity: header, footer strip, statistics, capacity, “Produção por servidor”, Responsável suggestions. Its work (correções, revisões, pendências, minutas diversas) appears in the Assessoria part of the day productivity on `/cmt`.
- Identity is the footer star (browser-local `pauta.footer-pinned-server.v1`); the footer planilha lists Assessoria and members without processes under “Identificar-se”.
- The CM is never counted in productivity or andamentos, never offered as Responsável or revisor, and always signs.
- Avisos (footer bell, `window.CMTNotices`): revisão → the designated revisor; assinatura → the CM; Assessoria flag (on a pendência, an urgência or a monocrática) → every Assessoria member except the CM. Seen keys per identity in `cmt_targeted_seen_v1`.

**Why:** the user wants non-members treated as one coherent group with their own notices and access, and fixed the vocabulary as CM / Assessoria / Equipe.

**How to apply:** test membership with `PautaTeam.isAssessoria` / `isDesembargador` (enhancements: `assessoria`, `assessoriaRecipient`), never by name lists.

## Controle de Decisões flow

Urgências (dialog): header icon pill (novo pedido, importar, modelo, exportar, limpar lista); new pedido and the decision are inline rows, placed by the list order. Fields: processo, classe, medida, pedido, partes, assunto, tema, especificidades, datas, urgência, prazo, responsável, observações do responsável and de revisão, Assessoria flag. Deciding an urgência creates or updates its monocrática (synced both ways). Monocráticas: Responsável (who drafts) ≠ revisor; “Minutado” date counts in the Responsável's productivity and history, like Minutado/Entregue in Controle de Pauta. From the row, one click sends to Revisão (choosing the revisor) or straight to Assinatura; “Revisada” moves to Pronta para assinatura and “Assinada” closes it; each step is logged in the record history. Footer metas: the session's pauta metas when defined, otherwise the individual metas of the member's ficha (`metaMonoDia`, `metaCorrecaoDia`).

Monocrática andamentos end at **Assinada** (“Publicada” was removed; restored or imported “Publicada” becomes “Assinada”). Decision types include “Tutela de Urgência”, pre-selected when deciding an urgência. The Acervo de monocráticas page has no Fluxo strip: indicators, then the Equipe and Resultado panels.

## Despachos e diligências

The footer Ordem do dia › Histórico of each server has “+ Despacho/diligência”: date (not future), tipo (Minuta de despacho | Diligência), processo (optional) and a short description (≤ 280 chars; no document text is kept). Records live in `team.diligencias` (`{id, memberId, memberName, date, tipo, processo, descricao, at, by}`), are sessionless, appear in that history and in the ficha (Histórico › Despachos e diligências) and never count as minuta de voto, monocrática or pendência completion.

## Informar dúvida

“Informar dúvida” sits in the Avisos strip of every process card and as a “?” icon in the Monocráticas and Urgências rows. It opens a small dialog (asker's name, pre-filled from the footer star, and the question) and creates a pendência `kind: 'duvida'` linked to the process number, with Assessoria marked and the asker as responsável (so the answer notifies them). In the Pendências drawer, “Respondida por” records who answers; a doubt cannot be answered without a name. The button shows the number of open doubts (green once answered) and the dialog lists earlier doubts with their answers. API: `PautaPendencias.askDoubt / doubtsFor / doubtState / lastAnswer / openIssue`; `window.CMTDoubt`.


## Pendências: deletion and the CM's desk

A pendência can be deleted only when it was created by mistake: still open and with no andamento (`comment`) or conclusion from anyone. The drawer then shows “Excluir” (confirmation, then “Desfazer” for a few seconds); otherwise it must be concluded. A pendência whose Responsáveis include the CM shows the “Mesa do CM” chip and appears on `/cmt`.

## Calendário público

Clicking another day (or month / Hoje) redraws the dialog and shows that day; the outside-click closer ignores targets detached by the redraw (`target.isConnected`).

## Statistics: temas under assuntos

In “Assuntos CNJ e temas” (Lista), the tema chips under an assunto stay inside the label column: one line, horizontal scroll, never under the bars (`.cmt-at-sub` width/max-width `calc(38% - 12px)`, chips `flex:0 0 auto`).

## Crachá (perfil público)

One dialog, four divisions (version A “Crachá ao lado”): 01 ID card on the left (photo, name, group · main atribuição, naturalidade, aniversário dd/mm, ingresso, chegada ao gabinete, contato), 02 Produção (mês, semana, hoje, sessão, próximas sessões; Resumo/Calendário), 03 CTPS & Currículo (atribuições read-only from the team config; curriculum records `{id,tipo,titulo,local,assunto}`), 04 Presença (absence request). Only the server pinned with the footer star in this browser edits their own crachá (“Editar meu crachá” → Salvar); others see a hint. Edit state lives in `dialog.dataset.pp2Mode` (never `data-pp2-edit` on the dialog itself — `closest()` would match it).

## Configurações Globais

Dark dialog in the calendar language (graphite #292c2f, borders #45494d, gold kicker #c9a463, × square): one-line header with the tabs, storage pill, Exportar/Importar JSON icons, Salvar (solid gold when there are unsaved changes), Recarregar, “…” and ×. Actions are injected into the live header (`.app-main:not(.cfg-page-snapshot)`), never the background clone. Reopens on the last tab (`pauta.cfg-tab.v1`); switching tab scrolls to the top. The theme is generic (`cfg-v59-style`) and also covers the import centre and the import preview.

## Arquivos, não GitHub

All GitHub integrations and related app buttons must stay disabled unless the user explicitly asks to reconnect them. Keep preserved Acervo data in the development database; do not reintroduce GitHub sync or mirror code from imported HTML.

**Why:** the user explicitly chose to disconnect all GitHub functions and keep the 5,773 existing records only in the development database.

**How to apply:** when importing HTML or scripts, exclude GitHub buttons, requests, mirrors, and sync flows; use the existing local database instead.

## Acervo do app e importação por sessão

The app's own PostgreSQL Acervo is the official process-data source inside this app. Do not use or synchronize an external shared Acervo as a source. Acervo lookups use the app's database; DataJud may enrich missing local records. The Acervo interface belongs to the current GabCMT HTML in Global Settings; do not reintroduce a separate React Acervo page or route. Preserve the distinction between imported/source fields and operational corrections.

Imported/source fields and team-entered operational corrections are stored separately. A card correction is keyed by normalized CNJ plus that card's sorted session set (`_pautaEntries` and `Sessão Destino`); never apply a session-scoped correction to every card with the same CNJ. Legacy global corrections may only be used when the CNJ has one card. Refreshing imported fields updates values still controlled by the source or empty fields, while preserving untracked manual values. Card edits are saved through the shared Pauta transaction and update the app's Acervo operational record.

**Why:** the user chose the Acervo owned by this app instead of an external shared Acervo, while retaining the app's internal shared database and avoiding accidental overwrites between imported data, team corrections, or cards for different sessions. They also explicitly chose the Acervo already present in GabCMT's Global Settings over the separately implemented React Acervo.

**How to apply:** keep source fields in `importado` and per-card team overrides in `operacional.pautasPorFicha`; use normalized CNJ for lookup and a session-scope key for every write/read of card overrides. Keep the Acervo UI in the active GabCMT document and retain only backend endpoints that it uses.

## Excel por servidor e histórico do rodapé

The per-server Excel (designated processes, daily goal, deadline) lives in the Painel de Controle header (“Excel por servidor…” + ⇩ Excel) for the selected session. The footer server row keeps Hoje (the day) and Histórico: every productivity record of the server in all sessions, like the `/cmt` relation — minutas de voto, monocráticas, despachos, diligências, pendências concluded with “Adicionar também ao histórico pessoal” (now offered to everyone; the log keeps `issueId` and `process`), produção complementar and, for Assessoria, correções and revisões — with ⇩ Excel (Resumo + Registros). API: `window.PautaServerRecords.{list,html,xlsx}`.

## Sincronização e presença

The footer shows a sync icon (green synced, amber spinning while saving/reconnecting, red on failure) with a count badge; hovering or focusing shows the status text and who is using the app now, named by each browser's starred server (“você” for this one; tabs of the same server count once; people without a star are counted apart). The parent page opens `/api/pauta/events?client=<tab id>&who=<star>` and posts `/api/pauta/presence` when the star changes or the stream reconnects; the server broadcasts `event: presence` `{count, people:[{who,count}], unidentified}`. Only the starred name is shared.

## Servidor usuário

The server marked with the footer star in a browser is called **servidor usuário** in every text (never “servidor fixado”). It drives personal notices, the crachá editing, the presence list and the default of “Excel por servidor” in the Painel de Controle header (pre-selected, marked ★, and kept in sync when the star changes).

## Página pessoal do servidor

Use one canonical `/serv-user` page, rendered by the server page already integrated in `gabcmt.html` and derived only from the authenticated account. Do not create a separate React profile or a full-page URL per server. Legacy profile URLs may only redirect to `/serv-user`, ignoring the old slug; `/servidor` is not a valid page route.

**Why:** the user explicitly asked for only the logged-in user's server page, under `/serv-user`, using the native GabCMT page.

**How to apply:** route `/serv-user` through the shared GabCMT shell and its internal router; make personal-page links use `/serv-user` only for the matching logged-in server, and never expose another member through a path or hash.

## Nomes compostos de servidor

“RODRIGO/DEBORA” and “RODRIGO/BRUNO” (either order) are not servers: `cmt-v62-name-fix` wraps `restoreSnapshot` and rewrites every such string or key to “RODRIGO” (path-copy, the received object is never mutated), merges duplicated members, and saves the fix.

## Modo Lista do Painel de Controle

One click on a list line opens the process card right below it; the line stays visible and highlighted (`aria-expanded`), and a second click (or Enter/Espaço) collapses it.

## Metas diárias por servidor

Configurações Globais › Servidores › Dados pessoais › “Metas diárias”: minutas de voto / dia (`profile.metaVotoDia`, meta-base), monocráticas / dia (`metaMonoDia`) and correções / dia (`metaCorrecaoDia`). Today's vote goal in the Ordem do dia (`window.CMTMetaPlan.adjust`, only for today) = max(meta-base, max over the next sessions k ordered by entrega das minutas of ⌈minutas pending at the start of the day up to k ÷ business days available until k's entrega⌉), never above the total pending. Available days = `PautaTeam.days` (calendar + the server's absences). It is 0 with nothing pending (“sem pendências”) or on a non-working day for that server (“sem expediente”); null only when there are no deadlines and no meta-base. The focus session is the first one with the server's minutas pending; when it is done the meta and the session column roll to the next one (tag with the session when it is not the selected one). Servers with pending minutas in other sessions also appear. The meta-base applies to the Equipe only; Assessoria stays out of the vote productivity. The início da preparação does not start the window: the window is today → entrega. Saved daily snapshots (`pautaDaily`, used by the calendar “Meta de minutas” events) still keep the per-session goal.

Monocráticas in the server history: date = `minutado`, or, when empty and the decision already left elaboração, `enviadoRevisaoEm` / `enviadoAssinaturaEm` / `dataAssinatura`; Responsável matches by id or by name.

## Ícones dos marcos no calendário público

Peço-dia = autos (folder with sheets), Entrega das minutas = check circle (conclusão), Liberação dos votos = document with outgoing arrow, Sessão de julgamento = gavel. `pauta-calendar-milestone-icons` decorates the grid dots, the day list marks (`.pauta-calendar-mark[data-milestone-key]`) and the filled stages of the session timeline, always in the session colour.

## Configurações Globais › Servidores: painel único

One compact card (`hubHTML`) replaces the old “Mostrar produtividade – correções” card, the “Time” card and the “Perfis / servidores” header: views (Por servidor, Produtividade, Atribuições, Assuntos ↗), “Status em” date and “+ Novo servidor” (Por servidor only), icon actions (imprimir, exportar JSON, importar), KPIs (servidores, disponíveis, aptos a minutar), who is out on the status date and until when (plus base-status Indisponível), absences starting in the next 15 days, pending absence requests (`member.absenceRequests` with `status:'pending'`) and the “Correções no rodapé” switch (`team.showCorrectionProductivity`). Each person chip opens the profile; `data-th-tab="presenca"` opens it on Presença, where the requests are confirmed.

Atribuições: tasks live in `team.catalog` (`{id,name,group,kind,atribuicoes,specializations}`, six groups: Triagem e Fluxo, Pré-Sessão, Elaboração, Sessão, Supervisão, Gestão Administrativa); a server's tasks are `member.functions` (catalog ids), the main one `member.primary`, subtasks `member.specializations[taskId]`, and minuta specialities `member.minutaScopes` (`docType` Voto/Decisão/Despacho, `subjectId`). Views: Responsáveis por tarefa, Gerenciar tarefas e subtarefas, Fluxo (`team.flow`, ordered stages).

## /cmt: layout, navegação e Mapa da equipe

Em Mesa sits on the left (first on narrow screens) on a gold panel in the accent tone (#c9a463), with its items kept in graphite. The header has a section navigator (Panorama da sessão › Produtividade do gabinete › Mapa da equipe) that scrolls `#cmt-adv` below the sticky header and highlights the visible section. The page ends with “Mapa da equipe” (`window.CMTTeamMap`): Organograma (CM → Assessoria and Equipe, a card per server with status, absence end date and colour-coded tasks, ★ main task, minuta doc types) or Fluxo de atribuições (the six groups in order, each task with its responsáveis, tasks without anyone folded). Mode is kept in `cmt.teamMap.mode`. In the process list the number always fits; the Assunto column is dropped when the card is narrow (container query).

## Tela de carregamento

During authentication and shared-app startup, reuse the current welcome page with its time-based greeting. Show stage-specific progress tied to the actual auth, API, module, and hydration states; if startup does not finish within 45 seconds, show a recoverable error and retry. Once a valid session and shared data are ready, transition to the app; without a session, route to `/sign-in`.

**Why:** the user asked to replace the old loading page with the existing welcome experience and send people without a completed login to the login page, then reported that a static message made startup appear stalled.

**How to apply:** reuse the existing login/welcome document rather than duplicating its design or form. Do not expose the shared iframe before authentication, modules, and snapshot are ready; the main progress line must reflect the actual stage. Ensure the startup timeout has an `onTimeout` handler that displays an error and retry action; otherwise polling can stop while the loading screen remains pending. On narrow or low-height screens, keep status text, progress, and recovery actions reachable by safe alignment, scrolling when needed, and keyboard focus. Light or humorous phrases can appear intermittently in a shuffled secondary line with blank intervals; never pin one beneath every stage or let it replace factual progress. Show the greeting once after each confirmed successful login, then continue with a short destination-specific loader without repeating it during internal navigation. Never mark the greeting pending before authentication succeeds.

**Why:** the user requested a welcome on every login and route-specific loading, while repeated greetings during navigation made transitions feel redundant. A one-use login marker preserves the greeting without coupling it to authentication roles or account storage.

## Modo Lista (v69)

The list follows the approved preview: sticky header with column names, one grid for header and rows (`--pcl-cols`): ☐, Item, Processo (whole number, ED/AgInt tag from subclassification tags or class), Classe (code), Assunto · tema (second line: tema · especificidades, else partes), Servidor (“Sem servidor” in italic gold), Minutado, Corretor, Revisão, Resultado (`Voto - Resultado`), Situação (coloured pill + three stage dots: minuta, revisão, voto liberado), chevron. Rows are neutral zebra; tone is only in the pill; selected rows tinted gold, the open row blue with a gold inset. Header checkbox selects every filtered open process (`page.selected`) or clears; the ☰ button toggles density (`pauta.list-density.v1`, 42/54 px). Clicking a row still opens the full card below it. The old field-reorder script (`pauta-list-compact-fields`) stays but is inert, since the new row has no `pauta-compact-*` field spans.

## “Por lista” filtra e seleciona

“Por lista” (items, ranges or process numbers) now FILTERS the pauta to the matches and also selects them for the batch action: `page.list` is wrapped to keep only `page._pautaListFilter` (row indices) for the session it was made in (`_pautaListFilterSession`); the other filters still apply, and matching ignores the previous list filter. A gold chip “Lista · N processos ×” beside the picker removes it.

## Atribuições editáveis na aba Atribuições

Configurações › Servidores › Atribuições has a mode “Editar por servidor”: a tasks × servers matrix (tasks grouped by type, servers Equipe then Assessoria, CM left out); each checkbox is `data-team-role` + `data-member`, the same save path as the ficha (a minutar task also gets the default minuta scope). Totals per task (red “—” when nobody) and per server; ★ marks the main task (set in the ficha). The matrix keeps its inner scroll across re-renders. In “Responsáveis por tarefa”, the other tasks and the supervision columns get × to remove (`data-team="role-remove"`) and “+ Responsável” to add (`data-team-role-add`); elaboration columns link to the matrix.

## /cmt v72: modelo aprovado (Mesa do CM)

The CM page now follows the approved preview (canvas “Página do CM refinada”, MainV3). Code lives in `cmt-adv-feature` (`cmt2*` functions, styles `#cmt-v72-cmt-style`); the v56 `topbarV56`, `mesaV56` and `signCardV56` stay in the file but are no longer called.
- **Header**: one sticky line — back · “Mesa do CM” · centred navigator 01 Panorama da sessão / 02 Produtividade do gabinete / 03 Atribuições da equipe · Urgências, Pendências (badge), Calendário público · Atualizar, Tema, Notificações (sino). Icon-only buttons with hover labels (`data-tip`). After 56 px of scroll `#cmt-adv` gets `cmt2-compact` and the header becomes a floating, centred dark pill (like the app's icon nav): gold mark, round 01·02·03 (active one filled gold, names in the tooltip), | the three dialogs, | Atualizar, Tema, sino. The page reserves the header height (`--c2-hh`) so nothing jumps. There is no “imprimir página” button and no session selector in the header.
- **No footer on /cmt**: `body.cmt-adv-open` hides the dock bar (`#pauta-global-dock .gd-foot`); the header bell clicks the dock's real bell (`.gd-bell`) and mirrors its counter, and the notifications panel (`.gd-p-notif`) opens as a drop-down under the header.
- **Em mesa** (left, gray #deddd8 with gold top border, graphite cards): per item Conclusão (`entrada`), Minuta (date · author), Revisão (reviewer · date, or “Sem revisão”); icon buttons Assinar, Devolver (note), Designar revisor (select → `PautaDecisoes.designateMono(h,id,memberId)`, which records history and moves a ready minuta back to “Em revisão”), open; “Assinar prontas” signs every ready monocrática on a second click within 5 s.
- **01 Panorama**: session selector on the section header; graphite band with the five marcos, progress track and HOJE marker, next marco highlighted; tiles A liberar · Liberados (n com devolutiva) · Revisados, não liberados · Próximo marco (with its session).
- **Processos da pauta**: tabs A liberar / Revisados, retidos / Liberados / Todos; search accepts items (“2, 3, 4, 5-9”, across all stages) or text (processo, tema, servidor, partes); “Selecionar todos (n)” / header checkbox and “Liberar selecionados (n)” (purple). Pauta para anotações (print) and CSV buttons sit on this panel's header and always use the session selected in the Panorama. Columns: ☐ · Ações (✓ liberar, ⊖ revisado sem liberar + motivo, balão devolutiva) · Item · Processo (+ ED / AgInt tags in distinct yellows) · Assunto · tema · especificidades · Servidor · Etapa · **Atenção (last column)**. Etapa: Ag. minuta (gray) → Minutado (green) → Revisado (blue) → Liberado · dd/mm (purple), or Revisado · retido (orange), plus devolutiva count. Clicking the row toggles the details (Pontos de atenção boxes, then Processo / Acompanhamento / Julgamento columns, all fields, open in Painel). Footer: “Mostrando n de N” and the Legenda tooltip.
- **Record format** (on the process row, same as the Painel card): liberar = the five `Rev - *` fields, `CORRIGIDO` and `LIBERADO` = 'Sim' + history “Liberado para a sessão (revisado)” (undo: “Liberação desfeita”); revisado sem liberar = `_cmRetido {at,motivo}` + `CORRIGIDO` + history “Revisado pelo CM, não liberado: …”; devolutiva = `_cmDevolutivas[] {at,text,by,to}` + history “Devolutiva do CM: …” (allowed after liberado).
- **Pauta para anotações**: A4 with no page margin (3 mm / 5 mm inner padding), at most 100 rows per page and the list split over at most 2 pages; the title block (with the ED / AgInt / visto legend) only on page 1, column titles on both, no footer, rows stretched to fill the page. Columns: item, processo, tema · especificidades, ED/AgInt, visto box and observações (existing ones printed) with room to write.
- **02 Produtividade** reuses `dayProd`; **03 Atribuições** reuses `CMTTeamMap` (Organograma // Fluxos; Assessoria · CJ only, Equipe = servidores and FC).

## Responsáveis e atribuições (Config › Servidores › Atribuições)

“Responsáveis por tarefa” and “Editar por servidor” are one view (`unifiedAssignHTML`, mode `resp`; the old `edit` mode maps to it). Top: per-document summary for Elaboração and Supervisão de minutas (chips select the server). Main: the tasks × servers matrix with the same `data-team-role` checkboxes; cells show the minuta doc types (Dp/Dc/V) or ✎ when the atribuição has specifications. Clicking a server's name (`data-team="assign-focus"`) opens the side panel for that server: situação, autonomia, meta, ♡ preferências, ◈ experiência, ⊘ não gosta, preferências de trabalho, tópicos, antecedentes/objetivos (all from the ficha), then each atribuição with ★ principal, × retirar, subtarefas (`data-team-spec`), vínculos de minutação (read-only + link to the ficha) and free-text “Especificações desta atribuição” saved in `member.profile.taskNotes[taskId]` (`data-team-task-note`; the ficha's Funções tab edits the same field), plus “+ Atribuir tarefa” (`data-team-task-add`). Print “Relação · A4” is kept.

## Especialidades do Minutar por tipo de minuta (v73)

In Atribuições › servidor em foco, the Elaboração de minutas card shows tabs Votos · Decisões · Despachos (count per tab; “todas” = no restriction; “—” = not drafted). Each tab has a “Minuta …” switch and the tree of the Assuntos page: 1ª, 2ª, 3ª Seção (“Toda a seção” or chosen assuntos, added through a searchable field limited to that section) and Outros (assuntos without section and free specialties). Decisões and Despachos add Procedimentos from the Procedimentos tab (`PautaAssuntos.procedures(h)`, filtered by `docTypes`: Despacho / Decisão…), grouped by procedure group. Everything is stored in `member.minutaScopes` (`docType`, `section`, `assuntoId`, `specificity` for free items, new `procId`); a generic scope (no section, assunto, procedure or specificity) means “todas as matérias” and is dropped as soon as something specific is chosen and restored when the last item is removed. Old flat subtasks of the Minutar task (`member.specializations.minutar`, e.g. BPC, Pensão por morte) appear as suggestions: matched to a catalog assunto when the name matches, otherwise to Outros; one click (or “Organizar todas”) converts them into scopes of the open tab. Controls use `data-team-atu` so the app's change dispatcher (keys starting with `team`) reaches them.

## Mapa da equipe: especialidades e diálogo na Ordem do dia (v73)

Organograma cards list the minuta specialties per type (V / Dc / Dp: section: assuntos · section (toda) · Procedimentos: … · Outros), and non-minuta tasks show their subtasks; in Fluxos each person under a task shows the same summary (full text on hover). In the Ordem do dia (dock production panel), a second icon button after the “mostrar todos” button in the Servidor heading (`.cmt-tm-open`) opens `#cmt-tm-dlg`, a dialog in the public-calendar look (graphite, gold top border and kicker) with the same Organograma // Fluxos view (`CMTTeamMap.html`). The map's own header (Equipe do gabinete · Mapa da equipe, summary, Organograma // Fluxos) is the dialog header, with the close button added beside the toggle (re-added after each mode switch); the legend is the dialog footer and only the map body scrolls. The team-map styles are copied with the `#cmt-tm-dlg` scope.

## Ordem do dia: duas sessões (v73)

In the Ordem do dia panel, the “Sessão · andamento e entrega” cell shows two fields, Próxima and Subsequente: the two next sessions by judgment date (`sessionDetails`), each with minutadas/designadas, a progress bar, “a minutar”, pace per business day and “Entrega dd/mm · n d.ú.” (red when overdue); “Sem minutas designadas” or “Sem sessão agendada” otherwise (`window.CMTSessPair`). The bottom bar keeps the single focus-session field.

## Urgências no novo layout (v74)

The Urgências dialog follows the approved preview (Urgencias-v2). The dialog header stays graphite in both themes and holds the KPI chips (pendentes, vencem hoje, vencidas, decididas no mês, deferimento, tempo médio; the first four filter the list) and the icon tools: Novo, Importar, Exportar, Excluir em lote, and Tema claro/escuro (`cmt.urg.theme`; the light theme only lightens the body). The existing filter bar stays (search, Abertas/Concluídas/Todas, andamento, responsável, resultado, Detalhado/Lista compacta). The list is grouped Vencidas → Vencem hoje → Próximos dias → Sem prazo → Decididas, sorted by urgency and deadline. Columns: urgency stripe and tag, processo · partes, pedido · medida (tema chips), responsável · minuta · correção, conclusão · prazo (with chip), andamento as a four-step control (same path as the old status select, including the decision prompt), and actions: dúvida (CMTDoubt), Assessoria, Designar, Minuta e correção, Decisão monocrática inline, Editar. Clicking a row opens details (pedido, prazos, minuta e correção, decisão e CM, delete).

Lim records gain `conclusao` (conclusão dos autos ao gabinete: base of the deadline, `prazo = conclusão (or recebido) + urgency`; an auto deadline is recalculated when conclusão or urgency changes), `minutadoPor`, `dataMinuta`, `corretor`, `dataCorrecao` (in `cleanLim`, the edit form, imports and the XLSX export). Minuta and correction fall back to the linked monocrática (`responsavel`/`minutado`, `revisor`/`revisadoEm`), and values set on the urgency fill the monocrática's empty ones. The CM's state from the Mesa do CM shows on the row: “Na Mesa do CM” (pronta para assinatura), “Devolvida pelo CM · dd/mm” (last `CM (…)` line of the monocrática's `obsRevisao`, full text in the details) or “Assinada pelo CM”. Dialogs (Designar with current load, Minuta e correção, Importar, Exportar by scope, Excluir em lote with checkboxes) reuse the module's form/submit path; Cancelar returns to the Urgências dialog (`data-dec="urg-back"`).

## Pendências › Intercorrências da pauta (v75)

The Pendências dialog has a third view, “Pauta” (next to Quadro and Lista, with a badge of pending items), with a session selector (one session or all), search and three tabs:
- **Adiados**: every entry with status ADIADO. The next session is suggested; there are “Tarefa no PJe” (liberada para minutar, with date), “Quem vai fazer”, Situação (A fazer · Em andamento · Feito), a note, and “Incluir na pauta”, which uses `PautaControl.nextSession` + `include` so the old session stays in the history.
- **Retirados**: entries RETIRADO DE PAUTA, with destination “A definir” or a session, and the same controls.
- **Chamados ao TI**: incidents of type “Chamado à TI”, in active and closed sessions, with número, aberto em, situação (Aberto · Em atendimento · Aguardando retorno · Resolvido; Resolvido marks the incident as sanada), última atualização and andamento; “+ Chamado” registers a new one on a process.

Follow-up data lives on the process row in `r._cmtFollow[originSession] = {pje, pjeAt, resp, st, note, at}`, with history entries. Ticket fields (`ticketStatus`, `ticketNote`, `ticketUpdatedAt`) are kept by `parseIncidents` when the incident text is edited. `window.CMTPautaIntercorrencias.open(tab)` opens the view.

## Supervisão no editor de Atribuições e tipos de julgamento (v76)

In Atribuições › servidor em foco, the three catalog tasks “Supervisão de Minutas de Voto / Decisão / Despacho” are shown as one “Supervisão de minutas” card. It uses the same editor as Elaboração: tabs Votos · Decisões · Despachos. Each tab's switch “Supervisiona …” adds or removes that supervision task from `member.functions`, and the tab shows the task's subtasks plus the Seção › assunto / Outros / Procedimentos tree, saved as `minutaScopes` with `functionId` = the supervision task. The matrix keeps the three tasks as separate rows. In every section (and in Outros, meaning any section), both editors offer judgment types as toggles (Agravo interno, Embargos de declaração, Juízo de retratação), saved as scopes `{section, julgamento}`. They appear in the scope labels, in the Responsáveis summary (supervision now lists its scopes) and in the Mapa da equipe specialties.

## Revisão unificada e devolutivas do Desembargador (v77)
The “Revisão” block of each process card and its dialog (formerly “Correção”) now gather three sources of pending work: the **devolutivas do Desembargador** sent from `/cmt` (`r._cmDevolutivas[]`, each with `id`, `at`, `text`, `to`, `done`, `doneAt`, `doneBy`, `resp`), the **retenção pelo CM** (`r._cmRetido`, plus `ajustadoAt`/`ajustadoBy` when the minuta was adjusted and goes back to the CM) and the corretor's **itens de correção** (`_pautaCorrections`).
- The card header shows one situation chip (Liberado · Retido pelo CM · Ajustado · ao CM · Devolutiva do CM · Em correção · Revisado · A revisar). Below it, up to three pending items are listed, each with a check button. The “Revisão” button shows the total of pending items.
- **Anyone** can mark a devolutiva as atendida, a retenção as ajustada or a correction as done. The app records who marked it: the servidor usuário, i.e. the footer ★, or “Equipe” when none is set. It also records when, and the history entry carries `by`. An optional answer (“o que foi feito”) also marks the devolutiva as atendida.
- “Liberar” (quick-lib) asks for confirmation while revision items are still pending.
- Closing `/cmt` re-renders the panel, so the cards reflect devolutivas and retenções right away.
- In `/cmt`, the devolutiva counter shows pending devolutivas, or ✓ when all of them are atendidas. The detail list says who answered each one and when. The stage reads “Retido · ajustado” after the adjustment. The Mesa do CM cards show “Devolutiva pendente/atendida” for monocráticas.
- **Monocráticas:** `obsRevisao` lines (`Autor (dd/mm/aaaa): texto`, where `CM` means a devolutiva from `returnMono`) are turned into items. Their state lives in `x.revState[hash da linha]` (`done`, `doneAt`, `doneBy`, `resp`), and the lines themselves are never rewritten. The list row shows “Devolvida pelo CM · dd/mm” or “Devolutiva atendida”. The new “✓” button opens the Revisão dialog, which has the devolutivas (checkbox + answer), the revision notes (new note by revisor/corretor), the history and “Enviar à assinatura do CM”. That button stays blocked while a CM devolutiva is pending. `PautaDecisoes.monoRevItems(x)` is exported.
- Avisos (bell): the server and corretor of the row receive “Devolutiva do CM” and “Retido pelo CM” (go → the card). The responsible person and revisor of the monocrática receive the CM's pending devolutivas.

## Página /padrao · Gerador de minutas integrado aos cards (v78)
`public/padrao.html` is the Gerador de minutas (CMTEXT: relatório, minuta/voto, ementa, correção, paradigmas). It opens in its own layer `#cmt-padrao` (`window.CMTPadrao`) inside `pauta-original.html`, under the route `/padrao`.
- **Routing.** The shell routes `/padrao` → `Home`. The iframe posts `pauta:open-padrao` / `pauta:close-padrao`. `applySharedPautaRoute(location, ready, CMTAdvanced, CMTPadrao)` keeps `/cmt` and `/padrao` mutually exclusive, closing the other layer silently. Outside the shell, use `pauta-original.html?view=padrao`.
- **Card button.** Each card has a pen-icon “Padrão” button in the data pill, next to JSON/TXT (`data-action="padrao-open"`). It opens the layer and imports the card through `Page.processPayload(i, session, {slim:true})`. This is the same `gabA-processo` payload as the card's JSON export: ident (number, class, subject, parties, tema, `especificidadesTags` from `_pautaSpecificities`), relatório and ementa from the Painel.
- **Import rules.** The import goes through the generator's own `importarProcessoJsonTexto`. Two cases skip the generator's confirmation:
  - the active case is empty: the import applies directly (`__grAplicarDireto`);
  - it is already the same process: the app reports “mesmo” and does not re-import.
  In every other case the generator asks before replacing the active case. While that confirmation is pending, the bar keeps the chosen card (`ST.want`).
- **Bar.** The top bar has ← Pauta (or Esc), Sessão, Processo, “Ir para” (item or number), and the card's context: server, delivery, CM devolutivas, retenção. Its actions are Carregar/Reimportar do card, “Registrar entrega” and “Ir ao card”.
  - “Registrar entrega” uses `PautaControl.recordMinutado`. It asks before replacing an existing date, and before filling the server with the servidor usuário.
  - The bar follows the generator's active case (`padrao:caso` message from the `padrao-ponte` script) and finds the matching card.
- **What the card stores.** Only `r._padrao {at, by, session}` (last use, at most once a day per person). No minuta text is stored in the pauta; the active case stays in the generator's own browser storage, as before.
- **Storage protection.** The original generator, and the copies embedded in its internal frames (decoded in `decode64` and in the Correção gzip), erased every localStorage key on load. `padrao.html` now preserves the keys `cmt*`, `pauta*` and `__pauta*` (`window.__protegerPauta`). As a safety net, the layer restores pauta keys removed by another document within 20 s of the frame loading.
- **DataJud.** The module that was in a `<template>` (and depended on the missing `/datajud-ui.js`) now runs inline (`<script id="datajud-modulo">`).
- **API (api-server).** `routes/padrao.ts` + `lib/padrao-catalog.ts`:
  - `/api/shared/session`, `/catalogs?sinceRevision&julgados=excluir|somente|incluir`, `/catalogs/mirror-status` and `/catalogs/precedents/search` (the generator's grammar, with facets) are read-only. They read `data/paradigmas.json` (schema `gabcmt.catalogos`) from `PADRAO_CATALOG_REPO` (default `brndutra/gabcmt`), `PADRAO_CATALOG_BRANCH` and `PADRAO_CATALOG_PATH`.
  - Reads use an optional token (`PADRAO_GITHUB_TOKEN` or `CNTRLA_GITHUB_TOKEN`), with a 10-minute cache; the last valid read is kept if GitHub fails. `paradigmas` = Modelo + Modelo-matriz; precedents come only through search.
  - `POST /catalogs/publish-github` and `POST /session` answer 403: this app does not write to the (public) repository.
  - `POST /api/datajud/:tribunal` proxies the CNJ public API with the key on the server (`DATAJUD_API_KEY` or the CNJ public key).
  - `/api/jurisprudencia/*` (external jurisprudence search in the generator) is not implemented.

## Importar/Exportar por aba nas Configurações Globais (v79)
Module `cmt-cfgio-feature` (`window.CMTConfigIO`).
- **Header buttons ⇩/⇧.** At runtime they become `data-app="cfg-tab-export"` / `cfg-tab-import` and act on the open tab:
  - **Sessões e marcos** reuses the Hub de Sessões. Export: format `controle-pauta-hub-sessoes` with sessions, marcos, linked processes, lists, productivity, calendar, team and statistics. Import: the hub's own preview (merge/replace, team, calendar). The hub's own “Exportar/Importar sessões” buttons are hidden.
  - **Servidores** uses `controle-pauta-servidores` v1 (`team` without `pendingIssues`/`pendingCompletions`).
  - **Assuntos e Procedimentos** uses `controle-pauta-assuntos` v1 (`assuntos` without the derived `rows`).
  - **Avisos e notificações** uses `controle-pauta-avisos` v1 (`pautaPreferences.globalDashboardAlerts`).
- **Import rules.** Every import opens the `#cfg-io-dlg` preview, with counts of existing and new records and a choice between:
  - **Mesclar** (default): matches by id, then by normalized name; nothing missing from the file is removed;
  - **Substituir**: asks for a second confirmation.
  The dialog also offers “Baixar backup atual”. A failed import restores the snapshot. After applying, the app re-renders and saves.
- **Full backup.** The complete panel backup (`data-app="backup"` / `restore`, unchanged) moved to the ⋯ menu: “Backup completo do painel (JSON)” and “Restaurar backup completo”.
- **Session pill.** In Editar sessão selecionada, “Exportar processos” is now a pill `.pse-pill`:
  - **Excel**: the old export, sheets Processos and Sessão;
  - **JSON**: all the information of that session in the Hub format (`escopo:'sessão'`), re-importable through the ⇧ button of Sessões e marcos.

## Calendário do gabinete em aba própria (v80)
The office work calendar (working weekdays, holidays, recesses, days without office hours, the Justiça Federal holiday preset, the month grid) is no longer below Sessões e marcos. It has its own Configurações Globais tab, **Calendário** (`#cmt-settings-cal-tab`, aria-label “Calendário do gabinete”), placed right after Sessões e marcos.
- **How it works.** Both tabs keep the app's internal tab `state.tab='calendario'`; the view is chosen by `data-cfg-calview` and remembered in `pauta.cfg-calview.v1`. CSS hides the other part: `#app-content.cfg-calview-cal .psh` and `.cfg-calview-sessoes .cal-area`. The calendar module is unchanged.
- **Import/export.** The header ⇩/⇧ buttons on this tab use the format `controle-pauta-calendario` v1 (`workCalendar`: weekdays, excluded, labels). Import also accepts the calendar inside a Hub de Sessões file or a GitHub sessões-calendário file.
  - Mesclar adopts the file's weekdays, adds the new dates and updates type and description of matching dates; no date is removed.
  - Substituir makes the calendar exactly the file's.
  - After applying, the session deadlines are recalculated (`syncSessionPlans`).
- **Header layout.** So that the 5 tabs fit, the save indicator in the header became a dot; its text moved to the tooltip.

## Padrão: barra, sincronização com o card e espécies próprias (v81)
- **Barra do Padrão** (`#cpd-bar`, módulo `cmt-padrao-feature`) em duas linhas: navegação (Pauta, sessão, processo, Ir para) e caso (processo, espécie, estado de sincronização, servidor, entrega, devolutivas/retenção do CM). Ações: **Inteiro teor**, **Carregar no Padrão** / **Atualizar do card**, **Devolver ao card** e o menu ⋯ (Registrar entrega da minuta, Reimportar tudo do card, Ir ao card).
- **Sincronização.** A ponte (`padrao-ponte` em padrao.html) guarda em `gabA_padrao_base_v1` (localStorage do Padrão, 30 casos, sem textos de peças) a base da última importação: `card` (seções ident/relatório/ementa do card) e `pad` (estado do Padrão logo após aplicá-las). Estado: `em-dia`, `alterado` (o card mudou) ou `sem-base`.
  - “Atualizar do card” mescla campo a campo: só troca o que mudou no card e não foi editado no Padrão; o que foi editado no Padrão é mantido e listado. Sem base, só preenche campos vazios.
  - “Devolver ao card” abre a conferência `#cpd-dev` (vazios no card marcados; divergentes só com “Substituir”) e grava no card os campos integrados (dados do processo, decisão impugnada/ED/AgInt/retratação, decisão recorrida, relatório, contrarrazões, MPF, recursos); registra “Campos devolvidos do Padrão” no histórico.
- **Inteiro teor no Padrão = diálogo do card.** `window.CMTInteiroTeor.open(row)` / `openFile(row,file)` abrem o mesmo `#cmt-txt-dlg` (documentos → conferência → gravação, nunca sobrescreve sem “Substituir”); ao gravar, `cmt:inteiro-teor-gravado` atualiza o Padrão campo a campo. No Padrão, o botão “Inteiro teor .txt” do gerador, o atalho do cabeçalho e o arrastar-soltar de .txt passam por esse diálogo quando há card; fora da pauta, segue a leitura própria do gerador.
- **Espécies** (ED, agravo interno, juízo de retratação): `Page.padraoKind(r)` — manual em `Padrão - Espécie` (ou `nenhum`), senão etiquetas/classe/tipo de recurso/assunto.
  - Card: bloco próprio no Painel Operacional (Sentença e recursos), com `Impugnada - ID/Data/Órgão/Relator/Síntese`, `ED - Vício/Ponto`, `AgInt - Fundamentos` e `Retratação - …` (síntese, embargos, precedente, tema, tribunal, devolução, questão, resultado, alteração).
  - TXT: destinos novos `impugnada`, `devolucao`, `edret`; pré-seleção por espécie (acórdão embargado; decisão agravada; acórdão em retratação + embargos anteriores + decisão de devolução + recurso então julgado) e sugestões dos campos próprios; a espécie detectada no TXT pode ser gravada no card.
  - Payload ao Padrão (`padraoIdent`): `ident.recurso`, decisão impugnada, partes p1/p2 e recursos ligados às partes com o resultado do voto; para ED/AgInt `relatorio.sentencaIds` = ID da decisão impugnada; retratação no vocabulário do gerador (`retratOrgao` '' = da Turma, `retratTribunal` '' = STF, `retratDevOrgao` '' = Vice-Presidência); ementa com a classe da espécie e dispositivo próprio (o que foi escrito à mão no card prevalece).
  - Cabeçalho do gerador: etapas por espécie (a marca CMTEXT é mantida) (Acórdão embargado / Decisão agravada / Acórdão em retratação, Devolução).
- **Minuta.** (v81) O gerador anexado tinha os quadros de voto, matriz e outros vazios; a partir da v83 eles vêm do `construtor.html` do repositório gabcmt.

## Padrão integrado ao gerador; notificações com referência; comparativo expansível (v82)
- **Padrão.** Com o gerador pronto, a navegação (Pauta, sessão, processo, Ir para) entra no rodapé do gerador (`#grFoot`, nó `#cpd-foot`), com as mensagens da barra no lugar do status (`#cpd-msg`). O card (item, sincronização, servidor, entrega, devolutiva/retenção do CM) e as ações (Inteiro teor, Carregar/Atualizar, Devolver, ⋯) entram na célula do CMTEXT (`#grHero .gr-id`, nó `#cpd-hero`, antes de `#grTools`).
  - A pauta desenha esses nós dentro do iframe; a ponte chama `CMTPadrao.renderSlots()` a cada redesenho do cabeçalho. A barra de cima (`#cpd-bar`) só aparece enquanto o gerador carrega.
  - Os estilos vão em `<style id="cmt-cpd-frame-style">` com seletores `#cpd-hero.slot`/`#cpd-foot.slot`: os motores de tema claro/noturno do gerador pulam ids `cmt-…` e seletores com `.slot`. Sem isso, as cores são recoloridas.
- **Notificações.** O módulo `cmt-notif-ref-feature` (`window.CMTNotifRef`) envolve `PautaApp.notify`. Cada aviso ligado a um processo grava `ref`, `proc`, `item`, `session` e `row`.
  - A referência vem do número CNJ no texto; do “item N” na sessão em foco; ou do card em que houve clique ou edição nos 4 s anteriores (exceto mensagens gerais de sessão, backup, importação etc.).
  - Onde aparece: no aviso flutuante, no sino (avisos do painel e entregas) e na lista “Para você” (agora com data/hora da ação), com o botão “Ir ao item”. O botão fecha sino, Padrão, /cmt e Configurações Globais, seleciona a sessão do item e localiza o card. Para monocrática/urgência, abre a lista própria.
- **Configurações Globais.** O “Comparativo de produtividade por sessão” é um `<details class="psh-cmp">`, recolhido por padrão; a escolha fica em `pauta.cfg-comparativo.v1`.
- **Sessões antigas.** O HTML trazia uma cópia estática, salva do navegador, da pauta de 19/10/2026 dentro de `#controle-pauta-root` (~2,9 MB). Foi removida: o aplicativo redesenha tudo ao abrir.

## Padrão: minuta da decisão/voto, Ementa no rodapé, monocráticas e sem duplicações (v83)
- **Construtor de minuta.** `padrao.html` traz as fontes `voto`, `matriz` e `outros` do `construtor.html` do repositório gabcmt. Todas passam por `decode64`, logo por `__protegerPauta`. O gerador usa a página `matriz` (estrutura + modelos) para o voto e `outros` (despachos e decisões) para pronunciamento não voto.
- **Painel “Minuta · Prévia editável”.** A segunda vista deixou de ser a Ementa e passou a ser **Voto** (ou **Decisão**, conforme o pronunciamento): a página da minuta é posicionada sobre a prévia do relatório.
  - Script `padrao-v83-minuta`, `window.PadraoMinuta`. O `grVista('voto')` mostra a minuta; o `grVista('eme')` abre a Ementa. A última vista fica em `gabA_padrao_vista_v83`.
- **Ementa no rodapé.** Botão “Ementa” no `#grFoot`, que abre uma gaveta acima do rodapé (`body.gr-eme-dock`). A gaveta tem um cabeçalho `#grEmeHead` com Ampliar (`gabA_padrao_ementa_alta_v83`) e ✕; Esc também fecha. O iframe não é movido; só reposicionado por CSS.
- **Sem duplicações.**
  - O grupo Docx/PDF/Copiar do rodapé foi ocultado, porque cada painel tem a sua barra.
  - Dentro da pauta (`html.em-pauta`), o “Inteiro teor .txt” do gerador e o atalho do cabeçalho dão lugar ao botão “Inteiro teor” da célula do CMTEXT.
- **Monocráticas.** O seletor de sessão do rodapé tem o grupo “Controle de Decisões → Decisões monocráticas”, e os processos aparecem como `m:<id>`.
  - `monoPayload` monta um gabA-processo com `origemTipo:'monocratica'`: pronunciamento `terminativa` (ou `interlocutoria` para tutela/sobrestamento), recurso pela classe, partes, assunto, tema e resultado pelo tipo. Relatório e ementa partem em branco (`prep` na ponte).
  - O Padrão entra em `modo('mono')`: vista Decisão, sem Ementa e sem “Devolver ao card”. O inteiro teor usa a leitura do próprio gerador (`teorNativo`), e o ⋯ leva à monocrática no Controle de Decisões.
  - “Ir para” e a busca pelo número digitado no gerador também encontram monocráticas. Existe ainda `CMTPadrao.open({mono:id})`.

## Painel da Ementa no visual da Ordem do dia (v84)
- **Painel.** A gaveta da Ementa do rodapé do /padrao virou um painel no visual da Ordem do dia: ocupa a largura toda sobre o rodapé, escuro (`hsl(214 9% 21%)`), com sobretítulo dourado “EMENTA · CONSTRUÇÃO”, título, subtítulo com a contagem de avisos, “Ampliar” e ✕ quadrados.
- **Duas colunas.** Dentro do quadro da ementa (estilo `cmt-eme-dock-css`, seletores `html.slot[data-aba="ementa"]`), a prévia fica à esquerda e os campos (fases) à direita. Somem o “Minimizar preenchimento” e o divisor.
- **Conformidade da ementa.** O `#avBody` do quadro (avisos e “Corrigir termos”) passa para um campo próprio, `#cpdEConf`, sob a prévia, com selo “n avisos” ou “Conforme”.
  - O painel lateral “Conformidade” mostra só o relatório, e o número no puxador conta só o relatório. Isso foi feito por substituição de texto em `p83.py` sobre `ladosMontar`/`abrirLado`/`atualizarContagem`.

## /padrao direto, menos botões, pronunciamento, catálogo e contraminuta (v85)
- **Abertura direta do /padrao.** Em produção, `.replit-artifact/artifact.toml` só reescrevia /cmt. O /padrao caía no arquivo `padrao.html` (URL limpa), ou seja, no gerador nu e sem rodapé. Correção:
  - nova regra `[[services.production.rewrites]] from = "/padrao" to = "/index.html"`;
  - guarda `padrao-rota` no topo do `padrao.html`: aberto fora de iframe, faz `location.replace(base+'?rota=padrao')`;
  - o `index.html` do shell converte `?rota=padrao|cmt` no caminho (`history.replaceState`). Exige rebuild do shell.
- **Sem “versões” antes do Padrão.**
  - Script `cmt-route-boot` no topo da pauta-original: `html.cmt-route-padrao` cobre a pauta até a camada abrir. O shell mostra “Abrindo o Padrão…”.
  - Na camada, só a tela de carregamento (com botão “Pauta”) até a ponte ficar pronta e `#cpd-hero`/`#cpd-foot` serem vistos duas vezes (`ST.ready`). A barra de cima é só reserva (`ST.failed`, após cerca de 60 s).
- **Enxugamento do /padrao.**
  - Saem do rodapé o status “navegador · arraste…” e o grupo Docx/PDF/Copiar.
  - Saem do Registro e Relatório o “Recolher preenchidas”, os “Ajustes de redação” e o “i”.
  - O ícone “Importar dados do processo” (`#gabImpBtn` da seção 1) vai para a linha de ferramentas do CMTEXT (`#grImpDados`). Saem dali o .json (`#grJson`) e o “Salvar ficha” (`#grSave`).
  - O “Inteiro teor” do gerador (`#grTeor`) fica visível e é o único, interceptado para o diálogo do card. O botão da célula saiu.
  - Ações do caso: `#cpd-tools`, primeiro filho de `#grTools`, com “Carregar” (quando outro caso está aberto) e o menu ⋯ com Atualizar (ponto âmbar quando o card mudou), Devolver, entrega, Reimportar e Ir ao card.
- **Tipo de pronunciamento no rodapé.** `#grPron` (voto, terminativa, interlocutória, despacho) chama `setIdent({pronunciamento})`. Fora de voto, `body.gr-sem-ementa` esconde a Ementa e bloqueia `PadraoMinuta.ementa()`.
- **Catálogo integrado.** O módulo `cmt-padrao-catalogo-feature` (`window.CMTPadraoCatalogo`) põe o bloco `#cmt-pad-int` na aba Assuntos das Configurações Globais.
  - KPIs: em comum, só no Padrão, divergências de seção/ramo, paradigmas por assunto.
  - Ações: “Trazer N assuntos” (cria assunto e ramo na pauta) e “ver no Padrão” (abre os paradigmas filtrados).
  - No gerador, `Banks.lista('assuntos')` mescla `CMTPadraoCatalogo.assuntos()` (a pauta primeiro). O original fica em `Banks.__listaOriginal`.
- **Referências nas Configurações Globais.** O catálogo de assuntos e procedimentos, sua integração ao Padrão e as estruturas relacionadas devem ser administrados pela área nativa “Configurações Globais › Referências”; não reintroduzir a aba Referências na Central de Comando.

**Why:** o usuário decidiu manter a edição e a navegação de referências nas Configurações Globais, usando o catálogo compartilhado já consumido pelo app, em vez de duplicar a interface na Central.

**How to apply:** mantenha a área nativa Assuntos e Procedimentos habilitada e vinculada ao estado compartilhado; preserve na Central apenas usos auxiliares do catálogo, sem uma aba própria de Referências.
- **Contraminuta.** Em agravo (de instrumento ou interno), “contrarrazões” vira “Contraminuta”: no passo 3 do hero, nos títulos do relatório, nos cards da pauta e no diálogo de inteiro teor.

## Ficha à direita, Minuta à esquerda, conformidade interna e Ementário (v86)
- **Ficha e Minuta.** A Ficha (Registro & Relatório) e a Minuta (Estrutura & Edição) são painéis minimizáveis. Na vista Voto, a página da minuta cobre todo o `main.layout` do relatório, e abrir uma fecha a outra.
  - A Ficha minimiza para uma aba vertical (`gr-ficha-min`, salvo em `gabA_ficha_min`).
  - A Minuta ganha o cabeçalho “MINUTA · Estrutura & Edição” e o seletor `.cpd-seg` (Relatório | Voto/Decisão | Ambos), que comanda `grVista` e o gabu interno.
- **Diretrizes e Conformidade internas.** Os puxadores e laterais do relatório (`#sbHandle`/`#avHandle`/`#sidebar`/`#avSide`) voltaram a ser internos à Prévia editável, como no voto. `#grHandles`/`#grSide` ficam ocultos.
  - `grAbrirLado` e `avToggle` apontam para `ladoInterno`. O “Conformidade” do hero abre o painel interno.
- **Faixa do CMTEXT.** `#grFaixa` ocupa o topo da área branca (`.gr-steps-w`), com “BANCO”, “Paradigmas N” e “Ementário” mais o indicador de semelhança (`simCount`).
  - O Ementário é o `#bancoBox` com `body.gr-ementario`: título “Ementário”, só a peça Precedente, ordem por semelhança.
  - Nos Paradigmas comuns, a aba Precedentes sumiu.

## CMTEXT e rodapé do /padrao reorganizados (v87)
- **Etiqueta do número.** “Item N” (ou “Monocrática”) fica à esquerda do número do processo, em `#cpd-item`, dentro de `.cpd-numrow`. A `.cpd-numrow` é criada em `slots()` em volta de `.gr-num`, porque o hero é refeito por `innerHTML`.
  - A etiqueta só aparece quando o caso aberto no Padrão é o do card escolhido (`c.same`).
  - Na monocrática, o número usa 19px para caber.
- **Célula do CMTEXT sem chips.** `#cpd-hero` só mostra o texto de “escolha o processo” quando não há caso; fora isso, fica oculto. `#cpd-tools` saiu de `#grTools`.
- **Rodapé.** Ordem visual: Pauta · Pronunciamento · Sessão/Processo/Ir para · `#cpd-stat` · `#cpd-tools` · Ementa (à direita).
  - `#cpd-foot` usa `display:contents` e `order`. O `#grPron` continua inserido pelo layout83 antes da Ementa.
  - `#cpd-stat` mostra integração, servidor, estado da minuta, devolutiva, retido e encerrada (`chipsHTML(c,{semItem:true})`). Na monocrática: integração, situação, responsável, revisor e prazo.
  - `#cpd-tools` traz “Carregar” e o ⋯. O menu abre para cima e alinhado à direita. Abaixo de 1640px, “Carregar” fica só no ícone e os seletores encolhem.
- **Avisos.** A antiga faixa `#cpd-msg` virou um balão passageiro acima do rodapé, à esquerda (fixo, sem cliques, 9 s). O aviso “outro caso no Padrão” saiu: o indicador do rodapé e o botão “Carregar” já dizem isso.

## /padrao em qualquer moldura e pacote cumulativo (v88)
- **Guarda `padrao-rota`.** Só fica quieta quando o `padrao.html` está no `#cmt-padrao-frame` da pauta (`window.frameElement.id`) ou com `?solo=1`. Em aba própria ou dentro de outra moldura (por exemplo a prévia do Replit), volta a `?rota=padrao`.
- **Shell antigo.** O módulo do Padrão também abre com `?rota=padrao` (na própria URL ou na do shell), mesmo antes de o shell novo converter a rota.
- **Histórico.** Em 21/10/2026 o repositório estava na v78; os pacotes v79–v87 não tinham sido aplicados. Por isso a página mostrava a barra superior antiga e o rodapé do gerador sem a Ementa. A v88 foi entregue como pacote cumulativo.

## Seção competente no Ementário (v88)
- **Campo.** Script `padrao-v88-secao` (`window.PadraoSecao`). Cria a coluna `secaoCompetente` logo depois de `assunto` em `BANCO_COLS`. Na ficha de precedente, “Seção competente” aparece ao lado do assunto.
  - A primeira opção, “Pelo assunto · X”, é o automático. Outra opção fica gravada no registro, e só com `body.adm`.
- **Preenchimento automático.** `secaoDe(x)` = seção gravada na ficha, senão a do assunto, senão a do ramo do direito.
  - Assunto: `Banks.lista('assuntos')`, com a pauta primeiro e o catálogo completando; comparação normalizada, com sinônimos.
  - Ramo do direito: primeiro o do próprio assunto, depois `x.ramoDireito`. Só vale quando o catálogo é praticamente unânime (pelo menos 5 assuntos e 90% numa seção): Tributário → 2ª, Civil → 1ª, Previdenciário → 3ª.
  - Nada é escrito nos registros: o valor é sempre derivado. Assim não se criam falsos “conflitos” com o banco compartilhado.
- **Filtro.** Faceta “Seção competente” (`#bfSecBox`, depois de Pronunciamento), com contagens, etiqueta (`data-bf-rm="secao"`) e “Sem seção definida”.
  - Enquanto há seção escolhida, a faceta de assunto esconde os assuntos de outras seções.
  - Pesquisa paginada no servidor: `parametrosBuscaJulgados` troca a seção pela lista `assuntos` dela; `chaveBuscaJulgados` inclui a seção; as contagens saem de `JULGADOS_FACETAS.assuntos`.
- **Ajuste visual.** A opção marcada das facetas ficava em `#e8eef8` (herança de painel escuro). Agora fica legível no tema claro.

## Faixa inferior do CMTEXT e Minuta no molde da Ficha (v89)
- **Faixa inferior.** `#grFaixaInf` é o último filho de `.gr-steps-w` (área branca do CMTEXT): “Aba” com Relatório · Voto/Decisão · Ambos e uma dica do painel aberto.
  - Relatório chama `grVista('rel')`. Voto e Ambos chamam `grVista('voto')` e clicam no `.gabu-seg` `foco`/`ambos` da página da minuta.
  - A alternância saiu do cabeçalho das prévias: `.gr-seg` do relatório oculto; `.cpd-seg` e o antigo `seg()` não são mais usados.
  - O hero é refeito por `innerHTML`, por isso `faixa()` reinsere as duas faixas.
- **Minuta = Ficha.** `minutaCartao(d,n)` em `matriz` e `outros`:
  - cabeçalho `.cpd-hd` com sobretítulo “Minuta” e título “Estrutura & Edição” (mesma tipografia do `.panel-head` da Ficha);
  - no modo matriz, o botão “Modelos e parágrafos” mostra ou esconde `aside.ref` dentro do cartão;
  - ‹ minimiza para a aba vertical `.cpd-mn-tab` (`gabA_minuta_min`). A coluna de modelos é lembrada em `gabA_minuta_ref`, aberta por padrão.
- **Matriz.** `.shell` é uma grade de dois cartões: cabeçalho sobre `ref` + `workspace`, e a prévia em cartão à direita, separada por 16px. Os `.pn-tg` nativos ficam ocultos.
- **Decisões (`outros`).** `#formMain` vira o cartão da esquerda. A prévia (`h2.prevhead`) ganha o sobretítulo “Minuta”.
- **Tema noturno.** Coberto por `html.slot[data-tema="noturno"]`.

## Ementário no padrão A: coluna única, filtros em linha (v90)
- **Escopo.** Script `padrao-v90-ementario` (+ estilo `cmt-v90-ementario-style`, com `data-tcl="1"` para os motores de tema não o recolorirem; o da seção v88 também).
  - Vale só com `body.gr-ementario` e `BTIPO==='Precedente'` (classe `#bancoBox.em-a`). Fora disso, `desfazer()` devolve `#bfSoClasse` ao lugar e o painel de Paradigmas fica como era.
- **Cabeçalho.** Sobretítulo, título e o selo `#bfSimChip` (texto de `#simCount`), com `#bancoSum` à direita. `.bf-tipos` e `#bfNovoTopo` ficam ocultos.
- **Busca.** “Procurar em” vira `select.bf-escsel` dentro de `.bf-sbox`, clicando no botão oculto de `#bfEscopo`. O “?” (`.bf-ajuda`) mostra a dica da busca precisa; `#bfInterp` aparece sempre que a busca tem termos.
- **Filtros em linha (`#bfFiltros`).**
  - Botões para Pronunciamento, Seção competente, Classe, Assunto e Validação. Cada um abre a sua `.bf-fbox` numa janelinha (o `aside.bf-fac` vira popover, com `data-pop`). Fecha com clique fora ou Esc.
  - Os filtros do catálogo (`#pcView .pc-filtros`) são movidos a cada render para a linha, como “Resultado”, “Semelhança” e “Situação do assunto”. “Abrir/Recolher todos” vão para a barra de resultados.
  - Também na linha: “Só a classe do processo aberto (classe)” e “Limpar filtros” (`data-em-limpar`: zera o BF, inclusive a seção, e os selects do catálogo).
- **Resultados.** Ordem Semelhança · Relevância · Recentes; Agrupado · Tabela (sem Planilha; `BVIEW='planilha'` volta a `sumario`).
  - Cada `.pc-it` em grade: semelhança (`.em-sim`, 3 barras por `SIMNIVEL`) · dados e ementa (cabeçalho em serifa, tese, resultado, temas) · Usar (dourado) e Ver ficha.
- **Rodapé.** `#bfEmRodape`: “Novos registros e edições ficam no Gerenciar banco, com senha” (abre `abrirGerenciarBanco`, onde está o `+ Novo registro`) e “Sobre o banco”, que mostra o `.banco-foot`.

## Conformidade em cartão próprio ao lado do CMTEXT (v91)
- **Layout.** `confCard()` em `layout83` envolve o `#grHero` num `#grHeroRow` (flex) e põe ao lado o `#grConfCard`, escuro como a célula do CMTEXT, com 300px.
  - O conteúdo fica num `.gcc-in` absoluto, para o cartão nunca ser mais alto que o hero.
  - A etapa “Conformidade” sai da linha de etapas (`--n:4` e 5º ponto do trilho oculto); a largura do trilho é recalculada sobre as quatro etapas.
- **Conteúdo pela aba.**
  - Relatório: `#warnings .warnitem` e `#grConf .warnitem` (regras de redação, em dourado) do quadro do relatório.
  - Minuta: `#avWarn .warnitem` e `#warnings .warnitem` da página da minuta (matriz ou outros). A etiqueta diz “Relatório” ou “Minuta · Voto/Decisão”.
- **Comportamento.** Clicar num aviso abre o painel interno de conformidade da aba (`confInterna()` no relatório; `#avHandle` na minuta) e destaca o aviso. “Abrir o painel de conformidade ›” só abre o painel.
  - Hero minimizado: cartão em uma linha. Abaixo de 1100px, o cartão desce para a linha de baixo.

## Revisão de duplicações, divergências e sobreposições do /padrao (v92)
- **IDs duplicados.** O `botoes()` do gerador recriava `#grImp` (Inteiro teor .txt, .json e os `input[type=file]`) depois de o `ferramentas()` movê-los para `#grTools`. Agora sai cedo também quando `#grTools` existe (substituição em `p83.py`).
- **Um aviso por evento.** O `say()` do módulo da pauta usa o `toast()` do próprio gerador quando ele está montado.
  - Saíram as mensagens “Dados do card importados no Padrão”, que repetiam o aviso “Importado de Controle de Pauta…”.
  - `#toast` e `#djAviso` ficam a 62px do fundo (acima do rodapé, e acima da Ementa quando aberta).
- **Contagem coerente.** A linha sob o CMTEXT (`#grMeter`) passou a mostrar “N de 4 etapas do relatório completas”, sem a conformidade, que tem cartão próprio; deixou de ser clicável.
- **Rótulos.** A prévia do relatório tem sobretítulo “Relatório”; “Minuta” fica só na aba da minuta.
- **Pronunciamento único.** `pronUnico()` esconde os seletores iguais (com `terminativa`, `interlocutoria` e `despacho`) nas páginas da minuta e deixa a nota “escolhido no rodapé”. O filtro de modelos da coluna da matriz permanece.
- **Modelo ativo.** Com “Modelos e parágrafos” aberto, o `#matSelect` do topo da estrutura fica oculto; a escolha é feita na coluna.
- **Auditoria.** Em tempo de execução (relatório, voto, ementa, decisão, Ementário): sem IDs repetidos. As sobreposições restantes são camadas intencionais: a gaveta da Ementa, o diálogo do Ementário e o balão transitório.

## Conformidade só no cartão; “Ambos” na prévia (v93)
- **Sem painel lateral.** O puxador ⚠ (`#avHandle`) e o painel lateral (`#avSide`) de conformidade/conferência ficam ocultos no relatório, na matriz e nas decisões (`outros`), e `av-open` é retirado. A Diretrizes continua interna. A Ementa mantém o seu campo próprio (`#cpdEConf`).
- **Tudo no cartão.** “Detalhes e regras ▾” abre `#grConfPop` sob o cartão: um espelho do `#avBody` da aba aberta (pendências, regras de redação, regras a observar).
  - Cliques e alterações no espelho passam ao elemento original (`popClique`/`popMuda`, pelo caminho de índices no DOM), e o espelho é refeito quando o conteúdo muda.
  - Clicar num aviso do cartão abre o detalhe e destaca o aviso. Fecha com ×, Esc ou clique fora.
  - `confInterna()`, `avToggle()` e `grAbrirLado('conf')` abrem o detalhe do cartão.
- **Abas × visualização.** A faixa do CMTEXT tem só as abas Relatório e Voto/Decisão. A visualização “Ambos” voltou para a prévia da minuta: `.gabu-seg` no cabeçalho, com “Só o voto | Relatório e voto” (ou “a decisão”); a opção “outro” (só o relatório) fica oculta, porque a aba Relatório já cumpre esse papel.

## Avisos no cartão, regras na Diretrizes (v94)
- **Cartão da Conformidade.** Contém todos os avisos da aba aberta, não apenas um resumo. Cada aviso traz as suas ações, se houver: os botões e campos do aviso original viram botões `data-gcc-k`, que clicam no original identificado por `data-cpd-k`, marcado por `marcarK`.
  - O quadro “Detalhes e regras” (`#grConfPop`) foi retirado.
  - `confInterna()`, `avToggle()` e `grAbrirLado('conf')` passaram a só realçar o cartão (`gcc-flash`).
- **Regras na Diretrizes.** `regrasDiretrizes(d,nome)` espelha no topo do `#sidebar .sb-body` de cada aba (relatório, matriz, outros) um `<details class="cpd-regras">` “Regras a observar”.
  - O conteúdo é o do `#avBody`, sem avisos (`.warnlist`, `.warnitem`, `.okitem`, `.edrep`) e sem o rótulo das pendências.
  - Cliques e alterações nas regras passam ao original. Sem regras, a seção não aparece.
- **Atalho.** “Regras no painel Diretrizes ›”, no cartão, abre a Diretrizes da aba aberta e leva às regras.
- **Largura da minuta.** `posicionar()` usa a largura do quadro do relatório, e não a do `main.layout`. Assim, a Diretrizes aberta no relatório não estreita a minuta.

## Diálogos de Urgências e Pendências redesenhados (v95)
- **Moldura comum.** Os dois diálogos abrem em altura cheia, centrados (até 1320 px), com filete dourado. O cabeçalho é grafite, com indicadores clicáveis. O rodapé traz os atalhos. Os estilos ficam em `cmt-v95-dialogos-style` (`data-tcl="1"`, ignorado pelos motores de tema).
- **Urgências** (as funções do módulo de decisões foram reescritas na fonte: `urg2Row`, `limHTML`, `urg2Drawer`).
  - Grupos por prazo: “Vencidas e vencendo hoje”, “Próximas 48 h”, “No prazo”, “Sem prazo” e “Concluídas”. Todos recolhem; “Concluídas” vem recolhido. A escolha fica em `cmt.urg.fold`.
  - Natureza do pedido em segmentos com contagem (`ui.lim.medida`). Os demais filtros continuam: recorte e responsável na barra; andamento, resultado e Detalhado/Compacta em “Filtros”.
  - Responsável trocado na própria linha (`data-dec-quick="resp"`), com a regra responsável ≠ corretor. “Designar”, com a carga da equipe e o corretor, continua no detalhe.
  - Detalhe numa gaveta lateral (`urg2-drawer`): andamento; Designar, Minuta e correção, Registrar decisão, Editar, Dúvida, Assessoria e Excluir; as quatro seções de dados. A decisão inline abre dentro da gaveta.
  - Indicadores do cabeçalho: vencidas, vencem hoje, em 48 h (filtro `prazo='48h'`), sem responsável, abertas e decididas no mês. Deferimento e tempo médio passaram ao rodapé. O resumo (resultados e natureza) abre por botão no rodapé (`cmt.urg.resumo`).
  - Atalhos: ↑/↓ navegam, Enter abre, N cria e Esc fecha, nesta ordem: decisão, gaveta e filtros.
- **Pendências** (`cmt-v75-pip` substituído pelo módulo v95, que usa os mesmos dados).
  - Abas GERAIS, CHAMADOS e SESSÃO, com G/C/S; [ ] trocam a sessão; N cria. Indicadores do cabeçalho: atrasadas, adiados a reincluir, retirados ag. reinclusão, chamados abertos e “para {servidor fixado}”. Há ainda o botão “Nova pendência”.
  - GERAIS: quadro e lista de sempre.
  - CHAMADOS: todos os chamados ao TI, separados em Abertos/Resolvidos/Todos, com filtro de sessão e busca. Ordem: o mais antigo primeiro. Cada intercorrência aparece uma vez (edita-se a versão viva, mostra-se a sessão de origem).
  - SESSÃO: adiados, com “Incluir os N na pauta de X” em lote; retirados (desta sessão ou todos aguardando reinclusão); chamados da sessão. Mantêm-se os controles da v75: destino, tarefa no PJe, quem vai fazer, situação, observação e “Incluir”.
  - Fluxo da sessão: oito afazeres-modelo (antes, durante, depois), afazeres próprios e três itens automáticos (reincluir adiados, destino dos retirados, chamados abertos). Fica guardado em `sessionDetails[sessão].cmtFluxo = {done:{kN:{by,at}}, extra:[…]}`.
  - `CMTPautaIntercorrencias.open('tickets'|'adiados'|'retirados')` continua valendo e abre a aba correspondente.
  - Outras intercorrências (v96): na SESSÃO, um cartão próprio lista as intercorrências da sessão que não são chamado ao TI (tipo, descrição, Pendente/Sanada), com “＋ Registrar” (tipos da lista global, sem “Chamado à TI”). Sanar ou reabrir grava no histórico do processo. O fluxo ganhou o item automático “Sanar as outras intercorrências”, e a contagem da aba SESSÃO as inclui.
  - Chamado para outra intercorrência (v97): “＋ Chamado” na linha registra o chamado (`ticketStatus='Aberto'`, data de hoje) sem trocar o tipo, e a intercorrência passa a Chamados, com o foco no nº. Classifica-se como chamado quem é do tipo “Chamado à TI”, cita “chamado” ou tem `ticketStatus`/`ticketNumber`. “↩” no chamado convertido desfaz o registro e a devolve a Outras. As duas ações vão ao histórico do processo.
  - Alertas, solicitações e intercorrências efetivamente registradas devem permanecer em controles distintos; a lista de intercorrências não deve incorporar alertas nem pedidos de sustentação/preferência.
    **Why:** o usuário pediu que o botão de intercorrências mostre somente registros de intercorrência, sem misturá-los com alertas ou solicitações.
    **How to apply:** ao alterar linhas ou cards de processo, mantenha cada tipo ligado à sua fonte e ação próprias.

## Cadastro de urgência enxuto e decisão no Controle de Decisões (v98)
- **Nova urgência / Editar pedido.** O formulário traz só o essencial do processo:
  - Processo: número, classe, partes, assunto, tema e especificidades.
  - Pedido: natureza, objeto, conclusão ao gabinete, urgência e prazo.
  - Na edição, “Mais dados do processo” guarda os campos importados (recebido, distribuição, última movimentação, tarefa atual, tramitação e observações). Na criação, “recebido” vai oculto com a data de hoje.
  - Os campos fora do formulário são preservados ao salvar.
  - Responsável: na linha ou em Designar. Saíram do formulário o bloco Minuta e correção e o bloco Decisão; este só aparece no modo decidir, aberto pelo Controle de Decisões.
- **Registrar decisão monocrática.** O botão, realçado na fase Minuta, chama `urg2ToMono`:
  - cria o card vinculado em Controle de Decisões, ou reabre o existente. Leva processo, classe, assunto, partes, tema, responsável (quem minutou ou o responsável), revisor (o corretor, se for outra pessoa), entrada (a conclusão), prazo, urgência e minutado. O andamento nasce “A minutar” ou “Em elaboração”;
  - fecha as Urgências, abre a aba Controle de Decisões filtrada pelo processo e abre o formulário do card;
  - o passo “Decidida” sem resultado faz o mesmo. O botão “Minuta e correção” saiu da linha e da gaveta.
- **Card vinculado.** O formulário da monocrática ganhou “Pedido de urgência vinculado”, com resultado do pedido, data da decisão e cumprimento (`limResultado`, `limDataDecisao`, `limCumprimento`). Esses valores gravam no pedido antes de `syncMonoToLim`, e o resultado é exigido para marcar Assinada.

## Diretrizes padronizadas, prévias idênticas e colunas lisas no /padrao (v99)
- **Conformidade.** Os avisos de conferência da aba aberta continuam todos no cartão Conformidade, ao lado do CMTEXT (v94). Não há outro quadro de avisos visível nas folhas.
- **Diretrizes** (`diretrizes99.js`, script `cmt-v99-diretrizes`).
  - As três folhas (relatório, matriz e outros) usam o painel escuro do relatório. A folha `dz-dark` é copiada como `cmt-dz-dark`, com o prefixo `cmt-` para escapar do motor de tema da folha, que trocava o dourado por azul. Complementam-na `cmt-dz99` e a alça “Diretrizes” igual.
  - Cabeçalho “{Relatório | Minuta de voto | Minuta · decisões e despachos} · consulta e apoio”, título “Diretrizes” e abas sublinhadas em dourado.
  - Abas da minuta: Minuta (específica), Gerais e Redação (cópias das abas `gerais` e `gr-red` do relatório, atualizadas quando mudam), e depois as abas próprias da folha (Modelos, Vocabulário).
- **Prévias** (`previa99.js`, script `cmt-v99-previa`, CSS `cmt-pv99`). O mesmo desenho e os mesmos botões nas três folhas:
  - Cabeçalho: “Prévia editável”; Relatório | Voto/Decisão | Ambos (o `gabu-seg` nativo, relido); limpar; regerar; copiar; ↓ .docx | .txt | ▾ (.doc, .odt, .rtf, PDF); − (minimizar).
  - Barra de formatação: N, I, ¶ Parágrafo e ❝ Citação. Na matriz, criada com `execCommand` e a classe `cpd-cit`.
  - Folha em papel e rodapé “alteração manual preservada até regenerar · N palavras”.
- **Funções por folha.**
  - Regerar: no relatório, devolve cada `p[data-g]` ao texto gerado e chama `registrarEdicaoPrevia` e `generate()`; na matriz, `#generateBtn`.
  - .docx da matriz: o `gabMatrizDocx` da folha do voto é embrulhado para ler negrito, itálico e citação de `#paper`.
  - Outros formatos: no relatório, `grExportar` nativo; na matriz e em outros, exportador próprio (.doc em HTML, .rtf, .odt em zip sem compressão e PDF por impressão).
  - Na visão de leitura da outra folha (`body.gabu-outro`), a barra de formatação some.
- **Ficha e Minuta em colunas lisas** (o desenho da imagem de referência, anterior à v89).
  - O cartão `.cpd-hd` sai. Volta o cabeçalho em linha `.cpd-mn-head` (“MINUTA Estrutura & Edição”) com o “−” nativo (`pn-tg`).
  - Grade nativa Modelos | Estrutura | Prévia: `--c1/--c2/--c3` com `:has(.pmin)`. O seletor do modelo-matriz continua só na coluna de modelos.
  - A Ficha usa cabeçalho em linha “FICHA Registro & Relatório” com “−” e colunas sem cartões. Ficha e prévia não ficam minimizadas ao mesmo tempo.

## Seções da Ficha como tópicos da Minuta (v100)
- `topicos()` (em `previa99.js`) converte cada `.section-head` da Ficha no formato dos tópicos da Minuta:
  - índice “0N” em dourado;
  - sobretítulo em versalete, com o parágrafo do relatório que a seção alimenta (`.gr-alvo`) ou o subtítulo (`.di-sub`);
  - título (“Processo”, “Partes e sentença”…).
- O cartão segue o tópico da Minuta: fundo #f9fafa, borda #e1e3e6, raio de 9 px e cabeçalho com linha inferior. Os botões da seção (Similares, + Recurso, recolher…) ficam à direita.
- O rótulo nativo “N. Título” fica guardado e oculto em `.cpd-tp-src` e é relido a cada ciclo, porque o relatório o reescreve (“Processo” ↔ “Dados do processo”; “Partes e sentença” ↔ “Juízo de origem”).
- O cabeçalho novo não usa `<span>`, porque o relatório escreve no primeiro `<span>` da seção.

## Voto com construtor Padrão ou Matriz (v101)
- **Antes.** O gerador unificava o voto na matriz (`voto-unif-js`), que forçava `VOTO_MINUTA_MODO='matriz'` e trocava o seletor “Padrão | Matriz” por um só botão “Voto”.
- **Agora.** Com Pronunciamento = Voto, o cabeçalho “MINUTA Estrutura & Edição” traz o seletor **Padrão | Matriz**:
  - Padrão = `frame-voto`, cartões 01 Abertura, 02 Fundamentação, 03 Caso vertente e 04 Encerramento;
  - Matriz = `frame-matriz`, tópicos e parágrafos dos modelos;
  - nas decisões e despachos o seletor some.
- **Implementação** (em `previa99.js`):
  - a escolha fica em `cmt.voto.modo`, por navegador;
  - `setMinutaModo` e `showPage` são reembrulhados para não forçar a matriz;
  - `aplicarModo()` repõe `VOTO_MINUTA_MODO` a cada ciclo;
  - carregar um modelo-matriz do banco leva à Matriz, como antes.
- **O Padrão tratado como a matriz.**
  - Recebe `MN_CSS`, por isso os avisos ficam só no cartão Conformidade, e `pronUnico`.
  - Recebe a mesma prévia: Relatório | Voto | Ambos, regerar, copiar, .docx | .txt | ▾ e −. O Padrão não tem “limpar”.
  - Recebe as Diretrizes escuras com Minuta · Gerais · Redação · Vocabulário. O painel, que abria pela esquerda, abre à direita (`cmt-dz99-lado`) sem empurrar o conteúdo.
- **Conteúdo separado.** Cada construtor guarda a sua própria minuta; a troca não converte um texto no outro.

## Aba Correção removida do /padrao (v102)

- A antiga aba **Correção** (Mesa de revisão · correção da minuta) nunca teve conteúdo em nenhuma base: o bloco `mesa-correcao-gz` vinha vazio e a página ficava oculta por `#page-correcao{display:none!important}`. A pedido do usuário, saiu por inteiro.
- Removidos no `padrao.html`: botão da aba (`data-page="correcao"`, Alt 4), `<section id="page-correcao">` com o `frame-correcao`, o bloco `mesa-correcao-gz`, o script `correcao-js` (`window.correcaoHost`, `mesaAoAbrir`, `#correcao` na URL), a regra CSS, as funções-ponte `registrosParaCorrecao`/`similaresParaCorrecao`/`avisosEmentaParaCorrecao`/`ligar` e os comentários que a citavam. O atalho global de teclas passou a interceptar só Alt 1–3.
- Preservado: a similaridade dos Dados do processo, que lia os textos do caso pela ponte, agora usa `textosAbasCaso()` (mesma leitura de Relatório, folha da Minuta parágrafo a parágrafo e Ementa).
- Não confundir com coisas homônimas que permanecem: o tipo de regra `correcao` do banco de Redação (substituições de termos), assuntos como "Correção monetária" e as correções da pauta (`_pautaCorrections`, corretor, "Data da correção").
- A remoção é feita por `p83.py` (passo `corta`, cada corte com contagem asserida); teste: `tests/padrao-v102-sem-correcao.test.mjs`.

## Roteiros temáticos da Minuta, compartilhados pela pauta (v103)

- Origem: proposta externa "Atualização Minuta/Paradigmas" (zip sobre a v102). Aproveitados o catálogo (18 assuntos, 7 espécies, 4 transversais, roteiro-mestre, 16 posições; 211 perguntas) e o fluxo de verificação; o resto foi refeito. Não reintroduzir o seletor paralelo de modo (`gabA_minuta_modo` reescrito, `__cmtShowPageOriginal`, `CMT_RTE.setMode`): o Padrão | Matriz é o da v101 (`cpdModoVoto`).
- Matriz: `#cmt-guide-root` entra antes de `#skeleton` no HTML embutido da Matriz (p83 decodifica, injeta `rt103/guia103.html`, recodifica). Com o roteiro ligado, somem `.w-head`, `.strip` e `#skeleton`; "Estrutura textual" volta com um clique e a escolha fica em `cmt.roteiros.pref.v103` (por navegador).
- Respostas: no card (`r._roteiro`) ou na monocrática (`m.roteiro`, preservado em `cleanMono`), via `window.CMTRoteiros` na pauta (`rt103/pauta_rt103.js`, aplicado por `p103.py`). Só gravam se o processo do Padrão confere com o card ativo; sessão encerrada = somente leitura; fora disso, só no navegador (`cmt.roteiros.local.v103`) com aviso na tela. Limites: 400 respostas, 4.000 caracteres por texto.
- Catálogo: só as alterações do gabinete sobre a base embutida, em `PautaApp.padrao.roteiros` (snapshot inclui `padrao` só quando há conteúdo; restore preserva). Edição em Paradigmas · Roteiros temáticos (4º cartão de tipos), liberada pela senha das Configurações Globais (`POST /api/pauta/settings/unlock`); salvar grava no estado compartilhado. Importar/Exportar JSON; desativar/restaurar originais.
- Espécie e assunto sugeridos pelo processo (`IDENT.recurso`, assunto/temas); assunto sem correspondência fica em branco para escolha. A resposta factual nunca vira resultado jurídico sozinha; substituir campo da Matriz pede segundo clique (sem `alert`/`confirm`).
- Teste: `tests/padrao-v103-roteiros.test.mjs`.

## Roteiros na coluna da esquerda da Matriz e aba "Minuta" (v104)

- A coluna esquerda da Matriz (antes "Modelo ativo" + biblioteca de matrizes: `.rh`, `.rt`, `.rb` de `aside.ref`) mostra só os roteiros (`#cmt-guide-root` injetado no início de `aside.ref`, `rt103/guia104.html`). Pergunta abre em sanfona na própria lista; "Aplicar à Estrutura" envia ao campo escolhido. Painel recolhido se chama "Roteiros".
- A Estrutura & Edição volta inteira ao centro (sem alternância Roteiro/Estrutura). O modelo-matriz passa a ser escolhido numa barra no topo dela (`.cmt-mx-bar`, espelho do `#matSelect` original, com "Gerenciar matrizes" e "Exportar JSON" acionando `#manageBtn`/`#exportBtn`).
- Rótulo da aba e da prévia: "Voto" → "Minuta" (`rotulo()` em layout83 e `LBL()` em previa99); "Decisão" segue para pronunciamentos que não são voto. O pronunciamento "Voto" no rodapé e os nomes de modelos não mudam.

## Seletor Padrão | Matriz na linha da aba (v105)

- O seletor do modelo da minuta (Padrão | Matriz) fica em `#grFaixaInf`, logo após Relatório | Minuta, como `.gfi-modo` ("Modelo"); aparece só com a aba Minuta aberta e pronunciamento Voto. Saiu do cabeçalho da Estrutura & Edição (`.cpd-mn-head .cpd-modo` é removido). Código em `seletorModo()` de previa99.js; estilo em layout83.

## Roteiros compõem o modelo-matriz; buscador Padrão; etapas da Minuta no CMTEXT (v106)

- Matriz: o campo/barra “Modelo-matriz” saiu. A estrutura de tópicos é definida pelos roteiros: `roteiros.json` liga ESP/ASS a uma estrutura (`matriz`: `ed`→`matriz-ed`; assuntos previdenciários→`matriz-apelacao-previdenciaria`; demais→`matriz-voto-geral`). `guia105.html` (`estruturaAlvo`/`sincEstrutura`) seleciona a estrutura conforme espécie e assunto; os seletores da coluna são Espécie · Assunto · Módulos adicionais. Em Paradigmas › Roteiros, o editor tem “Estrutura de tópicos que compõe” (`data-matriz`).
- Coluna dos roteiros rola (`aside.ref:not(.pmin)>#cmt-guide-root{overflow-y:auto}`).
- Padrão: `rt103/modelos105.js` injeta `#cmt-mp` no frame-voto (buscador dos modelos de estrutura padrão, `estruturaModelo(x)==='padrao'`, Voto); “Usar” → `useParadigma`. `usarModeloAplicar` (patch em p83) só manda à Matriz modelo com `estruturaModelo(x)!=='padrao'`; o texto do modelo padrão cai na Fundamentação (fallback `x.fundamentacao`). Obs.: a Matriz não tem `importarModeloParadigma` — modelos de estrutura específica ainda falham ao “Usar” (pendência).
- CMTEXT: `#grMeter` (“x de 4 etapas do relatório completas”) oculto. `rt103/etapas106.js` troca as etapas do herói só na Minuta: Matriz → 6 fases do roteiro (`CMT_GUIDE.fases()`; clique → `CMT_GUIDE.focar(id)`); Padrão → cartões 01 Abertura · 02 Fundamentação · 03 Caso vertente · 04 Encerramento (clique abre e rola o cartão). Relatório e Decisão mantêm as etapas originais.

## Roteiro dentro dos tópicos da Matriz; trechos de modelo padrão por tópico (v107)

- Matriz: `rt103/guia107.html` (substitui guia105). As perguntas do roteiro ficam dentro de cada tópico da Estrutura (`#sec-{id}>.cg-rt`, logo após `.fhead`); posição do roteiro = id do tópico (`alvoDe`); `relat` vira bloco solto antes dos tópicos e `revis`/demais, bloco solto ao fim. Um MutationObserver no `#skeleton` reinjeta os blocos após cada `renderSkeleton`. A coluna da esquerda guarda espécie, assunto, módulos, progresso, filtro/busca e o índice “Tópicos da estrutura” (clique rola até o tópico). Eventos dos blocos são delegados no documento do frame.
- Padrão: `rt103/modelos107.js` (via `mk_modelos107.py` sobre modelos105). “Usar” (no buscador e em Paradigmas, para modelo de estrutura padrão de Voto) abre o seletor de trechos por tópico: textos do `esqueletoModelo` (por `_topicos`), `paragrafosModelo` e parágrafos do voto do modelo (após “VOTO”, até “É como voto.”/ementa; “Na espécie” → Caso vertente; “Ante o exposto” → Dispositivo; aspas → citação). Destino editável; os marcados entram por `cmtAddTrechos` (injetado no frame-voto, `rt103/trechos107-voto.html`) como blocos novos — nada é apagado. O fallback v106 que despejava `fundamentacao` saiu.

## Modelos padrão em coluna lateral; cabeçalhos claros; CMTEXT da Minuta redesenhado (v108)

- Padrão: `rt103/modelos108.js` (via `mk_modelos108.py` sobre modelos107) cria `aside#cmt-mp-col` como primeira coluna de `.wrap>.layout` do frame-voto (grid `.cmt-mp-on`: lateral · Estrutura & Edição · Prévia), separada da Estrutura & Edição, com rolagem própria (sticky, `calc(100vh - 64px)`) e recolhimento em barra vertical “Modelos” (`.pmin`, `.cmt-mp-min`; estado em `cmt.mp.aberto.v105`). Cabeçalho claro com “←” (voltar à busca, no seletor de trechos) e “−” (minimizar).
- Roteiro (Matriz): cabeçalho `.cg-top` claro (guia107.html editado; backup guia107.v107.html).
- CMTEXT: `rt103/etapas108.js` substitui etapas106 — na Minuta, `.cpd-et108` com legenda (“Fases do roteiro · x de y verificações · n essenciais” + estrutura / “Partes da minuta · x de 4 partes completas”) e cartões com barra de progresso, rótulo em até 2 linhas, contagem x/y e situação; a próxima fase pendente fica destacada (`.prox`). Os passos e o trilho originais ficam ocultos só na Minuta (`body.cpd-et108`).

## Roteiros dentro de Modelos; Padrão no desenho da Matriz; ao menos um painel aberto (v109)

- Paradigmas: o cartão “Roteiros” entre os tipos saiu. `roteiros103.js` cria `#cmt-rte-faixa` (após `#bfTipos`, antes do hub), visível só com o tipo Modelos (`data-bf-tipo="Modelo-matriz"`) selecionado; “Ver e editar roteiros” abre o hub no lugar da lista (`#bancoBox.cmt-rte-on`); trocar de tipo fecha. `CMT_RTE.abrirEditor()` seleciona Modelos antes. Cabeçalho e rodapé do hub ficaram claros. Backups: roteiros103.v108.js/.css.
- `rt103/minuta109.js` (top-level): no frame-voto, cartões `#formMain>section.cn-card` no desenho dos tópicos da Matriz (fundo #f9fafa, borda #e1e3e6, raio 9, índice dourado, sobretítulo por `h2[data-ey]::before`, sem tocar no texto do h2 — o `cardNav` lê o texto); subseções com número em selo. Estrutura & Edição minimizável (`.cpd-ed-tg` “−” / `.cpd-ed-bar` vertical; `body.cpd-ed-min`; chave `cmt.ed.min.v109`). Grade com variáveis `--c1/--c2/--c3` (seletor `html.slot body .wrap>div.layout.cmt-mp-on`, mais específico que o `cpd-pv-min` da previa99).
- Regra: nas abas Minuta › Padrão (Modelos · Estrutura · Prévia) e Minuta › Matriz (Roteiros · Estrutura · Prévia, `.pmin`), um ouvinte em captura bloqueia minimizar o último painel aberto (aviso “Ao menos um painel fica aberto…”); estado salvo com tudo fechado reabre a Estrutura & Edição.
- `etapas108.js`: o resumo “x de y campos” só existe com o cartão recolhido; guarda o último lido por cartão.

## O Relatório não integra o roteiro (v110)

- Perguntas de posição `relat` (MESTRE 0–2; ESP ain, ed, mono) continuam no catálogo, mas saem da Minuta e do editor: `guia107.html` pula `relat` em `passos()` mantendo o índice original na chave (`layer:id:i`, respostas gravadas preservadas), tira `relat` de `P` (códigos começam em Admissibilidade), do bloco solto e de `FASES`. `roteiros103.js` (`ehRel`) oculta essas perguntas na lista, nas contagens, na escolha de posição e no mover. Backups: guia107.v109.html, roteiros103.v109.js.

## Todos os roteiros viram modelos-matriz: espécie × assunto (v111)

- `guia107.html` › `gerarModelos()`: para cada espécie ativa × (sem assunto + cada assunto ativo) gera um modelo-matriz `rt:{esp}:{ass|geral}` (7 × 19 = 133 com o catálogo-base), `gerado:true`, no `CAT` da Matriz, em memória. Tópicos/textos-base vêm da estrutura-base (`e.matriz` › `a.matriz` › `matriz-voto-geral`; a espécie prevalece); tópico opcional fica ativo se a espécie ou o assunto têm pergunta nele. Parágrafos: os da estrutura-base (copiados) + as fórmulas de redação (assunto, espécie, roteiro-mestre, módulos adicionais), cada uma numa posição própria do seu tópico, sem “Senhores Desembargadores,” inicial. Regera quando o catálogo muda (assinatura `GSIG`).
- `estruturaAlvo()` devolve o modelo da combinação do caso; o caso troca de modelo ao mudar espécie/assunto. `saveCat` da Matriz (patch em p83) grava `cmtCatPersistivel(CAT)` — sem os gerados.
- Correção: a coluna Roteiros redesenha quando o caso compartilhado carrega/troca (`sigCaso()!==RSIG`), antes ficava com o caso vazio inicial.
- Paradigmas › Modelos: a faixa mostra “→ N modelos-matriz (espécie × assunto)”; no editor, “Estrutura-base de tópicos”.

## Sem painéis laterais na Minuta; trechos pelo Paradigmas; modelo-matriz no CMTEXT; topo do Paradigmas (v112–v113)

- Matriz: `aside.ref` oculto (guia107.html: `html.slot aside.ref{display:none!important}`; grade de 2 colunas com `--w2/--w3` e `.pmin`). As perguntas seguem dentro dos tópicos. A regra “ao menos um painel aberto” (minuta109) passou a considerar só Estrutura & Edição e Prévia.
- `rt103/cmtext112.js`: na Minuta › Matriz, `#grFaixaInf .gfi-mx` (linha própria) com Espécie × Assunto, módulos (selos removíveis + “+ Módulo”) e estado de compartilhamento; muda `CMT_RTE.caso().dados`, salva e redesenha guia/etapas.
- Padrão: `modelos108.js` saiu do build; `rt103/trechos112.js` (via `mk_trechos112.py`, reaproveita `trechosDe`/`pickerHtml`) abre o seletor de trechos dentro do Paradigmas (`#cmt-mpk` após `#bfTipos`, `#bancoBox.cmt-mp-on` esconde a lista). “Adicionar” → `cmtAddTrechos` no frame-voto, fecha o Paradigmas e vai à Minuta › Padrão. Estilos criados por JS precisam de `data-tcl="1"` (senão o conversor de cores do topo os altera).
- `rt103/paradigmas113.js`: no topo do Paradigmas, linha “GitHub dono/repo · ramo · atualizado em…” (pendências do outbox), e botões Importar ▾ / Exportar ▾ (Modelos, Parágrafos, Citações, Precedentes, Planilha; “Aba aberta”) / Publicar (✓ ou nº pendente). Cada item clica o botão original oculto da `#bfAdmBar` / `.bf-pill` — senha e validações continuam as nativas. `#bancoSum`, `#bancoLockBtn`, `.bf-pill` e `#bfAdmBar` ocultos; tipos em uma linha.

## Prévia editável no desenho da Mesa de Revisão (v114)

- `rt103/previa114.js` (top-level) atua nas prévias dos frames relatorio, voto, matriz e outros (`.cpd-pvp` dentro de `.cpd-pvs`): parágrafos-folha numerados (`data-rvn` + `::before` “§n”), grifos das 34 regras de redação da Mesa (`RULES`/`analisar`, a corrigir × alerta) pela API `CSS.highlights` (sem tocar no texto), parágrafo selecionado (`data-rvsel`) com barra de selos (semelhança com o texto-padrão, a corrigir, alertas, “Corrigir tudo”, “Comparar”), balão ao clicar no grifo (“Aplicar”), painel Comparar (6 candidatos, diff palavra a palavra, “Adotar redação do padrão” em dois cliques, “Copiar padrão”) e placar “Revisão: § · a corrigir · alertas · aderência ao padrão · só parágrafos com apontamentos”.
- Acervo da semelhança: trincas de palavras sobre BANCO (modelos: texto, fundamentação, esqueleto, parágrafos; precedentes: ementa, inteiro teor), `Banks.lista('paragrafos'|'jurisprudencia')` e `public/acervo-mesa.json` (209 textos da Mesa de Revisão, carregado sob demanda). Campos `{campo|RÓTULO}`/`{{VAR}}` viram `[RÓTULO]`.
- Edições programáticas disparam `input` no parágrafo (+ `registrarEdicaoPrevia`). Os atributos saem antes de cada `input` (captura) e voltam no quadro seguinte; na Matriz, `state().manual` grava `cmtHtmlLimpo($('paper'))` (patch em p83).

## Prévia única e Ficha no desenho da Estrutura & Edição (v115)

- `rt103/unica115.js` (top-level): em cada aba (Relatório, Minuta — voto/matriz/decisão — e Ementa, inclusive no painel da Ementa), a prévia mostra o documento inteiro na ordem Relatório → Minuta → Ementa: a peça da aba é a editável (marca “… · em edição nesta aba”) e as demais entram como seções `.u115` em leitura (cópia limpa da folha de origem, atualizada a cada 0,9 s); clique abre a aba que edita. A navegação “Relatório · Minuta · Ementa” substitui o seletor antigo (gabc em “foco”, oculto). O contêiner da folha (`.u115-host`) passa a rolar inteiro; a prévia vai até a seção da aba ao trocar de aba/versão (`foco`, com desconto da barra de formatação fixa). Aba detectada por `.page.active`, `gr-vista-voto` e `body.gr-eme-dock`.
- Ficha · Registro & Relatório (frame relatorio): CSS `cmt-ficha115-css` reproduz a Minuta · Estrutura & Edição — fundo #f2f4f7, `main.layout` com 16/18 px e colunas 1,04 : 1, painel transparente, cabeçalho “sobretítulo + título” sublinhado com “−” à direita, seções com 10 px, prévia em cartão (borda e sombra da Minuta). Seletores com `html.slot body` (outros estilos tardios usavam o mesmo seletor).
- Teste da v102 proíbe a expressão “Mesa de Revisão” em padrao.html: o módulo da prévia fala em “revisão de minutas”.

## Abas no rodapé; seletores da pauta no CMTEXT (v116)

- `rt103/nav116.js`: no rodapé (`#grFoot`), depois de Pronunciamento, “Aba: Relatório · Minuta (ou Decisão) · Ementa” (`.ft-abas`; Relatório/Minuta via `grVista`, Ementa abre/fecha o painel por `#grEmeBtn`, que fica oculto). O seletor de aba da faixa inferior do CMTEXT saiu (a faixa some quando nada nela está visível).
- Sessão · Processo · Ir para: a pauta continua desenhando `#cpd-foot` no rodapé (e o recoloca lá a cada ciclo), mas `.cpd-pick` fica oculto; uma cópia viva (`#grFaixa>.cmt-nav116.cpd-x`, refeita por MutationObserver, nunca com foco dentro) aparece na linha “Banco” do CMTEXT. Como a pauta delega `change`/`keydown` a qualquer `.cpd-x [data-cpd]`, a cópia usa os mesmos comandos, sem patch na pauta.

## Vade Mecum; versão e modelo da minuta no cabeçalho do CMTEXT (v117)

- `rt103/vade117.js`: botão “Vade Mecum” no CMTEXT (`#grFaixa`, logo após Ementário; `.gf-pdg.gf-vm`, contagem = citações do gabinete + repertório). Abre o próprio diálogo do Paradigmas no modo `#bancoBox.cmt-vm` (título “Vade Mecum”, sem `#bfTipos`), com abas `#vm-abas`: Do gabinete (a antiga aba Citações, lista nativa `BTIPO='Citacoes'`, rótulos “citação(ões)”) · Temas STF e STJ · Súmulas · Normas · Julgados do relator (`#vm-rep`, busca + filtros por tribunal/grupo/coleção/norma).
- Repertório: `public/vade-mecum.json` (extraído do “Acervo Jurídico TRgMS”: 182 temas, 51 súmulas, normas por diploma, 133 julgados do relator), carregado sob demanda. Temas sem tese oficial são marcados “Resumo — confira a tese oficial”.
- Ações por item: Copiar citação; Inserir na Minuta (`frame-voto` `cmtAddTrechos([{sec:'fund',kind:'juris'|'norma'}])`, Minuta › Padrão); Salvar no banco do gabinete (`Banks.upsert('jurisprudencia', …)`, id `vm-…`; publicar no GitHub pelo Publicar).
- A aba Citações saiu do Paradigmas: CSS oculta o tipo fora do modo Vade Mecum; se o Paradigmas abrir em Citações, volta a Modelos. `paradigmas113.js`: Importar/Exportar mostram “Citações do gabinete” só no Vade Mecum, e as demais só no Paradigmas.
- `rt103/cabecalho117.js`: linha `#grMinHead` (“MINUTA”) logo abaixo de Banco/Pauta, só na aba Minuta com pronunciamento Voto: Padrão | Matriz (`cpdModoVoto`; o `.gfi-modo` antigo da faixa inferior fica oculto) + busca com filtros (Alt M). Padrão: os 54 modelos com `estruturaModelo(x)==='padrao'`, ordenados pelo caso (classe e palavras do assunto), “Sugerido”; Enter abre os trechos por tópico (`CMTModelosPadrao.escolher`). Matriz: espécie × assunto (“Em uso”, “Sugerido” pela detecção), aplica por `CMTMatrizCmtext.definir(esp,ass)`; os seletores `.gfi-mx` (`cmtext112.js`) passaram para essa linha.

## Versão única da minuta no cabeçalho; Ementa só onde se aplica (v118)

- `cabecalho117.js`: a linha MINUTA (`#grMinHead`) aparece em todas as abas com um seletor de cinco versões: Voto · Padrão · Voto · Matriz · Decisão terminativa · Decisão interlocutória · Despacho. Comanda o `#grPron select` original (valor + eventos input/change) e, no voto, `cpdModoVoto('voto'|'matriz')`. A busca do modelo continua só na aba Minuta com voto (`.gmh-so-versao` oculta a busca nas demais).
- `versao118.js`: o Pronunciamento sai do rodapé (`#grFoot>#grPron` oculto, mas continua lá como fonte da verdade). Interlocutória e despacho não têm Ementa: `body.cmt-sem-ementa` oculta a aba do rodapé e `#grEmeBtn`; nos frames, `html.cmt-sem-ementa` oculta a seção e o botão Ementa da prévia única; Alt 3 é bloqueado; com a Ementa aberta, volta à Decisão. Decisão terminativa mantém a Ementa.

## Ementa como aba; Revisão no card de Conformidade; versão/pauta no rodapé; ⋯ no CMTEXT; Estrutura & Edição (v119)

- `aba119.js`: a Ementa continua usando o estado do layout (`body.gr-eme-dock`, `#grEmeBtn`), mas com `body.cmt-eme119` vira aba: sem `#grEmeHead`/`#grEmeBack`, `#page-ementa` posicionado na área das outras abas (mesmo cálculo de `posicionar()`: `frame-relatorio` + `main.layout`, variáveis `--e119-*`). Dentro do quadro (`html.e119`): fundo claro, Estrutura & Edição (`.e119-tt`) à esquerda, prévia à direita. Esc reabre se o atalho antigo fechar. Só o voto tem ementa (regra do construtor: `ementa()` recusa se `pronAtual()!=='voto'`); `versao118.js` usa `SEM=['terminativa','interlocutoria','despacho']`.
- Revisão: `previa114.js` oculta `.rv-stats` e expõe `CMTPreviaRevisao.placar(n)`/`.so(n,v)`; `aba119.js` desenha `.gcc-rv` no `#grConfCard` (frame da aba atual; nada na Ementa). `unica115.js`: `nav()` remove o `.u115-nav` (sem seletor: é só rolar).
- `cabecalho117.js`: a versão (Voto Padrão/Matriz · Decisão terminativa/interlocutória · Despacho) está no rodapé (`.ft-versao`, logo depois de `.ft-abas`); a linha `#grMinHead` (MODELO, busca e espécie × assunto) só aparece na Minuta de voto. `nav116.js`: sessão, processo e “ir para” voltam ao rodapé (`.cpd-pick` visível, compacto; a cópia no CMTEXT saiu).
- `p119.py` (pauta, rodado pelo `m9/build.sh` depois do p103): `#cpd-tools` (⋯ Ações do caso) vai para `#grTools`, antes do último separador; menu abre para baixo.
- `estrutura119.js`: Padrão — `#cardNav` (expandir/recolher) no título do painel, cartões com borda fina e destaque dourado quando abertos; Matriz — cartões no mesmo desenho e parágrafos opcionais do modelo em lista legível.

## Verificações do card → Admissibilidade (v120)

- `p119.py` acrescenta `payload.verificacoes` em `processPayload` (vale no envio `slim`): tempestividade + `Tempest - Publicação/Protocolo`, prazo/limite pelo `tempCalc` da pauta, preparo, AJG, DPU, representação e ID da procuração, impedimento, mídias, MPF.
- `trechos107-voto.html`: `window.cmtAdmDoCard(v)` mexe em `d.preliminares` (o mesmo estado que a Matriz usa por `guidedPrelimEdit`): só preenche vazio; cria item só para intempestividade apurada (acolher, de ofício); tempestivo/preparo/representação preenchem itens já existentes (vindos das contrarrazões etc.); preparo não recolhido gera só aviso (art. 1.007, § 4º).
- `card120.js`: envolve `PadraoPonte.importar`/`mesclar`, aplica quando o caso ativo é o do card (espera a confirmação), redesenha a Matriz, avisa em toast e mostra “Verificações do card” no `#grConfCard`.
- Roteiros (análise de 21/10): a resposta tem Situação (pendente, em análise, confirmada, não se aplica), “O que consta”, peça/ID, questão vinculada, conclusão e destino `{{campo}}`. Efeito na minuta só por “Aplicar à Estrutura” (exige confirmada + texto + destino). Situação só conta progresso (fases, essenciais); questão vinculada e conclusão não são usadas; fórmulas viram parágrafos opcionais dos modelos-matriz independentemente das respostas.

## Vade-mécum no desenho do módulo da Pauta (v121)

- Base: o módulo `cmt-vademecum` (PautaVademecum, grafite e ouro, dados embutidos: 165 temas, 51 súmulas, 113 precedentes STF/STJ/TRF3, 93 dispositivos) enviado pelo usuário, guardado em `m10/rt103/vdm/vademecum-base.html`; `vdm/mk_vdm121.py` gera `rt103/vademecum121.js` (script `cmt-v121-vademecum`): `data-tcl` no estilo, blindagem contra regras globais do Padrão (`header`, `label`, `.jp`), aba **Do gabinete** (`renderG`, banco `jurisprudencia`, filtros tipo/assunto), e ao lado de cada Copiar: **Inserir** (`cmtAddTrechos` na Fundamentação da Minuta › Padrão) e **Guardar** (`Banks.upsert`). Exporta `PautaVademecum.cit/total/gabinete`.
- `vade117.js`: o botão do CMTEXT abre o PautaVademecum; o diálogo do Paradigmas em modo `cmt-vm` virou **Gerenciar citações** (botão na aba Do gabinete), só com a lista nativa; ao fechar, volta ao Vade-mécum. `vade-mecum.json` deixou de ser usado (pode sair do repositório).
- GitHub (verificado no código): Paradigmas, Ementário (precedentes) e o banco Do gabinete vêm de `brndutra/gabcmt · main · data/paradigmas.json`, lidos pelo api-server (`/api/shared/catalogs`, cache de 10 min; token opcional `PADRAO_GITHUB_TOKEN`/`CNTRLA_GITHUB_TOKEN`, senão raw público). Somente leitura: `POST /shared/catalogs/publish-github` responde 403; o que se edita/guarda fica só na aba (nada no navegador). Temas, súmulas, precedentes e normas do Vade-mécum são estáticos (embutidos no padrão.html).

## Redesign dos Controles (v122)

- Base: a prévia “Redesign dos Controles” (`redesign-controles-preview.html`). Aplicado como pele em `m10/ctl122.html`, injetada no fim do `pauta-original.html` pelo `p119.py` (estilo `cmt-v122-controles` + script `cmt-v122-controles-js`); nada da lógica da pauta foi reescrito.
- Controle de Pauta: moldura clara com filete dourado; cabeçalho grafite `.c122-phead` (Sessão de dd/mm/aaaa, chips a minutar/pronta p/ revisão/votos liberados/sem servidor/intempestividade/representação a verificar/intercorrências; os com filtro clicam no `[data-action="metric"]` original) e ações que comandam os originais (select de sessão por `change`, + processo, Estatísticas → `.pq-dist-toggle`, Excel → `[data-action="xlsx"]`, minimizar → `toggle-panel`). Marcos em 4 colunas (o chip de sessão vira `.c122-marco` com os contadores 1º julgamento/ED clicáveis; Peço-dia em `.c122-meters`); panorama em indicadores compactos; Painel de Controle com faixa grafite, barra de comando e lista com iniciais do servidor, filete pelo estado e etapas Minutar · Revisar · Liberar · Julgado (lidas dos pontos da situação). Números lidos com o painel minimizado ficam em cache.
- Controle de Decisões: hero e cabeçalho da lista em grafite, KPIs como chips, tabela no padrão das linhas.

## Roteiros só com o que alimenta a minuta; campos do modelo-matriz ligados ao caso (v123)

- `guia107.html` · `passos()`: ficam só as perguntas com fórmula de redação cuja posição é um tópico da estrutura (`SECS`): 24 das 45 no caso de teste. Cada passo guarda `oid`/`i`; o parágrafo gerado é `model().id+':'+layer+':'+oid+':'+i`.
- Resposta com consequência: “Aplica-se · incluir no tópico” (`togglePar`, `s='confirmada'`), “Não se aplica” (retira, `s='nao_aplicavel'`), “Desfazer”. `stDe`/`feito` derivam da inclusão real (incluir pelo chip do tópico também conta). O detalhe mostra o que conferir e o texto que entra; saíram “O que consta”, peça/ID, questão vinculada, conclusão e destino/Aplicar.
- Campos (`cmt-campos123`, no frame da Matriz): `varValue` envolvido — campo vazio recebe NUMERO_PROCESSO/QUESTAO da Ficha, FATOS do Registro & Relatório (objeto da ação + resultado da sentença), RESULTADO e FUNDAMENTO do card (`verificacoes.votoResultado` vira “nego provimento à apelação” etc.; `votoDescricao`). Nada é gravado; escrever substitui, apagar devolve. Os campos ficam no texto do tópico (o painel “Variáveis do caso” segue oculto, decisão anterior); os preenchidos pelo caso ganham marca verde e título com a origem. `p119.py` acrescenta `votoResultado/votoHonorarios/votoDescricao/votoTopico` às verificações do card.

## Card de Conformidade compacto (v124)

- `conf124.js`: `#grConfCard .gcc-in` em fluxo com quebra e rolagem própria; `.gcc-h` com `display:contents` (título, total de avisos e aba numa linha); ordem avisos → Revisão da prévia → Verificações do card → “Regras no painel Diretrizes”, com chips menores. O checkbox “só parágrafos com apontamentos” saiu do card (`aba119.js`) e fica na barra de formatação da prévia de cada frame (`.edbar` › `.c124-so`, chama `CMTPreviaRevisao.so(n,…)`).

## Grafite nos diálogos do banco e no primeiro painel dos Controles (v125)

- `pdg125.js` (padrão): estilo `cmt-v125-pdg` (`data-tcl="1"`) + script `cmt-v125-pdg-js`. Com o banco à vista, `#identBody.pdg-dlg` ganha `c125` (sai ao fechar). Duas camadas: desenho explícito (cabeçalho com sobretítulo dourado, tipos Modelos/Parágrafos, busca, filtros, ordenação/visão, cartões `pc-it`/`mc`/`xc`, menus Importar/Exportar, faixa dos roteiros, modo Ementário `em-a`) e camada automática `c5-*`: um MutationObserver tira as classes `c5-*`, lê o estilo original e reclassifica fundo/texto/borda claros (fichas, editores, planilha, popups, Gerenciar citações). Transições de cor desligadas dentro do diálogo para a leitura ser exata. `window.CMTParadigmasGrafite.{aplicar,ativo}`.
- `ctl125.html` (pauta, depois de `ctl122.html` em `p119.py`): `section.pc-session-overview` e `.dec-hero` inteiros em grafite (marcos em cartões, panorama, estatísticas, intercorrências, régua do painel minimizado; KPIs das Decisões como blocos com filete de cor; painéis Equipe/Resultado escuros). Linha cronológica devolvida: rótulo e data curta (`em[data-d]`, tirada do `title` do marco) sob cada marco, “Hoje” acima, intervalos sobre o trilho; marcos até Hoje recebem `c125-past`, o 1º/último alinham às bordas (`c125-ini`/`c125-fim`).

## Cabeçalhos mínimos e painel único nos Controles (v126)

- `ctl126.html` (depois de `ctl125.html` em `p119.py`). Pauta: cabeçalho só com “Controle de Pauta”, “Sessão de …”, prazo e total, os alertas fora do panorama (sem servidor, intempestividade, representação, intercorrências — só quando houver) e o ícone Excel; saíram os chips repetidos do panorama, o seletor, o “+”, Estatísticas e minimizar. O cartão Sessão (`.c122-marco`, `ctl122.html`) traz o seletor da sessão (`.msel select[data-c122-ses]`, comanda `select[data-control="session"]`) e “+ processo” (`data-c122-m="novo"` → `process-create-inline`). O painel não se minimiza mais (se `.pc-ref-expand` vier fechado, reabre). Rodapé `.c126-foot` depois do panorama aciona `.pq-dist-toggle`; `.pq-dist-head` oculto e o XLSX das estatísticas vira ícone `.c126-sx` no `.cmt-st-head` (aciona `stats-xlsx`).
- Painel único: `pc-session-overview + pc-sheet-card` e `dec-hero + dec-card` encostados (margem negativa, cantos e borda partilhados); os títulos das listas ficam como divisória grafite (“Painel de Controle”, “Processos”). Decisões: sobretítulo “Controle de Decisões”, descrição oculta, botões curtos Importar · + Dados · Excel (o texto longo fica no title).

- v127: o cartão Avisos do panorama fica oculto e, no lugar dele, `.cmt-pan-card.c126-tags` (“Pendências”, em `ctl126.html`) lista sem servidor, intempestividade, representação a verificar e intercorrências (esta filtra a lista pelo `metric` original); zerados aparecem com ✓ esmaecido. Um aviso ativo do cartão original, se houver, aparece no rodapé do cartão. Os números vêm de `CMTControles122.numeros()`; o cabeçalho da sessão ficou só com título, prazo, total e o ícone Excel.

- v128: a parte branca da lista (Pauta e Decisões) perdeu a borda grafite; o título da lista é “Processos” + contagem nas duas abas (na Pauta o `h2` é reescrito a partir de `.pc-result-count`, que fica oculto: “147” ou “12 de 147”); a faixa de busca e filtros (`.pq-filter-workspace`, a dica abaixo e `.dec-toolbar`) tem o fundo do cabeçalho (`--g-bg`), com campos, facetas e menus das facetas em grafite; a lupa da busca foi redesenhada em cinza claro.

- v129: o botão “+ processo” saiu do cartão Sessão (fica só o seletor da sessão); adicionar processo continua pelos meios originais da pauta.

- v130: a escolha Formulário/Lista some (`.pauta-view-pill` oculto) e a pauta passa a Lista (se o `localStorage` guardava “form”, o botão original “Lista” é acionado uma vez). No lugar fica `.c130-exp` “Expandir todos / Recolher todos” (com “N abertos” quando parcial), que aciona o clique original de cada `.pauta-compact-summary` (a lista expandida é privada da pauta); durante a operação `scrollIntoView` fica neutralizado e a rolagem volta ao ponto de partida. Linha e formulário expandido partilham a faixa à esquerda (`--c122-edge`, que agora mantém a cor do estado — vermelho, laranja ou dourado) e o fundo creme, com uma faixa cinza de 12px separando o bloco do processo vizinho.

- v131: no processo aberto em Lista voltam `tr.pq-alert-footer-row` (botão “Painel operacional”, agora com rótulo visível) e, quando o grupo está `.is-open`, `tr.pq-detail-row` (Regularidade, Sentença e recursos, Parecer e outras peças), no mesmo bloco (faixa e fundo; a separação cinza vai para a última linha visível). O botão Estatísticas saiu do rodapé do painel e virou ícone no cabeçalho da sessão, à esquerda do Excel. “Intercorrências · todas as sessões” (`details.pauta-global-intercurrences`) fica oculto no painel da sessão; segue no diálogo de Pendências.

- v132→v133: as abas (`.c132-tabs`) foram experimentadas e retiradas a pedido do usuário (“não gostei”): o processo aberto volta à organização original — Processo, Acompanhamento e Julgamento lado a lado e, no mesmo bloco, o botão “Painel operacional” com o painel que ele expande (estado da v131). Não reintroduzir abas sem pedido.

- v134: no processo aberto em Lista, `.pq-concept-section`, `.pq-detail`, `.pq-detail-sec` e `.pq-card-foot` ficam sem fundo, borda, raio, sombra, padding e margem (o bloco creme é o único fundo); o título `.pq-panel-title` das seções operacionais também perde o fundo branco. As caixinhas internas (Elaboração, Revisão, Intercorrências, Recursos…) continuam. Para ajustes visuais, há uma prancha no Claude Design (“Processo aberto · Controle de Pauta”, privada, com o sistema Gabinete CMT instalado) que reproduz o processo aberto da v134 com tweaks de cor da faixa e do fundo; mudanças feitas lá precisam ser trazidas para `ctl126.html`.

- v135: base da pauta passa a ser `m8/y80v11.html` (`build.sh`; o anterior ficou em `build.v134.sh`): é a `y80.html` com o script principal e os 11 blocos da prévia “Controle_de_Pauta_Elaboracao_Revisao_V11” do usuário (`cmt-form-density-subject-footers-v3`, `cmt-form-footer-persistence-v3`, `cmt-judge-single-line-and-work-header-tools`, `cmt-header-popover-state`, `cmt-elaboracao-voto-v5`, `pauta-v6-revisao-intercorrencias`, `pauta-v7-*`, `cmt-review-workflow-v10`, `cmt-elab-grid-v10b`, `cmt-pauta-v11-elaboracao-revisao-coerente`). Os seletores `:not(.pauta-list-mode)` desses blocos foram ampliados para `:is(.pauta-list-mode,:not(.pauta-list-mode))`, de modo que a mesma ficha vale no processo aberto da Lista. Resultado: Especificidades e Observações gerais como rodapés recolhíveis do assunto; Etiquetas e Histórico no título de Acompanhamento; Elaboração com servidor, minutado, estado curto (“Entregue”) e Padronização; Revisão com corretor, apontamentos (prioridade, detalhes, Registrar), nota e “Correções e devolutivas do Desembargador”; Julgamento em linha (resultado, honorários, situação, fundamentos com + Justificativa e Tópico-síntese, sessões). O processo aberto caiu de ~570 para ~410px. O visual da v130–v134 (faixa, creme, quadros sem fundo) segue por cima.

- v136 (`julg()` em `ctl126.html`): no processo aberto, o painel operacional é aberto em segundo plano (o grupo fica `.is-open`) para que seus nós existam; `.pq-d-aleg>.pq-op-body` (Sentença e recursos) vai para `.c136-sent`, no topo do Julgamento, acima do Voto; de `.pq-d-pecas` o par MPF/parecer vai para `.c136-par` logo abaixo do Voto e `.pq-pecas-solo` para `.c136-pecas`, aberto pelo botão “Outras peças” (estado por processo, só na sessão). `.pq-judge-session-panel` (sessões de origem, inauguração, destino e 1º julgamento) entra no topo do popover de Histórico. Os nós originais são movidos (a delegação de eventos da pauta continua valendo) e recolocados a cada nova renderização. O botão “Painel operacional” passa a só mostrar/ocultar a linha de detalhe (classe `c136-op`, sem fechar o `.is-open`), que agora contém apenas Regularidade, em três colunas.

- v137: o botão “Outras peças” do Julgamento abre `#c137-dlg` (dentro de `#controle-pauta-root`, para a delegação de eventos da pauta valer), que hospeda o `.pq-pecas-solo` original como tabela grafite: ID (+ Sem ID), Tipo · descrição (tipo e, em “Outro”, o nome), Juntada (novo campo `_ocorrencias.N.juntada`, gravado pelo mesmo `data-ed` da pauta, só a data) e Natureza (derivada do tipo/nome, com a marca “sem ID”). “+ Adicionar peça” aciona o `ed-add` original; Esc, ×, Concluir ou clique fora fecham e devolvem o bloco. Como a pauta refaz a raiz ao adicionar ou remover peças, o diálogo é reconstruído no tick seguinte (estado em `DLG`). Nenhum texto de documento é guardado.

- v138: (1) os `.pq-concept-head` (Processo, Acompanhamento, Julgamento) ficam ocultos; Etiquetas/Histórico (`.cmt-header-tools`) vão para `.c138-tools`, no topo de Acompanhamento. (2) Hierarquia: 1º quadro = identificação → assunto (seção, tema, especificidades, observações) → Regularidade (`.pq-d-reg>.pq-op-body` movido para `.c138-reg`, em grade 2×; os chips de verificação `.pq-op-status` saem por redundância) → alertas e “Informar dúvida”; 2º = Elaboração | Revisão; 3º = Sentença e recursos → Voto → Parecer → Outras peças. (3) Painel operacional extinto: rodapé e linha de detalhe ocultos; para os nós existirem, `PautaControl.page.expandAll=true` (uma vez, com `render()`), em vez de abrir o painel processo a processo. (4) Recursos em grade 2 colunas, sem rótulos repetidos. (5) Lista inteira: `p119.py` troca `rows.slice(0,this._listDisplayLimit||50)` por `rows`; `.pq-scroll` sem `max-height`/rolagem própria (a página rola), `.pc-sheet-card` com `overflow:clip`; testes de paginação ajustados. (6) “Expandir todos” por classe (`ALL`/`FECH`, observador de classe): ~0,1 s por lote em vez de um clique por processo (147 levavam ~40 s); recolher um processo no modo todos continua possível.

- v139 · /cmt · Pauta para anotações: botão abre diálogo grafite (#cmt2-po) para escolher as fontes das observações (observações, especificidades, intercorrências pendentes, dúvidas abertas, devolutivas pendentes, servidor; preferência em localStorage cmt.pauta-anotacoes.v139), limpar todas ou editar/limpar por linha; PDF com visto à esquerda do item, cabeçalho de uma linha e tag ED · AgInt · JR após o número do processo (cmt2Kind). Fonte: m10/cmt140.js, injetado por p119.py.

- v143 · processo aberto do Controle de Pauta em hierarquia K (ctl126.html · k148 + julg): 4 colunas de tópicos — 1 Autos (identificação + Assunto e tema) e Alertas; 2 Minuta (Elaboração, Revisão, Regularidade); 3 Origem e recursos (Decisão na origem, Recursos com rolagem própria que cresce até a coluna mais alta, Parecer); Outras peças (Representação, Mídias, Peças, com rolagem) e 4 Julgamento (Etiquetas/Histórico no cabeçalho, sem título Voto). Nós originais movidos; seletores com prefixo de alta especificidade (html body #controle-pauta-root …). Calculadora de tempestividade (.pq-temp-panel) como diálogo com fundo; diálogos (.pc-overlay, .c137-ov, .pq-editor-overlay, .pq-correction-overlay, #cmt-doubt-modal) em z-index 2147482000. Padronização oculta no card. Linha do item inalterada.

## Próximas diligências (registradas em 20/10/2026)

1. **Arquivar sessão**: export to GitHub the whole process list of a session plus its marcos and statistics, so it stays searchable but leaves the app storage; the minutados of that session must stay in the servers' productivity history.
2. **ED / AgInt**: review how the Controle de Pauta lists mark embargos de declaração and agravo interno, and allow setting it in bulk through filters + ação em lote.
3. **Busca e filtros**: improve search and crossed filters, and filtering/selecting a batch of items or process numbers, integrated with “ação em lote” to change/fill fields of several processes at once.

## Central de mensagens AgentMail

A Central deve usar a caixa AgentMail existente escolhida pelo usuário, não uma caixa nova vazia. A consulta deve dar acesso ao histórico remoto com busca textual, mas consultar e ler não deve importar mensagens. Para adicionar à caixa do app, o usuário aplica um filtro e seleciona os resultados desejados; não importar o histórico inteiro automaticamente. Preservar mensagens já salvas e sua triagem, sem duplicações. Um endereço institucional externo não é uma caixa AgentMail sem uma integração ou encaminhamento próprio.

**Why:** o usuário refinou o pedido: quer acesso a tudo no AgentMail para buscar por correspondência de texto, selecionando e adicionando efetivamente à caixa do app somente os e-mails filtrados.

**How to apply:** separar navegação/leitura remota de importação explícita; permitir paginação sem um corte arbitrário de histórico; não restaurar a importação integral ao abrir o painel; manter autorização no servidor e explicar as limitações de busca/categorias do AgentMail. A aceitação automática de novos eventos do webhook continua sujeita às regras abaixo.

Na aba Solicitações do painel Notificações, manter o conteúdo integralmente encaixado nessa aba, sem expandi-lo para fora; preservar os filtros e a rolagem ao redesenhar. A aba E-mail deve usar a caixa separada `gabinete-cmt@agentmail.to`, não a caixa de solicitações.

**Why:** o usuário pediu que Solicitações permaneça fixa no painel e que E-mail use a caixa institucional separada.

**How to apply:** ao selecionar Solicitações, force o modo encaixado mesmo se a pessoa tiver expandido a caixa antes; deixe o envio ampliado fora desse modo. Mantenha as chaves e as caixas isoladas conforme suas permissões.

### E-mails de relatoria do Des. Carlos Muta

Somente mensagens recebidas do AgentMail com indicação explícita de relatoria do Desembargador Carlos Muta devem gerar notificação geral. Para aceitação automática, o e-mail precisa apontar a um único CNJ, a um único card e a exatamente uma sessão ativa (data de hoje ou futura, não arquivada); então é vinculado e marcado como registrado. Se houver ambiguidade, sessão passada/arquivada ou falta de correspondência, deixar pendente para conferência. Vínculos confirmados geram aviso para toda a equipe, inclusive CMT e assessoria, e registro no card/histórico; não copiar assunto ou corpo do e-mail para alertas públicos. Outros e-mails não recebem notificação geral. A chave `AGENTMAIL_ENTRADA_KEY` é exclusiva da caixa de solicitações; `AGENTMAIL_MAIL_KEY` fica reservada para eventual envio e não deve ser usada para leitura. Para o histórico, aplicar a consulta e importação seletiva descritas acima.

**Why:** o usuário confirmou que mensagens de Gabinete A em sessão ativa devem ser vinculadas e registradas automaticamente, com aviso ao CMT e à assessoria; números repetidos em sessões diferentes são cards independentes, e o conteúdo do e-mail não deve ser exposto em avisos públicos. A escolha manual da equipe precisa conseguir confirmar ou corrigir a classificação automática.

**How to apply:** usar apenas a chave de entrada para leitura/listagem/webhook e reservar a chave de e-mail para futuros envios; tratar mensagens novas via webhook e sincronizações recentes; solicitar conferência quando os dados não bastarem, e combinar previamente qualquer backfill retroativo que possa emitir muitos avisos. No vínculo manual, aceitar mensagens já tratadas automaticamente, exigir CNJ e sessão explícitos, evitar duplicar a solicitação e preservar histórico ao corrigir o card. Em listas com foco preservado para não desmontar o formulário, atualizar diretamente os controles de ações em lote após mudanças de checkbox.

## Faixa da marca

No Gabinete autenticado, a barra superior da logo deve permanecer verde e plana, sem herdar gradientes ou tons azuis específicos da aba ativa.

**Why:** o usuário pediu a remoção do gradiente azul que aparecia apenas na barra da marca.

**How to apply:** mantenha o fundo da barra da logo independente do tema da aba; o cabeçalho do painel direito pode continuar acompanhando a cor da aba.

## Ordem do dia no painel lateral

O painel direito da Ordem do dia reúne as abas Calendário e Meu dia. O Meu dia usa os dados e as ações do usuário autenticado; a página de servidor não deve duplicar essa seção nem abrir automaticamente após o login.

**Why:** o usuário pediu integrar o Meu dia ao antigo painel Calendário e remover a Ordem do dia duplicada da página do servidor.

**How to apply:** encaminhe atalhos de Meu dia para o painel direito; mantenha a página do servidor focada no perfil e preserve o Gabinete como destino padrão após login, salvo rota explícita.
---
name: Browser test fixtures
description: Authentication fixtures required by browser smoke tests that load the shared Pauta app.
---

Browser tests that open the shared Pauta app through its React shell must intercept `/api/auth/session` with a valid test session, in addition to the `/api/pauta` endpoints. Otherwise the access gate stays on the login screen and tests that wait for the embedded editor time out before their actual assertions run.

**Why:** The shared route loads the legacy editor iframe only after the app confirms an authenticated session and hydrates the docket snapshot.

**How to apply:** When a browser test mounts the shared app, ensure its DevTools request interception includes `/api/auth/session` and the shared test API returns a valid fixture session. Keep this confined to test fixtures; do not bypass application authentication.

Same-origin browser tabs share `localStorage`, even though page-local authorization variables are independent. A second-tab test can therefore alter an active draft in the first tab.

**Why:** Loading a second copy of the editor during an Ementa draft restoration test changed the browser-shared draft state and made later assertions unstable.

**How to apply:** Put multi-tab authorization scenarios after assertions that depend on the first tab's local drafts, or explicitly preserve and restore the affected draft state.

Performance comparisons must keep the scheduler's layout-diagnostic mode off, and avoid activating the editor's localhost preview mode.

**Why:** Layout diagnostics deliberately force style/layout flushes around periodic callbacks, changing the workload being measured. A loopback hostname also activates extra preview-only UI and timers, unlike the embedded authenticated editor.

**How to apply:** Use an isolated test hostname mapped to loopback for editor-only profiles, or the real iframe fixture. Treat diagnostic-mode runs only as attribution aids, never as baseline response-time measurements.

---
name: Compatibilidade da página do desembargador
description: Rota canônica e compatibilidade com a navegação emitida pelo HTML legado.
---

A página do desembargador usa `/cm`. A antiga `/cmt` deve apenas redirecionar, sem manter uma segunda interface. O acesso do CM é independente de conta individual e usa link secreto permanente, revogável somente quando a Administração trocar a chave; a Mesa usa as categorias e preferências de notificação globais no perfil CM.

**Why:** o desembargador não deve depender de cadastro individual, e o usuário pediu que o link não expire nem mude por rotina; os avisos devem seguir o padrão comum do app.

**How to apply:** mantenha a rota `/cm` canônica, restrinja o link aos perfis CM/Administração, não adicione expiração automática ao token e use o perfil CM das preferências globais. Normalize eventos antigos do HTML; eventos periódicos da página de fundo não devem trocar a rota.

A página do Desembargador deve ter apresentação exclusiva, sem a barra lateral esquerda nem o rodapé do Gabinete, mantendo a integração com os dados do app. As mudanças de barra esquerda e de rodapé do Gabinete não valem aqui.

**Why:** o usuário pediu uma área separada/exclusiva acessada pelo endereço único do Desembargador, não mais uma página dentro da estrutura visual comum.

**How to apply:** preserve o cabeçalho e a navegação próprios do CM; alterações de apresentação não devem desconectar dados nem exigir conta individual.

Ao acessar `/cm`, exiba uma tela de carregamento própria da Mesa do Desembargador, em vez de revelar o Gabinete de fundo durante a abertura.

**Why:** o usuário pediu expressamente uma tela de carregamento ao acessar a Mesa do CM.

**How to apply:** reutilize a identidade visual do carregamento padrão, com texto da Mesa e encerramento vinculado à prontidão real da interface.

As notificações do CM ficam no painel próprio à direita, e não no painel expansível do rodapé do Gabinete; a navegação permanece visível acima de Em mesa. O calendário e os marcos ficam lado a lado no Panorama. As cores acompanham o carregamento do CM.

**Why:** o usuário pediu essa organização para eliminar sobreposições e manter os atalhos disponíveis durante a consulta dos painéis.

**How to apply:** não reintroduza cabeçalho flutuante compacto nem avisos fora do painel próprio; preserve os atalhos até o fim da rolagem e empilhe calendário/marcos no celular.

Quem entra pelo link exclusivo do CM sem conta individual deve continuar identificado como Desembargador ao navegar para o Gabinete. Não confine essa sessão à rota `/cm`.

**Why:** o usuário quer que o acesso da Mesa estabeleça a identidade do Desembargador também nas outras páginas.

**How to apply:** reutilize a sessão assinada e revogável, sem criar conta individual nem transformar a URL pública `/cm` em autorização automática. Preserve os limites de Administração.

O calendário do CM deve ligar os marcos de cada sessão por traçados distintos e mostrar sessões simultâneas; selecionar uma sessão deve atualizar também seus marcos e a listagem.

**Why:** o usuário precisa enxergar os períodos sobrepostos das sessões, não apenas datas isoladas.

**How to apply:** use os marcos cadastrados, diferencie a sessão selecionada sem ocultar as demais e mantenha visíveis sessões futuras ainda sem processos.

Na Mesa do CM, o painel direito e os avisos usam o controle de notificações do Desembargador, mesmo quando uma conta administrativa visualiza a página.

**Why:** o usuário pediu que a gestão desse painel seja própria do Desembargador, não herdada de quem está visualizando a Mesa.

**How to apply:** preserve as categorias configuradas nas Configurações Globais, mas filtre primeiro o destinatário: só avisos dirigidos ao CM, inclusive os críticos. Menção textual ao CM ou categoria habilitada não autoriza mostrar avisos de outros usuários. Não abra o painel geral oculto nem limpe registros filtrados.

Na Mesa do CM, as dúvidas a ele dirigidas são prioritárias, com uma visão geral de todas as dúvidas ainda abertas do gabinete. O organograma da Mesa do CM deve refletir a Equipe das Configurações, sem aba de grupo de serviço; isso não reabre o botão Organograma no painel lateral esquerdo do Gabinete, de onde ele saiu em definitivo.

**Why:** o usuário pediu que o Desembargador acompanhe tanto suas dúvidas quanto as do gabinete sem misturar destinatários, e consulte a mesma equipe cadastrada no app.

**How to apply:** mantenha a visão das dúvidas dos demais separada das ações de resposta dirigidas ao CM; não crie outro cadastro de equipe para o organograma.

---
name: Pauta productivity history
description: Rules for attributing and displaying productivity records from sessions and non-session work.
---

The productivity history counts completed session votes, completed pendencies, and completed monocratic decisions. Session-linked records retain their own session, agenda item, and session date; pendency and monocratic records remain sessionless.

Every pending-item completion creates one general productivity record for the completing server. An optional personal history note for Assessoria is separate and must not add a second productivity count.

**Why:** the user specified that pending completions and monocratic decision work count toward productivity even though they are not votes and have no session association, and that Assessoria history must not be double-counted.

**How to apply:** do not fabricate a session for non-session work or merge records just because the same process number appears in different sessions. Keep each session's vote attribution separate; re-opening and completing again is a new event, but a repeat click on a completed item is not.

---
name: CMT archive privacy and manual refresh
description: Keep CMT case records server-side and let users manually revalidate current aggregate statistics.
---

The official CMT archive endpoint returns full process records, including case identifiers and party or attorney fields. The Pauta de Julgamento interface needs aggregate statistics, not those individual records.

**Why:** returning raw rows to a browser would expose more case-level information than the requested dashboard requires.

**How to apply:** fetch the CMT archive in the API server, calculate aggregates there, and keep response schemas limited to counts and source timestamps. Never proxy the raw record array to clients.

The CMT statistics view should have a single manual refresh control that retrieves the current aggregates and source timestamp. Do not add freshness banners or historical tracking unless the user asks.

**Why:** the user clarified that a refresh button is sufficient; extra freshness and history indicators are out of scope.

**How to apply:** bypass the local 60-second cache for manual refreshes, send the cached ETag upstream, and retain the last valid aggregates on a `304` response. Never send individual case records to the browser.

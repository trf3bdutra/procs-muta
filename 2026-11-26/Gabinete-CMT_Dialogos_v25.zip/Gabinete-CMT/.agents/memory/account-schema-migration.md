---
name: Evolução das tabelas de contas
description: Ordem segura para adicionar a separação por ambiente ao cadastro
---

Ao acrescentar uma coluna obrigatória que participa de uma chave composta já durante a mesma sincronização de esquema, a ferramenta de push pode tentar criar a chave antes de adicionar a coluna. O erro não significa que haja problema com os dados.

**Why:** a primeira sincronização do cadastro já havia criado tabelas vazias; a inclusão posterior da separação entre desenvolvimento e produção falhou por ordem das operações.

**How to apply:** numa evolução semelhante, adicionar primeiro a coluna com valor-padrão compatível em uma migração aditiva e só depois sincronizar o índice/chave; conferir quantidade de registros e esquema antes, sem forçar o push nem apagar tabelas. Manter as identidades de desenvolvimento e produção isoladas mesmo se ambas usarem o mesmo banco.

---
name: Diálogos de Configurações
description: Armadilhas do transform de diálogos do gabcmt.html e como testar no navegador
---
- O servidor injeta `dialogs/frame.css` antes do ÚLTIMO `</body>`; o HTML tem `</body>` dentro de strings de scripts, então replace do primeiro quebra o CSS dos diálogos silenciosamente.
**Why:** o diálogo ficava com ~300px e a tela de config usava position:fixed.
**How to apply:** ao mexer em prepareDialogDocument, confirme `link[href*="dialogs/frame.css"]` no iframe real.
- Settings: cabeçalho único é o da própria tela (`.cmt-settings-header`); o cabeçalho do diálogo fica oculto. Abrir um diálogo fecha o outro.
- O diálogo standalone do Ementário foi removido; suas visões permanecem integradas ao Gerador e ao painel `/cm`.
  **Why:** o usuário pediu retirar a página e o diálogo próprios, mantendo o conteúdo embutido.
  **How to apply:** não reintroduza runtime, rota ou controles para abrir o diálogo antigo; preserve a integração já existente.
- O portal fixo de formulários dentro de Configurações deve ficar `display:none` quando vazio; aberto sem conteúdo, cobre a tela e bloqueia cliques na configuração.
  **Why:** `#cfg-app-modal` fica depois do conteúdo principal e ocupa o viewport com `position:fixed`.
  **How to apply:** use `:empty` para ocultá-lo sem alterar seu display quando tiver conteúdo; teste clique nos controles principais e em formulários secundários.

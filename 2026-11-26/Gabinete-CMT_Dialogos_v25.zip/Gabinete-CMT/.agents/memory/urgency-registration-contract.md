---
name: Registro de urgências
description: Resultado esperado pelo usuário ao informar uma urgência no aplicativo.
---

Ao informar uma urgência, o usuário espera que ela entre no painel de Urgências, notifique o desembargador e prepare um e-mail formatado.

**Why:** o usuário relatou a ausência dos três resultados na versão publicada como uma falha do fluxo.

**How to apply:** verificar os três resultados separadamente ao corrigir ou testar esse fluxo. Preparar o e-mail não equivale a enviá-lo; não afirmar entrega sem confirmação.

No campo “Pedido de urgência vinculado” das Monocráticas, o encaminhamento por WhatsApp é opt-in ao salvar. O conteúdo é automático com base no card da urgência, com opção de mensagem totalmente personalizada. Após um encaminhamento confirmado, só permitir nova solicitação ao reabrir o card, ativar novamente e salvar.

**Why:** o usuário definiu explicitamente o canal, as duas modalidades de conteúdo e a regra de reenvio.

**How to apply:** não reenviar por simples edição, sincronização ou repetição de clique. Diferenciar aceitação pela Twilio de confirmação de entrega ao destinatário.

No modo de edição, usar o destinatário de teste indicado pelo usuário, separado do contato do desembargador na versão publicada.

**Why:** o usuário pediu para desvincular o número do desembargador no ambiente de edição e testar com seu próprio número.

**How to apply:** manter o destino exibido no controle coerente com o destino efetivo do servidor; não transportar a substituição de teste para a versão publicada.

Não substituir silenciosamente o conteúdo automático/personalizado da urgência por um modelo fixo da Twilio.

**Why:** o usuário definiu que o conteúdo vem do card ou de mensagem inteiramente personalizada; um exemplo de `ContentSid` não informa quais dados ou variáveis o modelo contém.

**How to apply:** modelos são uma escolha explícita e não podem combinar `Body` com `ContentSid`. Explicar que texto livre exige a janela de conversa do WhatsApp e que a aceitação do provedor não comprova entrega.

No Controle de Monocráticas, somente níveis de urgência não ordinários criam automaticamente um item vinculado na fila de urgências e no quadro geral de Pendências; o nível ordinário não cria.

**Why:** o usuário definiu que apenas níveis urgentes devem entrar na fila geral.

**How to apply:** aplicar a regra tanto ao salvar uma monocrática quanto ao importá-la, evitando duplicar uma urgência já aberta para o mesmo processo.

---
name: Node test runner behavior in this workspace
description: Test-runner quirks observed here, including transient test-tree changes and TypeScript module resolution.
---

After invoking the Node test runner with serialized concurrency, the test run reported many tracked test modules missing and the workspace showed the test directory as empty. Restoring tracked tests from the current Git revision recovered them; the standard test command and focused browser tests subsequently ran.

Direct `node --experimental-strip-types --test` also does not resolve extensionless relative TypeScript imports or workspace directory exports the way the project build does. For isolated helper tests, bundle the target module with esbuild or split pure contracts from workspace-bound database modules rather than adding `.ts` extensions to production imports.

**Why:** Node's type stripping removes TypeScript syntax but does not provide TypeScript path-alias or extension resolution; one unusual test invocation also coincided with a test-tree change whose cause was not established.

**How to apply:** Prefer the package's normal test command or focused test files. Check the test-file count and Git status before and after unusual test invocations; bundle helper modules or isolate pure contracts for Node tests, and restore only files known to have been clean beforehand if files disappear.

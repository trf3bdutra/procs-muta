---
name: Rotas do Gabinete
description: Regra de URL para navegação interna do Gabinete e páginas separadas.
---

A Pauta de Julgamento e o Controle de Monocráticas têm URLs próprias `/pauta` e `/mono`; os endereços antigos `/controle-de-pauta` e `/controle-de-decisoes` continuam redirecionando para elas. Sessões e marcos são configurados somente em Configurações Globais; `/session` e `/sessions` redirecionam ao Gabinete e não têm página ou botões próprios. Ementário, Protocolo e Repositório não têm mais páginas ou diálogos standalone: seus links antigos redirecionam ao Gabinete. O Ementário segue integrado ao Gerador e ao painel do Desembargador em `/cm`. `/gabinete` continua aceito como entrada padrão/compatível da Pauta. A Triagem fica exclusivamente em `/tria`; `/triagem`, `/filter` e `/controle-de-triagem` normalizam para `/tria`. Não juntar Triagem e Sessões nem recriar a antiga aba Sessões na Triagem. Não deve haver acesso à aba Triagem no menu esquerdo do Gabinete. O servidor mantém `/serv-user`, conteúdo e cabeçalho próprios e agora recebe o rodapé central padrão; `/servidor` é alias para `/serv-user`. Após login sem destino explícito, abra o Gabinete, não o perfil do servidor. `/cm` permanece exclusiva do desembargador.

**Why:** o usuário pediu URLs próprias para as telas principais, mas depois decidiu que sessões/marcos devem ficar somente em Configurações Globais, sem página independente; as antigas páginas de apoio também foram retiradas, mantendo o Ementário embutido.

**How to apply:** preserve `/gabinete`, `/pauta`, `/mono`, `/tria` e `/serv-user` dentro do frame autenticado; redirecione `/session` e `/sessions` ao Gabinete e mantenha a configuração de sessões em Configurações Globais. Faça rotas antigas de apoio voltarem ao Gabinete; não remova a integração embutida do Ementário no Gerador ou em `/cm`. Carregue a Triagem somente em `/tria`, sem hooks de Sessões, Calendário ou Prontuário. Preserve `/cm` e o alias `/servidor` para `/serv-user`. Teste entrada direta, navegação cruzada e recarga.

Sincronize a URL do shell também pelo evento confiável `cmt:page` do iframe: mapeie a Pauta de Julgamento e o Controle de Monocráticas para `/pauta` e `/mono` e ignore a página Configurações, que é um diálogo sobreposto.

**Why:** o roteador interno envia o nome da página mesmo quando o evento de rota não altera o caminho; ignorar esse sinal deixava a URL do navegador desatualizada.

**How to apply:** aceite somente mensagens da origem e iframe esperados, compare o caminho atual antes de navegar para evitar entradas repetidas no histórico e preserve a URL subjacente enquanto Configurações estiver aberta.

Pauta de Julgamento, Controle de Monocráticas e Campo do Servidor continuam no mesmo frame: barras laterais compartilhadas, centro e cabeçalho próprios por tela e rodapé padrão com identidade própria por página, inclusive Campo do Servidor.

**Why:** o usuário escolheu reorganizar o frame atual, em vez de criar frames separados; em 2026-11-07 pediu aplicar o rodapé padrão também ao Campo do Servidor, substituindo a regra anterior de ocultá-lo.

**How to apply:** preserve os nós, eventos e rascunhos ao navegar. Não desmonte o enquadramento entre essas três telas: restaurar temporariamente a rolagem global introduz uma barra de rolagem e desloca a largura medida. Libere os estilos apenas para módulos com layout próprio, como Configurações e Gerador. Meça somente o rodapé ativo, nunca o contêiner que também abriga painéis flutuantes.

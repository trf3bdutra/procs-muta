---
name: Pendências: conflito após reabertura
description: Falha observada entre navegadores ao reabrir uma pendência recém-concluída.
---

Em uma validação real com dois navegadores, criação, edição, troca de etapa, comentário e conclusão sincronizaram e geraram avisos distintos. Em um fluxo adicional, reabrir uma pendência já concluída deixou a outra sessão em conflito nos campos de conclusão e ela não recebeu o aviso da reabertura.

**Why:** Esse conflito apareceu somente na sequência de conclusão e reabertura, não no fluxo comum de conclusão única, então testes básicos de sincronização não o detectam.

**How to apply:** Até corrigir o caso, incluir reabertura de pendências concluídas em testes de colaboração; confirmar que a outra sessão recebe o estado e o aviso sem duplicar atividades ou entrar em conflito. O acesso a testar é a caixa Pendências do painel expansível do rodapé, não o diálogo antigo nem a navegação lateral.

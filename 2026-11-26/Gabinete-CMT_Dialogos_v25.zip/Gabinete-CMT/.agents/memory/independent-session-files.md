---
name: Listagens offline de sessões
description: Intenção e limites da troca manual entre o HTML independente e o GabCMT.
---

O HTML independente de Sessões deve permitir preparar listagens e transferi-las manualmente ao app pelo contrato nativo de sessão, não por substituição do backup inteiro do Gabinete.

**Why:** o usuário quer montar as listagens fora do app e depois importá-las, mantendo os campos compartilhados com a Pauta e os marcos.

**How to apply:** preserve a distinção entre backup local e exportação de uma sessão. Não conecte o arquivo diretamente ao banco, não acrescente credenciais e não transforme a mesclagem em exclusão de processos ou substituição de equipe/calendário sem consentimento explícito.

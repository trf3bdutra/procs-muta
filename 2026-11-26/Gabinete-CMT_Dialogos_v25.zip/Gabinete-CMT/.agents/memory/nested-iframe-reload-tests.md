---
name: Nested iframe reload tests
description: Browser test lifecycle considerations when reloading apps that contain nested same-origin iframes.
---

After a full page reload, nested iframe contexts and their transient UI state may be recreated asynchronously. A successful state assertion immediately after reload does not mean later test steps can safely use the prior frame setup.

**Why:** Continuing UI checks after the reload in a long browser test encountered missing/recreated nested-frame state even though automatic data restoration had succeeded.

**How to apply:** Put full-reload checks at the end of a multi-behavior browser test, or wait for the new frame tree and reacquire its references before continuing.

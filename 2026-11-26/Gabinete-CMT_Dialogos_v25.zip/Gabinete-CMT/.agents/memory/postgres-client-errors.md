---
name: Resiliência a reinícios do PostgreSQL
description: Como manter a API disponível quando uma conexão PostgreSQL é encerrada durante manutenção.
---

Uma reinicialização administrativa do PostgreSQL pode encerrar conexões ativas ou ociosas com SQLSTATE `57P01`. O evento de erro do cliente `pg` precisa ser tratado; caso contrário, o EventEmitter pode encerrar todo o processo da API mesmo que as consultas de autenticação tenham funcionado momentos antes. Registre o erro sem dados de conexão e permita que as requisições afetadas falhem de forma explícita enquanto o pool descarta e substitui conexões.

**Why:** no ambiente de desenvolvimento, o banco encerrou uma conexão durante o uso e a API saiu por um evento `error` sem listener. O cadastro de contas continuava no banco; a indisponibilidade do endpoint de login era consequência da queda do processo.

**How to apply:** em qualquer serviço que use `pg.Pool`, trate erros tanto de clientes conectados quanto de clientes ociosos no pool. Não interprete um erro transitório `57P01` como ausência de contas nem recrie ou apague os dados.

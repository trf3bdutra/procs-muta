---
name: Padrão da Equipe nas Configurações
description: Escopo definido pelo usuário para a área unificada de equipe e designações e seu padrão visual.
---

Equipe e Designações devem formar uma única área nas Configurações Globais. O modelo de “Designações e atribuições” fornecido pelo usuário substitui os padrões visuais anteriores; não deve ser acrescentado como mais uma versão sobreposta.

**Why:** o usuário pediu explicitamente a unificação e a substituição dos padrões anteriores, após problemas recorrentes de versões e estilos sobrepostos.

**How to apply:** preservar os cadastros, vínculos, metas, ausências e ações reais ao adaptar o modelo. Manter a apresentação em módulos e estilos externos ao `gabcmt.html`, conforme o pedido de não fixar o padrão visual dentro desse HTML.

---
name: Protected runtime assets
description: Deployment/build behavior for authenticated JavaScript and CSS assets stored under the API protected directory.
---

Any authenticated route that reads a file from `src/protected` must have that file explicitly copied into the API's `dist/protected` during the build. The route may work from source but return 503 after a compiled build if the copy step is missing.

**Why:** the API build clears `dist` and copies only selected protected assets; a new workspace script was missing from the output and failed at runtime.

**How to apply:** when adding a protected runtime asset, update the build copy list and add a test that guards the source-to-output mapping.

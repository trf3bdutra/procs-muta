---
name: Organização dos painéis da Pauta e do Acompanhamento
description: Posição do Prontuário e acessos a Pendências, Urgências e Acompanhamento.
---

Meu dia fica na base do painel lateral esquerdo, com um pequeno painel de Entregas do dia imediatamente abaixo. Meu dia usa a identidade autenticada; Entregas do dia reúne as entregas gerais de todos os servidores naquele dia. Ambos saíram do painel expansível do rodapé.

Notificações e Calendário ficam no painel expansível/minimizável na parte inferior da barra esquerda, imediatamente acima de Meu dia. Os tópicos de Avisos são expansíveis, sem o seletor Por tipo/Tudo. Pendências não é mais outra aba desse painel: tem um único painel próprio, que expande para cima a partir do rodapé central, com a base conectada ao topo do rodapé. Nas páginas sem rodapé central, Pendências não precisa aparecer. Não recriar cópias no trilho direito ou em diálogos. A Ordem do Dia completa da Assessoria continua nas Configurações Globais, com sua permissão própria. Chamados ao TI ficam em Configurações Globais › Chamados. Urgências seguem na fila única do Controle de Monocráticas.

Triagem mantém seus campos próprios e inclui os campos compartilhados da Pauta, com o Prontuário lateral selecionável por processo. Sessões tem uma aba Processos filtrada pela sessão escolhida e usa o mesmo Prontuário.

Os cabeçalhos e rodapés da Pauta e do Controle de Monocráticas são individuais; suas barras laterais são compartilhadas. O Campo do Servidor também usa o rodapé padrão, conforme a revisão do usuário em 2026-11-07, incluindo acesso a Pendências. O Prontuário e o Gerador ficam no painel interno esquerdo da Pauta, sem botão de modo Mesa; “Meus”, junto de Meta, é apenas um filtro por usuário autenticado.

**Why:** o usuário separou Pendências do Centro Operacional e esclareceu que ela não precisa aparecer nas páginas sem rodapé central.

**How to apply:** mantenha o acionador de Notificações acima dos painéis diários na barra esquerda, com caixas expansíveis, feed real e Calendário. Pendências abre exclusivamente no rodapé central visível, independentemente da página. Ao fechar Notificações, retire o feed nativo do DOM para permitir a contagem de novos avisos; ao reabrir, monte-o novamente. Use os mesmos registros e preserve permissões e a estabilidade do cabeçalho.

## Prontuário compartilhado em Triagem e Sessões

Preserve os campos nativos da Triagem; associe o Prontuário compartilhado por número CNJ somente quando houver registro correspondente na Pauta. Em Sessões, filtre a lista de processos pela sessão selecionada e mantenha a seleção do mesmo processo no Prontuário e no Gerador. Reutilize os nós e APIs compartilhados, sem duplicar formulários ou alterar campos exclusivos.

**Why:** o usuário pediu integrar os campos compartilhados e o Prontuário à lista da Triagem e adicionar o painel lateral de Prontuário com Gerador à página de Sessões.

**How to apply:** mantenha os componentes nativos dessas páginas e use o foco comum do Prontuário para os campos compartilhados e o Gerador. Não invente dados para itens sem correspondência CNJ.

## Rodapé e moldura comum

O acionador acima de Meu dia abre Notificações e Calendário. Pendências é um painel separado no rodapé central das páginas que o possuem. Meu dia e Entregas gerais continuam abaixo do acionador lateral, sem sobrepor a navegação. No modo recolhido, preserve indicadores compactos dentro da largura da barra.

**Why:** o usuário manteve Notificações e Calendário na esquerda, mas pediu Pendências expandindo para cima no rodapé e dispensou sua exibição onde não há rodapé.

**How to apply:** mantenha um único acionador de Notificações na base da barra esquerda e um acionador de Pendências no rodapé central visível. Preserve os filtros de Pendências e a fonte real do feed/calendário; não recrie a lista de processos nem perca o foco do Prontuário.

Painéis interativos montados dentro da moldura compartilhada devem conservar o mesmo nó quando o rodapé é atualizado; não basta preservar os botões.

**Why:** a atualização agendada ao fechar Notificações substituía o contêiner do rodapé e descartava o quadro de Pendências que acabava de abrir.

**How to apply:** ao acrescentar um painel compartilhado, estabeleça quem é dono do seu ciclo de vida e preserve o nó nas reconstruções dessa moldura. Verifique a troca entre painéis e as atualizações de dados, não apenas abrir a partir do estado fechado.

## Acesso único às Configurações Globais

No lugar do antigo botão Pendências no trilho direito fica o único botão que abre o diálogo Configurações Globais (`#v2-rr-mintag`), dentro da faixa ADM e visível só para a Administração.

**Why:** o usuário pediu essa posição e um único botão ativador do diálogo.

**How to apply:** suprimir os acionadores genéricos duplicados, mantendo os acessos contextuais internos e a checagem de permissão existente. Não restaurar o botão de Configurações sob a marca nem na navegação esquerda.

## Cabeçalho e processo em pauta

Não restaurar a faixa inferior de botões do cabeçalho nem seu display “Em foco”. O buscador rápido no rodapé indica o item/processo em pauta, continuando editável. Os marcos da sessão integram o cabeçalho de forma estável, com quebras responsivas, sem compressão contínua ou corte das datas. A segunda faixa fica fixa e não muda de posição por causa da abertura ou ocultação do Prontuário.

**Why:** o usuário pediu retirar o display e todos os botões daquela faixa e usar o buscador do rodapé como indicador.

**How to apply:** atualizar o valor automático somente sem sobrescrever uma busca digitada; preservar a seleção compartilhada e os eventos de navegação existentes.

## Indicadores e linha cronológica da sessão

O cabeçalho da Pauta de Julgamento reúne três pills/displays: pautados, julgados, adiados e retirados; minutados, corrigidos e liberados; alertas e intercorrências dos processos daquela sessão. Ao expandir, devem aparecer os números dos itens referenciados, não apenas as quantidades. A referência visual é a pill compacta com rótulo e resumo enviada pelo usuário.

**Why:** o usuário pediu esses três grupos no cabeçalho e uma linha cronológica mais visual e interativa, sem inconsistências.

**How to apply:** os totais representam a lista oficial inteira da sessão selecionada, não a busca, os filtros ou a paginação. Preservar as regras de julgamento e os dados históricos da sessão. Diferenciar data passada de tarefa concluída: a passagem de um prazo não comprova que a minuta ou a liberação foi feita. As interações de detalhe não devem escrever datas nem reinventar os filtros existentes.

## Exportações da Pauta

Não exibir o botão de baixar Pauta simplificada no cabeçalho da Pauta de Julgamento. O Excel de designações fica na faixa Baixar, no topo do trilho direito, somente nessa página; a faixa também carrega o Acervo de monocráticas em Excel, visível só no Controle de Monocráticas.

**Why:** o usuário pediu remover o primeiro botão e mover o segundo para essa posição.

**How to apply:** preservar a exportação nativa para o servidor selecionado e suas verificações; usar os números reais dos itens da sessão nos indicadores, nunca índices da lista como numeração substituta.

## Rodapé da Pauta de Julgamento e Campo do Servidor

Na Pauta de Julgamento, não mova nem reordene os componentes existentes do cabeçalho para encaixar ações. Não existe mais seletor Pauta completa / Mesa de trabalho nem botão de modo Mesa. “Meus” fica ao lado de Meta, sem deslocar ou cobrir os marcos; o Prontuário completo e o Gerador pertencem ao painel interno esquerdo. A Pauta e o Controle de Monocráticas têm cabeçalhos e rodapés próprios e barras laterais compartilhadas, com cor por página. O Campo do Servidor tem rodapé padrão, mas continua sem legendas de papel, e-mail ou endereço técnico no cabeçalho. Ementário, Protocolo e Repositório standalone continuam removidos; preserve apenas as integrações existentes.

**Why:** o usuário pediu essas posições e a retirada desses elementos do Campo do Servidor; depois esclareceu que os componentes do cabeçalho da Pauta de Julgamento nunca devem ser movidos e preferiu preservar os marcos. A Pauta de Julgamento e o Controle de Monocráticas mantêm seus próprios painéis centrais, compartilhando apenas as barras laterais. O acesso da equipe à Biblioteca deve ser preservado.

**How to apply:** dar identidade e estado próprios aos painéis da Pauta de Julgamento, do Controle de Monocráticas e do Campo do Servidor, mantendo a navegação, as barras laterais compartilhadas e um rodapé padrão ativo por vez. Manter os painéis junto ao perfil na barra esquerda e preservar as ações dos botões. O seletor de julgamento conserva uma cor por tipo, com tons discretos compatíveis com a página verde.

## Edição em lote

Os campos rápidos são preparados antes da confirmação; não gravam apenas ao escolher uma opção. Aplicar alterações reúne campos rápidos e adicionais na mesma validação, preserva sessões encerradas e ignora campos vazios. Marcar ou desmarcar outros processos não deve apagar o formulário em preparação.

**Why:** a refatoração funcional deve evitar alterações acidentais durante o preenchimento e perda de trabalho ao ajustar a seleção.

**How to apply:** reutilizar as regras nativas de validação, histórico e salvamento; limpar um valor exige ação explícita, nunca um seletor deixado em branco.

## Estabilidade das faixas do cabeçalho

A distribuição dos marcos pertence a uma única regra de CSS responsivo ao espaço do próprio cabeçalho, não a timers que escrevem colunas inline a partir da largura da janela. Atualizações com os mesmos dados devem ser idempotentes no DOM.

**Why:** dois redimensionadores legados usavam limites diferentes e alternavam a grade continuamente. Escrever atributos já iguais também realimenta os observadores do documento.

**How to apply:** retirar os escritores antigos na montagem do documento, preservando seus dados e a troca de sessão. Manter os marcos compactos, com ícone ao lado de rótulo/data; em espaço estreito, permitir rolagem horizontal em vez de empilhar uma faixa alta sobre o Prontuário. Verificar a grade com os dois módulos antigos em execução e medir mutações em atualizações sem mudanças.

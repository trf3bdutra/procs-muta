---
name: Biblioteca dos Geradores
description: Fontes do Ementário, catálogo do app, edição da Assessoria e personalizações compartilhadas do CM.
---

Modelos, parágrafos e diretrizes do Padrão Muta pertencem aos Geradores, não às Configurações Globais. O Ementário não é uma página standalone: permanece integrado à aba nativa Jurisprudência do Gerador e ao painel `/cm`, com as subabas Precedentes e Modelos, sem recriar busca ou cartões. O Gerador também mantém correspondências e julgados similares ao processo atual. Somente a Assessoria edita o acervo interno do Padrão Muta; o catálogo de personalizações do Ementário é separado e tem edição exclusiva do Desembargador.

**Why:** o usuário pediu remover a página e o diálogo standalone do Ementário, mas manter o conteúdo integrado à interface já existente do Gerador e do painel `/cm`.

**How to apply:** compartilhar o componente e o estado do catálogo entre Gerador e `/cm`, sem duplicar busca, filtros ou cartões nem restaurar rota/dialog standalone. Verificar no servidor a permissão para escrita compartilhada; alterações da pauta não devem apagar a biblioteca nem conceder vínculo de Assessoria.

O usuário decidiu manter público `brndutra/trf3-muta-jurisprudencia`, substituindo a decisão anterior de torná-lo privado. Ele é a fonte de jurisprudência, modelos e seus parágrafos nos Geradores e no apoio direito. O Padrão Muta permanece interno, explicitamente separado; não publicar suas diretrizes no GitHub público.

**Why:** após a tentativa bloqueada de mudar a visibilidade, o usuário disse “mantenha público mesmo”. Isso não autoriza divulgar diretrizes internas.

**How to apply:** manter o acervo público somente leitura pelo backend e identificar as diretrizes internas na interface. Essa decisão é específica dos Geradores: o Acervo de processos continua PostgreSQL próprio do app.

## Personalizações do Ementário pelo Desembargador

O Desembargador pode editar modelos e parágrafos canônicos e criar modelos e trechos no painel de controle do Ementário em `/cm`. As personalizações são armazenadas separadamente no banco do app, combinadas com o catálogo canônico no Gerador e disponibilizadas a toda a equipe. Nunca gravar essas alterações no GitHub nem na biblioteca do Padrão Muta, cuja edição continua sendo da Assessoria.

**Why:** o usuário pediu um painel de controle do Ementário na página `/cm` e confirmou que toda a equipe deve usar os modelos e trechos editados no Gerador.

**How to apply:** autorizar escrita somente para a sessão CM verificada; manter leitura autenticada para a equipe; mesclar ajustes e registros novos nos mesmos métodos de modelos e parágrafos usados pelo Gerador; manter controle de revisão para evitar sobrescrita concorrente.

Não exibir aos usuários avisos técnicos sobre GitHub, repositório, branch, leitura exclusiva ou versões embutidas dos Geradores.

**Why:** o usuário pediu ocultar o aviso “Fonte pública, somente leitura” e informações semelhantes na versão publicada.

**How to apply:** manter atualização e mensagens úteis de falha, a atribuição jurídica e a identificação dos parágrafos pessoais. Ocultar a apresentação técnica não altera fontes, permissões ou sincronização.

Modelos, parágrafos e diretrizes do Padrão Muta devem ser consultados juntos na mesma aba de apoio à redação. Na pesquisa do Ementário, tipo de pronunciamento, classe processual e tipo de julgamento são classificações distintas.

**Why:** o usuário pediu escolher modelos e parágrafos junto das diretrizes, com filtros explícitos para essas três dimensões. A classe de uma apelação não revela sozinha se o julgado é ED, agravo interno ou primeiro julgamento.

**How to apply:** preservar a consulta conjunta e a origem pública/interna de cada seção. Mostrar “Não informado” quando a fonte não permitir identificar o tipo de julgamento com segurança; não classificar automaticamente todo o restante como primeiro julgamento.

Os parágrafos pessoais que já existiam no navegador não devem ser apagados nem publicados silenciosamente.

**Why:** publicar esses dados automaticamente confundiria rascunhos pessoais com o acervo oficial e poderia sobrescrever conteúdo já compartilhado.

**How to apply:** manter os pessoais identificados como locais, sem publicação automática. Qualquer envio ao repositório público exige autorização explícita de divulgação; não exibir um botão que grave apenas numa fonte local ignorada pelo catálogo oficial.

Verifique o tipo MIME, não apenas o HTTP 200, ao entregar módulos do Gabinete.

**Why:** o endereço de um arquivo estático ausente pode devolver o HTML inicial com HTTP 200, deixando o módulo silenciosamente indisponível.

**How to apply:** recursos usados pelo HTML protegido precisam entrar no pacote publicado; confirme que os endereços devolvem JavaScript/CSS de fato.

## Superfícies do Ementário

O Ementário autônomo é um diálogo, não uma página que substitui o conteúdo do Gabinete. Gerador e `/cm` continuam com consultas embutidas independentes, compartilhando o catálogo e as personalizações do CM.

**Why:** o usuário pediu que as três superfícies reutilizem o mesmo núcleo sem transportar um único painel entre elas nem alterar a página por trás do diálogo.

**How to apply:** preserve a separação de filtros, seleção e DOM de cada superfície; compartilhe dados e requisições, não a instância visual. Abrir o diálogo não deve trocar o item ativo da navegação.

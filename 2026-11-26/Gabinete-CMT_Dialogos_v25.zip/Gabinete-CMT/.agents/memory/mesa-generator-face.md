---
name: Gerador na Mesa
description: Gerador expansível do Prontuário no painel interno esquerdo da Pauta, sem modo Mesa nem acionador próprio no rodapé.
---

O Gerador expande a partir do Prontuário compartilhado na Pauta, na Triagem e em Sessões, sem modo Mesa, aba separada ou acionador no rodapé. Usa o mesmo processo selecionado e preserva campos, seleção e rascunhos. Em Sessões, a seleção vem da lista filtrada pela sessão atual; na Triagem, vem da lista própria e só se liga a um registro da Pauta por número CNJ correspondente.

**Why:** the user requested the shared Prontuário fields and panel in Triagem and the same panel with Gerador in Sessions, keeping a single selected-process context.

**How to apply:** Keep Generator-only navigation and routes retired; enable it only when a selected process is loaded in the Prontuário, validate direct open requests against that process, and retain selected-process and draft state. Reuse the shared nodes and embed the Ementário when opened from the Generator.

O Gerador de Acórdão não deve ter uma aba própria de Jurisprudência. O apoio contextual à redação usa o catálogo integrado; não restaurar a página ou o diálogo standalone do Ementário.

**Why:** o usuário pediu para remover a aba Jurisprudência do Gerador dentro da Pauta de Julgamento.

**How to apply:** preserve o Ementário e as fontes dos modelos e correspondências, sem restaurar a aba de consulta geral no editor.

## HTML independente no mesmo Gabinete

A Mesa de trabalho tem estrutura HTML própria, servida por rota autenticada e montada no mesmo DOM do Gabinete, sem iframe. O módulo reúne slots para a lista existente de processos e para a raiz do Gerador; ambos continuam usando as APIs, estado e eventos globais do app.

**Why:** o usuário escolheu um módulo interno para separar o HTML sem criar uma ponte de sincronização entre janelas.

**How to apply:** mova os nós existentes para os slots, sem duplicar lista ou rascunho; preserve o shell e a seleção compartilhada. Mantenha `display: contents` nos wrappers para não alterar a geometria atual.

## Seleção especial Em foco

“Em foco” é uma seleção única de trabalho, não uma aba nem um filtro. O controle de foco dedicado na linha de Processos em Mesa define o processo; o Prontuário apenas o reflete, sem seletor próprio, e mantém o Gerador no mesmo processo. Esse controle é separado do checkbox de ações em lote.

**Why:** o usuário esclareceu que “Em foco” é um tipo especial de seleção compartilhada, não uma aba ou o mecanismo de seleção em lote, e pediu para excluir o seletor do Prontuário para que ele só reflita o foco da Mesa.

**How to apply:** mantenha a seleção de trabalho separada de `selected`; o controle dedicado da linha atualiza destaque, identificação somente de leitura no Prontuário e processo do Gerador, sem alterar checkboxes de lote ou filtros.


O Gerador é um painel expansível do Prontuário, que preenche a região interna da Pauta entre cabeçalho, rodapé e a barra direita; “Recolher” fica na barra do próprio Gerador. O Prontuário inteiro, incluindo seu Gerador, pertence ao painel interno esquerdo ampliado. As abas antigas e o botão de modo Mesa foram excluídos. “Meus”, ao lado de Meta, somente filtra os processos vinculados ao usuário.

**Why:** o usuário pediu transferir todo o Prontuário e o Gerador para a moldura lateral ampliada, excluir o modo Mesa e adicionar um filtro “Meus” independente.

**How to apply:** não recrie abas ou botões de Prontuário/Gerador no rodapé, nem as abas “Pauta completa” e “Mesa de trabalho”.

## Coluna inteira do Prontuário

O Prontuário preenche a altura disponível no painel interno esquerdo, abaixo dos filtros e até o rodapé, com seus controles dentro do painel. Sem processo em foco, fica aberto com estado vazio e sem escolher um processo automaticamente. Não deve parecer uma faixa inferior, ter ações flutuando fora dele ou depender de um botão de modo Mesa.

**Why:** o usuário relatou que apenas a faixa de ações aparecia embaixo enquanto a coluna permanecia vazia.

**How to apply:** não derive a altura do Prontuário do final do cartão de filtros/processos, que pode se estender até o fim da lista. Mantenha a geometria limitada pelas faixas de cabeçalho e pelo rodapé visíveis; valide também com zoom reduzido.

## Cabeçalho do Prontuário

O número do processo fica no cabeçalho do Prontuário e permanece visível durante a rolagem do conteúdo. Nesse cabeçalho não deve haver o texto “Em foco”, o botão de recolher nem o ícone de expandir o formulário. Não restaurar o botão “Abrir o cartão na lista”.

**Why:** o usuário pediu mover a numeração para o cabeçalho e fixá-lo durante a rolagem, removendo esses textos e controles.

**How to apply:** manter a identificação somente de leitura, vinculada à seleção compartilhada, sem duplicá-la no corpo ou alterar o foco do Gerador.

---
name: DataJud no servidor
description: Onde mora a integração com o DataJud (CNJ) e as notificações automáticas, e o que não quebrar.
---

A linha de base do DataJud, a comparação entre leituras, as regras de aviso (códigos da TPU) e os envios ficam na API (`lib/datajud.ts`, `lib/datajud-servico.ts`, `routes/datajud.ts`), no PostgreSQL. A Central de Comando (`command.html`) só exibe e configura quando `CMT.on`.

**Por quê:** o gabinete precisa de uma só linha de base e de avisos que saiam mesmo com a Central fechada; o Acervo também é o cadastro oficial, e leituras do CNJ não podem introduzir processos fora das importações.

**Como aplicar:**
- `routes/datajud.ts` deve continuar montado antes de `lib/padrao.ts` (a rota antiga `POST /datajud/:tribunal` capturaria `/datajud/consulta`).
- A consulta de processos lê o Acervo como cadastro oficial; o DataJud só atualiza CNJs já cadastrados, nunca cria nem remove processos. Seus documentos e movimentos ficam no bloco importado `datajud`; dados PJe/BI e `operacional` são preservados.
- A regra da petição intercorrente lê a designação por sessão em `_pautaEntries[].work.SERVIDOR` (depois `SERVIDOR` do card). Se a pauta mudar esse formato, ajuste `indicePauta`.
- Atos de Secretaria (remessa, recebimento, certidão, expedição, publicação, decurso) ficam silenciados por padrão: o gabinete não certifica nem dá seguimento.
- Mudou uma regra? Mantenha `lib/datajud.ts` e o bloco V42 do `command.html` (modo autônomo) em sintonia.
- Não troque o aviso ao vivo por consultas periódicas da Central: o servidor publica um resumo (NOTIFY, até 8 000 bytes) e o navegador busca só o delta (`/datajud/estado?desde=`). A leitura leve depende de o CNJ manter `@timestamp` como data de carga; a completa diária corrige qualquer falha da leve.

## Precedência do Acervo

PJe é a fonte prioritária para tarefa, etiquetas, partes, advogados e campos descritivos sem dono específico. BI prevalece nos códigos de classe/assunto, conclusão, sobrestamento, seção julgadora e data de distribuição; nos campos sem dono, completa lacunas, mas não substitui o PJe. DataJud preenche campos vazios, registra divergências e só troca movimentação quando a data recebida é posterior. Indicadores agregados e dados da Central permanecem separados dos campos importados; nenhuma importação substitui `operacional`.

**Por quê:** PJe, BI e DataJud têm escopos e confiabilidades diferentes; tratar o último arquivo recebido como autoridade pode apagar valores mais confiáveis ou as decisões da equipe.

**Como aplicar:** qualquer nova fonte ou campo precisa declarar sua precedência e manter origem, data e divergências; não fazer mesclagem geral por espalhamento de objetos.

## Triagem recursal

A bancada de triagem usa os movimentos do DataJud apenas como sinais para revisão humana. A consulta é somente leitura: não deve gravar no Acervo, alterar cards ou concluir tempestividade, preparo, representação ou admissibilidade. Mantenha a consulta independente da rota avulsa que atualiza o Acervo.

**Por quê:** movimentos públicos podem estar incompletos ou não refletir todos os elementos jurídicos; a bancada aponta evidências, não decide a situação processual.

**Como aplicar:** preserve o JSON de origem para conferência, classifique separadamente ausência de registro e falha técnica, e não use os rótulos das regras como transições ou decisões do processo.

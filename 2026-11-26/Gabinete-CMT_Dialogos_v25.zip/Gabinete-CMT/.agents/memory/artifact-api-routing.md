---
name: Artifact API routing checks
description: Distinguish Replit path-routed API requests from direct web dev-server requests.
---

For this app, keep the `api` service mounted at `/api` alongside the web service, and keep production rewrites for both `/cmt` and `/padrao` to `/index.html`. If the API service is removed, Vite may answer API requests with HTML; if `/padrao` has no rewrite, a direct production visit can fall back to the wrong page.

**Why:** Removing the API service made `/api/pauta` return the web page instead of the shared snapshot. Separately, preview history-fallback handled `/padrao` while static production did not, so the published deep link opened the wrong screen.

**How to apply:** Verify `/api/pauta` through the routed app preview and check for JSON containing `revision` and `state.rows`. Keep the production SPA rewrite for `/padrao` and confirm direct `/padrao` opens the generator, not the root dashboard.

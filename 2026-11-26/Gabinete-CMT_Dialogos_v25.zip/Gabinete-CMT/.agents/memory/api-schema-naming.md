---
name: API schema naming with Orval and Zod
description: Avoid duplicate generated exports when OpenAPI component names overlap with operation request and response types.
---

Give reusable OpenAPI component schemas domain-specific names rather than names that match operation-generated request or response types. For example, `GabnetInventoryUpdate` and `GabnetInventoryResult` can back an operation whose generated types are `SetGabnetInventoryBody` and `SetGabnetInventoryResponse`.

**Why:** Codegen emits operation request/response aliases and component-schema exports separately; identical exported names conflict when the generated modules are re-exported together.

**How to apply:** When adding OpenAPI routes, check both operation IDs and component schema names, then run codegen and the generated-library typecheck before wiring route handlers.

Anonymous form bodies with `additionalProperties` can also generate duplicate operation-body exports. Give form-map payloads an explicit, distinct component schema and reference it; do not work around the collision by editing generated files.

**Why:** Orval can emit the same anonymous request-body name in both the Zod operations module and the generated type barrel.

---
name: Clearing case data across frames
description: Why clearing the active case must also clear the temporary storage map shared by the embedded Padrão frames.
---

When clearing a case from the embedded Padrão, remove the active draft and clear the app's temporary `localStorage` shim before reloading the frame. The shim's `clear()` clears only its in-memory map; it does not erase persisted Pauta data or whitelisted preferences.

**Why:** the Padrão frame reload does not reload its host. The host's shared in-memory map can therefore retain Ementa values and restore them after the active draft was removed.

**How to apply:** preserve this cache clear in the explicit full-case reset path. Browser tests must wait for the embedded frame's navigation to complete before checking that the Ementa fields and Pauta bridge are empty.

---
name: Safe edits in legacy HTML
description: Guardrails for small changes to the app's large embedded HTML documents.
---

Before replacing a large legacy HTML file, compare its version markers with the current project source; prefer the latest tracked project version over an older attached snapshot unless the user explicitly requests that snapshot. Anchor subsequent edits to a unique selector or script block.

**Why:** an older attached snapshot can silently discard later app features; a previous small style edit also landed in the document prologue.

**How to apply:** confirm the selected source's version markers, preserve the latest modules, and remove only the explicitly retired page or feature. After editing, confirm the opening doctype, inspect the focused diff, parse changed inline scripts, and run focused tests before rebuilding. Also parse the resulting HTML to ensure CSS-like text remains inside `<style>` elements rather than rendering as page content.

Keep app-owned integrations outside the user-edited HTML whenever possible.

**Why:** the user frequently supplies or directly edits new GabCMT versions. Those versions can restore retired embedded workspaces and navigation resets even after an earlier correction; overwriting the new document would discard the user's work.

**How to apply:** preserve the latest source document and apply required compatibility rules at the serving boundary. Verify against the current document, including repeated opening of settings tabs, instead of assuming an earlier source edit remains present. If the document is replaced during concurrent work, re-check unique anchors and reapply only the scoped patch to the latest source; never restore the whole older document.

Recovery-state tests must check CSS visibility against the actual nested template, not just the JavaScript state.

**Why:** a loading/error controller can pass state-machine tests while its retry control remains invisible because a selector assumes the wrong ancestor relationship.

**How to apply:** verify loading, error and ready states in a small rendered fixture using the real styles and wrapper hierarchy. This can be checked without changing authentication or loading shared records.

Order patch hunks by their actual position in the current document, not by the apparent chronology of embedded modules.

**Why:** the patch tool searches forward from the previous hunk. A newer module can occur before an older module, so otherwise valid contexts fail when applied in assumed version order.

**How to apply:** locate unique anchors first; order distant hunks by current positions or apply independent sections separately.

Use the real final body closing tag when injecting resources; earlier `</body>` occurrences may be print templates inside JavaScript strings. Parse every executable inline script in the resulting document.

**Why:** inserting an external script before the first body closing tag terminated an enclosing script inside a print template and prevented application initialization, despite the modified form script passing its isolated check.

**How to apply:** inspect the complete transformed document, skip JSON/binary script payloads, and validate all executable scripts rather than only the edited module.

When moving a native control, preserve its node and reconcile its creator, delegated click selector and active-state lookup with the new container.

**Why:** periodic native reconciliation can recreate a moved launcher in its old container, while delegated clicks or selection styling still recognize only the previous location.

**How to apply:** update ownership and event recognition together; do not clone controls or tie their availability to an unrelated neighboring button's permissions.

Repeated layout reconciliation must be a true DOM no-op once placement is correct, not a temporary move followed by moving the node back.

**Why:** periodic profile placement can look correct after each pass while still reparenting twice per pass, causing flicker and triggering other observers.

**How to apply:** test settled refreshes with a child-list MutationObserver and use all real legacy style blocks in visual fixtures; a final override alone misses older specificity conflicts.

Distinguish visible replacement toolbars from the hidden native controls they drive before relocating an input.

**Why:** a control can have nonzero bounds and computed visibility yet remain clipped by its native toolbar's accessibility-hiding rules. DOM placement assertions alone miss this.

**How to apply:** use the visible toolbar as the destination, verify clipping ancestors and a rendered screenshot, and assert highlighting against the active list renderer rather than only its hidden native counterpart.

Keep explicit application routes out of any catch-all single-segment public-profile boot guard.

**Why:** classifying an app page as a profile can hide its already-rendered content until a long fallback timer expires, even though data and scripts loaded successfully.

**How to apply:** test direct entry to every app route as well as public-profile slugs; preserve actual profile guards rather than globally removing loading protection.

For a bounded redesign overwhelmed by legacy `!important` rules, prefer a scoped named CSS layer over another escalation of repeated IDs.

**Why:** important declarations in a named layer take precedence over unlayered important declarations; escalating selectors alone repeatedly missed late nested profile rules.

**How to apply:** keep every selector within the redesigned page, explicitly reset obsolete grid placement for moved visual groups, and check both computed styles and real desktop/mobile screenshots. Preserve native interactive nodes.

For independent HTML exports, separate page behavior from the original host's frame controllers and development preview.

**Why:** an exported page can initialize and pass data tests while the host still applies sidebar placeholders and important viewport offsets, clipping the page. File URLs also enable the development preview unless it is excluded.

**How to apply:** verify the actual downloaded file under `file://`, including full-width page bounds, absence of host overlays, local JSON round-trip and persistence after reload. Keep source application authentication and production data unchanged.

Serving-boundary transforms must tolerate a legacy fragment already removed by an earlier transform.

**Why:** the composed document pipeline can retire an interval before a later compatibility pass reaches it; requiring that fragment caused the authenticated GabCMT document route to return HTTP 500.

**How to apply:** skip only the replacement whose target is absent, keep strict matching when it is present, and verify the fully composed response transform against the current document.

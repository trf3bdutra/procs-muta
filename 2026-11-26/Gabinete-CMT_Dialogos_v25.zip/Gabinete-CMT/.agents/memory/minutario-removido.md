---
name: Minutário removido
description: Decisão do usuário de remover a antiga página /padrao.
---

O usuário informou: “deletei codigo da pagina /padrão, retire as referencias a isso do codigos”.

**Why:** a página foi removida por decisão do usuário, não por perda acidental do arquivo.

**How to apply:** não restaurar `padrao.html` para satisfazer testes antigos, nem recriar links, carregadores ou integração com essa página. Menções históricas ao Minutário nesta memória não autorizam sua restauração.

---
name: Replit workflow port leftovers
description: Handling artifact workflows that fail to restart because child servers still occupy their ports.
---

When a managed artifact workflow reports `EADDRINUSE`, inspect the listening process and its process group before restarting again. A failed workflow launch can leave its Vite or API child alive and holding the injected artifact port; stop only the confirmed stale workflow process group, then restart the exact managed workflow.

**Why:** in this workspace, restarting web and API briefly spawned duplicate servers while prior child processes still held ports 20815 and 20816.

**How to apply:** use workflow logs, `lsof`/`ss`, and `ps` to identify the exact port owner; do not change artifact ports or create replacement workflows to work around stale listeners.

---
name: Confirmação de salvamento da Pauta
description: Regras para aceitar a consolidação do servidor sem perder edições feitas durante a gravação.
---

A resposta de uma gravação deve ser reconciliada usando como base o estado enviado naquela requisição, não o último estado remoto anterior ao envio. Somente mudanças locais posteriores ao envio devem continuar pendentes.

**Why:** Usar a base remota anterior reaplicava mudanças já enviadas sobre a consolidação devolvida pelo Acervo, podendo provocar ciclos de gravações bem-sucedidas sem convergência.

**How to apply:** Preserve o snapshot de cada envio e aceite integralmente a resposta quando não houver edições posteriores. Quando houver novas edições, mescle apenas essas diferenças e envie novamente.

Marcar uma gravação para depois não equivale à confirmação do servidor. A pendência visual só pode ser encerrada para a mesma versão de edição confirmada, e o controlador do compartilhamento deve continuar sendo o dono do estado de alteração pendente.

**Why:** Limpar a pendência no agendamento ou forçar o estado como limpo após uma requisição antiga pode anunciar sincronização enquanto existem mudanças mais recentes.

**How to apply:** Use uma versão crescente das edições pendentes e confira-a ao concluir a gravação. A recuperação do salvamento HTTP não deve depender de o fluxo SSE já ter reconectado.

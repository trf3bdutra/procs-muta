---
name: Pauta runtime extensions
description: Constraints for responsive process filters, productivity controls, and shared-state updates in the embedded app.
---

When custom filters hide process groups, set inline `display: none !important` and restore the prior inline display value when clearing the filter. The embedded panel's group styling can override class-only hiding.

**Why:** a class-based hide still left filtered process groups visible because the original panel set its own `display` value.

**How to apply:** for future injected filters, verify both the hidden class and computed visibility in the embedded frame, in both form and list modes.

The footer productivity panel is repainted as shared app state changes. Injected controls and rows must be idempotent; append only missing roster members once instead of recalculating every member's metrics on each repaint.

**Why:** an earlier full-roster calculation stalled the "Ver todos" interaction; the idempotent, lightweight expansion now completes promptly.

**How to apply:** guard repeated DOM additions and keep expansion work limited to the rows that are actually missing.

Keep recursive equality checks on shared snapshots unsorted: compare key counts and own-key membership instead. Coalesce document-wide mutation observers to one animation-frame repaint and disconnect them while the repaint changes the DOM.

**Why:** sorting keys repeatedly and observing a repaint's own mutations added avoidable work to a large shared docket and could create repeated full-page updates.

**How to apply:** use the same comparison behavior in browser and API merge paths, and keep injected observers idempotent and silent during their own DOM updates.

Keep notification summaries event-driven: sync after `PautaApp.renderShell`, `pauta:updated`, and successful saves. Do not observe the whole body or poll state to detect unrelated DOM changes; limit discovery to the active settings dialog.

**Why:** the global alert feature recalculated dashboard and recipient notices after unrelated page mutations, adding work across every route.

**How to apply:** use app-state lifecycle events, scope any remaining observer to `#app-modal`, and rotate the carousel only while it is visible.

## Single expanded process

Across both Pauta display modes, keep at most one process form expanded at a time. Opening another closes the previous one; do not offer an expand-all action. Footer search may open its matching process, replacing any prior open card.

**Why:** multiple detailed process forms at once clutter the docket and increase rendering work.

**How to apply:** use one expansion state for each mode, clear it before opening a different process, and enforce the same rule for direct clicks, rerenders, and programmatic navigation. Keep compact-list virtualization and on-demand batches independent.

## Compact process list

In compact list mode, initially show up to 200 filtered processes, all minimized. If more than 200 processes match, preserve on-demand batches. Keep compact-list mode out of the table virtualizer; retain virtualization for form cards.

**Why:** the user wants to scan a full session list without rendering every detailed process form at once.

**How to apply:** initialize the displayed limit to `min(200, filtered rows)` when the session or filtered row set changes; keep filtered results available for counts and bulk actions.

## Scroll responsiveness

Keep virtualized form-card scrolling separate from the dashboard render. A scroll-window update may replace visible process groups and spacer heights, but should not rebuild the statistics, filters, or page shell. Keep compact-list mode outside the table virtualizer; render the first 200 filtered rows immediately and load any later batch only on demand.

**Why:** rendering the whole dashboard for each virtual window caused freezes, while virtualizing the compact list made scroll position and later items unreliable.

**How to apply:** update the visible form-card window incrementally, preserve focused edits and scroll position, and keep the compact list's initial 200-row limit independent of the optional “Ver mais” action.

When anchoring a compact-list card expansion, retain the clicked group element; if a full render replaces it, re-find it by session row index only after validating the same process identity. Only adjust the same scroll container.

**Why:** virtualization can replace or reuse row keys between frames; a stale lookup may anchor to a different row and move the list by hundreds of pixels.

**How to apply:** capture the clicked summary's position, session row index, and process identity before expansion; cancel restoration after user scrolling and never trust the row index without identity validation.

When a pauta edit explicitly renders its card, do not also trigger a synchronous host refresh that calls the page's mount/tick path; coalesce derived refresh work and anchor the visible process row when rebuilding the list.

**Why:** host refresh can cause a second render for the same edit, and restoring only a numeric scroll offset lets the visible list jump when row heights change.

**How to apply:** keep the edited state and pending-save marker immediate, defer the global refresh, avoid re-entrant page ticks during it, and restore the same visible row when possible.

## Digitação e recalculo de layout

Keep the per-keystroke path limited to updating the edited field and its pending-save marker. Debounce full host refreshes until typing pauses, and filter broad mutation observers so process-body edits do not trigger full header measurements; run those measurements on relevant header changes or viewport resize.

**Why:** refreshing all process-derived state and measuring every card after each character made edits, button actions, and sidebar changes feel delayed.

**How to apply:** preserve the immediate local field value and pending status, keep persistence semantics unchanged, and defer only derived/global refresh work.

The Pauta Prontuário and its Gerador must stay responsive without continuous polling or observers across every process row. Reconcile layout from application events and direct replacements of the Pauta root only; preserve the real editor nodes and drafts.

**Why:** the user asked that using the integrated Prontuário not add load or freeze the application.

**How to apply:** keep observers shallow and idempotent, coalesce events into one animation frame, and avoid repeated full-list scans when nothing relevant changed.

## Seleção e navegação do Prontuário

Na Pauta, o Prontuário fica sempre aberto na coluna fixa de trabalho, sem controle de recolhimento. O estado vazio/carregando mantém a moldura visível sem selecionar o primeiro processo. Trocar o processo atualiza a ficha e o Gerador pelo fluxo existente.

**Why:** o usuário pediu que o painel nunca desapareça por clique, foco do processo ou ordem de carregamento.

**How to apply:** mantenha a seleção orientada a eventos e o próximo processo pela lista filtrada; em Triagem/Sessões, preserve a apresentação contextual já existente. Não reintroduza polling nem varreduras amplas.

## Busca e ordem da listagem

Use a ordem da relação oficial da sessão como ordenação principal dos processos, para que editar o número do item não mova o cartão. Reaproveite o resultado filtrado entre facetas dentro do mesmo estado de busca e invalide os caches após alterações locais ou sincronização externa.

**Why:** a renderização recalculava o mesmo conjunto de processos para cada faceta; além da lentidão, ordenar primeiro pelo item fazia o cartão saltar durante o preenchimento.

**How to apply:** mantenha a origem da pauta como ordem estável, use comparações diretas de dígitos para buscas de CNJ/item quando cabível, e limite as reconstruções completas às mudanças de busca, filtro ou dados.

## Busca rápida de item/processo

A busca rápida por item ou processo deve ficar dentro da barra principal `.pq-search-main`, não no rodapé nem ao lado do título. Como a renderização da Pauta recria essa barra, mantenha o mesmo controle e reposicione-o após a substituição do conteúdo.

**Why:** o usuário quer uma busca única e compacta, e perder o campo após cada render torna a navegação instável.

**How to apply:** conserve um único nó de busca, observe apenas a raiz da Pauta para reanexá-lo quando a barra for recriada e mantenha a busca nativa e a navegação rápida sem controles duplicados.

Filters belong to the selected pauta: switching sessions must not apply one session's search, tags, or quick filters to another. Keep each session's filter state isolated and show any wait indicator only over the process list.

**Why:** the user needs to compare session lists without stale filters hiding unrelated processes or making the whole Gabinete appear blocked.

**How to apply:** save and restore filter state by session key; scope loading UI to the process-list region and clear it on both success and failure.

## Lista legada como apoio invisível

Enquanto o Prontuário depender da tabela legada, preserve-a como estrutura de apoio invisível, não como apresentação provisória. A lista atual deve ficar pronta no ciclo da montagem da página; a exibição não pode depender de uma checagem periódica.

**Why:** a tabela antiga aparecia antes da lista atual e parecia uma troca de versão. Removê-la diretamente, porém, poderia romper a seleção e a edição do Prontuário.

**How to apply:** mantenha a proteção de primeira pintura, publique a lista somente após sua montagem completa e ofereça recuperação local explícita quando houver falha. Só elimine a tabela de apoio depois de desacoplar seus consumidores.

A montagem da lista não deve exigir que seu contêiner já esteja visível; só as medições de geometria devem esperar a exibição.

**Why:** a inicialização mantém áreas ocultas até os dados ficarem prontos. Exigir visibilidade para montar, depois de remover a checagem periódica, pode deixar a lista sem nenhum evento que conclua sua preparação.

**How to apply:** prepare o conteúdo assim que houver raiz e dados, observe apenas as remontagens locais necessárias e meça a altura quando houver layout disponível.

Only unsaved edits to process cards should trigger the browser's leave/reload warning. Other app areas autosave; a scheduled autosave is not a manual-save prompt, and a card's pending marker must remain until persistence succeeds.

**Why:** the user clarified that only process-card edits require explicit save confirmation.

**How to apply:** scope manual-save tracking to real edits within a process card, leave automatic persistence for other areas intact, and clear pending state only after a successful save.

## Metas diárias de minutas

Para os servidores que minutam votos, a produtividade padrão é 3 processos por dia; Estela e Victor têm padrão de 4 processos por dia. As metas diárias configuradas por servidor são fixas e não aumentam nem diminuem conforme o volume de processos ou sessões; ajuste-as em Configurações Globais › Equipe › Metas diárias e produtividade. A Ordem do Dia deve exibir as metas e as entregas do dia, separando-as da carga e dos prazos das sessões.

**Why:** o usuário definiu os valores padrão e esclareceu que a meta diária deve ser independente da quantidade de processos de sessão.

**How to apply:** use esses valores como metas-base para os servidores elegíveis a minutar voto, preserve metas individuais já preenchidas e use a meta do perfil como quota fixa; mantenha ritmo por prazo em um indicador separado.

Calendário, resumo da sessão e Ordem do Dia devem usar o mesmo agregado por servidor e data. A produção soma processos minutados em todas as sessões, contando cada CNJ uma vez, e lançamentos complementares do perfil, contando cada ID de lançamento uma vez. A meta diária permanece distinta do ritmo necessário para cumprir prazos de sessão. Metas de datas passadas ainda são recalculadas pela configuração e disponibilidade atuais; não há fotografia histórica da meta.

**Why:** somar metas por sessão inflava a quota, enquanto fontes diferentes de produção exibiam totais divergentes; o registro manual é complementar e não substitui uma entrega de processo.

**How to apply:** preserve a deduplicação por CNJ e ID, mantenha a mesma função de agregação nas três telas e deixe explícito quando uma meta histórica usa as configurações atuais; uma fotografia histórica deve ser implementada separadamente se necessária.

Em Preliminares dos recursos, o “+” deve permanecer disponível mesmo sem itens; o campo de texto só abre sob demanda, e a inclusão mantém os itens anteriores. O painel rápido deve continuar encaminhando a inclusão para esse mesmo editor.

**Why:** recolher o campo do card não pode remover o acesso rápido de inclusão nem criar duas versões de edição.

**How to apply:** preserve Enter para incluir e Escape para cancelar; ao adicionar pela prévia rápida, abra e use o editor do card em vez de manter uma edição paralela.

Devolutivas do Desembargador e apontamentos do corretor devem ficar acessíveis pelo mesmo botão em cada card e ser tratados no mesmo diálogo, mantendo as seções e ações próprias de cada origem.

**Why:** o usuário pediu reunir esses campos e abrir o conteúdo em um diálogo, em vez de ocupar a área do card.

**How to apply:** mantenha a identificação da origem, os dados e os controles existentes; ações de conclusão, resposta, prioridade, exclusão e ciência devem continuar salvas no processo e sessão corretos.

Chamados de TI e pendências da equipe não exigem vínculo com um processo; sessão e processo são referências opcionais.

**Why:** a equipe também registra solicitações gerais ou de sessão que não pertencem a um processo da pauta.

**How to apply:** mantenha chamados sem processo em estado compartilhado próprio, preserve-os ao importar/exportar o cadastro da equipe e não rejeite um número de processo apenas por ele não estar na pauta atual.

## Espaço livre da lista R3

A lista R3 ocupa a altura disponível até logo acima do rodapé fixo; quando há poucas linhas, o espaço restante continua pertencendo ao viewport da lista e deve manter a superfície visual da própria listagem, sem ser tratado como uma faixa ou painel independente.

**Why:** a altura preserva rolagem consistente quando a lista cresce; colapsá-la ao conteúdo pode deslocar o rodapé ou mudar o comportamento de rolagem entre sessões.

**How to apply:** mantenha a medição até o rodapé e use um fundo de superfície coerente com a tabela, sem alterar a geometria dos cartões nem o rodapé central.

## Barra esquerda recolhível

Os cartões “Meu dia” e “Entregas do dia” devem recalcular o estado estreito quando a largura real da barra esquerda mudar. Faça isso com `ResizeObserver` restrito à barra; não dependa de um redesenho periódico global.

**Why:** o estado `is-narrow` pode permanecer após minimizar e expandir a barra, deixando os cartões escondidos; polling para corrigir isso também aumenta o custo de interação.

**How to apply:** observe apenas `#alt-side`, altere as classes dos dois cartões somente ao cruzar o limite de largura e preserve os dados já renderizados.

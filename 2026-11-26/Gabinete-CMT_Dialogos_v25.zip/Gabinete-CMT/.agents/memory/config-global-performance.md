## Isolamento de diálogos

Os módulos de Configurações não devem substituir métodos nem o estado de navegação do controlador da página ao fundo. Extensões de renderização precisam de um hospedeiro privado, mantendo os dados e serviços compartilhados.

**Why:** atribuições de métodos por extensões legadas podem atravessar um proxy e substituir o renderizador da página principal; fechar o diálogo então deixa conteúdo de Configurações na Pauta.

**How to apply:** confira tanto leituras quanto atribuições no adaptador de visão. Retome o escopo da visão nos callbacks assíncronos de renderização, sem manter um contexto global ativo durante uma espera.
---
name: Global settings responsiveness
description: Performance constraints for the legacy Global Settings modal in Gabinete CMT.
---

Keep observers and refresh work scoped to the active settings dialog and its navigation/actions. Track elements changed by the palette adapter so closing the dialog only cleans those elements; do not scan the entire process DOM to reset it.

**Why:** The large shared docket makes document-wide mutation observers, frequent full synchronization, and repeated computed-style scans compound each other and make opening, switching, and closing settings visibly lag.

**How to apply:** When editing Global Settings in the legacy Gabinete HTML, trigger synchronization on modal state, navigation, and relevant form actions. Keep status counts event-driven or cached, and scope any visual adaptation to the active content.

Give inline scripts and UI containers distinct IDs. A script ID collision with its generated modal container makes `getElementById` return the script; modal CSS can then display the JavaScript source as page content.
